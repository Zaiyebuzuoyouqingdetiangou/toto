import * as split_heartData from './heartData.js';
import * as split_heartPrompts from './heartPrompts.js';
import * as split_heartRuntime from './heartRuntime.js';
import * as split_heartGeneration from './heartGeneration.js';
import * as core_modesBridge from '../core/modesBridge.js';
import * as generation_modesBridge from '../generation/modesBridge.js';
// 以下导出已搬到 modes/heartData.js、modes/heartPrompts.js、modes/heartRuntime.js、modes/heartGeneration.js，这里原样转发，调用方不用改。
export const normalizeHeartCore = split_heartData.normalizeHeartCore;
export const heartCorePrompt = split_heartPrompts.heartCorePrompt;
export const heartCoreLegacyPrompt = split_heartPrompts.heartCoreLegacyPrompt;
export const compactHeartDialoguesExisting = split_heartPrompts.compactHeartDialoguesExisting;
export const heartCoreIncrementPrompt = split_heartPrompts.heartCoreIncrementPrompt;
export const normalizeHeartCoreIncrement = split_heartData.normalizeHeartCoreIncrement;
export const mergeHeartCoreIncremental = split_heartData.mergeHeartCoreIncremental;
export const heartDramaContext = split_heartPrompts.heartDramaContext;
export const heartDramaRelationshipOnlyContext = split_heartPrompts.heartDramaRelationshipOnlyContext;
export const compactHeartSeasonExisting = split_heartPrompts.compactHeartSeasonExisting;
export const heartPostVoicePrompt = split_heartPrompts.heartPostVoicePrompt;
export const heartSeasonVoicePrompt = split_heartPrompts.heartSeasonVoicePrompt;
export const heartSeasonScenarioPrompt = split_heartPrompts.heartSeasonScenarioPrompt;
export const heartFireflyPrompt = split_heartPrompts.heartFireflyPrompt;
export const normalizeFireflyScript = split_heartData.normalizeFireflyScript;
export const normalizeFireflyVoice = split_heartData.normalizeFireflyVoice;
export const fireflyVoiceKey = split_heartData.fireflyVoiceKey;
export const normalizeFireflyVoicesPart = split_heartData.normalizeFireflyVoicesPart;
export const legacyFireflyVoices = split_heartData.legacyFireflyVoices;
export const heartFireflyUpgradePrompt = split_heartPrompts.heartFireflyUpgradePrompt;
export const normalizeFireflyUpgradePart = split_heartData.normalizeFireflyUpgradePart;
export const heartStripsPrompt = split_heartPrompts.heartStripsPrompt;
export const normalizeVoiceDramaPart = split_heartData.normalizeVoiceDramaPart;
export const normalizeScenarioDramaPart = split_heartData.normalizeScenarioDramaPart;
export const normalizeHeartStripsPart = split_heartData.normalizeHeartStripsPart;
export const normalizeHeartCollectionBatch = split_heartData.normalizeHeartCollectionBatch;
export const requestHeartPart = split_heartPrompts.requestHeartPart;
export const partsDialoguesReady = split_heartPrompts.partsDialoguesReady;
export const makeHeartShell = split_heartData.makeHeartShell;
export const projectHeartProgress = split_heartData.projectHeartProgress;
export const makeHeartSession = split_heartData.makeHeartSession;
export const generateHeartWithRepair = split_heartRuntime.generateHeartWithRepair;
export const heartDramaItemKey = split_heartData.heartDramaItemKey;
export const appendHeartDramaItem = split_heartData.appendHeartDramaItem;
export const heartStripKey = split_heartData.heartStripKey;
export const applyHeartPatchCoverage = split_heartData.applyHeartPatchCoverage;
export const preserveHeartSelection = split_heartData.preserveHeartSelection;
export const normalizeHeartContentPatch = split_heartData.normalizeHeartContentPatch;
export const applyHeartPartialPatch = split_heartData.applyHeartPartialPatch;
export const mergeDeferredHeartPatches = split_heartData.mergeDeferredHeartPatches;
export const applyHeartPageReplacement = split_heartRuntime.applyHeartPageReplacement;
export const regenerateHeartPage = split_heartGeneration.regenerateHeartPage;
export const captureHeartBackgroundTarget = split_heartRuntime.captureHeartBackgroundTarget;
export const persistHeartPartialPatch = split_heartRuntime.persistHeartPartialPatch;
export const generateHeartSection = split_heartGeneration.generateHeartSection;
export const generateHeartFirefliesSection = split_heartGeneration.generateHeartFirefliesSection;
export const pendingHeartDramaBatchId = split_heartRuntime.pendingHeartDramaBatchId;
export const nextHeartDramaBatchId = split_heartRuntime.nextHeartDramaBatchId;
export const heartSeasonRequestBase = split_heartPrompts.heartSeasonRequestBase;
export const generateHeartSeasonSection = split_heartGeneration.generateHeartSeasonSection;
export const normalizeHeartScript = split_heartData.normalizeHeartScript;
export const normalizeHeartPhotoshoots = split_heartData.normalizeHeartPhotoshoots;
export const normalizeHeart = split_heartData.normalizeHeart;

// 重构清单 C-3（r84.98）：把 core 层要用的函数登记到 core/modesBridge.js（core 不再 import 本文件）。
core_modesBridge.registerModesBridge({ mergeDeferredHeartPatches });

// 重构清单 C-4（r84.120）：把生成层要用的函数登记到 generation/modesBridge.js（生成层不再 import 本文件）。
generation_modesBridge.registerGenerationModesBridge({
    heartCorePrompt, heartPostVoicePrompt, heartSeasonVoicePrompt, heartSeasonScenarioPrompt, heartStripsPrompt, heartDramaRelationshipOnlyContext, requestHeartPart, normalizeVoiceDramaPart, normalizeScenarioDramaPart, normalizeFireflyVoicesPart, normalizeHeartStripsPart, normalizeHeart, makeHeartShell, generateHeartSection, generateHeartFirefliesSection, generateHeartSeasonSection, generateHeartWithRepair, projectHeartProgress,
});
