// Real runtime and Canvas pixels. Browser, storage and recording boundaries are doubles.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
import { editor, decode } from './motif-editor-fixture.mjs';
const require = createRequire(import.meta.url);
const native = require(require.resolve('@napi-rs/canvas', { paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || process.cwd()] }));
const flush = () => new Promise(resolve => setImmediate(resolve));
async function settle() { for (let i = 0; i < 8; i++) await flush(); }
function art(back = 'white', foreground = '#d02030') {
    const c = native.createCanvas(60, 80), g = c.getContext('2d');
    if (back) { g.fillStyle = back; g.fillRect(0, 0, 60, 80); }
    if (foreground) { g.fillStyle = foreground; g.fillRect(18, 20, 24, 40); }
    return c;
}
const read = c => c.getContext('2d').getImageData(0, 0, c.width, c.height);
const px = (data, x, y, w = 60) => [...data.slice((y * w + x) * 4, (y * w + x) * 4 + 4)];
async function setup(canvas = art(), imageExtra = {}) {
    const f = await ui(fixture), mv = f.get('extras/mv'), drawn = [], decodes = [], errors = [];
    const song = { id: 'SONG_motif', title: 'motif test', lyrics: '[Verse 1]\none\n[Chorus]\ntwo\n[End]' };
    const backdrop = native.createCanvas(80, 80); backdrop.getContext('2d').fillStyle = '#103040'; backdrop.getContext('2d').fillRect(0, 0, 80, 80);
    const source = canvas.toDataURL();
    const makeCanvas = () => {
        const c = native.createCanvas(540, 960), g = c.getContext('2d'), draw = g.drawImage.bind(g);
        g.drawImage = (img, ...args) => { if (img.naturalWidth === 60 || img.width === 60) drawn.push({ target: c, img }); draw(img, ...args); };
        c.style = {}; c.remove = () => {};
        const track = { canvas: c, stop() {} }; c.captureStream = () => ({ getTracks: () => [track], getVideoTracks: () => [track] });
        return c;
    };
    const preview = makeCanvas(); f.canvas.getContext = () => preview.getContext('2d');
    const create = f.sb.document.createElement; f.sb.document.createElement = tag => tag === 'canvas' ? makeCanvas() : create(tag);
    f.sb.Image = class extends native.Image { set src(value) { super.src = value; decodes.push(this.decode()); } };
    f.sb.toastr = { error: message => errors.push(message), success() {}, info() {} };
    let requests = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { requests++; throw Error('unexpected image generation'); };
    f.get('generation/client').generate = async () => { requests++; throw Error('unexpected generation'); };
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    const record = { id: song.id, version: 2, createdAt: 1, updatedAt: 1, storyRevision: 'original', duration: 120,
        settings: { output: 'tegaki', range: 'full', ratio: '9:16' }, tegaki: { introSeconds: 0, outroSeconds: 0, lyric: 'none' },
        motif: { name: '花瓣', prompt: 'red petal', image: { url: source, ...imageExtra } },
        groups: [{ id: 'G', layer: 'full', diffs: [{ id: 'D', image: { url: backdrop.toDataURL(), split: 'none' } }] }],
        shots: [{ id: 'S0', group: 'G', diff: 'D', sectionIndex: 0, lyric: 'one', cut: 'cut' },
            { id: 'S1', group: 'G', diff: 'D', sectionIndex: 1, lyric: 'two', cut: 'cut' }], timing: { taps: { 0: 0, 1: 60 } } };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    const saved = () => mv.readMv(f.host, song.id);
    const seek = t => {
        drawn.length = 0;
        f.mvui.handleMvClick({ target: { closest: () => ({ dataset: { rmtMv: 'seek' }, getBoundingClientRect: () => ({ left: 0, width: 120 }) }) }, clientX: t, preventDefault() {} });
        return drawn.filter(d => d.target === preview);
    };
    f.mvui.openMv({ songId: song.id }); f.click('go-tegaki'); seek(70); await settle(); await Promise.all(decodes); seek(70);
    const spriteData = img => { const c = native.createCanvas(60, 80); c.getContext('2d').drawImage(img, 0, 0); return read(c).data; };
    return { ...f, mv, saved, song, source, preview, seek, spriteData, drawn, decodes, errors, requests: () => requests, makeCanvas };
}

test('legacy white-background motifs are real transparent sprites in preview without touching saved art', async () => {
    const f = await setup(); try {
        const before = JSON.stringify(f.saved()); const rows = f.seek(70); assert.equal(rows.length, 7);
        const data = f.spriteData(rows[0].img); assert.equal(px(data, 0, 0)[3], 0); assert.equal(px(data, 30, 40)[3], 255);
        assert.ok(px(data, 30, 40)[0] > 190); assert.equal(JSON.stringify(f.saved()), before); assert.equal(f.requests(), 0);
        assert.equal(f.seek(20).length, 0);
    } finally { f.mvui.disposeMv(); }
});
test('opaque white or patterned motifs are not pasted as rectangular decorations', async () => {
    for (const c of [art('white', null), art('#608050')]) {
        const f = await setup(c); try {
            assert.equal(f.seek(70).length, 0); f.click('editor-tab', 'look'); assert.match(f.body.innerHTML, /处理意象背景/);
            assert.deepEqual(f.errors, []); assert.equal(f.requests(), 0);
        } finally { f.mvui.disposeMv(); }
    }
});
test('true transparent white motifs retain their original colour and semi-transparent pixels', async () => {
    const c = art(null, 'white'); c.getContext('2d').fillStyle = 'rgba(255,255,255,.4)'; c.getContext('2d').fillRect(12, 32, 3, 3);
    const original = read(c).data, f = await setup(c, { editMode: 'cutout' }); try {
        const rows = f.seek(70); assert.equal(rows.length, 7); assert.deepEqual(f.spriteData(rows[0].img), original);
    } finally { f.mvui.disposeMv(); }
});
test('white snow on the contrasting default background keeps its white foreground', async () => {
    const f = await setup(art('#0000ff', 'white')); try {
        const rows = f.seek(70); assert.equal(rows.length, 7);
        const data = f.spriteData(rows[0].img); assert.equal(px(data, 0, 0)[3], 0); assert.deepEqual(px(data, 30, 40), [255, 255, 255, 255]);
    } finally { f.mvui.disposeMv(); }
});
test('enclosed white motif details stay opaque while the outside becomes transparent', async () => {
    const c = art(); c.getContext('2d').fillStyle = 'white'; c.getContext('2d').fillRect(25, 30, 10, 10);
    const f = await setup(c); try { const data = f.spriteData(f.seek(70)[0].img); assert.equal(px(data, 0, 0)[3], 0); assert.deepEqual(px(data, 30, 35), [255, 255, 255, 255]); }
    finally { f.mvui.disposeMv(); }
});
test('motif background processing is not applied to a full-scene white character picture', async () => {
    const f = await setup(); try {
        f.mv.patchRecord(f.song.id, { shots: f.saved().shots.map(s => ({ ...s, image: { url: f.source } })), tegaki: { ...f.saved().tegaki, showMotif: false } });
        f.mvui.renderMv();
        await settle(); const rows = f.seek(70); assert.equal(rows.length, 1); assert.equal(px(f.spriteData(rows[0].img), 0, 0)[3], 255);
    } finally { f.mvui.disposeMv(); }
});
test('redrawing or importing a new motif invalidates the old prepared sprite', async () => {
    const f = await setup(); try {
        const old = f.seek(70)[0].img;
        f.mv.patchRecord(f.song.id, { motif: { ...f.saved().motif, image: { url: art('white', '#008000').toDataURL() } } });
        f.mvui.renderMv();
        f.seek(70); await settle(); await Promise.all(f.decodes); const next = f.seek(70)[0].img;
        assert.notEqual(next, old); assert.deepEqual(px(f.spriteData(next), 30, 40), [0, 128, 0, 255]);
    } finally { f.mvui.disposeMv(); }
});
test('canvas read failure skips only the motif and does not fall back to its opaque original', async () => {
    const f = await setup(art(null)); try {
        const c = art('white', '#202080'), url = c.toDataURL();
        const create = f.sb.document.createElement;
        f.sb.document.createElement = tag => {
            const el = create(tag); if (tag === 'canvas') { const g = el.getContext('2d'); g.getImageData = () => { throw Error('SecurityError'); }; } return el;
        };
        f.mv.patchRecord(f.song.id, { motif: { ...f.saved().motif, image: { url } } });
        f.mvui.renderMv();
        f.seek(70); await settle(); await Promise.all(f.decodes); assert.equal(f.seek(70).length, 0); assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});
test('preview and video export use the same transparent motif pixels', async () => {
    const f = await setup(); let exportCanvas, started = false;
    try {
        const expected = f.spriteData(f.seek(70)[0].img);
        f.mv.patchRecord(f.song.id, { exportRange: { range: 'custom', rangeFrom: 1, rangeTo: 1 } });
        f.mvui.renderMv();
        f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } }; f.sb.AudioContext = class {};
        f.sb.MediaRecorder = class { static isTypeSupported() { return true; } constructor(stream) { exportCanvas = stream.tracks[0].canvas; } start() { this.state = 'recording'; started = true; } stop() { this.state = 'inactive'; this.onstop?.(); } };
        f.drawn.length = 0; f.click('export'); await settle(); assert.equal(started, true, f.errors.join(';'));
        const rows = f.drawn.filter(d => d.target === exportCanvas); assert.equal(rows.length, 7);
        assert.equal(px(f.spriteData(rows[0].img), 0, 0)[3], 0); assert.deepEqual(f.spriteData(rows[0].img), expected);
        assert.equal(f.requests(), 0);
    } finally { f.mvui.disposeMv(); }
});
test('only the default motif recipe changes; white motifs use contrast and custom prompts remain verbatim', async () => {
    const f = await setup(); try {
        const r = structuredClone(f.saved()); r.motif.name = '雪花'; r.motif.prompt = 'one white snowflake, white background, simple background';
        const p = f.mv.assetPrompt(r, 'motif', f.host); assert.match(p, /blue background/); assert.doesNotMatch(p, /white background/); assert.match(p, /white snowflake/);
        r.assetPrompts = { motif: 'my exact white snow on white background' }; assert.equal(f.mv.assetPrompt(r, 'motif', f.host), r.assetPrompts.motif);
        assert.match(f.mv.defaultAssetPrompt(f.saved(), 'motif', f.host), /white background/);
    } finally { f.mvui.disposeMv(); }
});
test('motif editor opens with the prepared pixels and saves a real PNG while preserving its original', async () => {
    const c = art(), source = c.toDataURL(), e = await editor(source, { url: source }, { motif: true });
    try {
        const canvas = e.find('[data-editor-canvas]'); assert.equal(canvas.getContext('2d').getImageData(0, 0, 1, 1).data[3], 0);
        await e.click('save'); assert.equal(e.saves.length, 1); assert.equal(e.saves[0].image.mode, 'cutout');
        assert.equal(e.saves[0].image.originalRef.url, source);
        const png = await decode(e.saves[0].image.blob); assert.equal(px(read(png).data, 0, 0)[3], 0); assert.equal(px(read(png).data, 30, 40)[3], 255);
        assert.equal(c.toDataURL(), source);
    } finally { e.controller.dispose(); }
});
test('motif editor can undo background processing and manually restore white details', async () => {
    const c = art('#0000ff', 'white'), e = await editor(c.toDataURL(), null, { motif: true });
    try {
        await e.click('reset'); assert.equal(e.find('[data-layer]').checked, false);
        await e.click('auto'); assert.equal(e.find('[data-layer]').checked, true);
        await e.click('undo'); assert.equal(e.find('[data-layer]').checked, false);
        await e.click('auto'); await e.click('save'); const png = await decode(e.saves[0].image.blob);
        assert.deepEqual(px(read(png).data, 30, 40), [255, 255, 255, 255]); assert.equal(px(read(png).data, 0, 0)[3], 0);
    } finally { e.controller.dispose(); }
});
test('motif editor does not erase an unrecognizable background or call an empty image a cutout', async () => {
    const e = await editor(art('white', null).toDataURL(), null, { motif: true });
    try {
        await e.click('apply-crop'); await e.click('auto'); assert.equal(e.find('[data-layer]').checked, false);
        assert.match(e.find('[data-editor-status]').textContent, /未能分离/);
    } finally { e.controller.dispose(); }
});
test('outer anti-aliased colour is unmixed from white without changing the input or enclosed white', async () => {
    const f = await fixture(), c = art('white', '#ff0000'), g = c.getContext('2d');
    g.fillStyle = 'rgb(255,128,128)'; g.fillRect(17, 21, 1, 38);
    const original = read(c).data, before = new Uint8ClampedArray(original);
    const result = f.get('extras/mvImageTools').prepareMotifPixels(original, 60, 80);
    assert.equal(result.status, 'prepared'); assert.deepEqual(original, before);
    const fringe = px(result.data, 17, 30); assert.ok(fringe[3] >= 125 && fringe[3] <= 129); assert.deepEqual(fringe.slice(0, 3), [255, 0, 0]);
});
