// Public runtime timelines and actions; hosts/audio/recording are controlled doubles.
import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
const plain = x => JSON.parse(JSON.stringify(x));
const song = { id: 'SONG_clock', title: 'manual clock', bpm: 90,
 lyrics: '[Verse 1]\nfirst\nsecond\nthird\n[Chorus]\nfourth\nfifth\n[End]' };
const make = () => ({ id: song.id, version: 2, duration: 100, settings: { output: 'tegaki', range: 'full' }, tegaki: { range: 'full' },
 shots: ['first','second','second','third','fourth','fifth'].map((lyric,i) => ({ id:'S'+i,sectionIndex:i<4?0:1,lyric,phase:'still',cut:'cut',image:{url:'/user/images/'+i+'.png'} })),
 timing: { taps: {}, lineTaps: { '0:0':30.7,'0:1':35.5,'0:2':46,'1:0':61.3,'1:1':77.9 } } });
const positive = rows => rows.forEach((r,i) => { assert.ok(Number.isFinite(r.start) && r.end>r.start, `${r.shot.id}: ${r.start}..${r.end}`); if(i) assert.equal(r.start,rows[i-1].end); });
test('whole-song lyric taps keep repeated-shot starts ordered and every distinct lyric exactly on its tap',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),r=make(),before=JSON.stringify(r),out=mv.shotTimeline(r,song);
 positive(out.rows); const starts=out.rows.map(x=>x.start);
 for(const [i,t] of [[0,30.7],[1,35.5],[3,46],[4,61.3],[5,77.9]]) assert.equal(starts[i],t);
 assert.ok(starts[2]>35.5&&starts[2]<46);assert.equal(JSON.stringify(r),before);
});
test('a late lyric tap redistributes unmarked shots between anchors rather than leaving old starts behind',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),r=make();r.timing.lineTaps={'0:0':30.7,'0:2':46,'1:0':61.3};
 const out=mv.shotTimeline(r,song);positive(out.rows);assert.equal(out.rows[0].start,30.7);assert.equal(out.rows[3].start,46);assert.equal(out.rows[4].start,61.3);
 assert.ok(out.rows[1].start>30.7&&out.rows[2].start<46);
});
test('section taps remain exact fractional anchors even when automatic beat snapping is enabled',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),r=make();r.timing={taps:{0:0,1:61.3}};
 const out=mv.shotTimeline(r,song);positive(out.rows);assert.equal(out.rows[4].start,61.3);
});
test('unmarked earlier sections fit before a later manual anchor without pushing that anchor away',async()=>{
 const f=await fixture(),mv=f.get('extras/mv');const s={lyrics:'[Intro]\n[Verse 1]\na\n[Chorus]\nb\n[End]',bpm:90};
 const r={duration:120,timing:{taps:{2:12.3}}};const result=mv.sectionTimes(r,mv.parseSections(s.lyrics),90);
 assert.equal(result.sections[2].start,12.3);assert.ok(result.sections[1].start>0&&result.sections[1].start<12.3);
});
test('section ranges and clipped export follow first-line anchors from whole-song lyric sync',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),r=make();r.exportRange={range:'custom',rangeFrom:1,rangeTo:1};
 assert.equal(mv.exportRange(r,song).start,61.3);assert.equal(mv.exportRange(r,song).end,100);
 const full=mv.shotTimeline(r,song).rows.filter(x=>x.sectionIndex===1),clip=mv.playbackTimeline(mv.exportRecord(r,song),song).rows;
 assert.deepEqual(plain(clip),plain(full));positive(clip);
});
test('space and punctuation differences in copied lyrics still map to the same manual line',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),r=make();r.shots[1].lyric=' second，';r.shots[2].lyric='second!';
 const out=mv.shotTimeline(r,song);positive(out.rows);assert.equal(out.rows[1].start,35.5);assert.ok(out.rows[2].start>35.5&&out.rows[2].start<46);
});
test('repeated lyric text in separate occurrences receives distinct saved line times',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),s={...song,lyrics:'[Verse 1]\necho\nanswer\necho\n[End]'},r=make();
 r.shots=['echo','echo','answer','echo'].map((lyric,i)=>({id:'S'+i,sectionIndex:0,lyric}));r.timing={lineTaps:{'0:0':10.1,'0:1':30.3,'0:2':50.5}};
 const out=mv.shotTimeline(r,s);positive(out.rows);assert.equal(out.rows[0].start,10.1);assert.ok(out.rows[1].start>10.1&&out.rows[1].start<30.3);assert.equal(out.rows[2].start,30.3);assert.equal(out.rows[3].start,50.5);
});
test('null and empty lyric taps remain unmarked and corrupt reversed taps never make negative durations',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),r=make();r.timing.lineTaps={'0:0':null,'0:1':'','0:2':46,'1:0':30,'1:1':77.9};
 const before=JSON.stringify(r);positive(mv.shotTimeline(r,song).rows);assert.equal(JSON.stringify(r),before);
});
test('tiny manually timed line intervals retain both exact anchors and positive intermediate cuts',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),r=make();r.timing.lineTaps={'0:0':30.71,'0:1':30.73,'0:2':30.75,'1:0':61.3,'1:1':77.9};
 const rows=mv.shotTimeline(r,song).rows;positive(rows);assert.equal(rows[0].start,30.71);assert.equal(rows[1].start,30.73);assert.equal(rows[3].start,30.75);assert.ok(rows[2].start>30.73&&rows[2].start<30.75);
});
test('subtitles and timetable use the repaired positive timeline and preserve saved content',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),r=make();const srt=mv.srtText(r,song);
 assert.match(srt,/00:00:30,700 --> 00:00:35,500/);assert.ok(!mv.timetableText(r,song).includes('（-'));
 for(const m of srt.matchAll(/(\d\d):(\d\d):(\d\d),(\d{3}) --> (\d\d):(\d\d):(\d\d),(\d{3})/g)){
 const n=[...m].slice(1).map(Number);assert.ok(n[4]*3600000+n[5]*60000+n[6]*1000+n[7]>n[0]*3600000+n[1]*60000+n[2]*1000+n[3]);}
});
test('an untimed opening with no intro drawings preserves later estimated cut positions',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),s={bpm:120,lyrics:'[Intro]\n[Verse 1]\na\nb\n[End]'};
 const r={version:2,duration:80,shots:[{id:'A',sectionIndex:1,lyric:'a'},{id:'B',sectionIndex:1,lyric:'b'}]};
 const out=mv.shotTimeline(r,s);assert.deepEqual(plain(out.rows.map(x=>[x.start,x.end])),[[0,60],[60,80]]);
});
test('a corrupt zero tap after earlier drawings is ignored without rewriting data or collapsing those drawings',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),r=make();r.timing={lineTaps:{'0:2':0,'1:0':61.3}};
 const before=JSON.stringify(r);positive(mv.shotTimeline(r,song).rows);assert.equal(JSON.stringify(r),before);
});

import { createRequire } from 'node:module';
import { ui } from './mv-ui-fixture.mjs';
const require=createRequire(import.meta.url);
const native=require(require.resolve('@napi-rs/canvas',{paths:[process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||process.cwd()]}));
const flush=()=>new Promise(resolve=>setImmediate(resolve));
async function settle(){for(let i=0;i<10;i++)await flush();}
async function visualClock({version=2}={}){
 const f=await ui(fixture),mv=f.get('extras/mv'),decodes=[],draws=[],errors=[],media=new Map();let requests=0,exportCanvas;
 f.get('core/cache').loadSession=()=>({songs:[song]});f.get('extras/mvMedia').getMedia=async key=>media.get(key)||null;
 f.get('extras/mvMedia').putMedia=async(key,blob)=>{media.set(key,{blob});return true;};
 f.sb.toastr={error:x=>errors.push(x),success(){},info(){},warning(){}};
 f.get('generation/client').generate=async()=>{requests++;throw Error('unexpected generation');};
 f.get('generation/cgImageCore').invokeImageGeneration=async()=>{requests++;throw Error('unexpected drawing');};
 const colors=['#ff0000','#00ff00','#0000ff','#ff00ff','#00ffff','#ffff00'];
 const images=colors.map(color=>{const c=native.createCanvas(60,80),g=c.getContext('2d');g.fillStyle=color;g.fillRect(0,0,60,80);return{url:c.toDataURL(),split:'none'};});
 const r=make();r.version=version;r.timing={taps:{},lineTaps:{}};r.tegaki={range:'full',lyric:'subtitle',introSeconds:0,outroSeconds:0,showKeyword:false,showMotif:false};
 r.groups=[{id:'G',layer:'full',diffs:images.map((image,i)=>({id:'D'+i,image}))}];
 r.shots.forEach((s,i)=>Object.assign(s,{image:images[i],group:'G',diff:'D'+i,motion:'still'}));
 f.host.chatMetadata[mv.MV_KEY]={songs:{[song.id]:r}};
 const canvas=()=>{const c=native.createCanvas(540,960),g=c.getContext('2d'),text=g.fillText.bind(g);g.fillText=(t,...args)=>{draws.push({canvas:c,text:t});text(t,...args);};c.style={};c.remove=()=>{};const track={canvas:c,stop(){}};c.captureStream=()=>({getTracks:()=>[track],getVideoTracks:()=>[track]});return c;};
 const preview=canvas();f.canvas.getContext=()=>preview.getContext('2d');const create=f.sb.document.createElement;f.sb.document.createElement=tag=>tag==='canvas'?canvas():create(tag);
 f.sb.Image=class extends native.Image{set src(x){super.src=x;decodes.push(this.decode());}};
 f.sb.MediaStream=class{constructor(tracks){this.tracks=tracks;}};
 f.sb.MediaRecorder=class{static isTypeSupported(){return true;}constructor(stream){exportCanvas=stream.tracks[0].canvas;this.state='inactive';}start(){this.state='recording';}stop(){this.state='inactive';this.onstop?.();}};
 f.sb.AudioContext=class{createMediaElementSource(){return{connect(){}};}createMediaStreamDestination(){const track={stop(){}};return{stream:{getTracks:()=>[track],getAudioTracks:()=>[track]}};}async resume(){}async close(){}};
 f.mvui.openMv({songId:song.id});f.upload();f.audios.at(-1).duration=100;f.audios.at(-1).onloadedmetadata();f.click('go-tegaki');f.click('play');await settle();
 const saved=()=>mv.readMv(f.host,song.id);
 const at=t=>{f.audios.at(-1).currentTime=t;};
 const sync=async()=>{for(const[k,t]of Object.entries(make().timing.lineTaps)){at(t);f.click('tap-line',k);}await settle();};
 const seek=async t=>{const el={dataset:{rmtMv:'seek'},getBoundingClientRect:()=>({left:0,width:mv.shotTimeline(saved(),song).total})};
 f.mvui.handleMvClick({target:{closest:()=>el},clientX:t,preventDefault(){}});await settle();await Promise.all(decodes);draws.length=0;f.mvui.handleMvClick({target:{closest:()=>el},clientX:t,preventDefault(){}});
 return draws.filter(x=>x.canvas===preview).map(x=>x.text);};
 const pixel=(c=preview)=>[...c.getContext('2d').getImageData(c.width/2,c.height/2,1,1).data].slice(0,3);
 return{...f,mv,saved,sync,seek,pixel,at,errors,requests:()=>requests,exportCanvas:()=>exportCanvas};
}
test('public whole-song lyric sync, undo and reopening preserve exact timing and show no early lyric or skipped drawing',async()=>{
 for(const version of [1,2]){const f=await visualClock({version});try{
 await f.sync();f.click('editor-tab','timing');positive(f.mv.shotTimeline(f.saved(),song).rows);assert.doesNotMatch(f.body.innerHTML,/· -[\d.]+s/);assert.match(f.body.innerHTML,/全部句子已对齐/);
 f.click('tap-line-undo');assert.match(f.body.innerHTML,/这一句开始了/);f.at(78.4);f.click('tap-line','1:1');assert.equal(f.mv.shotTimeline(f.saved(),song).rows.at(-1).start,78.4);
 const timing=JSON.stringify(f.saved().timing);f.mvui.disposeMv();f.mvui.openMv({songId:song.id});f.click('go-tegaki');
 assert.equal(JSON.stringify(f.saved().timing),timing);assert.deepEqual(await f.seek(5),[]);assert.deepEqual(await f.seek(30.7),['first']);assert.deepEqual(f.pixel(),[255,0,0]);
 assert.deepEqual(await f.seek(35.5),['second']);assert.deepEqual(f.pixel(),[0,255,0]);assert.deepEqual(await f.seek(44),['second']);assert.deepEqual(f.pixel(),[0,0,255]);
 assert.deepEqual(await f.seek(46),['third']);assert.deepEqual(f.pixel(),[255,0,255]);assert.deepEqual(f.errors,[]);assert.equal(f.requests(),0);
 }finally{f.mvui.disposeMv();}}
});
test('video export starts at the marked chorus and uses the same absolute cut points and images as preview',async()=>{
 const f=await visualClock();try{
 await f.sync();const expected=await f.seek(61.3);assert.deepEqual(expected,['fourth']);assert.deepEqual(f.pixel(),[0,255,255]);
 f.click('export-range','1:1');f.click('export');await settle();assert.ok(f.exportCanvas(),f.errors.join(';'));assert.equal(f.audios.at(-1).currentTime,61.3);assert.deepEqual(f.pixel(f.exportCanvas()),[0,255,255]);
 f.at(77.9);const callbacks=[...f.frames.values()];f.frames.clear();for(const callback of callbacks)callback();assert.deepEqual(f.pixel(f.exportCanvas()),[255,255,0]);
 assert.equal(f.saved().timing.lineTaps['1:0'],61.3);assert.deepEqual(f.errors,[]);assert.equal(f.requests(),0);f.click('export-stop');
 }finally{f.mvui.disposeMv();}
});
test('legacy overall timing offsets retain their automatic cut positions when there are no manual marks',async()=>{
 const f=await fixture(),mv=f.get('extras/mv'),s={bpm:120,lyrics:'[Verse 1]\na\n[Chorus]\nb\n[Outro]\nc\n[End]'};
 for(const[shift,want]of [[-10,[0,20,50]],[10,[0,40,70]]]){
 const r={version:2,duration:90,timing:{shift},shots:['a','b','c'].map((lyric,i)=>({id:String(i),sectionIndex:i,lyric}))};
 const out=mv.shotTimeline(r,s);assert.deepEqual(plain(out.rows.map(x=>x.start)),want);assert.equal(out.total,90+shift);
 }
});
