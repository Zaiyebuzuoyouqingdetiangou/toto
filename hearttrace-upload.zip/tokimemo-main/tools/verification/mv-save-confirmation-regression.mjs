import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture, realClient } from './fixture.mjs';
const flush = () => new Promise(resolve => setImmediate(resolve));
const deferred = () => { let resolve, reject; const promise = new Promise((a, b) => { resolve = a; reject = b; }); return { promise, resolve, reject }; };
const song = { id: 'SONG_a', title: 'test', lyrics: '[Verse 1]\nline\n[Chorus]\nhook\n[End]' };
const storyboard = () => ({ shots: [{ plain: 'empty room', who: 'none', sectionIndex: 0, imagePrompt: 'empty room' }] });
async function setup() {
    const f = await fixture(); f.get('core/cache').loadSession = () => ({ songs: [song] });
    return { ...f, mv: f.get('extras/mv') };
}

test('paid result waits for a returned metadata promise when local storage cannot save', async () => {
    const f = await setup(), saving = deferred(), entered = deferred();
    delete f.sb.localStorage;
    f.host.saveMetadataDebounced = () => { entered.resolve(); return saving.promise; };
    realClient(f, storyboard);
    let finished = false;
    const task = f.mv.generateStoryboard(song.id, {}).then(r => { finished = true; return r; });
    await entered.promise; await flush();
    try { assert.equal(finished, false, 'Do not report saved before the sole save settles'); }
    finally { saving.resolve(); }
    const r = await task;
    assert.equal(r.pending, false); assert.equal(r.durable, true);
    assert.equal(f.mv.pendingMv(r.scope).length, 0);
});

test('rejected metadata with no local copy retains the paid result and retries saving without regeneration', async () => {
    const f = await setup(); delete f.sb.localStorage;
    f.host.saveMetadataDebounced = async () => { throw Error('fixture disk failure'); };
    let calls = 0; realClient(f, () => { calls++; return storyboard(); });
    const r = await f.mv.generateStoryboard(song.id, {});
    assert.equal(r.pending, true); assert.equal(r.durable, false);
    assert.match(r.message, /本页内存/);
    assert.match(f.mv.exportMvRecovery(r.scope), /empty room/);
    assert.equal(f.mv.pendingMv(r.scope).length, 1);
    f.host.saveMetadataDebounced = async () => {};
    const saved = await f.mv.retryMvSave(r.scope, r.id);
    assert.equal(saved.pending, false); assert.equal(saved.durable, true);
    assert.equal(f.mv.pendingMv(r.scope).length, 0); assert.equal(calls, 1);
    assert.equal((await f.mv.retryMvSave(r.scope, r.id)).alreadySaved, true);
});

test('confirmed local copy succeeds even if metadata rejects and survives a fresh runtime', async () => {
    const f = await setup(); f.host.saveMetadataDebounced = async () => { throw Error('metadata'); };
    realClient(f, storyboard); const r = await f.mv.generateStoryboard(song.id, {});
    assert.equal(r.pending, false); assert.equal(r.durable, true);
    const g = await setup(); for (const [k, v] of f.disk) g.disk.set(k, v);
    assert.equal(g.mv.readMv(g.host, song.id).shots[0].plain, 'empty room');
    await flush();
});

test('void-returning host debounce stays compatible when local storage quota is exhausted', async () => {
    const f = await setup(); f.sb.localStorage.setItem = () => { throw Error('quota'); };
    let saves = 0; f.host.saveMetadataDebounced = () => { saves++; };
    realClient(f, storyboard); const r = await f.mv.generateStoryboard(song.id, {});
    assert.equal(r.pending, false); assert.equal(saves, 1);
    assert.equal(f.host.chatMetadata[f.mv.MV_KEY].songs[song.id].shots[0].plain, 'empty room');
});

test('missing, throwing or explicitly failed metadata storage keeps recovery in memory', async () => {
    for (const method of [undefined, () => { throw Error('metadata'); }, () => false, async () => false]) {
        const f = await setup(); delete f.sb.localStorage; f.host.saveMetadataDebounced = method;
        realClient(f, storyboard); const r = await f.mv.generateStoryboard(song.id, {});
        assert.equal(r.pending, true); assert.equal(r.durable, false);
        assert.match(f.mv.exportMvRecovery(r.scope), /empty room/);
    }
});

test('failed paid redraw remains exportable and save-only recovery keeps its new image', async () => {
    const f = await setup(); delete f.sb.localStorage;
    f.host.chatMetadata[f.mv.MV_KEY] = { songs: { [song.id]: { id: song.id, settings: { appear: 'none' },
        shots: [{ id: 'S1', who: 'none', plain: 'room', image: { url: '/user/images/old.png' } }] } } };
    f.host.saveMetadataDebounced = async () => { throw Error('disk'); };
    let calls = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { calls++; return '/user/images/new.png'; };
    const r = await f.mv.drawFrame(song.id, 'S1');
    assert.equal(r.pending, true); assert.equal(r.durable, false);
    assert.match(f.mv.exportMvRecovery(r.scope), /new.png/);
    f.host.saveMetadataDebounced = async () => {};
    assert.equal((await f.mv.retryMvSave(r.scope, r.id)).pending, false);
    assert.equal(f.mv.readMv(f.host, song.id).shots[0].image.url, '/user/images/new.png');
    assert.equal(calls, 1);
});

test('a delayed rejected save retains only its original chat recovery', async () => {
    const f = await setup(), saving = deferred(), entered = deferred(); delete f.sb.localStorage;
    f.host.saveMetadataDebounced = () => { entered.resolve(); return saving.promise; };
    realClient(f, storyboard); const task = f.mv.generateStoryboard(song.id, {});
    await entered.promise;
    const other = { ...f.host, chatId: 'B', chatMetadata: { [f.constants.MEMORY_KEY]: { ...f.bank, chatId: 'B' } } };
    f.switchTo(other); saving.reject(Error('save failed'));
    const r = await task;
    assert.equal(r.pending, true); assert.equal(r.durable, false);
    assert.equal(other.chatMetadata[f.mv.MV_KEY], undefined);
    assert.equal(f.mv.pendingMv(f.mv.mvScope(other)).length, 0);
    assert.match(f.mv.exportMvRecovery(r.scope), /empty room/);
});

test('ordinary archive revision growth still allows unchanged-song storyboard saving', async () => {
    const f = await setup();
    realClient(f, () => { f.bank.archiveRevision = 'r2'; return storyboard(); });
    const r = await f.mv.generateStoryboard(song.id, {});
    assert.equal(r.pending, false);
    assert.equal(f.mv.readMv(f.host, song.id).shots[0].plain, 'empty room');
});

test('all appearance/shot combinations preserve the current branch cast and scenery intent', async () => {
    const f = await setup();
    f.get('core/castLooks').readCastLooks = () => ({ char: 'black hair', user: 'red hair', manual: true });
    for (const appear of ['face', 'back', 'none']) for (const who of ['char', 'user', 'both', 'none']) {
        const prompt = f.mv.framePrompt({ settings: { appear } }, { who, plain: 'quiet room' }, f.host);
        const c = ['char', 'both'].includes(who), u = appear !== 'none' && ['user', 'both'].includes(who);
        assert.equal(prompt.includes('black hair'), c, appear + who);
        assert.equal(prompt.includes('red hair'), u, appear + who);
        if (!c && !u) assert.match(prompt, /no (?:people|humans)/);
        if (who === 'user') assert.doesNotMatch(prompt, /second person/);
    }
});
