import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {fixture} from './fixture.mjs';
const plain=v=>JSON.parse(JSON.stringify(v));
const song={id:'SONG_a',title:'index recovery',bpm:120,lyrics:Array.from({length:8},(_,i)=>`[Verse ${i+1}]\n第${i+1}段，歌词。`).join('\n')};
const raw=(sections,index=i=>i)=>({groups:[{id:'G1',characterPrompt:'unchanged scene',diffs:[{id:'D1',change:'looks up'}]}],frames:sections.map((n,k)=>({sectionIndex:index(n,k),lyric:`第${n+1}段，歌词。`,group:'G1',diff:'D1'}))});
async function setup(factory=fixture){const f=await factory(),mv=f.get('extras/mv');f.get('core/cache').loadSession=()=>({songs:[song]});const record={id:song.id,createdAt:1,updatedAt:1,settings:{output:'tegaki',range:'full'},tegaki:{range:'full'},wardrobe:{char:'original clothes'},...mv.buildShots(raw([0,1,2,3]),f.bank,8,{output:'tegaki'})};record.groups[0].diffs[0].image={url:'/user/images/old-paid.png'};f.host.chatMetadata[mv.MV_KEY]={version:1,songs:{[song.id]:record}};return {...f,mv,record};}
for(const [label,index] of [['batch zero-based',(n,k)=>k],['batch one-based',(n,k)=>k+1],['song one-based',n=>n+1],['song zero-based',n=>n]])test(`${label} response accepts correct lyrics without replacing old images`,async()=>{
 const f=await setup(),old=plain(f.record);let calls=0;f.get('generation/client').requestJson=async()=>{calls++;return raw([4,5,6,7],index)};
 const result=await f.mv.continueStoryboard(song.id);assert.equal(result.pending,false);const saved=f.mv.readMv(f.host,song.id);assert.deepEqual(plain(saved.shots.slice(0,4)),old.shots);assert.deepEqual(plain(saved.groups[0]),old.groups[0]);assert.deepEqual(plain(saved.shots.slice(4).map(s=>s.sectionIndex)),[4,5,6,7]);assert.equal(calls,1);
});
test('missing indexes and normalized whitespace/punctuation are recovered from the actual lyric',async()=>{
 const f=await setup();const data=raw([4,5,6,7]);data.frames.forEach(s=>{delete s.sectionIndex;s.lyric=s.lyric.replace('，',' ').replace('。','！');});f.get('generation/client').requestJson=async()=>data;
 assert.equal((await f.mv.continueStoryboard(song.id)).pending,false);assert.deepEqual(plain(f.mv.readMv(f.host,song.id).shots.slice(4).map(s=>s.sectionIndex)),[4,5,6,7]);
});
test('already completed lyrics are never re-labelled as new sections just because their batch indexes fit',async()=>{
 const f=await setup(),old=plain(f.record);f.get('generation/client').requestJson=async()=>raw([0,1,2,3]);const result=await f.mv.continueStoryboard(song.id);assert.equal(result.pending,true);assert.deepEqual(plain(f.mv.readMv(f.host,song.id)),old);assert.equal(f.mv.pendingMv(result.scope).length,1);
});
test('valid absolute-index partial responses with paraphrased lyrics remain accepted',async()=>{
 const f=await setup();const data=raw([5]);data.frames[0].lyric='模型没有逐字抄写的歌词';f.get('generation/client').requestJson=async()=>data;
 assert.equal((await f.mv.continueStoryboard(song.id)).pending,false);assert.equal(f.mv.readMv(f.host,song.id).shots.at(-1).sectionIndex,5);
});
test('flat legacy shots with relative indexes also recover by lyric without upgrading old data',async()=>{
 const f=await setup();delete f.record.version;delete f.record.groups;f.record.shots.forEach(s=>{delete s.group;s.image={local:'old-local'};});f.get('generation/client').requestJson=async()=>({shots:[{sectionIndex:0,lyric:'第5段，歌词。',plain:'new scene',imagePrompt:'new scene'}]});
 assert.equal((await f.mv.continueStoryboard(song.id)).pending,false);const saved=f.mv.readMv(f.host,song.id);assert.equal(saved.shots[0].image.local,'old-local');assert.equal(saved.shots.at(-1).sectionIndex,4);assert.equal(f.mv.isV2(saved),false);
});
test('fresh runtime can repair an actual r84.209 blocked paid result with save-only retry',async()=>{
 const candidateRoot=process.env.TEST_ROOT,oldRoot=process.env.BASELINE_ROOT;assert.ok(oldRoot,'BASELINE_ROOT must identify delivered r84.209');
 process.env.TEST_ROOT=oldRoot;const legacy=await import('./fixture.mjs?legacy-index-recovery');process.env.TEST_ROOT=candidateRoot;
 const old=await setup(legacy.fixture);old.mv.writeMv(old.mv.mvScope(old.host),song.id,r=>r);old.get('generation/client').requestJson=async()=>raw([4,5,6,7],(n,k)=>k);
 const blocked=await old.mv.continueStoryboard(song.id);assert.equal(blocked.pending,true);assert.equal(old.mv.pendingMv(blocked.scope)[0].patch,null);
 const fresh=await setup();for(const[k,v]of old.disk)fresh.disk.set(k,v);let calls=0;fresh.get('generation/client').requestJson=async()=>{calls++;throw Error('must not regenerate');};
 const result=await fresh.mv.retryMvSave(blocked.scope,blocked.id);assert.equal(result.pending,false);assert.equal(fresh.mv.readMv(fresh.host,song.id).shots.length,8);assert.equal(fresh.mv.readMv(fresh.host,song.id).groups[0].diffs[0].image.url,'/user/images/old-paid.png');assert.equal(calls,0);await fresh.mv.retryMvSave(blocked.scope,blocked.id);assert.equal(fresh.mv.readMv(fresh.host,song.id).shots.length,8);
});
test('instrumental batch without lyrics accepts an unambiguous batch-local numbering scheme',async()=>{
 const f=await setup();f.get('core/cache').loadSession=()=>({songs:[{...song,lyrics:song.lyrics+'\n[Instrumental]\n[Outro]'}]});const data=raw([8,9],(n,k)=>k);data.frames.forEach(s=>s.lyric='');f.get('generation/client').requestJson=async()=>data;
 f.record.tegaki={range:'custom',rangeFrom:8,rangeTo:9};assert.equal((await f.mv.continueStoryboard(song.id)).pending,false);assert.deepEqual(plain(f.mv.readMv(f.host,song.id).shots.slice(4).map(s=>s.sectionIndex)),[8,9]);
});
test('a short instrumental reply with ambiguous one-based numbering is retained instead of placed on an arbitrary section',async()=>{
 const f=await setup();const data=raw([4],()=>1);data.frames[0].lyric='';f.get('generation/client').requestJson=async()=>data;const result=await f.mv.continueStoryboard(song.id);assert.equal(result.pending,true);assert.equal(f.mv.readMv(f.host,song.id).shots.length,4);assert.ok(f.mv.pendingMv(result.scope)[0].raw);
});
test('new pending results retain their requested section range when the display range changes before save',async()=>{
 const f=await setup();f.mv.writeMv(f.mv.mvScope(f.host),song.id,r=>r);f.get('generation/client').requestJson=async()=>{f.switchTo({...f.host,chatId:'B',chatMetadata:{}});return raw([4,5,6,7],(n,k)=>k);};
 const held=await f.mv.continueStoryboard(song.id);assert.equal(held.pending,true);assert.deepEqual(plain(f.mv.pendingMv(held.scope)[0].appendSections),[4,5,6,7]);f.switchTo(f.host);f.mv.patchTegaki(song.id,{range:'custom',rangeFrom:0,rangeTo:3});assert.equal((await f.mv.retryMvSave(held.scope,held.id)).pending,false);assert.equal(f.mv.readMv(f.host,song.id).shots.length,8);
});
