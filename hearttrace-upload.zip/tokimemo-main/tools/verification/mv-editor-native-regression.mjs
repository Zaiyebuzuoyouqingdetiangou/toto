// Native Canvas/PNG pixels with a small event-host double; this is not a browser DOM test.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
const require = createRequire(import.meta.url);
const native = require(require.resolve('@napi-rs/canvas', { paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || process.cwd()] }));

class Element {
    constructor(tag, attributes = '') {
        this.tag = tag; this.listeners = {}; this.dataset = {}; this.style = {}; this.value = ''; this.checked = false; this.disabled = false;
        for (const [, name, value] of attributes.matchAll(/([\w-]+)(?:="([^"]*)")?/g)) {
            if (name.startsWith('data-')) this.dataset[name.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = value || '';
            if (name === 'value') this.value = value;
            if (name === 'class') this.className = value;
        }
        if (tag === 'canvas') this.native = native.createCanvas(300, 150);
    }
    set innerHTML(value) { this.html = value; this.nodes = [...value.matchAll(/<([a-z]+)([^>]*)>/g)].map(([, tag, attrs]) => new Element(tag, attrs)); this.firstElementChild = this.nodes[0]; if (this.firstElementChild) this.firstElementChild.nodes = this.nodes.slice(1); }
    get innerHTML() { return this.html; }
    set textContent(value) { this.text = value; this.onText?.(value); }
    get textContent() { return this.text || ''; }
    matches(selector) {
        if (selector.startsWith('.')) return (this.className || '').split(' ').includes(selector.slice(1));
        const m = selector.match(/^\[data-([\w-]+)(?:="([^"]*)")?\]$/);
        if (m) { const k = m[1].replace(/-([a-z])/g, (_, c) => c.toUpperCase()); return k in this.dataset && (m[2] === undefined || this.dataset[k] === m[2]); }
        return selector === this.tag;
    }
    querySelectorAll(selector) { return (this.nodes || []).filter(el => selector.split(',').some(s => el.matches(s))); }
    querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
    closest(selector) { return this.matches(selector) ? this : null; }
    addEventListener(name, fn) { (this.listeners[name] ||= []).push(fn); }
    async fire(name, extra = {}) { for (const fn of this.listeners[name] || []) await fn({ target: this, preventDefault() {}, ...extra }); }
    setAttribute(name, value) { this[name] = value; }
    setPointerCapture() {}
    get width() { return this.native.width; } set width(v) { this.native.width = v; }
    get height() { return this.native.height; } set height(v) { this.native.height = v; }
    getContext() { return this.native.getContext('2d'); }
    getBoundingClientRect() { const width = (this.style.width || '').endsWith('px') ? parseFloat(this.style.width) : 360 * (parseFloat(this.style.width || '100') / 100); return { left: 0, top: 0, width, height: width * this.height / this.width }; }
    toBlob(fn) { fn(new Blob([this.native.toBuffer('image/png')], { type: 'image/png' })); }
    click() {}
}

async function editor(sourceUrl, image = null, extra = {}) {
    const f = await fixture(), blobs = new Map(); let serial = 0;
    f.sb.ImageData = native.ImageData;
    f.sb.innerHeight = 10000; // Geometry tests use a large viewport; the mobile fit test overrides it.
    f.sb.Image = class extends native.Image {
        set src(value) { if (blobs.has(value)) void blobs.get(value).arrayBuffer().then(b => { super.src = Buffer.from(b); }); else super.src = value; }
    };
    f.sb.URL = { createObjectURL(blob) { const url = `blob:test-${++serial}`; blobs.set(url, blob); return url; }, revokeObjectURL(url) { blobs.delete(url); } };
    f.sb.document = { createElement: tag => new Element(tag) };
    const host = new Element('div'), saves = [], state = { closed: 0 };
    const controller = f.get('ui/mvImageEditor').mountAssetEditor(host, { sourceUrl, imageUrl: sourceUrl, image, prompt: 'default', defaultPrompt: 'default', onSave: async draft => { saves.push(draft); return true; }, onClose: () => { state.closed++; }, ...extra });
    const root = host.firstElementChild, find = selector => root.querySelector(selector), click = action => root.fire('click', { target: find(`[data-edit="${action}"]`) });
    await controller.ready; return { f, root, controller, saves, state, find, click };
}
function fourPanels() {
    const c = native.createCanvas(120, 480), g = c.getContext('2d');
    ['#f00', '#0f0', '#00f', '#ff0'].forEach((color, i) => { g.fillStyle = color; g.fillRect(0, i * 120, 120, 120); });
    return c.toDataURL('image/png');
}
async function decode(blob) { const img = new native.Image(); img.src = Buffer.from(await blob.arrayBuffer()); await img.decode(); const c = native.createCanvas(img.width, img.height); c.getContext('2d').drawImage(img, 0, 0); return c; }

test('automatically prepared character can be downloaded directly while a prompt-only save keeps the source', async () => {
    const c = native.createCanvas(120, 90), g = c.getContext('2d');
    g.fillStyle = '#ddd'; g.fillRect(0, 0, 120, 90); g.fillStyle = '#35465a'; g.fillRect(48, 10, 24, 20); g.fillRect(40, 30, 40, 45);
    const e = await editor(c.toDataURL(), { url: c.toDataURL() }, { autoCharacter: true });
    try {
        assert.equal(e.find('[data-layer]').checked, true);
        let downloaded; e.f.sb.document.createElement = tag => { const el = new Element(tag); if (tag === 'a') el.click = () => { downloaded = el.href; }; return el; };
        const urls = new Map(); e.f.sb.URL.createObjectURL = blob => { const url = 'blob:download'; urls.set(url, blob); return url; };
        await e.click('download'); const png = await decode(urls.get(downloaded));
        assert.equal(png.width, 120); assert.equal(png.height, 90);
        assert.equal(png.getContext('2d').getImageData(0, 0, 1, 1).data[3], 0);
        assert.equal(png.getContext('2d').getImageData(60, 50, 1, 1).data[3], 255);
        e.find('[data-editor-prompt]').value = 'edited prompt'; await e.click('save');
        assert.equal(e.saves[0].prompt, 'edited prompt'); assert.equal(e.saves[0].image, undefined);
    } finally { e.controller.dispose(); }
});

test('editor selects the third of four panels before processing; saved PNG contains only blue pixels', async () => {
    const e = await editor(fourPanels()), grid = e.find('[data-grid]'), canvas = e.find('[data-editor-canvas]');
    grid.value = '4:1'; await grid.fire('change');
    await canvas.fire('pointerdown', { pointerId: 1, clientX: 180, clientY: 900 }); await canvas.fire('pointerup', { pointerId: 1 });
    await e.click('save'); assert.equal(e.saves.length, 0); assert.match(e.find('[data-editor-status]').textContent, /使用选中画面/);
    await e.click('apply-crop'); assert.equal(canvas.width, 120); assert.equal(canvas.height, 120);
    await e.click('save'); assert.equal(e.saves.length, 1);
    const saved = await decode(e.saves[0].image.blob);
    assert.equal(saved.width, 120); assert.equal(saved.height, 120);
    assert.deepEqual([...saved.getContext('2d').getImageData(60, 60, 1, 1).data], [0, 0, 255, 255]);
    assert.equal(e.saves[0].image.mode, 'full'); assert.equal(e.saves[0].image.crop.y, .5); e.controller.dispose();
});

test('native editor erase, restore, undo and saved transparent PNG preserve original reference', async () => {
    const c = native.createCanvas(100, 100), g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, 100, 100); g.fillStyle = '#202020'; g.fillRect(20, 20, 60, 60);
    const e = await editor(c.toDataURL(), { url: '/user/images/source.png' }); await e.click('apply-crop'); await e.click('auto');
    const canvas = e.find('[data-editor-canvas]'), alpha = (x, y) => canvas.getContext('2d').getImageData(x, y, 1, 1).data[3];
    assert.equal(alpha(0, 0), 0); assert.equal(alpha(50, 50), 255);
    await canvas.fire('pointerdown', { pointerId: 1, clientX: 180, clientY: 180 }); await canvas.fire('pointerup', { pointerId: 1 }); assert.equal(alpha(50, 50), 0);
    await e.click('restore'); await canvas.fire('pointerdown', { pointerId: 2, clientX: 180, clientY: 180 }); await canvas.fire('pointerup', { pointerId: 2 }); assert.equal(alpha(50, 50), 255);
    await e.click('undo'); assert.equal(alpha(50, 50), 0); await e.click('undo'); assert.equal(alpha(50, 50), 255);
    await e.click('save'); const saved = await decode(e.saves[0].image.blob);
    assert.equal(saved.getContext('2d').getImageData(0, 0, 1, 1).data[3], 0); assert.equal(e.saves[0].image.mode, 'cutout'); assert.equal(e.saves[0].image.originalRef.url, '/user/images/source.png'); e.controller.dispose();
});

test('free selection uses pointer coordinates after zoom and preserves a prompt-only draft on cancel', async () => {
    const e = await editor(fourPanels()), canvas = e.find('[data-editor-canvas]');
    e.find('[data-zoom]').value = '2'; await e.find('[data-zoom]').fire('input');
    await canvas.fire('pointerdown', { pointerId: 3, clientX: 180, clientY: 720 });
    await canvas.fire('pointermove', { pointerId: 3, clientX: 540, clientY: 1440 }); await canvas.fire('pointerup', { pointerId: 3 });
    await e.click('apply-crop'); assert.equal(canvas.width, 60); assert.equal(canvas.height, 120);
    e.find('[data-editor-prompt]').value = 'my text <script>literal</script>';
    await e.click('close'); assert.equal(e.saves.length, 0); assert.equal(e.state.closed, 1); e.controller.dispose();
});

test('prompt-only save needs no image; reset returns the default without requesting a new image', async () => {
    const e = await editor(''); e.find('[data-editor-prompt]').value = 'manual text'; await e.click('save');
    assert.equal(e.saves[0].prompt, 'manual text'); assert.equal(e.saves[0].image, undefined);
    await e.click('default-prompt'); await e.click('save'); assert.equal(e.saves[1].prompt, null); e.controller.dispose();
});

test('transparent PNG import keeps its alpha and provides its own original for persistent storage', async () => {
    const e = await editor(''), c = native.createCanvas(80, 120), g = c.getContext('2d'); g.fillStyle = '#800080'; g.fillRect(20, 20, 40, 80);
    let release; const decoding = new Promise(r => { release = r; });
    const file = new class extends Blob { async arrayBuffer() { await decoding; return super.arrayBuffer(); } }([c.toBuffer('image/png')], { type: 'image/png' });
    const input = e.find('[data-import="cutout"]'); input.files = [file];
    const imported = new Promise(resolve => { e.find('[data-editor-status]').onText = text => { if (text.includes('已导入')) resolve(); }; });
    await input.fire('change');
    await e.click('save'); assert.equal(e.saves.length, 0); assert.match(e.find('[data-editor-status]').textContent, /正在读取/);
    release(); let timer;
    try { await Promise.race([imported, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('PNG import never completed')), 5000); })]); } finally { clearTimeout(timer); }
    await e.click('save'); assert.equal(e.saves.length, 1); assert.equal(e.saves[0].image.sourceBlob, file);
    const saved = await decode(e.saves[0].image.blob); assert.equal(saved.width, 80); assert.equal(saved.height, 120);
    assert.equal(saved.getContext('2d').getImageData(0, 0, 1, 1).data[3], 0); assert.equal(e.saves[0].image.mode, 'cutout'); e.controller.dispose();
});

test('reopened cropped edit keeps saved pixels and can restore the full original', async () => {
    const single = native.createCanvas(120, 120); single.getContext('2d').fillStyle = '#00f'; single.getContext('2d').fillRect(0, 0, 120, 120);
    const savedImage = { local: 'saved', original: { url: '/user/images/source.png' }, editMode: 'full', crop: { x: 0, y: .5, w: 1, h: .25 } };
    const e = await editor(fourPanels(), savedImage, { imageUrl: single.toDataURL() });
    assert.equal(e.find('[data-editor-canvas]').height, 120);
    await e.click('original'); assert.equal(e.find('[data-editor-canvas]').height, 480);
    await e.click('save'); assert.equal(e.saves[0].image.restoreOriginal, true); assert.equal(e.saves[0].image.originalRef.url, '/user/images/source.png'); e.controller.dispose();
});

test('mobile overview fits a long four-panel image and pan mode does not draw over it', async () => {
    const e = await editor(fourPanels()); e.f.sb.innerHeight = 700;
    await e.find('[data-zoom]').fire('input'); const canvas = e.find('[data-editor-canvas]');
    assert.ok(canvas.getBoundingClientRect().height <= 700 * .55 + 1);
    await e.click('apply-crop'); await e.click('pan'); assert.equal(canvas.style.touchAction, 'pan-x pan-y');
    const before = canvas.native.toDataURL();
    await canvas.fire('pointerdown', { pointerId: 1, clientX: 20, clientY: 20 }); await canvas.fire('pointermove', { pointerId: 1, clientX: 30, clientY: 40 }); await canvas.fire('pointerup', { pointerId: 1 });
    assert.equal(canvas.native.toDataURL(), before); await e.click('pan'); assert.equal(canvas.style.touchAction, 'none'); e.controller.dispose();
});

test('unsuitable opaque image is not marked as a transparent layer by one-click processing', async () => {
    const e = await editor(fourPanels()); await e.click('apply-crop');
    assert.equal(e.find('[data-layer]').checked, false); await e.click('auto'); assert.equal(e.find('[data-layer]').checked, false);
    assert.match(e.find('[data-editor-status]').textContent, /未能分离背景/);
    await e.click('undo'); assert.equal(e.find('[data-layer]').checked, false); e.controller.dispose();
});

test('playback never uses white-removal percentage to layer unconfirmed pictures', async () => {
    for (const confirmed of [false, true]) {
        const f = await ui(fixture), mv = f.get('extras/mv'), state = f.get('core/state').state;
        const source = native.createCanvas(100, 100), g = source.getContext('2d');
        if (!confirmed) { g.fillStyle = '#fff'; g.fillRect(0, 0, 100, 100); }
        g.fillStyle = '#333'; g.fillRect(12, 12, 76, 76);
        const bg = native.createCanvas(100, 100); bg.getContext('2d').fillStyle = '#0000ff'; bg.getContext('2d').fillRect(0, 0, 100, 100);
        const song = { id: 'SONG_pixels', title: '', lyrics: '[Verse 1]\nline\n[End]' };
        f.get('core/cache').loadSession = () => ({ songs: [song] });
        f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: { version: 2, duration: 100, settings: { output: 'tegaki', range: 'full', ratio: '9:16' }, tegaki: { range: 'full', lyric: 'none' },
            groups: [{ id: 'G1', layer: 'cutout', scale: 'wide', motion: 'still', bg: { url: bg.toDataURL() }, diffs: [{ id: 'D1', image: { url: source.toDataURL(), split: 'none', ...(confirmed ? { editMode: 'cutout' } : {}) } }] }],
            shots: [{ id: 'S1', group: 'G1', diff: 'D1', sectionIndex: 0, lyric: 'line' }] } } };
        const decodes = [];
        f.sb.Image = class extends native.Image { set src(value) { super.src = value; decodes.push(this.decode()); } };
        const render = native.createCanvas(540, 960); f.canvas.getContext = () => render.getContext('2d');
        f.sb.document.createElement = tag => new Element(tag);
        f.mvui.openMv({ songId: song.id }); f.click('go-tegaki');
        await Promise.all(decodes);
        f.mvui.renderMv(); const rgb = [...render.getContext('2d').getImageData(5, 5, 1, 1).data];
        if (confirmed) assert.ok(rgb[2] > rgb[0] + 80, `confirmed alpha should expose the blue background: ${rgb}`);
        else assert.ok(rgb[0] > 200 && rgb[1] > 200 && rgb[2] > 200, `white pixels must survive without confirmation: ${rgb}`);
        f.mvui.disposeMv(); state.activeMode = '';
    }
});
