// Real production bundle with synthetic HTTP/media boundaries. Not a claim of
// live Suno, iPhone, or TT connectivity.
import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { ui, recorderHost } from './mv-ui-fixture.mjs';

const share = 'https://suno.com/s/example';
const songPage = 'https://suno.com/song/5619ac37-2d29-4393-9af2-98134b004b68';
const mediaUrl = 'https://cdn1.suno.ai/published.mp3';
const html = text => new Response(text, { headers: { 'content-type': 'text/html' } });
const audio = () => new Response(new Uint8Array([82,73,70,70]), { headers: { 'content-type': 'audio/wav' } });
const flush = async () => { for (let i = 0; i < 12; i++) await new Promise(resolve => setImmediate(resolve)); };

test('Suno short link uses published canonical identity and the existing host route', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink'), calls = [];
    const result = await m.readMusicLink(share, { hostProxy: true, fetcher: async (url, options) => {
        calls.push([url, options]);
        if (!url.startsWith('/proxy/')) throw new TypeError('Failed to fetch');
        const target = decodeURIComponent(url.slice('/proxy/'.length));
        if (target === share) return html(`<link rel="canonical" href="${songPage}">`);
        if (target === songPage) return html(`<meta property="og:title" content="本曲"><meta property="og:audio" content="${mediaUrl}">`);
        assert.equal(target, mediaUrl); return audio();
    }});
    assert.equal(result.blob.size, 4); assert.equal(result.sourceUrl, share); assert.equal(result.name, '本曲');
    assert.equal(calls.length, 6); assert.ok(calls.every(([, options]) => options.credentials === 'omit'));
    assert.ok(calls.every(([, options]) => !options.headers));
});

test('known audio plays directly when fetch cannot read cross-origin bytes', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    const result = await m.readMusicLink(mediaUrl, { hostProxy: false, fetcher: async () => { throw new TypeError('Failed to fetch'); } });
    assert.equal(result.url, mediaUrl); assert.equal(result.streaming, true); assert.equal(result.blob, undefined);
});

test('published audio from a share page can use the same streaming path', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    const result = await m.readMusicLink(songPage, { hostProxy: false, fetcher: async url => {
        if (url === songPage) return html(`<meta property="og:audio" content="${mediaUrl}">`);
        throw new TypeError('Failed to fetch');
    }});
    assert.equal(result.sourceUrl, songPage); assert.equal(result.url, mediaUrl); assert.equal(result.streaming, true);
});

test('HTML song pages are never sent to the audio element as fake media', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    await assert.rejects(m.readMusicLink(songPage, { hostProxy: false, fetcher: async () => { throw new TypeError('Failed to fetch'); } }), { code: 'RMT_MV_LINK_NETWORK' });
});

test('HTTP access denial stops without trying another transport', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink'); let calls = 0;
    await assert.rejects(m.readMusicLink(songPage, { hostProxy: true, fetcher: async () => { calls++; return new Response('denied', { status: 403 }); } }), { code: 'RMT_MV_LINK_HTTP', status: 403 });
    assert.equal(calls, 1);
});

test('local host route is used only for published Suno hosts, never arbitrary or private destinations', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    for (const url of ['https://127.0.0.1/page', 'https://suno.com.evil.example/page', 'https://example.com/page']) {
        const calls = [];
        await assert.rejects(m.readMusicLink(url, { hostProxy: true, fetcher: async u => { calls.push(u); throw new TypeError('Failed to fetch'); } }));
        assert.deepEqual(calls, [url]);
    }
});

test('unavailable host route leaves a clear error instead of importing its response', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink'); let calls = 0;
    await assert.rejects(m.readMusicLink(songPage, { hostProxy: true, fetcher: async url => {
        calls++; if (url.startsWith('/proxy/')) return new Response('unsupported', { status: 404 });
        throw new TypeError('Failed to fetch');
    }}), { code: 'RMT_MV_LINK_NETWORK' }); assert.equal(calls, 2);
});

test('automatic host adaptation does not assume Tauri supplies the web server proxy', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    for (const [protocol, bridge, count] of [['https:', false, 2], ['https:', true, 1], ['tauri:', true, 1]]) {
        f.sb.location = { protocol }; f.sb.__TAURITAVERN__ = bridge ? { abiVersion: 1 } : undefined;
        const calls = [];
        await assert.rejects(m.readMusicLink(songPage, { fetcher: async url => { calls.push(url); throw new TypeError('Failed to fetch'); } }), { code: 'RMT_MV_LINK_NETWORK' });
        assert.equal(calls.length, count);
    }
});

test('the media store keeps online URLs scoped by song and removes them when replaced with a file', async () => {
    const f = await fixture(), m = f.get('extras/mvMedia'), rows = new Map();
    f.sb.indexedDB = { open() {
        const request = { result: { transaction() {
            const tx = { objectStore: () => ({
                put(row) { rows.set(row.key, structuredClone(row)); return { result: row.key }; },
                get(key) { return { result: structuredClone(rows.get(key)) }; },
            }) }; queueMicrotask(() => tx.oncomplete()); return tx;
        } } }; queueMicrotask(() => request.onsuccess()); return request;
    } };
    const a = m.mediaKey('audio', 'chat-A', 'song-A'), b = m.mediaKey('audio', 'chat-A', 'song-B');
    assert.equal(await m.putMedia(a, null, '在线歌曲', { sourceUrl: songPage, mediaUrl }), true);
    assert.equal((await m.getMedia(a)).mediaUrl, mediaUrl); assert.equal(await m.getMedia(b), null);
    assert.equal(await m.putMedia(a, new Blob(['file']), '自己的文件'), true);
    const saved = await m.getMedia(a);
    assert.equal(saved.mediaUrl, undefined); assert.equal(saved.sourceUrl, undefined); assert.equal(saved.blob.size, 4);
});

test('JSON-LD AudioObject is parsed as data; arbitrary scripts and placeholders are ignored', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    assert.equal(m.publicMusicSource(`<script type="application/ld+json">{"@type":"MusicRecording","audio":{"@type":"AudioObject","contentUrl":"${mediaUrl}"}}</script>`, songPage)?.url, mediaUrl);
    assert.equal(m.publicMusicSource(`<script>const x={audio_url:"${mediaUrl}"};</script>`, songPage), null);
    assert.equal(m.publicMusicSource(`<audio src="https://studio-api.prod.suno.com/api/forbidden"></audio>`, songPage), null);
    assert.equal(m.publicMusicSource(`<meta property="og:audio" content="https://cdn1.suno.ai/silence.mp3">`, songPage), null);
    assert.equal(m.publicMusicSource(`<!--<script type="application/ld+json">{"@type":"AudioObject","contentUrl":"${mediaUrl}"}</script>-->`, songPage), null);
});

test('canonical parsing cannot leave Suno or follow an unrelated document', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    assert.equal(m.sunoSongPage(`<meta property="og:url" content="${songPage}">`, share), songPage);
    assert.equal(m.sunoSongPage('<link rel="canonical" href="https://127.0.0.1/private">', share), '');
    assert.equal(m.sunoSongPage(`<script>"<link rel='canonical' href='${songPage}'>"</script>`, share), '');
});

test('cancel settles even when a WebView fetch ignores AbortSignal', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink'), controller = new AbortController();
    const pending = m.readMusicLink(songPage, { signal: controller.signal, hostProxy: false, fetcher: () => new Promise(() => {}) });
    controller.abort(); await assert.rejects(pending, { name: 'AbortError' });
});

test('cancel also settles a stalled response body and never enables streaming after cancellation', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink'), controller = new AbortController();
    const pending = m.readMusicLink(mediaUrl, { signal: controller.signal, fetcher: async () => ({ ok: true, url: mediaUrl, headers: new Headers({ 'content-type': 'audio/mpeg' }), blob: () => new Promise(() => {}) }) });
    await flush(); controller.abort(); await assert.rejects(pending, { name: 'AbortError' });
});

async function setup(stored = new Map()) {
    const f = await ui(fixture), mv = f.get('extras/mv'), errors = [], writes = [];
    f.sb.document.querySelector = () => null;
    f.sb.toastr = { error: message => errors.push(message), success() {}, info() {} };
    const song = { id: 'ONLINE', title: '在线歌曲', lyrics: '[Verse 1]\n一句\n[Chorus]\n二句\n[End]' };
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.host.chatMetadata[mv.MV_KEY] = { songs: { ONLINE: { id: 'ONLINE', version: 1, duration: 100,
        settings: { output: 'tegaki', range: 'full', appear: 'none' }, tegaki: { range: 'full', lyric: 'none', introSeconds: 0, outroSeconds: 0 },
        timing: { taps: { 0: 0, 1: 50 }, lineTaps: { '0:0': 0 } }, shots: [{ id: 'A', sectionIndex: 0, lyric: '一句', plain: 'room', who: 'none' }, { id: 'B', sectionIndex: 1, lyric: '二句', plain: 'room', who: 'none' }] } } };
    f.get('extras/mvMedia').getMedia = async key => stored.get(key) || null;
    f.get('extras/mvMedia').putMedia = async (key, blob, name, details) => { const row = { blob, name, ...details }; writes.push(row); stored.set(key, row); return true; };
    const input = { value: mediaUrl };
    f.body.querySelector = selector => selector === '[data-rmt-mv-music-link]' ? input : null;
    f.sb.fetch = async () => { throw new TypeError('Failed to fetch'); };
    f.mvui.openMv({ songId: song.id }); f.click('go-tegaki'); f.click('editor-drawer', 'audio');
    const complete = async () => { const probe = f.audios.at(-1); probe.duration = 120; probe.onloadedmetadata(); await flush(); };
    return { ...f, mv, input, stored, writes, errors, complete };
}

test('streaming music uses existing play/pause/seek and line marking, with no separate player', async () => {
    const f = await setup(); try {
        f.click('audio-link'); await flush(); await f.complete();
        assert.equal(f.writes[0].blob, null); assert.equal(f.writes[0].mediaUrl, mediaUrl);
        f.click('play'); await flush(); const audio = f.audios.at(-1); assert.equal(audio.src, mediaUrl); assert.equal(audio.paused, false);
        f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-seek]', value: '37.5' } });
        f.click('tap-line', '1:0'); assert.equal(audio.currentTime, 37.5); assert.equal(f.mv.readMv(f.host, 'ONLINE').timing.lineTaps['1:0'], 37.5);
        f.click('play'); await flush(); assert.equal(audio.paused, true); assert.doesNotMatch(f.body.innerHTML, /<iframe/);
    } finally { f.mvui.disposeMv(); }
});

test('saved remote track restores locally scoped source and existing timing', async () => {
    const rows = new Map(), first = await setup(rows);
    first.click('audio-link'); await flush(); await first.complete(); first.mvui.disposeMv();
    const second = await setup(rows); try { await flush(); await second.complete(); second.click('play'); await flush(); assert.equal(second.audios.at(-1).src, mediaUrl); assert.equal(second.mv.readMv(second.host, 'ONLINE').timing.taps[1], 50); } finally { second.mvui.disposeMv(); }
});

test('export obtains readable audio before recording the online track', async () => {
    const f = await setup(); try {
        f.click('audio-link'); await flush(); await f.complete(); f.sb.fetch = async () => audio();
        const recorder = recorderHost(f); f.click('export'); await flush();
        assert.match(f.audios.at(-1).src, /^blob:/); assert.equal(recorder.recorders[0].state, 'recording'); assert.equal(recorder.contexts.length, 1);
        f.click('export-stop'); assert.equal(recorder.contexts[0].closed, true);
    } finally { f.mvui.disposeMv(); }
});

test('unreadable export audio never produces a silently muted video and preserves the preview track', async () => {
    const f = await setup(); try {
        f.click('audio-link'); await flush(); await f.complete(); const before = JSON.stringify(f.mv.readMv(f.host, 'ONLINE'));
        const recorder = recorderHost(f); f.click('export'); await flush();
        assert.equal(recorder.recorders.length, 0); assert.ok(f.errors.some(text => /用于导出的音频/.test(text)));
        assert.equal(JSON.stringify(f.mv.readMv(f.host, 'ONLINE')), before); f.click('play'); await flush(); assert.equal(f.audios.at(-1).src, mediaUrl); assert.equal(f.audios.at(-1).paused, false);
    } finally { f.mvui.disposeMv(); }
});

test('cancelling export stops a non-cooperative audio fetch before any recording starts', async () => {
    const f = await setup(); try {
        f.click('audio-link'); await flush(); await f.complete(); f.sb.fetch = () => new Promise(() => {});
        const recorder = recorderHost(f); f.click('export'); await flush(); f.click('export-stop'); await flush();
        assert.equal(recorder.recorders.length, 0); f.click('play'); await flush(); assert.equal(f.audios.at(-1).paused, false);
    } finally { f.mvui.disposeMv(); }
});
