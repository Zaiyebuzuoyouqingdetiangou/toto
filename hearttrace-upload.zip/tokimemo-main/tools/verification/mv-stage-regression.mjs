import test from 'node:test';
import assert from 'node:assert/strict';
import { stageSetup, stageRaw, song } from './mv-stage-fixture.mjs';
test('one shared procedural background serves two groups and does not request an extra image', async () => {
    const f = await stageSetup();
    assert.equal(f.record.stage?.backgrounds.length, 1, 'shared stage must survive normalization');
    assert.equal(f.record.groups[0].stageBackground, f.record.groups[1].stageBackground);
    assert.equal(f.record.groups[0].layer, 'cutout');
    assert.deepEqual(Array.from(f.mv.assetKeys(f.record, song)), ['G1:D1', 'G2:D1']);
});

test('a shared image background is one editable asset and one paid request across groups', async () => {
    const f = await stageSetup('image'), keys = Array.from(f.mv.assetKeys(f.record, song));
    assert.equal(keys.filter(k => k.startsWith('stage:')).length, 1);
    const key = keys.find(k => k.startsWith('stage:')); let calls = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = async prompt => { calls++; assert.match(prompt, /empty paper stage/); return '/user/images/shared.png'; };
    assert.equal((await f.mv.drawAsset(song.id, key)).pending, false);
    assert.equal(calls, 1);
    assert.equal(f.mv.assetOf(f.mv.readMv(f.host, song.id), key).image.url, '/user/images/shared.png');
});

test('stage prompts separate the character and stage while old expression records stay full-frame', async () => {
    const f = await stageSetup();
    const prompt = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
    assert.match(prompt, /white background/); assert.doesNotMatch(prompt, /empty paper stage/);
    assert.match(prompt, /horizontal 16:9/);
    const old = stageRaw(); delete old.stage; for (const g of old.groups) delete g.stageBackground;
    const legacy = f.mv.buildShots(f.json(old), f.bank, 2, f.record.settings);
    assert.equal(legacy.groups[0].layer, 'full');
    assert.equal(legacy.stage, undefined);
});

test('layer clocks retain the song anchor when only lyrics or the pose changes', async () => {
    const f = await stageSetup(), stage = f.get('extras/mvStage');
    const before = JSON.stringify(f.record.timing), rows = f.mv.shotTimeline(f.record, song).rows;
    assert.deepEqual(Array.from(rows.slice(0, 3), r => r.start), [0, 4, 8]);
    const held = stage.state(f.record, rows, 1, 4.1);
    assert.equal(held.backgroundTime, 4.1); assert.equal(held.poseTime, 4.1);
    assert.ok(Math.abs(held.textTime - 0.1) < 1e-9);
    const changed = stage.state(f.record, rows, 2, 8.1);
    assert.equal(changed.backgroundTime, 8.1); assert.ok(Math.abs(changed.poseTime - 0.1) < 1e-9);
    assert.equal(JSON.stringify(f.record.timing), before);
    const again = stage.state(f.record, rows, 1, 4.1);
    assert.deepEqual(JSON.parse(JSON.stringify(again)), JSON.parse(JSON.stringify(held)));
});

test('procedural scenes are ready without a paid background and manual clips remain selectable', async () => {
    const f = await stageSetup();
    for (const group of f.record.groups) group.diffs[0].image = { url: '/person.png', editMode: 'cutout' };
    assert.deepEqual(JSON.parse(JSON.stringify(f.mv.completedMvRanges(f.record, song))), [{ range: 'custom', rangeFrom: 0, rangeTo: 1 }]);
    f.record.stage.backgrounds[0].kind = 'image';
    assert.equal(f.mv.completedMvRanges(f.record, song).length, 0);
    f.record.stage.backgrounds[0].image = { url: '/stage.png' };
    assert.equal(f.mv.completedMvRanges(f.record, song).length, 1);
    f.record.exportRange = { range: 'custom', rangeFrom: 1, rangeTo: 1 };
    const exported = f.mv.exportRecord(f.record, song);
    assert.equal(f.mv.playRange(exported, song).start, 8);
    assert.equal(exported.stage.backgrounds[0].image.url, '/stage.png');
});

test('a shared background cannot be drawn twice concurrently or overwrite a newer edit', async () => {
    const f = await stageSetup('image'); let resolve, count = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = () => { count++; return new Promise(done => { resolve = done; }); };
    const key = f.mv.assetKeys(f.record, song)[0], a = f.mv.drawAsset(song.id, key);
    assert.equal(await f.mv.drawAsset(song.id, key), null); assert.equal(count, 1);
    f.mv.patchStageBackground(song.id, 'S1', { kind: 'window' });
    resolve('/late-shared.png');
    assert.equal((await a).pending, true);
    assert.equal(f.mv.assetOf(f.mv.readMv(f.host, song.id), key).image, null);
});

test('shared pose redraw updates its reusable asset and remains editable', async () => {
    const f = await stageSetup(); let resolve, options;
    f.get('generation/cgImageCore').invokeImageGeneration = (prompt, context, o) => { options = o; return new Promise(done => { resolve = done; }); };
    const drawing = f.mv.drawFrame(song.id, f.record.shots[0].id);
    assert.equal(f.mv.isFrameDrawing(f.mv.mvScope(f.host), song.id, f.record.shots[0].id), true);
    assert.equal(options.orientation, 'landscape');
    resolve('/new-pose.png'); assert.equal((await drawing).pending, false);
    const saved = f.mv.readMv(f.host, song.id);
    assert.equal(saved.shots[0].image, null);
    assert.equal(f.mv.shotImage(saved, saved.shots[0]).url, '/new-pose.png');
    assert.equal(f.mv.shotImage(saved, saved.shots[1]).url, '/new-pose.png');
    const edit = f.mv.captureAssetEdit(song.id, 'G1:D1');
    await f.mv.saveAssetEdit(edit, { image: { url: '/confirmed.png', editMode: 'cutout' } });
    assert.equal(f.mv.shotImage(f.mv.readMv(f.host, song.id), saved.shots[0]).editMode, 'cutout');
});

test('continuation preserves edited shared art and reuses IDs while appending new backgrounds', async () => {
    const f = await stageSetup('image');
    f.record.shots = f.record.shots.filter(s => s.sectionIndex === 0); f.record.groups = f.record.groups.slice(0, 1);
    f.record.stage.backgrounds[0].image = { url: '/user-edited.png' };
    let prompt = '', calls = 0;
    f.get('generation/client').requestJson = async value => { prompt = value; calls++; return f.json({
        stage: { backgrounds: [{ id: 'S1', kind: 'image', prompt: 'must not overwrite saved scene' }, { id: 'extra', kind: 'paper' }] },
        groups: [{ id: 'new', stageBackground: 'extra', diffs: [{ id: 'D1', imagePrompt: 'one still, hands clasped' }] }],
        frames: [{ sectionIndex: 1, lyric: '再抬眼', group: 'G1', diff: 'D1', stage: { background: 'S1', tone: 'accent' } },
            { sectionIndex: 1, lyric: '再抬眼', group: 'new', diff: 'D1' }] }); };
    const result = await f.mv.continueStoryboard(song.id);
    assert.equal(result.pending, false); assert.equal(calls, 1); assert.match(prompt, /reusableBackgrounds/);
    const saved = f.mv.readMv(f.host, song.id);
    assert.equal(saved.stage.backgrounds.length, 2);
    assert.equal(saved.stage.backgrounds[0].image.url, '/user-edited.png');
    assert.equal(saved.stage.backgrounds[0].prompt, 'empty paper stage');
    assert.equal(saved.shots[2].stage.background, 'S1');
    assert.equal(saved.shots[3].stage.background, 'S2');
    assert.equal(saved.groups[1].stageBackground, 'S2');
    assert.deepEqual(JSON.parse(JSON.stringify(saved.timing)), JSON.parse(JSON.stringify(f.record.timing)));
});

test('late storyboard cannot replace a manually changed shared background', async () => {
    const f = await stageSetup(); let resolve;
    f.get('generation/client').requestJson = () => new Promise(done => { resolve = done; });
    const pending = f.mv.generateStoryboard(song.id, f.record.settings);
    f.mv.patchStageBackground(song.id, 'S1', { colors: ['#123456', '#abcdef', '#888888'] });
    resolve(f.json(stageRaw()));
    assert.equal((await pending).pending, true);
    assert.equal(f.mv.readMv(f.host, song.id).stage.backgrounds[0].colors[0], '#123456');
});

test('unrecognized optional stage data falls back without blocking a usable storyboard', async () => {
    const f = await stageSetup(), data = stageRaw(); data.stage = { backgrounds: 'malformed' };
    const built = f.mv.buildShots(f.json(data), f.bank, 2, f.record.settings);
    assert.equal(built.shots.length, 4); assert.equal(built.groups[0].layer, 'full');
    const stage = f.get('extras/mvStage').prepare({ backgrounds: [{ id: 'main', kind: 'javascript:bad', motion: 'execute()', colors: ['bad'] }, { id: 'S1', kind: 'solid' }] });
    assert.equal(stage.backgrounds.length, 2); assert.notEqual(stage.resolve('main'), stage.resolve('S1'));
    assert.equal(stage.backgrounds[0].motion, 'still');
    assert.ok(stage.backgrounds[0].colors.every(c => /^#[0-9a-f]{6}$/i.test(c)));
});

test('one storyboard request saves executable stage data and its lyric mode', async () => {
    const f = await stageSetup(); let calls = 0, prompt = '';
    f.get('generation/client').requestJson = async p => { calls++; prompt = p; return f.json(stageRaw()); };
    assert.equal((await f.mv.generateStoryboard(song.id, f.record.settings)).pending, false);
    assert.equal(calls, 1); assert.equal(f.mv.readMv(f.host, song.id).tegaki.lyric, 'stage');
    const example = JSON.parse(prompt.split('\n').at(-1));
    assert.equal(example.stage.backgrounds.length, 1);
    assert.equal(example.frames[0].diff, example.frames[1].diff);
    assert.notEqual(example.frames[0].stage.layout, example.frames[1].stage.layout);
    assert.doesNotMatch(prompt, /其余段落尽量用新的构图|主构图的一个姿势短停→/);
});
