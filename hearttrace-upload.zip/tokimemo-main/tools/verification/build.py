#!/usr/bin/env python3
"""Rebuild this release's simple module registry from source.

The frozen initialization order was recovered from the supplied production
bundle; each baseline module transformation is checked byte for byte before use.
No production module body is copied from the bundle.
"""
from pathlib import Path
import hashlib, json, re, sys, posixpath, os
HERE = Path(__file__).resolve().parent
ROOT = Path(sys.argv[1]).resolve()
BASE = Path(os.environ.get('BASELINE_ROOT', str(HERE.parent / 'baseline')))
ORDER = json.loads((HERE/'runtime-order.json').read_text())
IMPORT = re.compile(r'^import\s+(\*\s+as\s+\w+|\{[^}]+\})\s+from\s+[\'"]([^\'"]+)[\'"];\s*$', re.M)
EXPORT = re.compile(r'^export (?:(?:async )?function\s+|const\s+)([A-Za-z_$][\w$]*)', re.M)
def token(path): return re.sub(r'[^A-Za-z0-9_]', '_', path)
def module(path): return '__m_' + token(path)
def compile_module(path, source):
    exports = [name for pattern in [r'^export async function\s+([A-Za-z_$][\w$]*)', r'^export function\s+([A-Za-z_$][\w$]*)', r'^export const\s+([A-Za-z_$][\w$]*)'] for name in re.findall(pattern,source,re.M)]
    def imported(match):
        spec, rel = match.groups()
        if not rel.startswith('.'): raise ValueError('Unexpected external import: '+rel)
        dep = posixpath.normpath(posixpath.join(posixpath.dirname(path), rel))
        if not (ROOT/'src'/dep).is_file(): raise ValueError('Missing dependency: '+dep)
        if spec.startswith('*'): return 'const ' + spec.split()[-1] + ' = ' + module(dep) + ';'
        names = []
        for item in spec[1:-1].split(','):
            parts = item.strip().split(' as ')
            if not parts[0]: continue
            names.append('const '+parts[-1]+' = '+module(dep)+'.'+parts[0]+';')
        return '\n'.join(names)
    bindings = []
    body = source
    for lead, spec in [('', r'\*\s+as\s+\w+'), ('', r'\{[^}]+\}')]:
        pattern = re.compile(r'^'+lead+r'import\s+('+spec+r')\s+from\s+[\'"]([^\'"]+)[\'"];\s*$', re.M)
        def remove_import(match):
            bindings.append(imported(match)); return ''
        body = pattern.sub(remove_import, body)
    body = re.sub(r'^export (?=(?:async )?function\s|const\s)', '', body, flags=re.M)
    if re.search(r'^(import|export)\s',body,re.M): raise ValueError('Unsupported module syntax: '+path)
    return 'function __init_'+token(path)+'() {\n// MODULE: '+path+'\n'+'\n'.join(bindings)+'\n'+body+'\n'+'\n'.join(module(path)+'.'+name+' = '+name+';' for name in exports)+'\n}\n', exports
def closure(path, found):
    if path in found: return
    found.add(path)
    source=(ROOT/'src'/path).read_text()
    for match in IMPORT.finditer(source):
        dep=posixpath.normpath(posixpath.join(posixpath.dirname(path),match.group(2)))
        closure(dep,found)
found=set(); closure('heartbeatMemories.js',found)
new=sorted(found-set(ORDER))
order=new+[p for p in ORDER if p in found]
if set(ORDER)-found: raise ValueError('Unexpected removed runtime module')
baseline_bundle=(BASE/'dist/heartbeatMemories.bundle.js').read_text() if BASE.is_dir() else ''
baseline_errors=[]
baseline_paths=[p for p in order if (BASE/'src'/p).is_file()] if baseline_bundle else []
for p in baseline_paths:
    block,_=compile_module(p,(BASE/'src'/p).read_text())
    if block not in baseline_bundle: baseline_errors.append(p)
if baseline_errors:
    # r84.184's bundler retained different empty lines around imports/exports.
    # Accept only blank-line differences; never ignore text, indentation or literals.
    for p in baseline_errors:
        block,_=compile_module(p,(BASE/'src'/p).read_text())
        marker='function __init_'+token(p)+'() {\n'
        original=marker+re.split(r'\n(?:function __init_|__init_)', baseline_bundle.split(marker,1)[1], maxsplit=1)[0]
        def canonical(value):
            lines=[line for line in value.splitlines() if line.strip()]
            assignments=[line for line in lines if line.startswith(module(p)+'.')]
            return [line for line in lines if line not in assignments]+sorted(assignments)
        if canonical(original)!=canonical(block):
            import difflib
            print(''.join(difflib.unified_diff(original.splitlines(True),block.splitlines(True))))
            raise ValueError('Baseline nonblank mismatch: '+p)
parts=[]; hasher=hashlib.sha256()
for p in sorted(found): hasher.update(p.encode()+b'\0'+(ROOT/'src'/p).read_bytes()+b'\0')
parts.append('// GENERATED FILE. Do not edit by hand.\n// Source modules: '+str(len(found))+'\n// Source SHA-256: '+hasher.hexdigest()+'\n// Build: python3 tools/verification/build.py <source-root>\n\n')
parts.append('\n'.join('const '+module(p)+' = Object.create(null);' for p in sorted(found))+'\n\n')
root_exports=[]
for p in order:
    block,exports=compile_module(p,(ROOT/'src'/p).read_text()); parts.append(block+'\n')
    if p=='heartbeatMemories.js': root_exports=exports
parts.append('\n'.join('__init_'+token(p)+'();' for p in order)+'\n\n')
parts.append('\n'.join('export const '+name+' = __m_heartbeatMemories_js.'+name+';' for name in root_exports)+'\n')
output=''.join(parts)
(ROOT/'dist/heartbeatMemories.bundle.js').write_text(output)
print(json.dumps({'modules':len(found),'baseline_module_bodies_verified':len(baseline_paths),'source_sha256':hasher.hexdigest(),'bundle_sha256':hashlib.sha256(output.encode()).hexdigest()}))
