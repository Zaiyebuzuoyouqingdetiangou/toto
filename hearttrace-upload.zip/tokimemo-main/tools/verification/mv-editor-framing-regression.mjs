import test from 'node:test';
import assert from 'node:assert/strict';
import { scene, native } from './mv-stage-canvas-fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
import { stageSetup } from './mv-stage-fixture.mjs';

// Three separated landmarks stand for the left/right hands or both eyes.
// All must survive composition, with the original spacing and aspect ratio.
function insert() {
    const c = native.createCanvas(320, 180), g = c.getContext('2d');
    g.fillStyle = '#d99a77'; g.fillRect(8, 74, 304, 32);
    g.fillStyle = '#ed314a'; g.fillRect(20, 82, 18, 16);
    g.fillStyle = '#375ee8'; g.fillRect(151, 82, 18, 16);
    g.fillStyle = '#ed314a'; g.fillRect(282, 82, 18, 16);
    return { url: c.toDataURL(), editMode: 'cutout', split: 'none' };
}

for (const ratio of ['16:9', '9:16']) test(`local detail keeps both edges and source proportions in ${ratio}`, async () => {
    const f = await scene({ ratio, imageBackground: true, createArt: insert,
        configure: r => { r.groups[0].scale = 'close'; r.groups[0].composition = '手部特写'; r.tegaki.lyric = 'off'; } });
    try {
        const before = JSON.stringify(f.record()); f.seek(1);
        const g = f.preview.getContext('2d'), scale = Math.min(f.w / 320, f.h / 180);
        for (const sx of [29, 160, 291]) {
            const x = Math.round((f.w - 320 * scale) / 2 + sx * scale), y = Math.round(f.h / 2);
            const rgb = Array.from(g.getImageData(x, y, 1, 1).data).slice(0, 3);
            assert.deepEqual(rgb, sx === 160 ? [55, 94, 232] : [237, 49, 74], 'landmarks must not be zoomed off screen');
        }
        assert.deepEqual(Array.from(g.getImageData(2, 2, 1, 1).data), [22, 114, 69, 255], 'unused space retains the shared background');
        assert.equal(JSON.stringify(f.record()), before); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

function node() {
    return { textContent: '', innerHTML: '', dataset: {}, style: { setProperty(k, v) { this[k] = v; } },
        setAttribute(k, v) { this[k] = v; }, removeAttribute(k) { delete this[k]; } };
}
async function player() {
    const f = await ui(stageSetup), label = node(), panel = node(), film = node(), slider = node();
    for (const group of f.record.groups) group.diffs[0].image = { url: '/saved.png' };
    let writes = 0, html = '';
    Object.defineProperty(f.body, 'innerHTML', { get: () => html, set: value => { html = value; writes++; } });
    const nodes = { '[data-rmt-mv-current]': label, '[data-rmt-mv-shot-panel]': panel, '[data-rmt-mv-filmstrip]': film, '[data-rmt-mv-seek]': slider };
    f.sb.document.querySelector = s => nodes[s] || null;
    f.body.querySelector = s => nodes[s] || null;
    f.sb.document.querySelectorAll = () => [];
    f.mvui.openMv({ songId: f.song.id });
    return { ...f, label, panel, film, slider, writes: () => writes,
        seek: t => f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-seek]', value: String(t) } }) };
}

test('seeking follows the visible shot and its editor without replacing the player or saved data', async () => {
    const f = await player();
    try {
        const before = JSON.stringify(f.mv.readMv(f.host, f.song.id)), writes = f.writes();
        f.seek(9);
        assert.match(f.label.textContent, /第 3 镜/); assert.match(f.panel.innerHTML, /第 3 镜/);
        assert.equal(f.writes(), writes, 'seek must not reconstruct the page/audio/canvas');
        assert.equal(JSON.stringify(f.mv.readMv(f.host, f.song.id)), before);
        f.click('set-motion', 'push');
        assert.equal(f.mv.readMv(f.host, f.song.id).shots[2].motion, 'push');
        assert.notEqual(f.mv.readMv(f.host, f.song.id).shots[0].motion, 'push');
    } finally { f.mvui.disposeMv(); }
});

test('seeking follows later thumbnail pages but keeps a focused edit field intact', async () => {
    const f = await player();
    try {
        f.seek(1); const before = f.panel.innerHTML;
        f.sb.document.activeElement = { closest: s => s === '.rmt-mve-tools' ? {} : null, matches: () => true };
        f.seek(9); assert.match(f.label.textContent, /第 3 镜/); assert.equal(f.panel.innerHTML, before);
        f.sb.document.activeElement = null; f.seek(9); assert.match(f.panel.innerHTML, /第 3 镜/);
        const record = f.mv.readMv(f.host, f.song.id);
        record.shots = Array.from({ length: 40 }, (_, i) => ({ ...record.shots[0], id: 'F' + i, sectionIndex: 0, hold: 1 }));
        f.mvui.renderMv(); const row = f.mv.playbackTimeline(record, f.song).rows[29];
        f.seek((row.start + row.end) / 2);
        assert.match(f.label.textContent, /第 30 镜/); assert.match(f.film.innerHTML, /第 30 镜/);
        assert.equal((f.film.innerHTML.match(/data-rmt-mv="select-shot"/g) || []).length, 12);
    } finally { f.mvui.disposeMv(); }
});

test('audio-free playback follows the actual clock across shots without rebuilding the player', async () => {
    const f = await player(); let clock = 1000;
    f.sb.performance.now = () => clock;
    try {
        f.seek(0); await f.click('play');
        // handleMvClick intentionally starts playback asynchronously.
        await new Promise(resolve => setImmediate(resolve));
        const writes = f.writes(); clock = 10000;
        for (const [id, tick] of [...f.frames]) { f.frames.delete(id); tick(); }
        assert.match(f.label.textContent, /第 3 镜/); assert.match(f.panel.innerHTML, /第 3 镜/);
        assert.equal(f.writes(), writes);
    } finally { f.mvui.disposeMv(); }
});
