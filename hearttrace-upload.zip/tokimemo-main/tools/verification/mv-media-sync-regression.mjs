// Real bundle/public actions and native Canvas. Host, storage, audio and recorder are doubles.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
const require = createRequire(import.meta.url);
const native = require(require.resolve('@napi-rs/canvas', { paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || process.cwd()] }));
const flush = () => new Promise(resolve => setImmediate(resolve));
// Image completion is deliberately batched in 1.0.17, not a synchronous page render.
async function settle() { for (let i = 0; i < 12; i++) await flush(); await new Promise(resolve => setTimeout(resolve, 35)); }
const plain = value => JSON.parse(JSON.stringify(value));
const song = { id: 'SONG_media_sync', title: 'media', lyrics: '[Verse 1]\none\n[Verse 2]\ntwo\n[Chorus]\nthree\n[Outro]\nfour\n[End]' };
function art(color) { const c = native.createCanvas(60, 80); const g = c.getContext('2d'); g.fillStyle = color; g.fillRect(0, 0, 60, 80); return c.toDataURL(); }
const red = art('#ff0000'), blue = art('#0000ff'), green = art('#00ff00');
async function setup({ taps = {}, images = [], layer = 'full', audio = false, storedMedia = {} } = {}) {
    const f = await ui(fixture), mv = f.get('extras/mv'), errors = [], media = new Map(Object.entries(storedMedia)), decodes = [], thumbnails = new Map();
    // Real elements receive their local blob URL in place, without replacing the page.
    f.body.querySelectorAll = selector => selector === '[data-rmt-mv-local]' ? [...f.body.innerHTML.matchAll(/data-rmt-mv-local="([^"]+)"/g)].map(([, key]) => {
        if (!thumbnails.has(key)) thumbnails.set(key, { dataset: { rmtMvLocal: key }, src: '' });
        return thumbnails.get(key);
    }) : [];
    f.sb.toastr = { error: message => errors.push(message), success() {}, info() {}, warning() {} };
    const canvas = native.createCanvas(540, 960); f.canvas.getContext = () => canvas.getContext('2d');
    f.sb.Image = class extends native.Image { set src(value) { super.src = value === '/user/images/redraw.png' ? green : value; decodes.push(this.decode()); } };
    f.sb.URL.createObjectURL = blob => blob.dataURL || 'blob:audio';
    f.get('extras/mvMedia').getMedia = async key => media.get(key) || null;
    f.get('extras/mvMedia').putMedia = async (key, blob) => { media.set(key, { blob }); return true; };
    f.get('core/cache').loadSession = () => ({ songs: [song, { ...song, id: 'OTHER' }] });
    let calls = 0;
    f.get('generation/client').generate = async () => { calls++; throw Error('unexpected text request'); };
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { calls++; return '/user/images/redraw.png'; };
    const record = { id: song.id, version: 2, storyRevision: 'initial', createdAt: 1, updatedAt: 1,
        settings: { output: 'tegaki', range: 'full', ratio: '9:16', appear: 'none' },
        tegaki: { range: 'full', lyric: 'none', introSeconds: 0, outroSeconds: 0, showMotif: false }, duration: 120,
        timing: { taps, shift: 0, lineTaps: { '0:0': 0 } },
        groups: [{ id: 'G', layer, motion: 'still', diffs: [{ id: 'D', image: { url: red, split: 'none' } }] }],
        shots: ['one', 'two', 'three', 'four'].map((lyric, i) => ({ id: 'S' + i, sectionIndex: i, lyric,
            group: 'G', diff: 'D', who: 'none', plain: 'room', imagePrompt: 'room', motion: 'still', cut: 'cut', image: images[i] || null })) };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    const saved = () => mv.readMv(f.host, song.id);
    f.mvui.openMv({ songId: song.id });
    if (audio) { f.upload(); f.audios.at(-1).onloadedmetadata(); }
    const seek = t => f.mvui.handleMvClick({ target: { closest: () => ({ dataset: { rmtMv: 'seek' },
        getBoundingClientRect: () => ({ left: 0, width: mv.shotTimeline(saved(), song).total }) }) }, clientX: t, preventDefault() {} });
    const preview = async t => { f.click('go-tegaki'); seek(t); await settle(); await Promise.all(decodes); seek(t); return [...canvas.getContext('2d').getImageData(270, 480, 1, 1).data]; };
    const importImage = (id, dataURL = blue) => f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-image]',
        dataset: { rmtMvId: id }, files: [{ type: 'image/png', name: 'own.png', dataURL }] } });
    const at = seconds => { f.audios.at(-1).currentTime = seconds; };
    return { ...f, mv, saved, media, thumbnails, errors, calls: () => calls, seek, preview, canvas, decodes, importImage, at };
}
function color(pixel, channel) { assert.ok(pixel[channel] > 200 && pixel.filter((_, i) => i < 3 && i !== channel).every(v => v < 45), 'unexpected scene: ' + pixel); }
const targetLabel = f => f.body.innerHTML.match(/class="rmt-mv-tap[^]*?<b>([^<]*)<\/b>/)?.[1];
function enabled(f) { assert.doesNotMatch(f.body.innerHTML, /class="rmt-mv-tap[^>]*\bdisabled\b/); }

test('saved per-shot local images appear after reopening v2 and do not replace shared sibling images', async () => {
    const f = await setup({ images: [{ local: 'old-import', at: 10 }], taps: { 0: 0, 1: 30, 2: 60, 3: 90 }, storedMedia: { 'old-import': { blob: { dataURL: blue } } } });
    try {
        f.media.set('old-import', { blob: { dataURL: blue } });
        f.mvui.disposeMv(); f.mvui.openMv({ songId: song.id });
        color(await f.preview(10), 2); assert.equal(f.thumbnails.get('old-import').src, blue);
        color(await f.preview(40), 0); assert.equal(f.calls(), 0);
        assert.equal(f.saved().groups[0].diffs[0].image.url, red);
    } finally { f.mvui.disposeMv(); }
});
test('importing a full scene takes effect in v2 preview without automatic splitting or cutout', async () => {
    const f = await setup({ layer: 'cutout', taps: { 0: 0, 1: 30, 2: 60, 3: 90 } });
    try {
        f.importImage('S0'); await settle(); color(await f.preview(10), 2);
        assert.ok(f.saved().shots[0].image.local); assert.equal(f.calls(), 0);
        assert.deepEqual(plain(f.mv.completedMvRanges(f.saved(), song)), [{ range: 'custom', rangeFrom: 0, rangeTo: 0 }]);
        assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});
test('single-shot redraw is visible in v2 while sibling shots retain their shared art', async () => {
    const f = await setup({ taps: { 0: 0, 1: 30, 2: 60, 3: 90 } });
    try { await f.mv.drawFrame(song.id, 'S0'); color(await f.preview(10), 1); color(await f.preview(40), 0); assert.equal(f.calls(), 1); }
    finally { f.mvui.disposeMv(); }
});
test('manual image failure preserves the old reference and blob', async () => {
    const f = await setup({ images: [{ local: 'old-import', at: 10 }] });
    try {
        f.media.set('old-import', { blob: { dataURL: blue } });
        f.get('extras/mvMedia').putMedia = async () => false;
        f.importImage('S0', green); await settle();
        assert.equal(f.saved().shots[0].image.local, 'old-import'); assert.equal(f.media.get('old-import').blob.dataURL, blue);
        assert.equal(f.errors.length, 1);
    } finally { f.mvui.disposeMv(); }
});
test('two rapid imports keep the last chosen image when storage finishes out of order', async () => {
    const f = await setup(); const writes = [];
    try {
        f.get('extras/mvMedia').putMedia = (key, blob) => new Promise(resolve => writes.push({ key, blob, resolve }));
        f.importImage('S0', blue); f.importImage('S0', green);
        assert.equal(writes.length, 2); assert.notEqual(writes[0].key, writes[1].key);
        for (const i of [1, 0]) { f.media.set(writes[i].key, { blob: writes[i].blob }); writes[i].resolve(true); await settle(); }
        assert.equal(f.saved().shots[0].image.local, writes[1].key); color(await f.preview(1), 1);
    } finally { f.mvui.disposeMv(); }
});
test('late import cannot overwrite a replacement storyboard and remains recoverable', async () => {
    const f = await setup(); let finish;
    try {
        f.get('extras/mvMedia').putMedia = () => new Promise(resolve => { finish = resolve; });
        f.importImage('S0', blue);
        f.mv.patchRecord(song.id, { storyRevision: 'new-story', shots: f.saved().shots.map(s => ({ ...s, plain: 'new room', image: { url: green } })) });
        finish(true); await settle(); assert.equal(f.saved().shots[0].image.url, green);
        assert.equal(f.mv.pendingMv(f.mv.mvScope(f.host)).length, 1); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});
test('late imported image stays bound to the original song after navigation', async () => {
    const f = await setup(); let finish;
    try {
        f.get('extras/mvMedia').putMedia = () => new Promise(resolve => { finish = resolve; });
        f.importImage('S0'); f.mvui.openMv({ songId: 'OTHER' }); finish(true); await settle();
        assert.ok(f.saved().shots[0].image.local); assert.equal(f.mv.readMv(f.host, 'OTHER'), null);
    } finally { f.mvui.disposeMv(); }
});
test('a new storyboard revision holds a late import even when its shot fields are identical', async () => {
    const f = await setup(); let finish;
    try {
        f.get('extras/mvMedia').putMedia = () => new Promise(resolve => { finish = resolve; });
        f.importImage('S0'); f.mv.patchRecord(song.id, { storyRevision: 'replacement' }); finish(true); await settle();
        assert.equal(f.saved().shots[0].image, null); assert.equal(f.mv.pendingMv(f.mv.mvScope(f.host)).length, 1);
    } finally { f.mvui.disposeMv(); }
});
test('changing chats during image storage cannot write the imported image into the new chat', async () => {
    const f = await setup(); let finish;
    try {
        const scope = f.mv.mvScope(f.host);
        f.get('extras/mvMedia').putMedia = () => new Promise(resolve => { finish = resolve; }); f.importImage('S0');
        const other = { ...f.host, chatId: 'B', chatMetadata: {} }; f.switchTo(other); finish(true); await settle();
        assert.equal(other.chatMetadata[f.mv.MV_KEY], undefined); assert.equal(f.mv.pendingMv(scope).length, 1);
    } finally { f.mvui.disposeMv(); }
});
test('a missing imported blob stops export with a message instead of exporting its replaced picture', async () => {
    const f = await setup({ images: [{ local: 'missing-import' }] }); let started = false;
    try {
        f.click('go-tegaki'); f.mv.patchRecord(song.id, { exportRange: { range: 'custom', rangeFrom: 0, rangeTo: 0 } });
        f.sb.MediaStream = class {}; f.sb.AudioContext = class {};
        f.sb.MediaRecorder = class { static isTypeSupported() { return true; } start() { started = true; } };
        const create = f.sb.document.createElement;
        f.sb.document.createElement = tag => tag === 'canvas' ? { captureStream() {} } : create(tag);
        f.click('export'); await settle(); assert.equal(started, false); assert.equal(f.errors.length, 1);
        assert.equal(f.saved().shots[0].image.local, 'missing-import'); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});
test('returning to shared art removes only the chosen shot override', async () => {
    const f = await setup({ images: [{ url: blue }, { url: green }] });
    try {
        await f.preview(1); f.click('select-shot', 'S0'); assert.match(f.body.innerHTML, /data-rmt-mv="use-group-image"/);
        f.click('use-group-image', 'S0'); color(await f.preview(1), 0);
        assert.equal(f.saved().shots[0].image, null); assert.equal(f.saved().shots[1].image.url, green);
    } finally { f.mvui.disposeMv(); }
});
test('completed clip export loads visible imported scenes instead of unavailable replaced assets', async () => {
    const f = await setup({ layer: 'cutout', images: [{ local: 'old-import' }], taps: { 0: 0, 1: 30, 2: 60, 3: 90 }, storedMedia: { 'old-import': { blob: { dataURL: blue } } } });
    let exportCanvas, started = false;
    try {
        f.media.set('old-import', { blob: { dataURL: blue } });
        f.mv.patchRecord(song.id, { exportRange: { range: 'custom', rangeFrom: 0, rangeTo: 0 },
            groups: [{ ...f.saved().groups[0], bg: { local: 'missing-unused-background' }, diffs: [{ id: 'D', image: { local: 'missing-unused-diff' } }] }] });
        color(await f.preview(10), 2);
        f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } };
        f.sb.AudioContext = class {};
        f.sb.MediaRecorder = class { static isTypeSupported() { return true; } constructor(stream) { exportCanvas = stream.tracks[0].canvas; } start() { this.state = 'recording'; started = true; } stop() { this.state = 'inactive'; this.onstop?.(); } };
        const create = f.sb.document.createElement;
        f.sb.document.createElement = tag => {
            if (tag !== 'canvas') return create(tag);
            const c = native.createCanvas(540, 960); c.style = {}; c.remove = () => {};
            const track = { canvas: c, stop() {} }; c.captureStream = () => ({ getTracks: () => [track], getVideoTracks: () => [track] }); return c;
        };
        f.click('export'); await settle(); assert.equal(started, true, f.errors.join(';'));
        color([...exportCanvas.getContext('2d').getImageData(270, 480, 1, 1).data], 2);
        assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

async function sync(taps = {}, audio = true) {
    const f = await setup({ taps, audio }); f.click('go-sync'); if (audio) { f.click('play'); await settle(); } return f;
}
test('undoing a correction after all sections are timed leaves that section ready to tap again', async () => {
    const f = await sync({ 0: 0, 1: 30, 2: 60, 3: 90 });
    try {
        f.click('select-section', '1'); f.at(32); f.click('tap'); f.click('tap-undo');
        assert.equal(targetLabel(f), '主歌 2开始了'); enabled(f); assert.equal(f.saved().timing.taps[1], 30);
        f.at(31); f.click('tap'); assert.equal(f.saved().timing.taps[1], 31);
        assert.equal(f.saved().timing.lineTaps['0:0'], 0); assert.equal(f.audios.at(-1).paused, false);
    } finally { f.mvui.disposeMv(); }
});
test('undoing an out-of-order section returns to that section, not the first missing one', async () => {
    const f = await sync();
    try {
        f.click('select-section', '2'); f.at(60); f.click('tap'); f.click('tap-undo');
        assert.equal(targetLabel(f), '副歌开始了'); enabled(f); f.at(61); f.click('tap');
        assert.deepEqual(plain(f.saved().timing.taps), { 2: 61 });
    } finally { f.mvui.disposeMv(); }
});
test('undoing a nudge restores its target and a new tap creates a correct undo record', async () => {
    const f = await sync({ 0: 0, 1: 30, 2: 60, 3: 90 });
    try {
        f.click('nudge', '2:0.5'); f.click('tap-undo'); enabled(f); assert.equal(targetLabel(f), '副歌开始了');
        f.at(62); f.click('tap'); f.click('tap-undo'); enabled(f); assert.equal(f.saved().timing.taps[2], 60);
    } finally { f.mvui.disposeMv(); }
});
test('sequential final-tap undo and reopened fallback undo can both be tapped again', async () => {
    const f = await sync();
    try {
        for (const t of [0, 30, 60, 90]) { f.at(t); f.click('tap'); }
        f.click('tap-undo'); enabled(f); assert.equal(targetLabel(f), '尾奏开始了');
        f.at(91); f.click('tap'); assert.equal(f.saved().timing.taps[3], 91);
        f.mvui.openMv({ songId: song.id }); f.click('go-sync'); f.click('tap-undo'); enabled(f);
        assert.equal(targetLabel(f), '尾奏开始了'); assert.equal(f.saved().timing.taps[3], undefined);
    } finally { f.mvui.disposeMv(); }
});
test('undo keeps the no-audio button disabled and reset removes stale undo targets', async () => {
    const f = await sync({ 0: 0, 1: 30, 2: 60, 3: 90 }, false);
    try {
        f.click('nudge', '2:0.5'); f.click('tap-undo'); assert.match(f.body.innerHTML, /class="rmt-mv-tap[^>]*\bdisabled\b/);
        f.click('tap-reset'); f.click('tap-undo'); assert.deepEqual(plain(f.saved().timing.taps), {});
        assert.equal(targetLabel(f), '主歌 1开始了');
    } finally { f.mvui.disposeMv(); }
});
