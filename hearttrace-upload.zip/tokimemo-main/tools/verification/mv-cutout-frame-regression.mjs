import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fixture } from './fixture.mjs';
import { editor, decode } from './motif-editor-fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
import { stageSetup, song } from './mv-stage-fixture.mjs';
const require = createRequire(import.meta.url);
const native = require(require.resolve('@napi-rs/canvas', { paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || process.cwd()] }));
function picture({ panel = false, matte = '#ddd', transparent = false } = {}) {
    const c = native.createCanvas(320, 180), g = c.getContext('2d');
    if (!transparent) { g.fillStyle = matte; g.fillRect(0, 0, 320, 180); }
    g.fillStyle = '#534350';
    if (panel) g.fillRect(32, 48, 256, 84);
    else { g.fillRect(140, 20, 40, 35); g.fillRect(120, 55, 80, 100); }
    g.fillStyle = '#fff'; g.fillRect(145, 67, 30, 40);
    return c;
}
const alpha = (c, x, y) => c.getContext('2d').getImageData(x, y, 1, 1).data[3];

test('one-click cutout opens directly on a transparent PNG draft and preserves original on save', async () => {
    const c = picture(), url = c.toDataURL(), e = await editor(url, { url }, { autoCutout: true });
    try {
        const canvas = e.find('[data-editor-canvas]').native;
        assert.equal(alpha(canvas, 0, 0), 0);
        assert.equal(alpha(canvas, 160, 85), 255, 'enclosed white clothing survives');
        assert.equal(e.saves.length, 0, 'preview is reversible before save');
        await e.click('save');
        const saved = await decode(e.saves[0].image.blob);
        assert.equal(alpha(saved, 0, 0), 0);
        assert.equal(e.saves[0].image.mode, 'cutout');
        assert.equal(e.saves[0].image.originalRef.url, url);
        assert.equal(e.saves[0].prompt, null);
    } finally { e.controller.dispose(); }
});

test('one-click cutout undo and cancel keep the paid source and do not save a mask', async () => {
    const c = picture(), e = await editor(c.toDataURL(), null, { autoCutout: true });
    try {
        assert.equal(alpha(e.find('[data-editor-canvas]').native, 0, 0), 0);
        await e.click('undo');
        assert.equal(alpha(e.find('[data-editor-canvas]').native, 0, 0), 255);
        assert.equal(e.find('[data-layer]').checked, false);
        await e.click('close'); assert.equal(e.saves.length, 0);
    } finally { e.controller.dispose(); }
});

test('explicit cutout removes panel outside white only and never describes it as recovered character', async () => {
    const c = picture({ panel: true, matte: '#fff' }), e = await editor(c.toDataURL(), null, { autoCutout: true });
    try {
        const canvas = e.find('[data-editor-canvas]').native;
        assert.equal(alpha(canvas, 0, 0), 0);
        assert.equal(alpha(canvas, 160, 85), 255);
        assert.match(e.find('[data-editor-status]').textContent, /外侧|外边/);
        await e.click('save'); assert.equal((await decode(e.saves[0].image.blob)).width, 320);
    } finally { e.controller.dispose(); }
});

test('complex and empty backgrounds produce no destructive saved image', async () => {
    for (const empty of [false, true]) {
        const c = picture(); const g = c.getContext('2d');
        if (empty) { g.fillStyle = '#fff'; g.fillRect(0, 0, 320, 180); }
        else { g.fillStyle = '#198573'; g.fillRect(0, 0, 320, 20); }
        const e = await editor(c.toDataURL(), null, { autoCutout: true });
        try { assert.equal(e.find('[data-layer]').checked, false); await e.click('save'); assert.equal(e.saves[0].image, undefined); }
        finally { e.controller.dispose(); }
    }
});

test('preview trims a rectangular panel border but never zooms into a full-body transparent figure', async () => {
    const f = await fixture(), p = f.get('extras/mvImageTools');
    for (const transparent of [false, true]) {
        const panel = picture({ panel: true, transparent }), data = panel.getContext('2d').getImageData(0, 0, 320, 180).data;
        const before = [...data];
        assert.deepEqual(JSON.parse(JSON.stringify(p.previewContentRect(data, 320, 180))), { x: 32, y: 48, w: 256, h: 84 });
        assert.deepEqual([...data], before);
        const person = picture({ transparent });
        assert.equal(p.previewContentRect(person.getContext('2d').getImageData(0, 0, 320, 180).data, 320, 180), null);
    }
});

test('character, group background, motif, and inspector use the selected frame shape and provide cutout action', async () => {
    const f = await ui(stageSetup);
    try {
        f.record.motif = { name: '雪花', image: { url: '/motif.png' } };
        for (const g of f.record.groups) for (const d of g.diffs) d.image = { url: '/pose.png' };
        f.mvui.openMv({ songId: song.id, page: 'board' }); f.click('inspect', 'G1'); f.mvui.renderMv();
        for (const key of ['G1:D1', 'motif']) {
            assert.match(f.body.innerHTML, new RegExp('class="rmt-mv-asset wide[^\"]*"[^>]*data-rmt-mv-anchor="' + key + '"'));
            assert.match(f.body.innerHTML, new RegExp('data-rmt-mv="cutout-asset"[^>]*data-rmt-mv-id="' + key + '"'));
        }
        assert.match(f.body.innerHTML, /rmt-mv-inspect-row wide/);
        let options;
        f.body.querySelector = selector => selector === '[data-rmt-mv-editor-host]' ? {} : null;
        f.get('ui/mvImageEditor').mountAssetEditor = (host, value) => { options = value; return { dispose() {} }; };
        f.click('cutout-asset', 'G1:D1');
        for (let i = 0; i < 5; i++) await Promise.resolve();
        assert.equal(options.autoCutout, true);
        assert.equal(options.autoCharacter, false, 'one-click processing gets its own undo, before any automatic preparation');
    } finally { f.mvui.disposeMv(); }
});

test('real board thumbnail excludes picture padding without changing persisted image, shots or timing', async () => {
    const f = await ui(stageSetup), panel = picture({ panel: true, matte: '#fff' }), url = panel.toDataURL();
    try {
        const decodes = [];
        f.sb.Image = class extends native.Image { set src(value) { super.src = value; decodes.push(this.decode()); } };
        const create = f.sb.document.createElement;
        f.sb.document.createElement = tag => tag === 'canvas' ? native.createCanvas(1, 1) : create(tag);
        const player = native.createCanvas(540, 960); f.canvas.getContext = () => player.getContext('2d');
        f.record.groups[0].diffs[0].image = { url };
        const before = JSON.stringify(f.record);
        f.mvui.openMv({ songId: song.id, page: 'board' }); f.click('group-open', 'G1');
        await Promise.all(decodes); f.mvui.renderMv();
        const match = f.body.innerHTML.match(/data-rmt-mv-anchor="G1:D1"[^>]*><img src="([^"]+)"/);
        assert.ok(match);
        assert.notEqual(match[1], url, 'preview should not keep the original padded canvas');
        const img = new native.Image(); img.src = match[1]; await img.decode();
        assert.equal(img.width, 256); assert.equal(img.height, 84);
        assert.equal(JSON.stringify(f.record), before, 'display-only padding trim cannot rewrite the saved material');
    } finally { f.mvui.disposeMv(); }
});

test('one-click never guesses a cell from a multi-panel sprite sheet', async () => {
    const c = native.createCanvas(120, 240), g = c.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, 120, 240);
    g.fillStyle = '#243547';
    for (const y of [10, 130]) { g.fillRect(48, y, 24, 25); g.fillRect(38, y + 25, 44, 60); }
    const e = await editor(c.toDataURL(), null, { autoCutout: true });
    try {
        assert.equal(alpha(e.find('[data-editor-canvas]').native, 0, 0), 255);
        assert.match(e.find('[data-editor-status]').textContent, /选单格/);
        await e.click('save'); assert.equal(e.saves[0].image, undefined);
    } finally { e.controller.dispose(); }
});
