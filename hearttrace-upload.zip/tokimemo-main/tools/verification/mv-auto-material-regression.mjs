import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { stageSetup, stageRaw, song } from './mv-stage-fixture.mjs';

function raster(w = 120, h = 90, color = [235, 235, 235, 255]) {
    const data = new Uint8ClampedArray(w * h * 4);
    const fill = (x, y, rw, rh, rgba) => { for (let yy = y; yy < y + rh; yy++) for (let xx = x; xx < x + rw; xx++) data.set(rgba, (yy * w + xx) * 4); };
    fill(0, 0, w, h, color);
    const person = (x = 40, y = 10) => { fill(x + 8, y, 24, 20, [190, 120, 100, 255]); fill(x, y + 20, 40, 45, [50, 60, 80, 255]); fill(x + 7, y + 24, 26, 32, [255, 255, 255, 255]); };
    return { data, w, h, fill, person, alpha: (d, x, y) => d[(y * w + x) * 4 + 3] };
}

for (const matte of [255, 235, 205]) test(`uniform ${matte} character matte is removed automatically, enclosed white clothing remains`, async () => {
    const f = await fixture(), p = raster(120, 90, [matte, matte, matte, 255]); p.person();
    const before = new Uint8ClampedArray(p.data);
    const result = f.get('extras/mvImageTools').prepareCharacterPixels(p.data, p.w, p.h);
    assert.equal(result.status, 'prepared');
    assert.equal(p.alpha(result.data, 0, 0), 0); assert.equal(p.alpha(result.data, 60, 50), 255);
    assert.deepEqual(p.data, before, 'the paid source stays intact');
});

test('genuine transparency needs no user-confirmed edit flag', async () => {
    const f = await fixture(), p = raster(120, 90, [0, 0, 0, 0]); p.person();
    const result = f.get('extras/mvImageTools').prepareCharacterPixels(p.data, p.w, p.h);
    assert.equal(result.status, 'transparent'); assert.equal(result.data, p.data);
});

test('blank images, scenic rectangles, and stacked cells are not called clean cutouts', async () => {
    const f = await fixture(), prepare = f.get('extras/mvImageTools').prepareCharacterPixels;
    const blank = raster(); assert.equal(prepare(blank.data, blank.w, blank.h).status, 'empty');
    const panel = raster(); panel.fill(10, 10, 100, 70, [90, 100, 120, 255]);
    assert.equal(prepare(panel.data, panel.w, panel.h).status, 'needs-edit');
    const sheet = raster(120, 190); sheet.person(40, 10); sheet.person(40, 110);
    assert.equal(prepare(sheet.data, sheet.w, sheet.h).status, 'needs-selection');
    const scenery = raster(); scenery.person(); scenery.fill(0, 0, 120, 10, [70, 140, 190, 255]);
    assert.equal(prepare(scenery.data, scenery.w, scenery.h).status, 'needs-edit');
});

test('new shared backgrounds use generated images, even if the model returns a local pattern', async () => {
    const f = await stageSetup();
    const built = f.mv.buildShots(f.json(stageRaw('rays')), f.bank, 2, f.record.settings);
    assert.equal(built.stage.backgrounds[0].kind, 'image');
    assert.equal(Array.from(f.mv.assetKeys(built, song)).filter(k => k.startsWith('stage:')).length, 1);
    assert.doesNotMatch(f.get('extras/mvStage').prompt(), /经用户确认抠图|（本地绘制）/);
});

test('previous procedural art can be replaced with one image without regenerating the storyboard', async () => {
    const f = await stageSetup(); f.record.stage.backgrounds[0].kind = 'rays';
    const before = JSON.stringify({ shots: f.record.shots, groups: f.record.groups, timing: f.record.timing }); let calls = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { calls++; return '/user/images/real-background.png'; };
    assert.equal((await f.mv.drawAsset(song.id, 'stage:S1')).pending, false);
    const current = f.mv.readMv(f.host, song.id);
    assert.equal(current.stage.backgrounds[0].kind, 'image'); assert.equal(calls, 1);
    assert.equal(JSON.stringify({ shots: current.shots, groups: current.groups, timing: current.timing }), before);
});

test('unfinished image backgrounds are not counted as completed layered clips', async () => {
    const f = await stageSetup('image');
    for (const group of f.record.groups) group.diffs[0].image = { url: '/generated-white.png' };
    assert.equal(f.mv.completedMvRanges(f.record, song).length, 0);
    f.record.stage.backgrounds[0].image = { url: '/background.png' };
    assert.equal(f.mv.completedMvRanges(f.record, song).length, 1);
});
