import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const [base, root, out] = process.argv.slice(2);
const sha = text => crypto.createHash('sha256').update(text).digest('hex');
const allowed = new Set();
async function load(dir) {
    let code = fs.readFileSync(path.join(dir, 'dist/heartbeatMemories.bundle.js'), 'utf8');
    code = code.replace(/\n(__m_extras_mv_js\.\w+ = \w+;)/, '\n__m_extras_mv_js.__storyboardPrompt = storyboardPrompt;\n__m_extras_mv_js.__tegakiGrammar = tegakiGrammar;\n$1')
        .replace(/\n(__m_extras_waiting_js\.\w+ = \w+;)/, '\n__m_extras_waiting_js.__waitingPrompt = waitingPrompt;\n$1');
    const names = [...code.matchAll(/^const (__m_\w+) = Object.create\(null\);/gm)].map(x => x[1]);
    const m = new vm.SourceTextModule(code + '\nexport { ' + names.join(',') + ' };', { context: vm.createContext({ console, queueMicrotask, TextEncoder, TextDecoder, URL, URLSearchParams, AbortController, DOMException, structuredClone, setTimeout, clearTimeout, setInterval, clearInterval, crypto: crypto.webcrypto }) });
    await m.link(() => {}); await m.evaluate(); return m.namespace;
}
const [a, b] = await Promise.all([load(base), load(root)]), rows = [];
function record(module, name, before, after) {
    assert.equal(typeof after, 'function', module + '.' + name);
    const x = before?.toString(), y = after.toString(), id = module + '.' + name.replace(/^__/, '');
    if (before && !allowed.has(id)) assert.equal(y, x, 'Unapproved prompt-bearing function change: ' + id);
    rows.push({ module, function: name.replace(/^__/, ''), baseline_sha256: x ? sha(x) : null, current_sha256: sha(y), unchanged: x === y, added: !before, before_chars: x?.length || 0, after_chars: y.length });
}
for (const module of Object.keys(b)) for (const [name, fn] of Object.entries(b[module])) {
    if (typeof fn === 'function' && !name.startsWith('__') && /prompt/i.test(name) && name !== 'assertPromptBudget') record(module, name, a[module]?.[name], fn);
}
for (const [module, name] of [['__m_extras_waiting_js', '__waitingPrompt'], ['__m_extras_mv_js', '__storyboardPrompt'], ['__m_extras_mv_js', '__tegakiGrammar'], ['__m_extras_mv_js', 'rewriteShot'], ['__m_extras_mv_js', 'continueStoryboard']]) record(module, name, a[module][name], b[module][name]);
assert.deepEqual(rows.filter(r => !r.added && !r.unchanged).map(r => r.module + '.' + r.function).sort(), [...allowed].sort());
assert.deepEqual(rows.filter(r => r.added).map(r => r.module + '.' + r.function).sort(), []);
const defaultBefore = a.__m_extras_mv_js.defaultAssetPrompt.toString();
const defaultAfter = b.__m_extras_mv_js.defaultAssetPrompt.toString();
assert.equal(defaultAfter, defaultBefore, 'Default asset prompt template must remain byte-identical');
const templateRows = rows.filter(r => !r.added).map(r => ({ id: r.module + '.' + r.function, before: r.baseline_sha256,
    after: r.current_sha256 }));
assert.ok(templateRows.every(r => r.before === r.after));
const templateHash = sha(JSON.stringify(templateRows.map(r => [r.id, r.before])));
fs.writeFileSync(out, JSON.stringify({ scope: 'All 172 prompt-bearing functions, including storyboard, lyric, default image and custom prompt reader, remain byte-identical.', default_template_sha256: sha(defaultAfter), all_templates_sha256: templateHash, template_rows: templateRows, rows }, null, 2) + '\n');
console.log(JSON.stringify({ checked: rows.length, unchanged: rows.filter(r => r.unchanged).length, override_reader_changed: 0, default_templates_changed: 0, all_templates_sha256: templateHash }));
