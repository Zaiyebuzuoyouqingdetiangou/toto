import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture,realClient} from './fixture.mjs';
const backendText='Internal error: Custom OpenAI endpoint failed with status 524: error code: 524';
const response=text=>({choices:[{message:{role:'assistant',content:text},finish_reason:'stop'}]});
const song={id:'SONG_transport',title:'首次分镜',lyrics:'[Verse]\n窗边的灯\n[Chorus]\n回家的路',bpm:120};
const storyboard={groups:[{id:'G1',characterPrompt:'at the window',diffs:[{id:'D1',change:'looks up'}]}],frames:[{sectionIndex:0,lyric:'窗边的灯',group:'G1',diff:'D1'},{sectionIndex:1,lyric:'回家的路',group:'G1',diff:'D1'}]};
async function setup(onRequest){const f=await fixture();f.get('core/cache').loadSession=()=>({songs:[song]});realClient(f,()=>storyboard);let calls=0;const sent=[];f.host.ConnectionManagerRequestService.sendRequest=async(...args)=>{calls++;sent.push(args);return onRequest?onRequest(calls):response(JSON.stringify(storyboard));};return {...f,mv:f.get('extras/mv'),calls:()=>calls,sent};}
async function fail(fn,code){let caught;try{await fn();}catch(e){caught=e;}assert.ok(caught,'must report failure');assert.equal(caught.code,code);return caught;}
test('first storyboard reports wrapped 524 as transport timeout; no fake storyboard or extra request',async()=>{
 const f=await setup(()=>response(backendText));const e=await fail(()=>f.mv.generateStoryboard(song.id,{output:'tegaki'}),'RMT_CONNECTION_SERVER');
 assert.equal(e.status,524);assert.match(e.safeUserMessage,/HTTP 524/);assert.match(e.safeUserMessage,/超时/);assert.equal(f.calls(),1);assert.equal(f.mv.readMv(f.host,song.id),null);assert.equal(f.mv.pendingMv(f.mv.mvScope(f.host)).length,0);
 const traces=f.get('core/taskTrace').taskTraceSnapshot();assert.equal(traces.at(-1).mode,'songMv');assert.equal(traces.at(-1).httpStatus,524);assert.equal(traces.at(-1).response.shape,'error');assert.ok(!traces.at(-1).stages.some(s=>s.startsWith('parse')));assert.ok(!JSON.stringify(traces).includes('Custom OpenAI'));
});
test('failed regeneration preserves every old shot and image; next manual click can succeed',async()=>{
 const f=await setup(n=>n===2?response(backendText):response(JSON.stringify(storyboard)));await f.mv.generateStoryboard(song.id,{output:'tegaki'});f.mv.writeMv(f.mv.mvScope(f.host),song.id,r=>{r.groups[0].diffs[0].image={url:'/old-paid.png'};return r;});const before=JSON.stringify(f.mv.readMv(f.host,song.id));
 await fail(()=>f.mv.generateStoryboard(song.id,{output:'tegaki'}),'RMT_CONNECTION_SERVER');assert.equal(JSON.stringify(f.mv.readMv(f.host,song.id)),before);assert.equal(f.calls(),2);assert.equal((await f.mv.generateStoryboard(song.id,{output:'tegaki'})).pending,false);assert.equal(f.calls(),3);
});
test('validated generation does not treat backend error prose as a paid empty-JSON reroll',async()=>{
 const f=await setup(()=>response(backendText));await fail(()=>f.get('generation/client').requestValidatedSegment('test','test',{mode:'songMv',context:f.host},v=>v),'RMT_CONNECTION_SERVER');assert.equal(f.calls(),1);
});
test('plain, content-array and profile-stream errors retain 524 without exporting backend text',async()=>{
 const f=await fixture(),api=f.get('core/independentApiConfig');
 for(const raw of [backendText,response(backendText),{content:[{type:'text',text:backendText}]},await api.readProfileCompletion(async function*(){yield{text:backendText,state:{reasoning:''}};})]){
  const e=await fail(()=>api.assertIndependentResponsePayload(raw),'RMT_PROVIDER_STATUS');assert.equal(e.status,524);assert.ok(!String(e).includes('Custom OpenAI'));assert.equal(api.transportFailureSummary(e).shape,'error');
 }
});
test('structured backend error message retains HTTP status when no numeric status field exists',async()=>{
 const f=await fixture(),api=f.get('core/independentApiConfig');for(const raw of [{error:{message:backendText}},{error:backendText},{success:false,message:backendText}]){const e=await fail(()=>api.assertIndependentResponsePayload(raw),'RMT_PROVIDER_STATUS');assert.equal(e.status,524);}
});
test('numeric envelope status takes priority over conflicting prose',async()=>{
 const f=await fixture(),api=f.get('core/independentApiConfig');const e=await fail(()=>api.assertIndependentResponsePayload({error:{status:401,message:backendText}}),'RMT_PROVIDER_STATUS');assert.equal(e.status,401);
});
test('valid JSON, fenced JSON and JSON after backend-like prose remain parseable',async()=>{
 const f=await fixture(),api=f.get('core/independentApiConfig'),parser=f.get('generation/jsonParser');const data=JSON.stringify({scene:backendText});for(const content of [data,'```json\n'+data+'\n```',backendText+'\n'+data])assert.equal(parser.extractJson(api.assertIndependentResponsePayload(response(content))).scene,backendText);
});
test('truncated JSON after error-like prose remains a recoverable JSON truncation',async()=>{
 const f=await fixture(),content=backendText+'\n{"frames":[';assert.equal(f.get('core/independentApiConfig').assertIndependentResponsePayload(response(content)),content);await fail(()=>f.get('generation/jsonParser').extractJson(content),'RMT_JSON_TRUNCATED');
});
test('ordinary prose and incidental error references keep the existing parser path',async()=>{
 const f=await fixture(),api=f.get('core/independentApiConfig');for(const text of ['请稍后再试','这一幕是角色看到 error code: 524。','故事里的 HTTP 524 错误']){assert.equal(api.assertIndependentResponsePayload(response(text)),text);await fail(()=>f.get('generation/jsonParser').extractJson(text),'RMT_JSON_NOT_FOUND');}
 const html=await fail(()=>api.assertIndependentResponsePayload(response('HTTP 524 <html><body>upstream error</body></html>')),'RMT_RESPONSE_HTML');assert.equal(html.retryable,false);
});
test('HTTP and error-code-only error replies preserve a safe numeric status',async()=>{
 const f=await fixture(),api=f.get('core/independentApiConfig');for(const text of ['error code: 524','HTTP 524: A timeout occurred','Failed to generate chat completion: '+backendText]){const e=await fail(()=>api.assertIndependentResponsePayload(response(text)),'RMT_PROVIDER_STATUS');assert.equal(e.status,524);}
});
test('real thrown 524 is shown as timeout with MV trace and a single request',async()=>{
 const f=await setup(()=>{throw Object.assign(new Error(backendText),{status:524});});const e=await fail(()=>f.mv.generateStoryboard(song.id,{output:'tegaki'}),'RMT_CONNECTION_SERVER');assert.match(e.message,/超时/);assert.equal(f.calls(),1);assert.equal(f.get('core/taskTrace').taskTraceSnapshot().at(-1).httpStatus,524);
});
test('successful first storyboard keeps configured max output, temperature, streaming choice and one request',async()=>{
 const f=await setup();assert.equal((await f.mv.generateStoryboard(song.id,{output:'tegaki'})).pending,false);assert.equal(f.calls(),1);assert.equal(f.mv.readMv(f.host,song.id).shots.length,2);assert.equal(f.sent[0][2],120000);assert.equal(f.sent[0][3].stream,false);assert.equal(f.sent[0][4].temperature,f.constants.DEFAULT_SETTINGS.temperature);assert.equal(f.get('core/taskTrace').taskTraceSnapshot().at(-1).mode,'songMv');
});
test('HTTP diagnostics permit only integer error statuses and never exception text',async()=>{
 const f=await fixture(),t=f.get('core/taskTrace');for(const value of [0,200,600,524.5,Infinity,'private text',Symbol('PRIVATE'),{valueOf(){throw Error('do not coerce arbitrary statuses')}}]){const row=t.startTaskTrace('private task','songMv');t.endTaskTrace(row,'failed',{code:'RMT_CONNECTION_SERVER',status:value,message:'PRIVATE'});const exported=t.taskTraceSnapshot().at(-1);assert.equal(exported.httpStatus,undefined);assert.ok(!JSON.stringify(exported).includes('PRIVATE'));}
});
