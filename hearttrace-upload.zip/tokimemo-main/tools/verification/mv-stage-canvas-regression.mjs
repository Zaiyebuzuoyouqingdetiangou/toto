import test from 'node:test';
import assert from 'node:assert/strict';
import { scene, native } from './mv-stage-canvas-fixture.mjs';

const pixels = canvas => Buffer.from(canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data);

for (const ratio of ['16:9', '9:16']) test(`native Canvas ${ratio}: one background continues through held poses and changed text`, async () => {
    const f = await scene({ ratio }); try {
        assert.deepEqual(f.errors, []); assert.equal(f.calls(), 0);
        const a = f.seek(3.9), firstPose = a.find(d => d.image === f.art1.url);
        const b = f.seek(4.1), samePose = b.find(d => d.image === f.art1.url);
        assert.ok(firstPose && samePose); assert.equal(firstPose.transform.a, samePose.transform.a);
        assert.notDeepEqual(a.filter(d => d.text).map(d => d.text), b.filter(d => d.text).map(d => d.text));
        const expected = native.createCanvas(f.w, f.h);
        const sample = c => [...c.getContext('2d').getImageData(4, 4, 30, 30).data];
        for (const t of [3.9, 4.1, 8.1]) {
            f.seek(t);
            f.get('ui/mvStageCanvas').drawBackground(expected.getContext('2d'), f.record().stage.backgrounds[0], f.w, f.h, t);
            assert.deepEqual(sample(f.preview), sample(expected), 'background must use absolute song time at ' + t);
        }
        const changed = f.seek(8.3); assert.ok(changed.some(d => d.image === f.art2.url));
        f.seek(4.1); const rewind = pixels(f.preview); f.seek(13); f.seek(4.1);
        assert.deepEqual(pixels(f.preview), rewind, 'seeking must produce the same frame');
    } finally { f.mvui.disposeMv(); }
});

test('background is behind confirmed transparent art, text order is deliberate, and opaque art stays intact', async () => {
    const f = await scene(); try {
        const draws = f.seek(1);
        assert.ok(draws.findIndex(d => d.text) < draws.findIndex(d => d.image === f.art1.url));
        const center = [...f.preview.getContext('2d').getImageData(f.w / 2, f.h * .7, 1, 1).data];
        assert.ok(center[0] > 200 && center[1] < 110, 'foreground figure is visible');
        f.mv.patchStageCue(f.song.id, f.record().shots[0].id, { depth: 'front' }); f.mvui.renderMv();
        const front = f.seek(1);
        assert.ok(front.findIndex(d => d.text) > front.findIndex(d => d.image === f.art1.url));
        const unchanged = JSON.stringify(f.record().timing);
        f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-stage-cue]', dataset: { rmtMvStageCue: 'text', shot: f.record().shots[0].id }, value: 'UPDATED' } });
        assert.equal(f.record().shots[0].stage.text, 'UPDATED'); assert.equal(JSON.stringify(f.record().timing), unchanged);
        assert.match(f.draws.filter(d => d.canvas === f.preview && d.text).map(d => d.text).join(''), /UPDATED/, 'saving updates the canvas without reopening it');
        assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
    const opaque = await scene({ opaque: true }); try {
        const draws = opaque.seek(1), corner = [...opaque.preview.getContext('2d').getImageData(4, 4, 1, 1).data];
        assert.deepEqual(corner, [0, 255, 0, 255]);
        assert.ok(draws.some(d => d.text), 'a full image has readable foreground text fallback');
        assert.equal(opaque.record().groups[0].diffs[0].image.editMode, 'full');
    } finally { opaque.mvui.disposeMv(); }
});

test('an opaque PNG marked as cutout keeps a full-frame fallback instead of hiding the stage text', async () => {
    const f = await scene({ opaque: true }); try {
        f.record().groups[0].diffs[0].image.editMode = 'cutout'; f.mvui.renderMv();
        const draws = f.seek(1);
        assert.deepEqual([...f.preview.getContext('2d').getImageData(4, 4, 1, 1).data], [0, 255, 0, 255]);
        assert.ok(draws.findIndex(d => d.text) > draws.findIndex(d => d.image === f.art1.url));
        assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('shared backgrounds appear once in the board and pose editing is reachable from the player', async () => {
    const f = await scene(); try {
        assert.match(f.body.innerHTML, /舞台编排/); assert.match(f.body.innerHTML, /图片编辑 · 选单格 · 修边/);
        f.mvui.navigateMvBack();
        assert.equal((f.body.innerHTML.match(/<b>共享背景<\/b>/g) || []).length, 1);
        assert.equal((f.body.innerHTML.match(/data-rmt-mv-anchor="stage:S1"/g) || []).length, 1);
        assert.match(f.body.innerHTML, /本地图案/);
        assert.doesNotMatch(f.body.innerHTML, /这一页没能打开/);
        assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('native Canvas export matches preview at the same song time even for a clipped second section', async () => {
    const f = await scene({ matte: '#ebebeb', unconfirmed: true, imageBackground: true }); let clock = 1000, exportCanvas, started, scheduled;
    const ready = new Promise(resolve => { started = resolve; });
    const playing = new Promise(resolve => { scheduled = resolve; });
    const raf = f.sb.requestAnimationFrame;
    f.sb.requestAnimationFrame = fn => { const id = raf(fn); if (fn.name === 'loop' && exportCanvas) scheduled(); return id; };
    f.sb.performance.now = () => clock;
    f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } };
    f.sb.AudioContext = class {};
    f.sb.MediaRecorder = class {
        static isTypeSupported() { return true; }
        constructor(stream) { this.state = 'inactive'; exportCanvas = stream.tracks[0].canvas; }
        start() { this.state = 'recording'; started(); }
        stop() { this.state = 'inactive'; this.onstop?.(); }
    };
    let timer;
    try {
        f.seek(8.1); const reference = pixels(f.preview);
        f.click('export-range', '1:1'); f.click('export');
        await Promise.race([Promise.all([ready, playing]), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('export did not start')), 5000); })]);
        clock = 1100;
        for (const [id, tick] of [...f.frames]) { f.frames.delete(id); tick(); }
        assert.equal(exportCanvas.width, f.w); assert.equal(exportCanvas.height, f.h);
        assert.equal(pixels(exportCanvas).equals(reference), true, 'export pixels must match the full-song preview at 8.1s');
        assert.equal(f.calls(), 0); assert.deepEqual(f.errors, []);
    } finally { clearTimeout(timer); f.mvui.disposeMv(); }
});

for (const matte of ['', '#ffffff', '#dddddd']) test(`automatic character layer (${matte || 'native alpha'}) is visible over the actual shared image`, async () => {
    const f = await scene({ matte, unconfirmed: true, imageBackground: true });
    try {
        const before = JSON.stringify(f.record()); f.seek(1);
        assert.deepEqual([...f.preview.getContext('2d').getImageData(4, 4, 1, 1).data], [22, 114, 69, 255]);
        const center = [...f.preview.getContext('2d').getImageData(f.w / 2, f.h * .7, 1, 1).data];
        assert.ok(center[0] > 200 && center[1] < 110, 'automatically prepared figure must remain visible');
        f.mvui.navigateMvBack();
        assert.doesNotMatch(f.body.innerHTML, /待抠图|检查背景|经用户确认/);
        f.click('inspect', 'G1'); f.mvui.renderMv();
        assert.match(f.body.innerHTML, /透明人物叠背景/);
        assert.equal(JSON.stringify(f.record()), before, 'automatic preparation must not mutate paid or manually saved assets');
        assert.equal(f.calls(), 0); assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});
