import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';

const flush = () => new Promise(resolve => setImmediate(resolve));
const song = { id: 'SONG_sync', title: '对时间测试', bpm: 84,
    lyrics: '[Intro]\n前奏\n[Verse 1]\n主歌\n[Chorus]\n副歌\n[Outro]\n尾奏\n[End]' };
async function setup({ audio = true, taps = {} } = {}) {
    const f = await ui(async () => {
        const base = await fixture();
        base.get('core/cache').loadSession = () => ({ songs: [song, { ...song, id: 'SONG_other' }] });
        return { ...base, mv: base.get('extras/mv') };
    });
    const record = id => ({ id, createdAt: 1, updatedAt: 1, settings: { appear: 'none' },
        shots: [{ id: 'S1', sectionIndex: 0, plain: 'empty room', who: 'none', lyric: '前奏',
            imagePrompt: 'empty room', image: null, motion: 'still', cut: 'cut' }],
        duration: 123, timing: { taps, shift: 0, lineTaps: { '0:0': 3 } } });
    f.host.chatMetadata[f.mv.MV_KEY] = { version: 1, songs: {
        SONG_sync: record('SONG_sync'), SONG_other: record('SONG_other'),
    } };
    f.errors = [];
    f.sb.toastr = { error: (...args) => f.errors.push(args) };
    f.mvui.openMv({ songId: song.id });
    if (audio) { f.upload(); f.audios.at(-1).onloadedmetadata(); }
    f.click('go-sync');
    if (audio) { f.click('play'); await flush(); }
    f.at = seconds => { f.audios.at(-1).currentTime = seconds; };
    f.taps = () => JSON.parse(JSON.stringify(f.mv.readMv(f.host, song.id).timing.taps));
    return f;
}
const targetLabel = f => f.body.innerHTML.match(/class="rmt-mv-tap[^]*?<b>([^<]*)<\/b>/)?.[1];

test('each section has a selectable button, including index zero', async () => {
    const f = await setup();
    for (let i = 0; i < 4; i++) assert.match(f.body.innerHTML, new RegExp('data-rmt-mv="select-section" data-rmt-mv-id="' + i + '"'));
});
test('selecting the chorus changes the big button without writing or seeking audio', async () => {
    const f = await setup(); f.at(48); f.click('select-section', '2');
    assert.equal(targetLabel(f), '副歌开始了'); assert.deepEqual(f.taps(), {});
    assert.equal(f.audios.at(-1).currentTime, 48); assert.equal(f.audios.at(-1).paused, false);
    f.click('tap'); assert.deepEqual(f.taps(), { 2: 48 });
    assert.equal(f.mv.readMv(f.host, song.id).timing.lineTaps['0:0'], 3);
});
test('original sequential tapping still advances through every section', async () => {
    const f = await setup();
    for (const seconds of [0, 24, 48, 80]) { f.at(seconds); f.click('tap'); }
    assert.deepEqual(f.taps(), { 0: 0, 1: 24, 2: 48, 3: 80 });
    assert.match(f.body.innerHTML, /class="rmt-mv-tap done" data-rmt-mv="tap" disabled/);
    assert.deepEqual(f.errors, []);
});
test('a completed section can be selected and corrected, then undo restores its old time', async () => {
    const f = await setup({ taps: { 0: 0, 1: 24, 2: 48, 3: 80 } });
    f.click('select-section', '1'); f.at(26); f.click('tap');
    assert.deepEqual(f.taps(), { 0: 0, 1: 26, 2: 48, 3: 80 });
    f.click('tap-undo'); assert.deepEqual(f.taps(), { 0: 0, 1: 24, 2: 48, 3: 80 });
});
test('undo removes the most recent selected tap, not the highest section number', async () => {
    const f = await setup();
    f.click('select-section', '2'); f.at(48); f.click('tap');
    f.click('select-section', '0'); f.at(1); f.click('tap');
    f.click('tap-undo'); assert.deepEqual(f.taps(), { 2: 48 });
    f.click('tap-undo'); assert.deepEqual(f.taps(), {});
});
test('selection resets on reopen and does not carry into another song', async () => {
    const f = await setup(); f.click('select-section', '2');
    f.mvui.openMv({ songId: 'SONG_other' }); f.click('go-sync');
    assert.equal(targetLabel(f), '前奏开始了');
});
test('reset clears manual selection and undo history; no audio still disables recording', async () => {
    const f = await setup(); f.click('select-section', '2'); f.at(48); f.click('tap');
    f.click('tap-reset'); f.click('tap-undo'); assert.deepEqual(f.taps(), {});
    assert.equal(targetLabel(f), '前奏开始了');
    const g = await setup({ audio: false }); g.click('select-section', '2');
    assert.match(g.body.innerHTML, /class="rmt-mv-tap" data-rmt-mv="tap" disabled/);
});
test('invalid selection leaves the current target and timing unchanged', async () => {
    const f = await setup();
    for (const id of ['-1', '4', 'nope', '1.5']) f.click('select-section', id);
    assert.equal(targetLabel(f), '前奏开始了'); assert.deepEqual(f.taps(), {});
});
test('saved timing can be reopened and neighbouring tap bounds remain monotonic', async () => {
    const f = await setup({ taps: { 0: 0, 2: 48 } });
    f.click('select-section', '1'); f.at(60); f.click('tap');
    assert.deepEqual(f.taps(), { 0: 0, 1: 47.5, 2: 48 });
    f.mvui.openMv({ songId: song.id }); f.click('go-sync');
    assert.equal(targetLabel(f), '尾奏开始了');
});
test('MV lyrics and other text panels use paired semantic theme colours', async () => {
    const f = await setup(); const styles = [];
    f.sb.document.getElementById = () => null;
    f.sb.document.createElement = () => ({});
    f.sb.document.head = { appendChild: el => styles.push(el.textContent) };
    f.mvui.renderMv();
    const css = styles.join('\n');
    assert.match(css, /\.rmt-mv-lyric\{[^}]*--rmt-content-ink:var\(--rmt-paper-letter-ink/);
    assert.match(css, /\.rmt-mv-lyric\{[^}]*background:var\(--rmt-paper-letter/);
    for (const cls of ['prompt', 'file', 'info', 'toggle', 'warn']) {
        assert.match(css, new RegExp('\\.rmt-mv-' + cls + '\\{[^}]*background:var\\(--rmt-(?:theme|paper)-'));
    }
});
test('theme colour pairs for MV panels exceed 4.5:1 in light, dark and custom modes', async () => {
    const f = await fixture(); const theme = f.get('core/theme');
    const settings = ['default', 'night', 'gs1', 'gs2', 'gs3', 'gs4'].map(themeMode => ({ themeMode }));
    settings.push({ themeMode: 'custom', themeCustom: { background: '#101828', surface: '#202a40', text: '#eeeeee' } });
    const pairs = [['--rmt-paper-letter-ink', '--rmt-paper-letter'], ['--rmt-paper-note-ink', '--rmt-paper-note'],
        ['--rmt-theme-text', '--rmt-theme-soft'], ['--rmt-theme-muted', '--rmt-theme-soft'],
        ['--rmt-theme-wash-ink', '--rmt-theme-wash'], ['--rmt-theme-text', '--rmt-theme-surface-solid']];
    for (const setting of settings) {
        const colors = {};
        theme.applyThemeToElement({ dataset: {}, style: { setProperty: (k, v) => { colors[k] = v; } } }, setting);
        for (const [ink, paper] of pairs) assert.ok(theme.contrastRatio(colors[ink], colors[paper]) >= 4.5, `${setting.themeMode}: ${ink} / ${paper}`);
    }
});
