// Render the production player into native Canvas with synthetic, unpaid art.
// This checks composition pixels, not browser DOM/CSS or device-specific fonts.
import fs from 'node:fs';
import path from 'node:path';
import { scene, native } from './mv-stage-canvas-fixture.mjs';

const out = path.resolve(process.argv[2] || 'verification/1.0.16');
fs.mkdirSync(out, { recursive: true });
const board = native.createCanvas(1920, 1200), g = board.getContext('2d');
g.fillStyle = '#ebedf0'; g.fillRect(0, 0, board.width, board.height);
const eye = native.createCanvas(240, 160), eg = eye.getContext('2d');
eg.fillStyle = '#c48a73'; eg.beginPath(); eg.ellipse(120, 80, 105, 57, 0, 0, Math.PI * 2); eg.fill();
eg.fillStyle = '#271e2a'; eg.fillRect(66, 64, 32, 8); eg.fillRect(142, 64, 32, 8);
eg.fillStyle = '#922e42'; eg.fillRect(80, 66, 9, 9); eg.fillRect(151, 66, 9, 9);

for (const [i, variant] of ['full', 'medium', 'wide', 'eye'].entries()) {
    const f = await scene({ matte: '#ebebeb', unconfirmed: true,
        ...(variant === 'eye' ? { createArt: () => ({ url: eye.toDataURL(), editMode: 'cutout', split: 'none' }) } : {}),
        configure: r => {
            r.groups[0].scale = variant === 'eye' ? 'close' : variant;
            if (variant === 'eye') r.groups[0].composition = '眼部特写';
            r.shots[0].lyric = 'I will stay by your side, tonight and tomorrow.';
            Object.assign(r.shots[0].stage, { text: r.shots[0].lyric, layout: 'sides', depth: 'back', shadow: true, tone: 'dark' });
            Object.assign(r.stage.backgrounds[0], { colors: ['#17202a', '#23252c', '#a65375'], motion: 'still', kind: 'solid' });
        }
    });
    try {
        f.seek(1);
        const x = (i % 2) * 960, y = Math.floor(i / 2) * 600;
        g.fillStyle = '#263a52'; g.font = 'bold 23px sans-serif'; g.fillText(`${variant.toUpperCase()} — production Canvas`, x + 24, y + 36);
        g.drawImage(f.preview, x, y + 60);
        fs.writeFileSync(path.join(out, `native-${variant}.png`), f.preview.toBuffer('image/png'));
    } finally { f.mvui.disposeMv(); }
}
fs.writeFileSync(path.join(out, 'native-composition-sheet.png'), board.toBuffer('image/png'));
console.log(JSON.stringify({ output: path.join(out, 'native-composition-sheet.png'), nativeCanvas: true, browserDOM: false }));
