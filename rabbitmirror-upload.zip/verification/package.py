from pathlib import Path
import hashlib, json, shutil, zipfile

out = Path(__file__).resolve().parent
project = out.parents[1]
base = out / 'baseline'
candidate = project / 'work/rabbitmirror-1.62.57'
deliver = project / 'deliverables'
deliver.mkdir(exist_ok=True)
installer = deliver / 'rabbitmirror-upload-1.62.57.zip'
files = sorted(p.relative_to(base) for p in base.rglob('*') if p.is_file() and 'tests' not in p.relative_to(base).parts)
assert len(files) == 164
with zipfile.ZipFile(installer, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for relative in files:
        archive.write(candidate / relative, str(relative))
reextracted = out / 'reextracted57'
assert not reextracted.exists(), 'Do not silently reuse a previous extraction'
with zipfile.ZipFile(installer) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(str(p) for p in files)
    archive.extractall(reextracted)
rows = []
for relative in files:
    before = (candidate / relative).read_bytes()
    after = (reextracted / relative).read_bytes()
    assert before == after, relative
    rows.append({'file': str(relative), 'bytes': len(after), 'sha256': hashlib.sha256(after).hexdigest()})
manifest = json.loads((reextracted / 'manifest.json').read_text())
assert manifest['version'] == '1.62.57'
report = {'installer': str(installer), 'bytes': installer.stat().st_size,
    'sha256': hashlib.sha256(installer.read_bytes()).hexdigest(),
    'crc': 'passed', 'root': '164 production files directly at archive root; tests excluded',
    'fileCount': len(files), 'byteComparison': '164/164 identical', 'manifest': manifest, 'files': rows}
(out / 'installer-manifest.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
# Tests are added only to the verification extraction, never to the installer.
shutil.copytree(candidate / 'tests', reextracted / 'tests')
print(json.dumps({key: value for key, value in report.items() if key not in ['files', 'manifest']}, ensure_ascii=False))
