import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { captureFinalPrompt } from '../../work/rabbitmirror-1.62.57/tests/helpers/finalPromptCapture.mjs';
import { createRuntime } from '../../work/rabbitmirror-1.62.57/tests/helpers/vmLoader.mjs';

const [candidate = 'work/rabbitmirror-1.62.57', destination = 'verification/1.62.57/request-evidence'] = process.argv.slice(2);
const baseline = 'verification/1.62.57/baseline';
const sha = text => createHash('sha256').update(text).digest('hex');
const normalized = (root, file, version) => readFileSync(root + '/' + file, 'utf8').replaceAll('\r\n', '\n').replaceAll(version, '<VERSION>');
const replacements = JSON.parse(readFileSync('verification/1.62.57/approved-prompt-replacements.json', 'utf8'));
const expectedMessages = messages => messages.map(message => ({...message, content: replacements.reduce((text, p) => text.replaceAll(p.before, p.after), message.content)}));
const copy = value => JSON.parse(JSON.stringify(value));
const a = createRuntime(baseline), b = createRuntime(candidate);
const oldIndex = (await a.load('data/structured/interactionIndex.js')).INTERACTION_RECIPES;
const nextIndex = (await b.load('data/structured/interactionIndex.js')).INTERACTION_RECIPES;
const oldDetails = await a.load('data/raw/rawInteractionRecipes.js'), nextDetails = await b.load('data/raw/rawInteractionRecipes.js');
assert.deepEqual(copy(nextIndex), copy(oldIndex));
for (const item of oldIndex) assert.deepEqual(copy(nextDetails.resolveInteractionDetail(item.id)), copy(oldDetails.resolveInteractionDetail(item.id)));
const protectedFiles = ['src/visualDesign.js', 'src/picker.js', 'src/storage.js', 'src/interactionRecipes.js', 'data/structured/interactionIndex.js', 'data/raw/rawPresentationFormats.js', 'data/structured/presentationIndex.js'];
const protectedHashes = Object.fromEntries(protectedFiles.map(file => {
  const before = normalized(baseline, file, '1.62.56'), after = normalized(candidate, file, '1.62.57');
  assert.equal(after, before, file);
  return [file, sha(after)];
}));
const { GUIDED_VISUAL_FLOOR, REFERENCE_VISUAL_FLOOR } = await b.load('src/visualDesign.js');
const history = [{ historyId: 'old-operation', interactionRecipeIds: ['page-turn'], visualSkeleton: 'operation_family: text_panel_switch；' },
  { historyId: 'old-dark', paletteFingerprint: { brightness: 'dark', confidence: .9, averageLuminance: 25, darkAreaRatio: .9, hueFamily: 'blue', temperature: 'cool', saturation: 'medium' } }];
const fields = r => ({ mainChars: r.meter.basePrompt.length, lockChars: r.meter.executionLock.length,
  totalChars: r.messages.reduce((n, m) => n + m.content.length, 0), messagesSha256: sha(JSON.stringify(r.messages)),
  mainSha256: sha(r.meter.basePrompt), lockSha256: sha(r.meter.executionLock) });
const counts = r => Object.fromEntries(['交互构造库【', '第三池', '正常文档流', '360px', 'Visual Scenery 场景优先级', '动态视觉组合【', '生成配色参考【'].map(key => [key, r.messages.map(m => m.content.split(key).length - 1)]));
const cases = [];
for (const lotteryMethod of ['random', 'atmosphere']) for (const kind of ['ordinary', 'scenery', 'combination']) for (const rawPolicy of ['compact', 'balanced', 'full']) for (const modes of [['html'], ['html', 'longtext']]) cases.push({ lotteryMethod, kind, rawPolicy, modes });
const rows = [];
mkdirSync(destination + '/final-requests', { recursive: true });
for (const [index, c] of cases.entries()) {
  const overrides = { lotteryMethod: c.lotteryMethod, atmosphereStoryPercent: 100, rawPolicy: c.rawPolicy,
    forceVisualScenery: c.kind === 'scenery', visualSceneryCombination: c.kind === 'combination',
    rabbitMirrorFaceCount: c.modes.length, rabbitMirrorPresentationModes: c.modes, visualDesignMode: 'guided1553' };
  const before = await captureFinalPrompt(baseline, { overrides, history });
  // The production composer supports one pinned face per serial request.
  // Compare each frozen face separately; multi-face normal captures remain below.
  const pinned = [];
  for (const selection of before.selections) {
    const single = { ...overrides, rabbitMirrorFaceCount: 1, rabbitMirrorPresentationModes: [selection.combo.requestedPresentationMode || 'html'] };
    const pin = { overrides: single, history, requestOptions: { pinnedSelections: [selection] } };
    const pinnedOld = await captureFinalPrompt(baseline, pin), pinnedNext = await captureFinalPrompt(candidate, pin);
    assert.deepEqual(pinnedNext.messages, expectedMessages(pinnedOld.messages), 'only approved scene-motion wording: ' + index);
    assert.deepEqual(pinnedNext.selections, pinnedOld.selections, 'frozen selection unchanged');
    let sameDynamicRulesAcrossBeautyModes = null;
    if (c.kind !== 'ordinary' && selection.combo.presentationMode !== 'text') {
      const oldBeauty = await captureFinalPrompt(candidate, { ...pin, overrides: { ...single, visualDesignMode: 'reference1553' } });
      assert.ok(pinnedNext.messages[0].content.includes(GUIDED_VISUAL_FLOOR));
      assert.ok(oldBeauty.messages[0].content.includes(REFERENCE_VISUAL_FLOOR));
      const withoutFloor = r => r.messages.map(m => ({ ...m, content: m.content.replaceAll(GUIDED_VISUAL_FLOOR, '<beauty-floor>').replaceAll(REFERENCE_VISUAL_FLOOR, '<beauty-floor>') }));
      assert.deepEqual(withoutFloor(oldBeauty), withoutFloor(pinnedNext), 'only the beauty floor differs: ' + index);
      sameDynamicRulesAcrossBeautyModes = true;
    }
    pinned.push({ before: fields(pinnedOld), after: fields(pinnedNext), sameDynamicRulesAcrossBeautyModes, messages: pinnedNext.messages });
  }
  const fresh = await captureFinalPrompt(candidate, { overrides, history });
  const section = fresh.meter.basePrompt.split('交互构造库【')[1]?.split('\n\n兔子镜')[0] || '';
  const sentCodes = [...new Set(section.match(/I\.\d{2}/g) || [])];
  assert.ok(sentCodes.length > 0 && sentCodes.length < 80);
  assert.equal(fresh.dispatches, 1);
  assert.equal(counts(fresh)['生成配色参考【'][0], 0);
  const row = { index, ...c, onlyApprovedPromptChanges: true, sameDynamicRulesAcrossBeautyModes: pinned.some(p => p.sameDynamicRulesAcrossBeautyModes), before: fields(before), pinned: pinned.map(({ messages, ...p }) => p), fresh: fields(fresh), sentCodes, counts: counts(fresh) };
  rows.push(row);
  if (c.rawPolicy === 'balanced') writeFileSync(destination + '/final-requests/' + index + '.json', JSON.stringify({ row, before: before.messages, pinned: pinned.map(p => p.messages), fresh: fresh.messages, selections: fresh.selections, boundary: 'Production request composer, offline transport interception; no model call.' }, null, 2));
}
writeFileSync(destination + '/request-matrix.json', JSON.stringify({ protectedHashes, oldRecipeEntriesUnchanged: 80, totalRecipes: nextIndex.length, rows }, null, 2));
console.log(JSON.stringify({ cases: rows.length, pinnedCompared: rows.reduce((n, r) => n + r.pinned.length, 0), sharedDynamicComparisons: rows.filter(r => r.sameDynamicRulesAcrossBeautyModes).length, fullPoolSent: false }));
