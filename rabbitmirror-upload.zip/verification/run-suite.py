import json, os, pathlib, re, subprocess, sys, time

root = pathlib.Path(sys.argv[1]).resolve()
label = sys.argv[2]
out = pathlib.Path(__file__).resolve().parent
dom = pathlib.Path(os.environ.get('RM_TEST_DOM_MODULE', str(out / 'dom-version-probe/node_modules/happy-dom/lib/index.js'))).resolve()
dom_version = json.loads((dom.parent.parent / 'package.json').read_text())['version']
env = os.environ | {'RM_TEST_DOM_MODULE': str(dom)}
command = ['node', '--experimental-vm-modules', '--test', '--test-reporter=tap', '--test-concurrency=2']
command += sorted(str(p) for p in (root / 'tests').glob('*.test.mjs'))
started = time.monotonic()
with (out / (label + '.tap')).open('w') as stream:
    result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, env=env)
log = (out / (label + '.tap')).read_text()
report = {
    'source': str(root), 'command': command, 'exitCode': result.returncode,
    'seconds': time.monotonic() - started,
    'stats': {key: int(value) for key, value in re.findall(r'^# (tests|pass|fail|skipped) (\d+)', log, re.M)},
    'failures': re.findall(r'^not ok \d+ - (.+)', log, re.M),
    'environment': f'Node {subprocess.check_output(["node", "--version"], text=True).strip()}, happy-dom {dom_version}, offline host stubs; no live model/host/device',
}
(out / (label + '.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2))
print(json.dumps(report | {'command': command[:5]}, ensure_ascii=False))
