import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const root = path.resolve(process.argv[2]);
const walk = dir => readdirSync(dir).flatMap(name => {
    const file = path.join(dir, name);
    return statSync(file).isDirectory() ? walk(file) : file.endsWith('.js') ? [file] : [];
});
const files = [path.join(root,'index.js'), ...walk(path.join(root,'src')), ...walk(path.join(root,'data'))];
const texts = new Map(files.map(file => [file, readFileSync(file,'utf8')]));
const hostNames = new Map();
const resolve = (specifier, from) => path.resolve(path.dirname(from),specifier.split('?')[0]);
for (const [file, source] of texts) for (const m of source.matchAll(/import\s+\{([\s\S]*?)\}\s+from\s+['"]([^'"]+)['"]/g)) {
    if (!m[2].startsWith('.')) continue;
    const target = resolve(m[2],file);
    if (target.startsWith(root+'/')) continue;
    const names = hostNames.get(target)||new Set();
    for (const part of m[1].split(',')) {
        const name = part.trim().match(/^([\w$]+)/)?.[1];
        if(name) names.add(name);
    }
    hostNames.set(target,names);
}
const context=vm.createContext({}), modules=new Map();
function get(file) {
    if(modules.has(file))return modules.get(file);
    const module = texts.has(file) ? new vm.SourceTextModule(texts.get(file),{context,identifier:file})
        : hostNames.has(file) ? new vm.SyntheticModule([...hostNames.get(file)],function(){},{context,identifier:file})
        : (()=>{throw new Error('Unexpected import '+file);})();
    modules.set(file,module);return module;
}
for (const file of files) {
    const module=get(file);
    if(module.status==='unlinked')await module.link((specifier,importer)=>get(resolve(specifier,importer.identifier)));
}
console.log(JSON.stringify({productionModulesLinked:files.length,missingNamedExports:0,hostModulesStubbed:[...hostNames.keys()].map(file=>path.basename(file)),evaluation:'not performed; link/exports check only'}));
