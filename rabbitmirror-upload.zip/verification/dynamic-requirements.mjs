import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { captureFinalPrompt } from '../../work/rabbitmirror-1.62.57/tests/helpers/finalPromptCapture.mjs';

const [root = 'work/rabbitmirror-1.62.57', destination = 'verification/1.62.57/dynamic-evidence'] = process.argv.slice(2);
const rows = [];
const digest = text => createHash('sha256').update(text).digest('hex');
mkdirSync(destination, { recursive: true });
for (const visualDesignMode of ['guided1553', 'reference1553'])
for (const kind of ['scenery', 'combination'])
for (const enhancedVisualDrawing of [false, true])
for (const lotteryMethod of ['random', 'atmosphere'])
for (const rawPolicy of ['compact', 'balanced', 'full']) {
    const overrides = { visualDesignMode, forceVisualScenery: kind === 'scenery',
        visualSceneryCombination: kind === 'combination', enhancedVisualDrawing,
        lotteryMethod, rawPolicy, rabbitMirrorFaceCount: 1, rabbitMirrorPresentationModes: ['html'] };
    const captured = await captureFinalPrompt(root, { overrides });
    const text = captured.messages.map(message => message.content).join('\n');
    const checks = {
        scope: text.includes(kind === 'scenery' ? 'Visual Scenery 场景优先级' : '动态视觉组合【'),
        realKeyframes: text.includes('@keyframes') && text.includes('animation') && text.includes('infinite'),
        visibleWithinOneSecond: text.includes('1 秒内') && text.includes('肉眼可见'),
        opensRunning: kind === 'scenery' ? text.includes('打开即运行') : text.includes('打开即循环'),
        mainAndEnvironment: text.includes('主动画') && text.includes('协同环境动画'),
        notOnlyStaticOrTransition: text.includes('transition') && text.includes('静态 SVG') && text.includes('不算'),
        activeBeforeInteraction: kind === 'scenery' ? text.includes('场景未操作时') : text.includes('未操作时核心画面'),
        sceneMarker: text.includes('data-rm-visual-scenery="true"'),
        enhancementIndependent: text.includes('增强视觉绘制：') === enhancedVisualDrawing,
        singleDispatch: captured.dispatches === 1,
        sceneCausality: text.includes('运动因果'),
        concreteExamples: ['落叶落花', '车辆行进', '命运红线'].every(x => text.includes(x)),
        rejectsCardOnlyMotion: text.includes('文字卡片漂浮') && text.includes('不能充当主动画'),
        coordinatedEnvironment: text.includes('方向、节奏或因果上呼应'),
        examplesNotTemplate: text.includes('例子只作启发') && text.includes('不固定套用'),
    };
    for (const [key, passed] of Object.entries(checks)) assert.equal(passed, true, JSON.stringify(overrides) + ': ' + key);
    const row = { index: rows.length, ...overrides, checks, messagesSha256: digest(JSON.stringify(captured.messages)) };
    rows.push(row);
    if (rawPolicy === 'balanced' && lotteryMethod === 'random') {
        writeFileSync(destination + '/' + row.index + '.json', JSON.stringify({ row, messages: captured.messages }, null, 2));
    }
}
writeFileSync(destination + '/matrix.json', JSON.stringify({
    source: root, evidence: 'Actual production request composer intercepted before network; no model response or real-device playback tested.',
    cases: rows.length, allPassed: true, rows,
}, null, 2));
console.log(JSON.stringify({ cases: rows.length, allPassed: true, checksPerCase: 15 }));
