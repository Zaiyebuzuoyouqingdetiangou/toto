import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import vm from 'node:vm';
import { createHash } from 'node:crypto';
import { createDomRuntime } from '../../work/rabbitmirror-1.62.57/tests/helpers/browserDomRuntime.mjs';

const [candidate = 'work/rabbitmirror-1.62.57', destination = 'verification/1.62.57/replayed-evidence.json'] = process.argv.slice(2);
const evidencePath = 'upload/rabbitmirror-evidence-rm-evidence-1790905739023-2.json';
const bytes = readFileSync(evidencePath);
const raw = JSON.parse(bytes).response.text;
const rows = [];
for (const root of ['verification/1.62.57/baseline', candidate]) {
    const rt = await createDomRuntime(root);
    try {
        const sanitizer = await rt.load('src/outputSanitizer.js');
        const request = await rt.load('src/independentApi/request.js');
        const geometry = await rt.load('src/independentApi/geometry.js');
        const source = readFileSync(root + '/src/independentApi/request.js', 'utf8');
        const between = (a, b) => source.slice(source.indexOf(a), source.indexOf(b));
        Object.assign(rt.context, {
            cleanRabbitMirrorOutput: sanitizer.cleanRabbitMirrorOutput,
            wrappedIndependentMirrorHtml: request.wrappedIndependentMirrorHtml,
        });
        vm.runInContext(between('function extractMirrorInner(', 'function recoverableCompletedIndependentAbort(')
            + between('function independentMirrorBodyEvidence(', 'function independentVisualProgramIntegrity('), rt.context);
        const rawComplexity = request.assertIndependentMarkupComplexity(raw);
        const inner = rt.context.extractMirrorInner(raw);
        const body = rt.context.independentMirrorBodyEvidence(inner);
        if (!body) { rows.push({ root, selectedBody: false, rawComplexity, selectedChars: inner.length }); continue; }
        const innerComplexity = request.assertIndependentMarkupComplexity(inner);
        const ready = geometry.prepareIndependentReadyHtml(inner);
        request.assertIndependentMarkupComplexity(ready);
        const saved = geometry.scrubIndependentInteractionState(ready, ready);
        const host = geometry.buildExternalHost('offline:real-evidence:1', saved, 'ready', 'independent', true);
        rt.window.document.body.append(host);
        const details = host.querySelector('details');
        const sheets = [...details.querySelectorAll('style')].map(n => n.textContent).join('\n');
        const keyframes = [...sheets.matchAll(/@keyframes\s+([^\s{]+)/g)].map(m => m[1]);
        const animated = [...details.querySelectorAll('*')].filter(n => {
            const animation = rt.window.getComputedStyle(n).getPropertyValue('animation');
            return animation && animation.includes('infinite');
        });
        assert.equal(keyframes.length, 3);
        assert.equal(details.querySelectorAll('svg').length, 2);
        assert.equal(details.querySelectorAll('input[type="checkbox"]').length, 4);
        assert.ok(animated.length >= 3);
        for (const label of details.querySelectorAll('label[for]')) assert.ok(details.querySelector(`[id="${label.htmlFor}"]`));
        assert.equal(rt.context.independentMirrorBodyEvidence(ready), true);
        assert.doesNotMatch(ready, /<script\b|\son\w+\s*=/i);
        rows.push({ root, selectedBody: true, rawComplexity, innerComplexity, selectedChars: inner.length,
            readyChars: ready.length, keyframes: keyframes.length, svg: 2, controls: 4,
            cssAnimationBoundNodes: animated.length, savedAndMountedInDom: true, liveBrowserRendering: false });
    } finally { await rt.close(); }
}
assert.equal(rows[0].selectedBody, false);
assert.equal(rows[1].selectedBody, true);
const report = { evidenceSha256: createHash('sha256').update(bytes).digest('hex'), rawChars: raw.length,
    sameReply: true, modelCalls: 0, boundary: 'Actual extraction, budgets, sanitation, save and DOM mount; no live browser or model generation.', rows };
writeFileSync(destination, JSON.stringify(report, null, 2));
console.log(JSON.stringify(report));
