from pathlib import Path
import concurrent.futures, json, re, subprocess, sys

root=Path(sys.argv[1]).resolve()
version=json.loads((root/'manifest.json').read_text())['version']
sources=sorted([*root.rglob('*.js'), *root.rglob('*.mjs')])
def check(p):
    r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
    return [str(p.relative_to(root)),r.returncode,r.stderr]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    syntax=list(pool.map(check,sources))
assert not [x for x in syntax if x[1]], [x for x in syntax if x[1]]
imports=0; host=set(); versions={}; targets={}
runtime=[root/'index.js',*sorted((root/'src').rglob('*.js')),*sorted((root/'data').rglob('*.js'))]
for p in runtime:
    s=p.read_text()
    for spec in re.findall(r'''(?:\bfrom\s*|\bimport\s*\(\s*|\bimport\s*)["']([^"']+)["']''',s):
        if not spec.startswith('.'): continue
        target=(p.parent/spec.split('?')[0]).resolve()
        if target.is_relative_to(root):
            imports+=1
            assert target.is_file(), [p,spec]
            if '?rmv=' in spec:
                assert spec.split('?rmv=')[1]==version, [p,spec]
                targets.setdefault(str(target.relative_to(root)),set()).add(spec.split('?rmv=')[1])
        else: host.add(spec)
for rel,key in [('index.js','RABBIT_MIRROR_RUNTIME_VERSION'),('src/independentApi/runtime.js','RUNTIME_VERSION'),('src/outputSanitizer/runtime.js','RUNTIME_VERSION'),('src/ui/runtime.js','RUNTIME_VERSION'),('src/ui/runtime.js','SETTINGS_UI_VERSION')]:
    stamp=re.search(r'\bconst '+key+r" = '([^']+)'",(root/rel).read_text()).group(1)
    assert stamp==version, [rel,stamp,version]
    versions[rel+':'+key]=stamp
manifest=json.loads((root/'manifest.json').read_text())
assert manifest['js']=='index.js?rmv='+version
assert manifest['css']=='style.css?rmv='+version
result={'syntaxPassed':len(syntax),'syntaxFailed':0,'internalImports':imports,'missingInternalImports':0,'cacheCohorts':1,'hostProvidedModules':sorted(host),'runtimeVersions':versions}
print(json.dumps(result,ensure_ascii=False,indent=2))
