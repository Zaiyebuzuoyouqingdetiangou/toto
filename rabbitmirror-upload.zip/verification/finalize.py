from pathlib import Path
import difflib, hashlib, json, zipfile

out = Path(__file__).resolve().parent
project = out.parents[1]
deliver = project / 'deliverables'
read = lambda name: json.loads((out / name).read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
baseline, candidate, final = [read(name) for name in ['round2-baseline.json', 'round2-candidate.json', 'round3-reextracted.json']]
assert baseline['stats'] == {'tests': 925, 'pass': 910, 'fail': 8, 'skipped': 7}
assert candidate['stats'] == final['stats'] == {'tests': 937, 'pass': 922, 'fail': 8, 'skipped': 7}
assert baseline['failures'] == candidate['failures'] == final['failures']
assert read('round2-source.json') == read('round3-source.json')
assert read('round2-links.json') == read('round3-links.json')
assert read('request-evidence/request-matrix.json') == read('final-package/request-evidence/request-matrix.json')
assert read('dynamic-evidence/matrix.json')['rows'] == read('final-package/dynamic-evidence/matrix.json')['rows']
snapshots = 0
for folder in ['request-evidence/final-requests', 'dynamic-evidence']:
    for p in (out / folder).glob('*.json'):
        if p.name == 'matrix.json': continue
        assert p.read_bytes() == (out / 'final-package' / folder / p.name).read_bytes(), p
        snapshots += 1
assert snapshots == 20
real = read('replayed-evidence.json')
packaged_real = read('final-package/replayed-evidence.json')
assert [{k:v for k,v in row.items() if k!='root'} for row in real['rows']] == [{k:v for k,v in row.items() if k!='root'} for row in packaged_real['rows']]
scope = read('scope.json')
assert scope['counts'] == {'unchanged': 80, 'functional/documentation': 4, 'version-only': 80}
installer = read('installer-manifest.json')
assert sha(Path(installer['installer']).read_bytes()) == installer['sha256']
assert read('targeted-summary.json')[1]['exit'] == 0
summary = {
    'baseline': read('baseline.json'), 'installer': {k:installer[k] for k in ['bytes','sha256','fileCount','crc']},
    'round1': read('targeted-summary.json'),
    'round2': {'baseline':baseline['stats'], 'candidate':candidate['stats'], 'noNewFailures':True},
    'round3': {'finalZip':final['stats'], 'source':read('round3-source.json'), 'links':read('round3-links.json'), 'identicalSnapshots':snapshots},
    'failureNames':final['failures'], 'scope':scope['counts'], 'promptFunctions':{k:v for k,v in scope['promptFunctions'].items() if k!='hashes'},
    'realReplyReplay':real, 'requestChecks':{'dynamic':48,'checksEach':15,'scopeMatrix':36,'frozenFaces':54,'sharedBeautyDynamic':24},
    'limitations':{'liveModel':False,'realSillyTavern':False,'TouchTheater':False,'iPhone':False,'pixelAnimationPlayback':False,'visualImprovementProven':False},
    'remoteGitRead':False,'remoteGitWrites':False,'extraModelRequests':0,
}
(out/'verification-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))

report = f'''RabbitMirror／兔子镜小剧场 1.62.57 复核说明
日期：2026-10-02（日本时间）

本次结果
修复独立单面回复中“前面空草稿挡住后面完整成品”的提取问题。动态场景与动态组合的动画方向改为景物、物件或关系自身的运动因果。
安装包：rabbitmirror-upload-1.62.57.zip
大小：{installer['bytes']} 字节；164 个生产文件直接在 ZIP 根目录；不含测试。
SHA-256：{installer['sha256']}
基线：本会话刚交付的 rabbitmirror-upload-1.62.56.zip，SHA-256 cd508aa1771864cfaf1c6e68e99955d6c43c790fe651caf5e6dad5c13395ccdf。
基线 ZIP CRC、文件清单、manifest 和 164 文件与实际源码逐字节一致；未使用其他旧包替换底座。

提取修复
在同一次可见回复里，按顺序检查已闭合的 toto 候选，跳过只含标题、注释或样式的空壳；采用首个具有正文的候选。正常首份成品保持优先，不盲取最长或最后一份，不拼接不同作品。
仍沿用已有正文识别，不能据此判断审美质量或语义是否写完。全部为空时保留原空壳错误，后续未闭合草稿不取代前面空壳；原有外壳救援分支不改。
整份原始回复的复杂度检查在选取之前执行；选中候选仍走原有复杂度、安全净化、净化后正文检查。多面协议不改；本地取消、响应超限及不完整输出的既有边界保留。没有新增重试、模型调用、生成拒收或运行时巡检。

真实用户证据重放
来源：rm-evidence-1790905739023-2；文件 SHA-256 ed2f5b0aafc6d1b6c3ad850cca8abc7f69fd4eb9ae422f2a4edfbdc57f52dd57。
原始回复 10288 字符；原运行版本 1.62.53。前面为空草稿，后面是《古宅诡梦分镜》完整作品。
1.62.56 选中 111 字符的空壳；1.62.57 选中后面 9721 字符的正文，正常准备后 9797 字符。
实际提取、复杂度检查、净化、保存与离线 DOM 挂载保留 3 组关键帧、2 个 SVG、4 个复选控件；6 个节点仍匹配 infinite 动画声明，label 与 input 绑定有效。
最终 ZIP 重解压后重放结果一致。没有重新请求模型，未改写用户作品内容。CSSOM 绑定存在不等于浏览器真实插值、手机播放或观感验收；该样本的原始动画仍偏装饰，本次提取修复不会凭空重画它。

动画方向
将原抽象运动说明换成“原理＋例如”：先确定景物、物件或关系的运动因果，例如落叶落花随风飘落、车辆行进与路面后移、命运红线牵引两端对象。例子只作启发，由正文与展现形式决定采用什么。
整张文字卡片漂浮、无关法阵旋转、通用光点游走不能代替主动画；辅助动画来自同一场景，在方向、节奏或因果上呼应。纯动态辅助动画不再局限于原先列举的几类环境元素。
打开即循环、1 秒内肉眼可见、真实关键帧、主辅协同保持。原一主一辅连续动画与粒子群／大面积滤镜性能要求不改。新旧美化共用，增强关闭也适用；不新增开关或固定动画模板。
新旧美化 × 纯动态/组合 × 增强开关 × 随机/正文挑签 × 三种资料档位，共 48 组实际请求组装、每组 15 项通过。36 组范围矩阵、54 个冻结面仅出现已审核的动态说明差异，24 组新旧美化对照仅美化指导不同。54 组最终消息字符差为 0、115 或 183，不能外推为所有设置的 Token 数。
新增说明是创作方向，不是生成后的审美拦截器。以上证明提示发送完整，不证明真实模型输出达到期待。

三轮验证
第一轮：最终 12 项定向在未改 .56 为 5 通过／7 失败，在候选 12 通过。初版测试有一处未绑定取证助手，已修正测试环境并重新对原版／候选执行；初始日志保留。
第二轮：基线 925 项，910 通过／8 失败／7 跳过；候选 937 项，922 通过／8 失败／7 跳过。失败名称一致，无新增失败或跳过。
第三轮：最终 ZIP 独立重解压为 937／922／8／7；265 个 JS/MJS 语法、575 条内部导入、156 个生产模块链接、运行/缓存版本、ZIP CRC 与 164 文件逐字节/SHA 通过。20 份最终请求快照与工作目录逐字一致，原样本重放一致。
8 项既有失败：3 项旧交互数量断言，2 项已退役配色库对比度，3 项长文本／纯点菜提示断言；本轮未删测或改产品迎合它们。7 项为缺少更早外部历史基线的条件跳过，不算通过。
基线安装包未附测试；沿用 .56 复核源的 115 个测试/夹具文件且字节不变，新增 completeWork57.test.mjs 与 sceneMotion57.test.mjs。环境 Node v24.19.0、happy-dom 20.14.5。

范围
4 个功能或说明文件：request.js、promptBuilder.js、visualSceneryRules.js、README.md；80 文件字节不变、80 文件仅版本戳变化。PromptBuilder 的 98 个原函数分段中 96 个规范化哈希不变，仅两段动态核心有授权修改。
.56 的 80 项交互及新增玩法适配、同面搭配偏好保留。增强、美化指导、配色冷却、存储、净化、挂载、多面、暂停恢复、手动一次尝试等源码除版本戳外不变。未新增控件/SVG配额、计时器、Observer、自动补发或设置迁移。
另外两份流式空正文证据缺少上游网络帧，本次没有推测修改传输解析；此问题不标为已解决。
没有访问或修改远端 Git；没有 commit、push、branch 或 PR。

使用与验收
安装候选后整页刷新，确认显示 1.62.57；无需清空设置、历史或收藏。提取规则作用于新处理的回复，动画说明作用于新的生成，旧成品不会自动重画。
尚未完成真实 SillyTavern 实机测试。
尚未完成该模型／中转站的真实联网生成测试。
尚未完成 TT／iPhone 播放、触屏、帧率和发热验收，不能宣称画面质量已经恢复。
下一次正常生成应观察：具体景物/事物是否自己发生持续运动、环境是否呼应、操作是否改变同一画面。保留同次最终请求、原始回复和成品，区分提取正确与模型画得是否合意。
'''
(deliver/'rabbitmirror-1.62.57-review.txt').write_text(report)

current = project/'project_sources/01-01-01-RabbitMirror-CURRENT.md'
before = current.read_bytes()
assert sha(before) == 'e9236630a28c30022154f5392620e49b772fd597e46f0dacb19a9460ff154905'
(out/'CURRENT-before.md').write_bytes(before)
text = before.decode()
heading = '### 1\\.1 最近候选：1.62.56 新增玩法适配与相近玩法同面搭配'
entry = f'''### 1\\.1 最近候选：1.62.57 完整成品提取与场景动画方向

- **本轮授权**：提取时跳过空草稿，采用同次回复里的完整成品，再正常净化；动画须与景色、事物或叙事关系密切相关，例如落叶落花、行车、命运红线，不用空泛装饰顶替。本轮局部改动态说明，不重写新旧美化指导或增强。
- **基线与候选**：沿用本会话已交付完整 .56 实包，SHA `cd508aa1771864cfaf1c6e68e99955d6c43c790fe651caf5e6dad5c13395ccdf`，164 文件逐字节核验。候选 `rabbitmirror-upload-1.62.57.zip`，{installer['bytes']} 字节，SHA `{installer['sha256']}`；独立新包，不换底座。
- **提取修复**：独立单面按先后顺序检查已闭合 toto，跳过原正文判据认定为空的标题/样式草稿，保留首个有正文候选；没有候选时维持原空壳失败。整回复预算、后续预算/安全净化/正文检查、取消边界、多面协议保留，不新增请求、不拼接或盲取最长/最后一份。
- **真实取证**：用户的 rm-evidence-1790905739023-2（运行 .53）10288 字符回复前空后全；.56 重放仍选 111 字符空壳，.57 选 9721 字符完整体，净化后 9797 字符；保存与 DOM 挂载保留 3 关键帧、2 SVG、4 控件及 6 个动画绑定节点。最终 ZIP 重放一致；没有新模型调用或真实浏览器播放。这份成品本身仍偏装饰，提取修复不等于重画。
- **动画说明**：纯动态/组合改为运动因果＋启发例子，主动画落实到景物/物件/关系，辅助动画与之呼应，例子不作固定模板；文字卡片漂浮、无关法阵/光点不能代替主动画。原纯动态辅助元素枚举改为同场景关系要求；打开即循环、1秒内可见、真实关键帧、一主一辅性能规则保持。增强关闭及新旧美化均适用。
- **三轮验证**：新12项在 .56 为5通过/7失败，候选全过；全量基线925/910通过/8失败/7跳过，候选与最终ZIP均937/922/8/7，既有失败名称相同。265语法、575内部导入、156模块链接、164文件CRC/字节/SHA通过；48动态请求、36范围矩阵/54冻结面/24美化对照、20最终快照一致。请求只出现审核后的局部动态说明差异，不以提示发送合格冒充画面验收。
- **范围与边界**：4功能/说明文件（request.js、promptBuilder.js、visualSceneryRules.js、README），80字节不变、80仅版本；98个PromptBuilder函数分段中96哈希不变。115继承测试文件不动，新加2测试文件。原8失败为3旧交互数量、2退役配色对比度、3长文本/纯点菜断言；7旧外部基线条件跳过。无新阻断、重试、控件/SVG配额、计时器或远端Git写入；.56交互改进保留。
- **未完成事项**：两份其他流式证据正文为空，没有原始网络帧，未臆测改传输。尚未完成真实 SillyTavern 实机测试，尚未完成该模型/中转站的真实联网生成测试；TT/iPhone与画面改善待实际验收。旧成品不自动重画。

### 1\\.1-56 上一候选：1.62.56 新增玩法适配与相近玩法同面搭配'''
assert heading in text
text = text.replace(heading,entry,1).replace('当前要求以顶部 .56 和第3／4节为准。','当前要求以顶部 .57 和第3／4节为准。')
anchor = '- 新旧美化共用同一套动态视觉专用规则与增强绘制，区别保留在美化指导，不维护两套分叉的动态实现。'
text = text.replace(anchor,anchor+'\n- 2026-10-02 最新动画方向：动画发生在本面景色、事物或关系上，用运动因果构思；落叶落花、行车、命运红线只作启发，不固定套用。主体和环境协同，整张文字卡片漂浮或无关法阵/光点不能替代主动画；实际输出验收与提示发送检查分开。',1)
anchor = '- DeepSeek 的 `reasoning_content` 必须排除，只读取最终 `content`。'
text = text.replace(anchor,anchor+'\n- 独立单面同次回复若先有空草稿、后有有正文的完整候选，按顺序跳过空草稿，采用首个有正文候选，再正常净化；不额外请求、不拼接不同成品，原完整性与安全边界保留。',1)
current.write_text(text)
(out/'CURRENT-after.md').write_text(text)
(out/'CURRENT.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),text.splitlines(True),fromfile='CURRENT-before.md',tofile='CURRENT-after.md')))

review = deliver/'rabbitmirror-review-1.62.57.zip'
with zipfile.ZipFile(review,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    source=project/'work/rabbitmirror-1.62.57'
    for p in sorted(source.rglob('*')):
        if p.is_file():archive.write(p,'source/'+str(p.relative_to(source)))
    for p in sorted(out.rglob('*')):
        if not p.is_file() or any(part in {'baseline','reextracted57','library-helpers'} for part in p.relative_to(out).parts):continue
        archive.write(p,'verification/'+str(p.relative_to(out)))
    archive.write(project/'deliverables/rabbitmirror-upload-1.62.56.zip','baseline/rabbitmirror-upload-1.62.56.zip')
    archive.write(deliver/'rabbitmirror-1.62.57-review.txt','review.txt')
    archive.write(current,'CURRENT.md')
with zipfile.ZipFile(review) as archive:assert archive.testzip() is None
paths=[deliver/'rabbitmirror-upload-1.62.57.zip',review,deliver/'rabbitmirror-1.62.57-review.txt']
(deliver/'rabbitmirror-1.62.57-SHA256.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in paths))
print(json.dumps({'installer':installer['sha256'],'review':sha(review.read_bytes()),'files':[str(p) for p in paths],'snapshotCount':snapshots,'currentSha256':sha(current.read_bytes())},ensure_ascii=False))
