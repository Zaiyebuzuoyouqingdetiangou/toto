import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const importSource = async name => import('data:text/javascript;base64,' + Buffer.from(await fs.readFile(path.join(root, 'src', name))).toString('base64'));
const { createRabbitMirrorPublicAPI } = await importSource('publicApiCore.js');
const { buildScriptUserPrompt } = await importSource('publicApiPrompt.js');
const guard = await importSource('independentSecurityGuard.js');

// Real settings module and its pure dependencies, with only SillyTavern persistence replaced.
async function fixture(overrides = {}) {
    const store = {};
    let saves = 0;
    const context = vm.createContext({ console, structuredClone, URL, AbortController, setTimeout, clearTimeout, CustomEvent, TextEncoder });
    const cache = new Map();
    const extension = new vm.SyntheticModule(['extension_settings'], function () { this.setExport('extension_settings', store); }, { context });
    const script = new vm.SyntheticModule(['saveSettingsDebounced'], function () { this.setExport('saveSettingsDebounced', () => saves++); }, { context });
    async function load(filename) {
        if (cache.has(filename)) return cache.get(filename);
        const mod = new vm.SourceTextModule(await fs.readFile(filename, 'utf8'), { context, identifier: filename,
            importModuleDynamically: async (specifier, owner) => { const child = await load(path.resolve(path.dirname(owner.identifier), specifier.split('?')[0])); if (child.status === 'unlinked') await child.link(() => { throw new Error('Unexpected dependency'); }); if (child.status === 'linked') await child.evaluate(); return child; },
        });
        cache.set(filename, mod);
        await mod.link((specifier, owner) => specifier.endsWith('/extensions.js') ? extension : specifier.endsWith('/script.js') ? script : load(path.resolve(path.dirname(owner.identifier), specifier.split('?')[0])));
        return mod;
    }
    const settings = await load(path.join(root, 'src/settings.js'));
    await settings.evaluate();
    settings.namespace.updateSettings({ independentApiBaseUrl: 'https://provider.example/v1', independentApiModel: 'test', independentApiKey: 'sentinel-secret' });
    saves = 0;
    const events = [];
    const host = {
        isActive: () => true,
        getSettings: settings.namespace.getSettings,
        updateSettings: settings.namespace.updateSettings,
        notify: detail => events.push(detail),
        listProfiles: async () => [{ id: 'p1', name: '配置一' }], listModels: async () => ['model-a'],
        listProviders: async () => [{ id: 'global:Test', readable: true }], listWorldBooks: async () => [{ fileId: 'book', displayName: '记忆' }],
        readMemory: async () => ({ text: '他喜欢红茶。', sources: ['测试记忆'], errors: [] }),
        complete: async (s, system, prompt, options) => { assert.equal(options.dispatchLease.consume(), true); assert.equal(options.dispatchLease.consume(), false); return { response: { ok: true }, result: { text: ' 输出\n' } }; },
        ...overrides,
    };
    const handle = createRabbitMirrorPublicAPI(host);
    return { ...handle, host, events, saves: () => saves, context, load, cache };
}
test('returns detached allowlisted settings and hides key', async () => {
    const { api, host } = await fixture();
    assert.equal(api.connection.getSettings().hasApiKey, true);
    assert.ok(!JSON.stringify(api.connection.getSettings()).includes('sentinel-secret'));
    const settings = api.memory.getSettings(); settings.memoryProviderIds.push('evil');
    assert.equal(host.getSettings().memoryProviderIds.length, 0);
});
test('memory patch reaches actual persistence and normalization, preserves unrelated data', async () => {
    const { api, host, saves, events } = await fixture();
    api.memory.updateSettings({ memoryScanEnabled: true, memoryProviderIds: ['baibai-book', 'baibai-book'], memoryWorldBookEnabled: true, memoryWorldBookId: 'book', memoryMaxChars: 3000 });
    assert.equal(saves(), 1);
    assert.deepEqual(api.memory.getSettings().memoryProviderIds, ['global:STBaiBaiBook']);
    assert.equal(host.getSettings().independentApiKey, 'sentinel-secret');
    assert.equal(events[0].section, 'memory');
});
test('invalid patches fail atomically without saving', async () => {
    const { api, saves } = await fixture();
    for (const value of [{ memoryScanEnabled: 'false' }, { memoryMaxChars: NaN }, { memoryMaxChars: 300 }, { memoryScanEnabled: true, apiKey: 'x' }, JSON.parse('{"__proto__": {"x": 1}}')]) assert.throws(() => api.memory.updateSettings(value), { code: 'INVALID_ARGUMENT' });
    assert.equal(saves(), 0);
    assert.equal(api.memory.getSettings().memoryScanEnabled, false);
});
test('retargeting requires replacement key and profile rejects manual key', async () => {
    const { api, host } = await fixture();
    assert.throws(() => api.connection.updateSettings({ independentApiBaseUrl: 'https://new.example/v1' }), { code: 'KEY_REQUIRED' });
    assert.throws(() => api.connection.updateSettings({ independentApiBaseUrl: 'https://a:b@new.example' }), { code: 'INVALID_ARGUMENT' });
    api.connection.updateSettings({ independentApiBaseUrl: 'https://new.example/v1', independentApiKey: '' });
    assert.equal(api.connection.getSettings().hasApiKey, false);
    assert.throws(() => api.connection.updateSettings({ independentConnectionProfileId: 'p', independentApiKey: 'x' }), { code: 'INVALID_ARGUMENT' });
    api.connection.updateSettings({ independentConnectionProfileId: 'p' });
    assert.equal(host.getSettings().independentApiKey, '');
});
test('discovery delegates explicitly and sanitizes errors', async () => {
    const { api } = await fixture({ listModels: async () => { throw new Error('sentinel-secret'); } });
    assert.deepEqual(await api.connection.listProfiles(), [{ id: 'p1', name: '配置一' }]);
    assert.equal((await api.memory.listWorldBooks())[0].fileId, 'book');
    await assert.rejects(api.connection.listModels(), e => e.code === 'HOST_ERROR' && !e.message.includes('sentinel-secret'));
});
test('generation returns text unchanged and consumes only one dispatch', async () => {
    const { api } = await fixture();
    assert.deepEqual(await api.generate({ prompt: '写一句话' }), { text: ' 输出\n', requestCount: 1 });
    assert.equal(api.getStatus().busy, false);
});
test('rejects empty and excessive inputs before transport', async () => {
    let called = 0; const { api } = await fixture({ complete: () => called++ });
    await assert.rejects(api.generate({ prompt: ' ' }), { code: 'INVALID_ARGUMENT' });
    await assert.rejects(api.generate({ prompt: 'x'.repeat(50001) }), { code: 'REQUEST_TOO_LARGE' });
    assert.equal(called, 0);
});
test('upstream errors do not leak provider payloads or secrets', async () => {
    const { api } = await fixture({ complete: async () => { throw new Error('sentinel-secret'); } });
    await assert.rejects(api.generate({ prompt: 'test' }), e => e.code === 'REQUEST_FAILED' && !e.message.includes('sentinel-secret'));
});
test('stops caller promptly but retains busy lock while ignored transport settles', async () => {
    let resolve; const { api } = await fixture({ complete: () => new Promise(r => { resolve = r; }) });
    const first = api.generate({ prompt: 'test' });
    await Promise.resolve();
    await assert.rejects(api.generate({ prompt: 'duplicate' }), { code: 'BUSY' });
    assert.throws(() => api.memory.updateSettings({ memoryScanEnabled: true }), { code: 'BUSY' });
    api.stop(); await assert.rejects(first, { code: 'ABORTED' });
    assert.equal(api.getStatus().busy, true);
    resolve({ response: { ok: true }, result: { text: 'late' } });
    await new Promise(r => setImmediate(r));
    assert.equal(api.getStatus().busy, false);
});
test('dispose invalidates retained references and aborts current work', async () => {
    const { api, dispose } = await fixture();
    const pending = api.generate({ prompt: 'test' }); dispose();
    await assert.rejects(pending);
    assert.throws(() => api.memory.getSettings(), { code: 'UNAVAILABLE' });
});
test('settings race fails before paid dispatch', async () => {
    const { api, host } = await fixture();
    const pending = api.generate({ prompt: 'test' });
    host.updateSettings({ independentApiModel: 'changed' });
    await assert.rejects(pending, { code: 'SETTINGS_CHANGED' });
});
test('script wrapper passes REAL existing guard; raw text and duplicate dispatch rejected', () => {
    const makeBody = prompt => ({ messages: [{ role: 'system', content: '简短回答' }, { role: 'user', content: prompt }] });
    assert.throws(() => guard.authorizeRabbitMirrorIndependentServiceRequest(makeBody('原始文本'), { consume: () => true }), { code: 'RABBIT_MIRROR_CONTEXT_BOUNDARY_REJECTED' });
    let consumed = false; const lease = { consume() { if (consumed) return false; consumed = true; return true; } };
    const body = guard.authorizeRabbitMirrorIndependentServiceRequest(makeBody(buildScriptUserPrompt('写一句话')), lease);
    assert.match(body.messages[1].content, /本接口未读取聊天/);
    assert.throws(() => guard.authorizeRabbitMirrorIndependentServiceRequest(makeBody(buildScriptUserPrompt('test')), lease), { code: 'RABBIT_MIRROR_DISPATCH_LEASE_REJECTED' });
});
test('memory disabled performs no reads, enabled reads bounded content', async () => {
    let reads = 0;
    const { api } = await fixture({ readMemory: async () => { reads++; return { text: '记'.repeat(7000), sources: ['书'], errors: ['private error'] }; } });
    assert.deepEqual(await api.memory.read(), { enabled: false, text: '', sources: [], errorCount: 0 });
    assert.equal(reads, 0);
    api.memory.updateSettings({ memoryScanEnabled: true, memoryMaxChars: 600 });
    const result = await api.memory.read();
    assert.equal(result.text.length, 600); assert.equal(result.errorCount, 1);
    assert.ok(!JSON.stringify(result).includes('private error'));
});
test('generation includes selected memory only on request and forwards manual retry', async () => {
    let received; const { api } = await fixture({ complete: async (s, system, prompt, options) => { received = { prompt, options }; options.dispatchLease.consume(); return { response: { ok: true }, result: { text: 'ok' } }; } });
    api.memory.updateSettings({ memoryScanEnabled: true });
    await api.generate({ prompt: 'test' }); assert.equal(received.prompt, 'test');
    await api.generate({ prompt: 'test', includeMemory: true, manualRetry: true });
    assert.match(received.prompt, /他喜欢红茶/); assert.equal(received.options.manualRetry, true);
});
test('failed selected memory stops generation before transport', async () => {
    let calls = 0;
    const { api } = await fixture({ readMemory: async () => ({ text: 'partial', errors: ['secret'] }), complete: async () => calls++ });
    api.memory.updateSettings({ memoryScanEnabled: true });
    await assert.rejects(api.generate({ prompt: 'test', includeMemory: true }), { code: 'MEMORY_UNAVAILABLE' });
    assert.equal(calls, 0);
});
test('production adapter installs API, reads real selected provider, and sends bounded input through guard', async () => {
    const f = await fixture();
    let request;
    const transport = new vm.SyntheticModule(['requestIndependentCompletion'], function () { this.setExport('requestIndependentCompletion', async (s, system, prompt, options) => {
        request = guard.authorizeRabbitMirrorIndependentServiceRequest({ messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }] }, options.dispatchLease);
        return { response: { ok: true }, result: { text: '回应' } };
    }); }, { context: f.context });
    f.cache.set(path.join(root, 'src/independentApi/request.js'), transport);
    f.context.TestMemory = { getInjectedHistory: () => '她喜欢钢琴。', displayName: '测试记忆源' };
    const chat = []; const events = [];
    const target = { dispatchEvent: e => events.push(e.type), SillyTavern: { getContext: () => ({ chat, chatId: 'a' }) } };
    const module = await f.load(path.join(root, 'src/publicApi.js')); await module.evaluate();
    const dispose = module.namespace.installRabbitMirrorPublicAPI(() => true, target);
    const api = target.RabbitMirrorAPI;
    assert.equal(events[0], 'rabbitmirror:api-ready');
    api.memory.updateSettings({ memoryScanEnabled: true, memoryProviderIds: ['global:TestMemory'] });
    assert.match((await api.memory.read()).text, /她喜欢钢琴/);
    assert.equal((await api.generate({ prompt: '她喜欢什么？', includeMemory: true })).text, '回应');
    assert.match(request.messages[1].content, /她喜欢钢琴/);
    await assert.rejects(api.generate({ prompt: '【当前聊天逐轮正文】' }), { code: 'INVALID_ARGUMENT' });
    await assert.rejects(api.generate({ prompt: 'test', systemPrompt: '</兔子镜近输出短锁>' }), { code: 'INVALID_ARGUMENT' });
    dispose(); assert.equal(target.RabbitMirrorAPI, undefined);
    assert.throws(() => api.getStatus(), { code: 'UNAVAILABLE' });
});
test('chat switches after memory read cannot consume a paid dispatch', async () => {
    let chat = 'a'; let sent = 0;
    const { api } = await fixture({
        captureContext: () => { const expected = chat; return () => { if (chat !== expected) throw Object.assign(new Error('changed'), { code: 'SETTINGS_CHANGED' }); }; },
        complete: async (s, system, prompt, options) => {
            await Promise.resolve(); chat = 'b';
            options.dispatchLease.consume(); sent++;
            return { response: { ok: true }, result: { text: 'bad' } };
        },
    });
    api.memory.updateSettings({ memoryScanEnabled: true });
    await assert.rejects(api.generate({ prompt: 'test', includeMemory: true }), { code: 'SETTINGS_CHANGED' });
    assert.equal(sent, 0);
});
