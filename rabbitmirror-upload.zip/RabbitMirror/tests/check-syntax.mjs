import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
let count = 0;
async function walk(dir) {
  for (const item of await fs.readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, item.name);
    if (item.isDirectory()) await walk(full);
    else if (/\.(?:m?js)$/.test(item.name)) { new vm.SourceTextModule(await fs.readFile(full, 'utf8'), { identifier: full }); count++; }
  }
}
await walk(process.cwd());
console.log(`Syntax OK: ${count} JavaScript modules`);
