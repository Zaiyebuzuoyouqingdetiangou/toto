import { normalizePresentationModes } from './presentationMode.js?rmv=1.67.34';
import { extension_settings } from '../../../../extensions.js';
import { saveSettingsDebounced } from '../../../../../script.js';
import { independentGenerationTiming } from './independentTiming.js?rmv=1.67.34';
import { AUTOMATIC_REROLL_DEFAULT, AUTOMATIC_REROLL_IDLE_DEFAULT_SECONDS, normalizeAutomaticRerollIdleSeconds, normalizeAutomaticRerollMax } from './automaticReroll.js?rmv=1.67.34';
import { DEFAULT_INDEPENDENT_MAX_REQUEST_CHARS, normalizeIndependentMaxRequestChars } from './independentRequestBudget.js?rmv=1.67.34';
import { normalizeMissingShellScanRange } from './independentApi/missingRetryShell.js?rmv=1.67.34';

export const MODULE_NAME = 'rabbit_mirror_theater';

export const VISUAL_PROMPT_MAX_CHARS = 5000;
export const VISUAL_EXTRA_PROMPT_MAX_CHARS = 1000;
export const VISUAL_AVOID_PROMPT_MAX_CHARS = 1000;
export const WORLD_INFO_BOOK_NAME_MAX_CHARS = 512;
export const VISUAL_TONE_MODES = Object.freeze(['normal', 'soft', 'dark']);
export const INDEPENDENT_CONTEXT_EXCLUDED_TAG_MAX_COUNT = 32;
// Keep startup normalization scalar-only; loading host world-book readers is a user action.
function normalizeMemoryWorldBookSettingId(value) {
    return typeof value === 'string' && value.length <= 1000 && !/[\u0000\r\n]/.test(value)
        ? value.trim() : '';
}
// Do not silently reduce a malformed early-body selection: that could start a
// request before all tags the user selected have closed. Reserved names are also
// rejected by the runtime parser; this startup normalizer stays dependency-free.
export function normalizeIndependentEarlyBodyTags(value) {
    if (!Array.isArray(value) || value.length > 8 || value.some(tag =>
        typeof tag !== 'string' || !/^[a-z][a-z0-9_:-]{0,63}$/i.test(tag.trim()))) return [];
    return [...new Set(value.map(tag => tag.trim().toLowerCase()))];
}
export const DEFAULT_INDEPENDENT_CONTEXT_EXCLUDED_TAGS = Object.freeze([
    'thinking',
    'updatevariable',
    'updatevarible',
]);

export const RABBIT_MIRROR_BANNED_WORD_MAX_COUNT = 256;
export const RABBIT_MIRROR_BANNED_WORD_MAX_CHARS = 80;

export function normalizeRabbitMirrorBannedWords(value) {
    const source = typeof value === 'string'
        ? value.replace(/\r\n?/g, '\n').split('\n')
        : Array.isArray(value) ? value : [];
    const result = [];
    const seen = new Set();
    for (const raw of source) {
        const term = String((raw && typeof raw === 'object' ? raw.find : raw) ?? '')
            .replace(/[\u0000-\u001F\u007F]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, RABBIT_MIRROR_BANNED_WORD_MAX_CHARS);
        if (!term) continue;
        const key = term.toLocaleLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);
        const replacement = raw && typeof raw === 'object'
            ? String(raw.replace ?? '').replace(/[\u0000-\u001F\u007F]/g, ' ').slice(0, 240) : '';
        result.push(replacement ? { find: term, replace: replacement } : term);
        if (result.length >= RABBIT_MIRROR_BANNED_WORD_MAX_COUNT) break;
    }
    return result;
}

function normalizeLotteryEntries(value) {
    if (!Array.isArray(value)) return [];
    const result = [];
    const seen = new Set();
    for (const raw of value) {
        if (!raw || typeof raw !== 'object') continue;
        const book = String(raw.book || '').trim().slice(0, 240);
        const uid = String(raw.uid || '').trim().slice(0, 80);
        const id = String(raw.id || (book && uid ? `${book}::${uid}` : '')).trim().slice(0, 360);
        if (!book || !uid || !id || seen.has(id)) continue;
        seen.add(id);
        result.push({
            id,
            book,
            uid,
            title: String(raw.title || uid).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 200),
            content: String(raw.content || '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 1800),
        });
        if (result.length >= 80) break;
    }
    return result;
}

function normalizeLotteryBooks(value, entries = []) {
    const source = Array.isArray(value) && value.length ? value : entries.map(entry => entry?.book);
    const result = [];
    const seen = new Set();
    for (const raw of source) {
        const book = String(raw || '').trim().slice(0, 240);
        if (!book || seen.has(book)) continue;
        seen.add(book);
        result.push(book);
        if (result.length >= 40) break;
    }
    return result;
}


export function normalizeIndependentContextExcludedTags(value) {
    const source = Array.isArray(value)
        ? value
        : String(value ?? '').split(/[\s,，、;；]+/);
    const normalized = [];
    const seen = new Set();
    for (const rawValue of source) {
        const raw = String(rawValue ?? '').trim();
        if (!raw) continue;
        const unwrapped = raw
            .replace(/^<\s*\/?\s*/, '')
            .replace(/\s*\/?>\s*$/, '')
            .split(/\s/, 1)[0]
            .toLocaleLowerCase();
        // User-defined context tags may be Chinese or other Unicode letter names.
        // Keep the same 64-code-point/name-character boundary used for ASCII tags.
        if (!/^[\p{L}][\p{L}\p{N}._:-]{0,63}$/u.test(unwrapped) || [...unwrapped].length > 64 || seen.has(unwrapped)) continue;
        seen.add(unwrapped);
        normalized.push(unwrapped);
        if (normalized.length >= INDEPENDENT_CONTEXT_EXCLUDED_TAG_MAX_COUNT) break;
    }
    return normalized;
}


const LEGACY_FORMAT_ID_ALIASES = Object.freeze({
    '6.2.1.2': '6.2.1.1.e',
});

function canonicalFormatSettingId(value) {
    const id = String(value || '').trim();
    return LEGACY_FORMAT_ID_ALIASES[id] || id;
}
// Retain the exact previous factory text for migration; never rewrite user edits.
const PREVIOUS_VISUAL_COLOR_RULES = String.raw`色彩组织:
  - 配色必须形成明确的主次关系，由主要色彩关系统领画面，再用有限的辅助色与局部强调色建立层次；不得让所有颜色平均分布或同时抢眼。
  - 不得为了避免重复或追求独特强行改变色相，也不得加入不属于媒介的霓虹、光晕或高饱和强调色。
  - 主背景、承载面、正文、装饰与交互状态须通过明度、饱和度、冷暖、透明度和材质差异清晰分层，并保持相互呼应。
  - 强调色只用于真正需要聚焦的主体、关系节点或状态变化，数量与面积必须克制。
  - 材质色、环境光与阴影必须共同作用，不能只给不同区域机械填充不同色块。
  - 视觉质感应由比例、留白、层次、材质、光影与色彩关系共同成立，不得依靠堆叠渐变、发光、阴影或高饱和色制造表面效果。
  - 当展现形式适合单色、低彩度或有限色域时，可以保持克制，但仍须依靠明度、纹理、材质与空间层次形成完整视觉。`;

// Retain the 82 factory text as an exact migration source.
const PREVIOUS_82_VISUAL_COLOR_RULES = PREVIOUS_VISUAL_COLOR_RULES
    .replace('配色必须形成明确的主次关系，由主要色彩关系统领画面，再用有限的辅助色与局部强调色建立层次；不得让所有颜色平均分布或同时抢眼。',
        '按本轮展现形式组织丰富而协调的色彩，让背景、主体与细节通过色相、明暗和冷暖相互衬托，整体保持主次。')
    .replace('强调色只用于真正需要聚焦的主体、关系节点或状态变化，数量与面积必须克制。',
        '物件自身的颜色可充分呈现；统一风格不等于统一色相，强调色用于聚焦主体、关系节点或状态变化。');

export const DEFAULT_VISUAL_COLOR_RULES = PREVIOUS_82_VISUAL_COLOR_RULES
    .replace('不得为了避免重复或追求独特强行改变色相，也不得加入不属于媒介的霓虹、光晕或高饱和强调色。',
        '从本体材质、部件与环境推导主辅色；非深色模式也可有浓郁主体、彩色承载面与局部深色，不默认整面近白或同色浅底。')
    .replace('当展现形式适合单色、低彩度或有限色域时，可以保持克制，但仍须依靠明度、纹理、材质与空间层次形成完整视觉。',
        '避重可变化主辅色关系、冷暖与彩度；媒介必要的单色、低彩度仍可保留，以明度、纹理、材质与空间层次完成视觉。');

export const DEFAULT_VISUAL_PROMPT = String.raw`兔子镜默认视觉规则:
  - 不得以通用圆角面板、卡片列表、数据仪表盘或信息框作为默认主体，再向其中填入本轮内容；仅替换标题和正文就能用于其他题材的通用界面不合格。
  - 当展现形式本身属于平面媒介时，其纸面、印刷面、画布、版式、纹理、边缘与承载内容可以直接构成主要视觉本体，不视为通用面板。
  - 主背景、主要承载面、文字、边界、阴影、发光和强调色，必须配合该形式实际采用的材质、环境和光线；不得预设固定的界面配色组合。

${DEFAULT_VISUAL_COLOR_RULES}`;

const PREVIOUS_82_DEFAULT_VISUAL_PROMPT = DEFAULT_VISUAL_PROMPT.replace(DEFAULT_VISUAL_COLOR_RULES, PREVIOUS_82_VISUAL_COLOR_RULES);
const PREVIOUS_DEFAULT_VISUAL_PROMPT = DEFAULT_VISUAL_PROMPT.replace(DEFAULT_VISUAL_COLOR_RULES, PREVIOUS_VISUAL_COLOR_RULES);

// Migrate only the exact superseded factory default; preserve all user edits.
const SUPERSEDED_DEFAULT_VISUAL_PROMPT = DEFAULT_VISUAL_PROMPT.replace(DEFAULT_VISUAL_COLOR_RULES, String.raw`色彩组织:
  - 从本轮场景、季节、物件与媒介推导主色、辅助色与强调色，建立主次和彼此呼应；主色不等于整面只用同一色相的深浅变化。
  - 色彩可以清亮、浓郁、鲜艳、冷暖对照或柔和克制，按内容选择；不要把低饱和、灰褐、米色或单色当成默认高级感。
  - 主体、背景、文字、装饰和交互状态用色相、明度、饱和度及材质形成清晰层次；需要时充分使用辅助色与强调色，保持文字可读。
  - 材质、环境光与阴影共同塑造画面；渐变、发光、投影和高饱和色均可在适合媒介时使用，效果与面积随内容决定。
  - 避重时可调整主辅色关系、冷暖、色相与彩度，不只替换一个背景色；用户明确指定的颜色，以及内容本就需要的单色或低彩度形式，继续尊重。`);

function cloneDefaultSettings() {
    return typeof structuredClone === 'function'
        ? structuredClone(defaultSettings)
        : JSON.parse(JSON.stringify(defaultSettings));
}

export const defaultSettings = Object.freeze({
    enabled: true,
    autoRabbitMirrorInjection: true,
    mode: 'integrated',
    generationSource: 'follow',
    independentGenerationTiming: 'auto',
    followDisplayMode: 'inline',
    independentConnectionProfileId: '',
    independentApiBaseUrl: '',
    independentApiKey: '',
    independentApiModel: '',
    independentApiTemperature: 0.8,
    independentApiMaxTokens: 30000,
    independentMaxRequestChars: DEFAULT_INDEPENDENT_MAX_REQUEST_CHARS,
    independentAutomaticRerollMax: AUTOMATIC_REROLL_DEFAULT,
    independentAutomaticRerollIdleSeconds: AUTOMATIC_REROLL_IDLE_DEFAULT_SECONDS,
    automaticRerollEnabled: true,
    independentAdvancedEnabled: false,
    independentReasoningEffort: '',
    independentExtraParams: '',
    independentExcludedParams: [],
    independentContextMaxLayers: 20,
    independentContextExcludedTags: [...DEFAULT_INDEPENDENT_CONTEXT_EXCLUDED_TAGS],
    behaviorRuleMode: 'off',
    behaviorRuleText: null,
    independentEarlyBodyEnabled: false,
    independentEarlyBodyTags: [],
    independentEarlyBodyChatKey: '',
    // Follow mode shares the host request with the main reply, so tag isolation is
    // instruction-only and must remain explicit opt-in to avoid permanent prompt cost.
    followTagIsolationEnabled: false,
    independentReadCharacterCardSummary: true,
    independentReadPersonaSummary: true,
    independentDisplayMode: 'external',
    missingShellScanRange: 10,
    independentReadGlobalWorldInfo: false,
    independentWorldInfoDisabledBooks: [],
    samplingMode: 'classic',
    singlePairSampling: false,
    // random：本地纯随机。atmosphere：按正文从已抽好的菜单里挑一张签。
    lotteryMethod: 'random',
    atmosphereStoryPercent: 70,
    rawPolicy: 'balanced',
    showCot: false,
    // Compatibility key: strong diversity is always active.
    avoidRepeat: true,
    darkVisualMode: false, // 由 visualToneMode 推出：只有选「深色」时为 true，保留给原有判断用。
    visualToneMode: 'normal', // 色调模式三选一：normal 普通／soft 柔和浅色／dark 深色。
    postGenerationRecolor: false, // Retired trial compatibility key; never generates variants.
    visualDesignMode: 'guided1553', // Compatibility key; old choices converge on the retained enhanced rules.
    cooldownRounds: 10,
    blacklistEnabled: true,
    blacklistedThemeIds: [],
    blacklistedFormatIds: [],
    favoriteThemeIds: [],
    favoriteFormatIds: [],
    favoriteThemeMultipliers: {},
    favoriteFormatMultipliers: {},
    presentationWorldviewLock: false,
    // 每轮生成的兔子镜面数（1～5）。默认 1，关闭多面不改旧单面路径。
    rabbitMirrorFaceCount: 1,
    // single：一次请求出全部面。serial：副 API 逐面排队，一面一次。
    multifaceDispatch: 'single',
    rabbitMirrorPresentationModes: ['html', 'html', 'html', 'html', 'html'],
    longTextSource: 'blank',
    // 自动呈现时，长文本所占百分比；其余为 HTML。0 表示仍按抽中的类别呈现。
    autoLongTextPercent: 0,
    // 1.6.16 起默认每面 HTML、自动时长文本 0%；老用户升级时统一迁移一次。
    presentationDefaultsMigration: 1,
    // builtin：兔子镜已有条目。worldbook：选中的世界书条目。both：按权重两边都抽。
    lotterySource: 'builtin',
    lotteryBuiltinPercent: 50,
    lotteryBooks: [],
    lotteryEntries: [],
    facePagerPosition: 'top',
    writingStyle: '',
    independentReadCharacterWorldBook: false,
    richFormatBias: false,
    maintenanceRabbitEnabled: true,
    maintenanceRabbitAutoSafeEnabled: false,
    maintenanceRabbitAutoSafeConsent: false,
    feedbackCatEnabled: true,
    rabbitMirrorBannedWords: [],
    // 1C-1 only: hidden production gate. The UI does not expose this until external raw lookup exists.
    externalWorldBookRandomEnabled: false,
    externalWorldBookMixMode: 'builtin-only',
    visualPromptEditingEnabled: false,
    visualPrompt: DEFAULT_VISUAL_PROMPT,
    visualExtraPrompt: '',
    visualAvoidPrompt: '',
    appearanceReferenceEnabled: false,
    appearanceReferenceRevision: '',

    hardStartup: true,
    hardChineseLock: true,
    userDirectivePriority: true,
    creativeExpansionMode: true,
    forceVisualScenery: false,
    visualSceneryCombination: false,
    imageEnabled: false,
    builtinImageEnabled: false,
    imagePromptFormat: 'nai5-natural',
    imageCompositionMode: 'scene',
    imageBackend: 'baibai',
    imageLlmEnabled: false,
    imageLlmProfileId: '',
    imageLlmBaseUrl: '',
    imageLlmKey: '',
    imageLlmModel: '',
    imageLlmTemperature: 0.8,
    imageLlmMaxTokens: 4096,
    memoryScanEnabled: false,
    memoryWorldBookEnabled: false,
    memoryWorldBookId: '',
    memoryProviderIds: [],
    memoryMaxChars: 2200,
    themesMin: 1,
    themesMax: 3,
    formatsMin: 1,
    formatsMax: 2,
    depth: 0,
    role: 'system',
    skipQuiet: true,
    skipImpersonate: true,
    debug: false,
});

export function getSettings() {
    // A saved key does not prove a user touched the switch: earlier versions
    // persisted default-filled settings. Only a missing extension is new.
    const newInstallation = !Object.prototype.hasOwnProperty.call(extension_settings, MODULE_NAME);
    if (!extension_settings[MODULE_NAME] || typeof extension_settings[MODULE_NAME] !== 'object') {
        extension_settings[MODULE_NAME] = cloneDefaultSettings();
        if (!newInstallation) extension_settings[MODULE_NAME].behaviorRuleMode = 'always';
    }
    const settings = extension_settings[MODULE_NAME];
    if (!newInstallation && settings.behaviorRuleMode === undefined) settings.behaviorRuleMode = 'always';
    // Resolve missing/corrupt timing from the old flags before defaults fill it.
    settings.independentGenerationTiming = independentGenerationTiming(settings);
    const legacyRescueWasEnabled = !!(settings.plainTextRescueMode || settings.codeBlockRescueMode || settings.interactionRescueMode);
    // 一次性迁移：必须在默认值回填之前判断，否则缺失的标记会被默认值直接补上。
    if (settings.presentationDefaultsMigration !== 1) {
        settings.rabbitMirrorPresentationModes = ['html', 'html', 'html', 'html', 'html'];
        settings.autoLongTextPercent = 0;
        settings.presentationDefaultsMigration = 1;
        try { saveSettingsDebounced(); } catch {}
    }
    // 旧版只有深色开关：开过深色的升级后是「深色」，其余是「普通」。必须在默认值回填之前判断。
    if (settings.visualToneMode === undefined) settings.visualToneMode = settings.darkVisualMode === true ? 'dark' : 'normal';
    for (const [key, value] of Object.entries(defaultSettings)) {
        if (settings[key] === undefined) settings[key] = value;
    }

    if (settings.mode === 'canon' || settings.mode === 'off') {
        settings.mode = settings.mode === 'off' ? 'off' : 'integrated';
    }
    if (!['follow', 'independent'].includes(settings.generationSource)) settings.generationSource = 'follow';
    if (!['inline', 'external'].includes(settings.followDisplayMode)) settings.followDisplayMode = 'inline';
    if (!['external', 'external_then_inline'].includes(settings.independentDisplayMode)) settings.independentDisplayMode = 'external';
    settings.missingShellScanRange = normalizeMissingShellScanRange(settings.missingShellScanRange);
    settings.independentReadGlobalWorldInfo = settings.independentReadGlobalWorldInfo === true;
    settings.independentConnectionProfileId = String(settings.independentConnectionProfileId || '').trim().slice(0, 160);
    settings.independentWorldInfoDisabledBooks = [...new Set((Array.isArray(settings.independentWorldInfoDisabledBooks) ? settings.independentWorldInfoDisabledBooks : [])
        .map(value => String(value || '').trim())
        .filter(value => value && value.length <= WORLD_INFO_BOOK_NAME_MAX_CHARS))];
    settings.independentApiBaseUrl = String(settings.independentApiBaseUrl || '').trim();
    settings.independentApiKey = String(settings.independentApiKey || '').trim();
    settings.independentApiModel = String(settings.independentApiModel || '').trim();
    {
        const temperature = Number(settings.independentApiTemperature);
        settings.independentApiTemperature = Math.max(0, Math.min(2, Number.isFinite(temperature) ? temperature : 0.8));
    }
    settings.independentApiMaxTokens = Math.max(512, Math.min(64000, Number(settings.independentApiMaxTokens) || 30000));
    settings.independentMaxRequestChars = normalizeIndependentMaxRequestChars(settings.independentMaxRequestChars);
    settings.independentAutomaticRerollMax = normalizeAutomaticRerollMax(settings.independentAutomaticRerollMax);
    settings.independentAutomaticRerollIdleSeconds = normalizeAutomaticRerollIdleSeconds(settings.independentAutomaticRerollIdleSeconds);
    settings.automaticRerollEnabled = settings.automaticRerollEnabled !== false;
    // Keep this startup path scalar-only. Invalid stored JSON is not silently
    // truncated or repaired; opt-in request preflight validates it before send.
    settings.independentAdvancedEnabled = settings.independentAdvancedEnabled === true;
    {
        const contextLayers = Number(settings.independentContextMaxLayers);
        settings.independentContextMaxLayers = Math.max(1, Math.min(200, Number.isFinite(contextLayers) ? Math.round(contextLayers) : 20));
    }
    settings.independentContextExcludedTags = normalizeIndependentContextExcludedTags(settings.independentContextExcludedTags);
    settings.behaviorRuleMode = ['always', 'off', 'adult-only'].includes(settings.behaviorRuleMode) ? settings.behaviorRuleMode : 'always';
    settings.behaviorRuleText = settings.behaviorRuleText == null ? null : String(settings.behaviorRuleText).replace(/\u0000/g, '').slice(0, 20000);
    settings.independentEarlyBodyEnabled = settings.independentEarlyBodyEnabled === true;
    settings.independentEarlyBodyTags = normalizeIndependentEarlyBodyTags(settings.independentEarlyBodyTags);
    settings.independentEarlyBodyChatKey = String(settings.independentEarlyBodyChatKey || '').slice(0, 2048);
    settings.followTagIsolationEnabled = settings.followTagIsolationEnabled === true;
    settings.independentReadCharacterCardSummary = settings.independentReadCharacterCardSummary !== false;
    settings.independentReadPersonaSummary = settings.independentReadPersonaSummary !== false;

    if (settings.showCot === undefined && settings.showWonderland !== undefined) {
        settings.showCot = !!settings.showWonderland;
    }
    if (settings.showWonderland !== undefined) delete settings.showWonderland;
    if (settings.forceInteractiveMode !== undefined) delete settings.forceInteractiveMode;
    if (settings.uiAudit !== undefined) delete settings.uiAudit;

    // Remove settings left by features that no longer exist in this build.
    for (const key of Object.keys(settings)) {
        if (!(key in defaultSettings)) delete settings[key];
    }

    settings.themesMin = Number(settings.themesMin) || defaultSettings.themesMin;
    settings.themesMax = Number(settings.themesMax) || defaultSettings.themesMax;
    settings.formatsMin = Number(settings.formatsMin) || defaultSettings.formatsMin;
    settings.formatsMax = Number(settings.formatsMax) || defaultSettings.formatsMax;
    settings.avoidRepeat = true;
    if (!VISUAL_TONE_MODES.includes(settings.visualToneMode)) settings.visualToneMode = settings.darkVisualMode === true ? 'dark' : 'normal';
    settings.darkVisualMode = settings.visualToneMode === 'dark';
    settings.postGenerationRecolor = false;
    settings.visualDesignMode = 'guided1553';
    settings.cooldownRounds = Math.max(1, Number(settings.cooldownRounds) || defaultSettings.cooldownRounds);
    settings.blacklistEnabled = settings.blacklistEnabled !== false;
    const normalizeSelectionIds = (value, mapId = id => id) => [...new Set((Array.isArray(value) ? value : []).map(id => mapId(String(id || '').trim())).filter(Boolean))].slice(0, 512);
    settings.blacklistedThemeIds = normalizeSelectionIds(settings.blacklistedThemeIds);
    settings.blacklistedFormatIds = normalizeSelectionIds(settings.blacklistedFormatIds, canonicalFormatSettingId);
    settings.favoriteThemeIds = normalizeSelectionIds(settings.favoriteThemeIds);
    settings.favoriteFormatIds = normalizeSelectionIds(settings.favoriteFormatIds, canonicalFormatSettingId);
    const normalizeFavoriteMultipliers = (value, favoriteIds, mapId = id => id) => {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        const allowed = new Set(favoriteIds || []);
        const forbiddenKeys = new Set(['__proto__', 'prototype', 'constructor']);
        const result = {};
        for (const [rawId, rawMultiplier] of Object.entries(source)) {
            const sourceId = String(rawId || '').trim();
            const id = mapId(sourceId);
            if (!id || forbiddenKeys.has(sourceId) || forbiddenKeys.has(id) || !allowed.has(id) || Object.keys(result).length >= 512) continue;
            const empty = rawMultiplier == null || (typeof rawMultiplier === 'string' && !rawMultiplier.trim());
            const parsed = empty ? NaN : Number(rawMultiplier);
            const bounded = Math.max(1, Math.min(50, Number.isFinite(parsed) ? parsed : 3));
            result[id] = Math.round(bounded * 2) / 2;
        }
        return result;
    };
    settings.favoriteThemeMultipliers = normalizeFavoriteMultipliers(settings.favoriteThemeMultipliers, settings.favoriteThemeIds);
    settings.favoriteFormatMultipliers = normalizeFavoriteMultipliers(settings.favoriteFormatMultipliers, settings.favoriteFormatIds, canonicalFormatSettingId);
    settings.presentationWorldviewLock = settings.presentationWorldviewLock === true;
    // 只接受数字 1～5；任何异常值（NaN、字符串、0、负数、超界）都回落到 1，
    // 保证旧设置升级与畸形写入都不会意外开启多面。
    settings.rabbitMirrorPresentationModes = normalizePresentationModes(settings.rabbitMirrorPresentationModes);
    settings.longTextSource = ['blank', 'text', 'mixed'].includes(settings.longTextSource) ? settings.longTextSource : 'blank';
    const autoPercent = Number(settings.autoLongTextPercent);
    settings.autoLongTextPercent = Number.isFinite(autoPercent) ? Math.max(0, Math.min(100, Math.round(autoPercent))) : 0;
    settings.lotterySource = ['builtin', 'worldbook', 'both'].includes(settings.lotterySource) ? settings.lotterySource : 'builtin';
    const builtinPercent = Number(settings.lotteryBuiltinPercent);
    settings.lotteryBuiltinPercent = Number.isFinite(builtinPercent) ? Math.max(0, Math.min(100, Math.round(builtinPercent))) : 50;
    settings.lotteryEntries = normalizeLotteryEntries(settings.lotteryEntries);
    settings.lotteryBooks = normalizeLotteryBooks(settings.lotteryBooks, settings.lotteryEntries);
    settings.lotteryEntries = settings.lotteryEntries.filter(entry => settings.lotteryBooks.includes(entry.book));
    settings.facePagerPosition = settings.facePagerPosition === 'bottom' ? 'bottom' : 'top';
    settings.writingStyle = typeof settings.writingStyle === 'string' ? settings.writingStyle : '';
    settings.independentReadCharacterWorldBook = settings.independentReadCharacterWorldBook === true;
    settings.imageCompositionMode = settings.imageCompositionMode === 'auto' ? 'auto' : 'scene';
    const faceCount = settings.rabbitMirrorFaceCount;
    settings.rabbitMirrorFaceCount = Number.isInteger(faceCount) && faceCount >= 2 && faceCount <= 5 ? faceCount : 1;
    if (settings.autoRabbitMirrorInjection === undefined) settings.autoRabbitMirrorInjection = settings.enabled !== false;
    if (settings.maintenanceRabbitEnabled === undefined) {
        settings.maintenanceRabbitEnabled = legacyRescueWasEnabled || defaultSettings.maintenanceRabbitEnabled;
    }
    settings.maintenanceRabbitEnabled = !!settings.maintenanceRabbitEnabled;
    settings.maintenanceRabbitAutoSafeConsent = settings.maintenanceRabbitAutoSafeConsent === true;
    settings.maintenanceRabbitAutoSafeEnabled = settings.maintenanceRabbitAutoSafeConsent === true
        && settings.maintenanceRabbitAutoSafeEnabled === true;
    if (!settings.maintenanceRabbitEnabled) {
        settings.maintenanceRabbitAutoSafeEnabled = false;
        settings.maintenanceRabbitAutoSafeConsent = false;
    }
    settings.feedbackCatEnabled = settings.feedbackCatEnabled !== false;
    settings.rabbitMirrorBannedWords = normalizeRabbitMirrorBannedWords(settings.rabbitMirrorBannedWords);
    settings.externalWorldBookRandomEnabled = settings.externalWorldBookRandomEnabled === true;
    settings.externalWorldBookMixMode = ['builtin-only','builtin-preferred','balanced','external-preferred','external-only'].includes(settings.externalWorldBookMixMode)
        ? settings.externalWorldBookMixMode
        : 'builtin-only';
    settings.visualSceneryCombination = settings.visualSceneryCombination === true;
    settings.imageEnabled = settings.imageEnabled === true;
    settings.imageLlmEnabled = settings.imageLlmEnabled === true;
    settings.imageBackend = settings.imageBackend === 'chatu8' ? 'chatu8' : 'baibai';
    for (const key of ['imageLlmProfileId', 'imageLlmBaseUrl', 'imageLlmKey', 'imageLlmModel']) settings[key] = typeof settings[key] === 'string' ? settings[key] : '';
    settings.imageLlmTemperature = Number.isFinite(Number(settings.imageLlmTemperature)) ? Math.min(2, Math.max(0, Number(settings.imageLlmTemperature))) : 0.8;
    settings.imageLlmMaxTokens = Number(settings.imageLlmMaxTokens) > 0 ? Math.min(64000, Math.round(Number(settings.imageLlmMaxTokens))) : 4096;
    settings.builtinImageEnabled = settings.builtinImageEnabled === true;
    settings.imagePromptFormat = settings.imagePromptFormat === 'nai45-tags' ? 'nai45-tags' : 'nai5-natural';
    settings.visualPromptEditingEnabled = !!settings.visualPromptEditingEnabled;
    settings.appearanceReferenceEnabled = settings.appearanceReferenceEnabled === true;
    settings.appearanceReferenceRevision = /^[a-z\d-]{8,80}$/i.test(String(settings.appearanceReferenceRevision || '')) ? String(settings.appearanceReferenceRevision) : '';
    const normalizeVisualSetting = (value, fallback, maxChars) => {
        const raw = typeof value === 'string' ? value : String(value ?? fallback);
        if (raw.length <= maxChars && raw.indexOf('\r') < 0) return raw;
        return raw.replace(/\r\n?/g, '\n').slice(0, maxChars);
    };
    settings.visualPrompt = normalizeVisualSetting(settings.visualPrompt, DEFAULT_VISUAL_PROMPT, VISUAL_PROMPT_MAX_CHARS);
    if (settings.visualPrompt === PREVIOUS_82_DEFAULT_VISUAL_PROMPT || settings.visualPrompt === SUPERSEDED_DEFAULT_VISUAL_PROMPT || settings.visualPrompt === PREVIOUS_DEFAULT_VISUAL_PROMPT) settings.visualPrompt = DEFAULT_VISUAL_PROMPT;
    settings.visualExtraPrompt = normalizeVisualSetting(settings.visualExtraPrompt, '', VISUAL_EXTRA_PROMPT_MAX_CHARS);
    settings.visualAvoidPrompt = normalizeVisualSetting(settings.visualAvoidPrompt, '', VISUAL_AVOID_PROMPT_MAX_CHARS);

    delete settings.plainTextRescueMode;
    delete settings.codeBlockRescueMode;
    delete settings.interactionRescueMode;
    if (!['classic', 'format_only'].includes(settings.samplingMode)) settings.samplingMode = defaultSettings.samplingMode;
    settings.singlePairSampling = settings.singlePairSampling === true;
    if (!['random', 'atmosphere'].includes(settings.lotteryMethod)) settings.lotteryMethod = defaultSettings.lotteryMethod;
    const storyPercent = Number(settings.atmosphereStoryPercent);
    settings.atmosphereStoryPercent = Number.isFinite(storyPercent) ? Math.max(0, Math.min(100, Math.round(storyPercent))) : defaultSettings.atmosphereStoryPercent;
    if (!['single', 'serial'].includes(settings.multifaceDispatch)) settings.multifaceDispatch = defaultSettings.multifaceDispatch;
    if (!['compact', 'balanced', 'full'].includes(settings.rawPolicy)) settings.rawPolicy = defaultSettings.rawPolicy;
    if (!Array.isArray(settings.memoryProviderIds)) settings.memoryProviderIds = [];
    settings.memoryProviderIds = settings.memoryProviderIds.map(value => {
        const id = String(value || '');
        return id === 'baibai-book' ? 'global:STBaiBaiBook' : id;
    });
    settings.memoryProviderIds = [...new Set(settings.memoryProviderIds.filter(Boolean))].slice(0, 12);
    settings.memoryScanEnabled = !!settings.memoryScanEnabled;
    settings.memoryWorldBookEnabled = settings.memoryWorldBookEnabled === true;
    settings.memoryWorldBookId = normalizeMemoryWorldBookSettingId(settings.memoryWorldBookId);
    settings.memoryMaxChars = Math.max(600, Math.min(6000, Number(settings.memoryMaxChars) || defaultSettings.memoryMaxChars));
    settings.richFormatBias = false;
    settings.depth = Number(settings.depth) || 0;
    return settings;
}

// One root attribute hides existing notes immediately without scanning chat DOM.
export function syncExternalReferenceVisibility(settings) {
    const root = globalThis.document?.documentElement;
    if (!root?.setAttribute) return;
    const value = settings?.externalWorldBookRandomEnabled === true ? 'true' : 'false';
    if (root.getAttribute('data-rabbit-mirror-external-sampling-enabled') !== value) {
        root.setAttribute('data-rabbit-mirror-external-sampling-enabled', value);
    }
}

export function updateSettings(patch) {
    const settings = getSettings();
    const safePatch = patch && typeof patch === 'object' ? { ...patch } : {};
    if (Object.prototype.hasOwnProperty.call(safePatch, 'visualDesignMode')) safePatch.visualDesignMode = 'guided1553';
    // 色调模式与旧深色开关保持一致：新写法以 visualToneMode 为准，旧调用只改深色开关时跟着换算。
    if (Object.prototype.hasOwnProperty.call(safePatch, 'visualToneMode')) {
        safePatch.visualToneMode = VISUAL_TONE_MODES.includes(safePatch.visualToneMode) ? safePatch.visualToneMode : 'normal';
        safePatch.darkVisualMode = safePatch.visualToneMode === 'dark';
    } else if (Object.prototype.hasOwnProperty.call(safePatch, 'darkVisualMode')) {
        safePatch.darkVisualMode = safePatch.darkVisualMode === true;
        safePatch.visualToneMode = safePatch.darkVisualMode ? 'dark' : (settings.visualToneMode === 'dark' ? 'normal' : settings.visualToneMode);
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'independentGenerationTiming')) {
        safePatch.independentGenerationTiming = independentGenerationTiming({ ...settings, ...safePatch });
    }
    if ((safePatch.generationSource ?? settings.generationSource) === 'independent'
        && (Object.prototype.hasOwnProperty.call(safePatch, 'independentGenerationTiming') || safePatch.generationSource === 'independent')) {
        const timing = independentGenerationTiming({ ...settings, ...safePatch });
        const enabled = timing !== 'off';
        const previousMode = safePatch.mode ?? settings.mode;
        safePatch.enabled = enabled;
        safePatch.autoRabbitMirrorInjection = enabled;
        safePatch.mode = enabled ? (previousMode === 'off' ? 'integrated' : previousMode) : 'off';
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'memoryWorldBookEnabled')) safePatch.memoryWorldBookEnabled = safePatch.memoryWorldBookEnabled === true;
    if (Object.prototype.hasOwnProperty.call(safePatch, 'memoryWorldBookId')) safePatch.memoryWorldBookId = normalizeMemoryWorldBookSettingId(safePatch.memoryWorldBookId);
    if (Object.prototype.hasOwnProperty.call(safePatch, 'independentEarlyBodyEnabled')) safePatch.independentEarlyBodyEnabled = safePatch.independentEarlyBodyEnabled === true;
    if (Object.prototype.hasOwnProperty.call(safePatch, 'independentEarlyBodyTags')) safePatch.independentEarlyBodyTags = normalizeIndependentEarlyBodyTags(safePatch.independentEarlyBodyTags);
    if (Object.prototype.hasOwnProperty.call(safePatch, 'independentEarlyBodyChatKey')) safePatch.independentEarlyBodyChatKey = String(safePatch.independentEarlyBodyChatKey || '').slice(0, 2048);
    if (Object.prototype.hasOwnProperty.call(safePatch, 'automaticRerollEnabled')) {
        safePatch.automaticRerollEnabled = safePatch.automaticRerollEnabled !== false;
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'independentAutomaticRerollMax')) {
        safePatch.independentAutomaticRerollMax = normalizeAutomaticRerollMax(safePatch.independentAutomaticRerollMax);
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'independentAutomaticRerollIdleSeconds')) {
        safePatch.independentAutomaticRerollIdleSeconds = normalizeAutomaticRerollIdleSeconds(safePatch.independentAutomaticRerollIdleSeconds);
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'missingShellScanRange')) {
        safePatch.missingShellScanRange = normalizeMissingShellScanRange(safePatch.missingShellScanRange);
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'behaviorRuleMode')) safePatch.behaviorRuleMode = ['always', 'off', 'adult-only'].includes(safePatch.behaviorRuleMode) ? safePatch.behaviorRuleMode : 'always';
    if (Object.prototype.hasOwnProperty.call(safePatch, 'behaviorRuleText')) safePatch.behaviorRuleText = safePatch.behaviorRuleText == null ? null : String(safePatch.behaviorRuleText).replace(/\u0000/g, '').slice(0, 20000);
    if (Object.prototype.hasOwnProperty.call(safePatch, 'independentContextExcludedTags')) {
        safePatch.independentContextExcludedTags = normalizeIndependentContextExcludedTags(safePatch.independentContextExcludedTags);
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'followTagIsolationEnabled')) {
        safePatch.followTagIsolationEnabled = safePatch.followTagIsolationEnabled === true;
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'rabbitMirrorBannedWords')) {
        safePatch.rabbitMirrorBannedWords = normalizeRabbitMirrorBannedWords(safePatch.rabbitMirrorBannedWords);
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'externalWorldBookRandomEnabled')) {
        safePatch.externalWorldBookRandomEnabled = safePatch.externalWorldBookRandomEnabled === true;
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'externalWorldBookMixMode')) {
        safePatch.externalWorldBookMixMode = ['builtin-only','builtin-preferred','balanced','external-preferred','external-only'].includes(safePatch.externalWorldBookMixMode)
            ? safePatch.externalWorldBookMixMode
            : 'builtin-only';
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'imageEnabled')) safePatch.imageEnabled = safePatch.imageEnabled === true;
    if (Object.prototype.hasOwnProperty.call(safePatch, 'builtinImageEnabled')) safePatch.builtinImageEnabled = safePatch.builtinImageEnabled === true;
    if (Object.prototype.hasOwnProperty.call(safePatch, 'longTextSource')) safePatch.longTextSource = ['blank', 'text', 'mixed'].includes(safePatch.longTextSource) ? safePatch.longTextSource : 'blank';
    if (Object.prototype.hasOwnProperty.call(safePatch, 'autoLongTextPercent')) {
        const autoPercent = Number(safePatch.autoLongTextPercent);
        safePatch.autoLongTextPercent = Number.isFinite(autoPercent) ? Math.max(0, Math.min(100, Math.round(autoPercent))) : 0;
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'lotterySource')) safePatch.lotterySource = ['builtin', 'worldbook', 'both'].includes(safePatch.lotterySource) ? safePatch.lotterySource : 'builtin';
    if (Object.prototype.hasOwnProperty.call(safePatch, 'lotteryBuiltinPercent')) {
        const builtinPercent = Number(safePatch.lotteryBuiltinPercent);
        safePatch.lotteryBuiltinPercent = Number.isFinite(builtinPercent) ? Math.max(0, Math.min(100, Math.round(builtinPercent))) : 50;
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'lotteryBooks')) safePatch.lotteryBooks = normalizeLotteryBooks(safePatch.lotteryBooks, []);
    if (Object.prototype.hasOwnProperty.call(safePatch, 'lotteryEntries')) safePatch.lotteryEntries = normalizeLotteryEntries(safePatch.lotteryEntries);
    if (Object.prototype.hasOwnProperty.call(safePatch, 'facePagerPosition')) safePatch.facePagerPosition = safePatch.facePagerPosition === 'bottom' ? 'bottom' : 'top';
    if (Object.prototype.hasOwnProperty.call(safePatch, 'writingStyle')) safePatch.writingStyle = typeof safePatch.writingStyle === 'string' ? safePatch.writingStyle : '';
    if (Object.prototype.hasOwnProperty.call(safePatch, 'independentReadCharacterWorldBook')) safePatch.independentReadCharacterWorldBook = safePatch.independentReadCharacterWorldBook === true;
    if (Object.prototype.hasOwnProperty.call(safePatch, 'imageCompositionMode')) safePatch.imageCompositionMode = safePatch.imageCompositionMode === 'auto' ? 'auto' : 'scene';
    if (Object.prototype.hasOwnProperty.call(safePatch, 'imagePromptFormat')) safePatch.imagePromptFormat = safePatch.imagePromptFormat === 'nai45-tags' ? 'nai45-tags' : 'nai5-natural';
    if (Object.prototype.hasOwnProperty.call(safePatch, 'visualSceneryCombination')) {
        safePatch.visualSceneryCombination = safePatch.visualSceneryCombination === true;
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'appearanceReferenceEnabled')) safePatch.appearanceReferenceEnabled = safePatch.appearanceReferenceEnabled === true;
    if (Object.prototype.hasOwnProperty.call(safePatch, 'appearanceReferenceRevision')) safePatch.appearanceReferenceRevision = /^[a-z\d-]{8,80}$/i.test(String(safePatch.appearanceReferenceRevision || '')) ? String(safePatch.appearanceReferenceRevision) : '';
    if (Object.prototype.hasOwnProperty.call(safePatch, 'rabbitMirrorPresentationModes')) {
        safePatch.rabbitMirrorPresentationModes = normalizePresentationModes(safePatch.rabbitMirrorPresentationModes);
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'rabbitMirrorFaceCount')) {
        const faceCount = safePatch.rabbitMirrorFaceCount;
        safePatch.rabbitMirrorFaceCount = Number.isInteger(faceCount) && faceCount >= 2 && faceCount <= 5 ? faceCount : 1;
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'multifaceDispatch')) {
        safePatch.multifaceDispatch = safePatch.multifaceDispatch === 'serial' ? 'serial' : 'single';
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'lotteryMethod')) {
        safePatch.lotteryMethod = safePatch.lotteryMethod === 'atmosphere' ? 'atmosphere' : 'random';
    }
    if (Object.prototype.hasOwnProperty.call(safePatch, 'atmosphereStoryPercent')) {
        const storyPercent = Number(safePatch.atmosphereStoryPercent);
        safePatch.atmosphereStoryPercent = Number.isFinite(storyPercent) ? Math.max(0, Math.min(100, Math.round(storyPercent))) : 70;
    }
    for (const key of ['independentReadCharacterCardSummary', 'independentReadPersonaSummary']) {
        if (Object.prototype.hasOwnProperty.call(safePatch, key)) safePatch[key] = safePatch[key] !== false;
    }
    const keys = Object.keys(safePatch).slice(0, 24);
    const changedKeys = keys.filter(key => {
        try { return JSON.stringify(settings?.[key]) !== JSON.stringify(safePatch[key]); } catch { return settings?.[key] !== safePatch[key]; }
    });
    globalThis.__rabbitMirrorPerfDiag?.mark?.('settings.update', {
        keys: keys.join(','),
        changedKeys: changedKeys.join(','),
        changedCount: changedKeys.length,
    });
    Object.assign(settings, safePatch);
    if (Object.prototype.hasOwnProperty.call(safePatch, 'externalWorldBookRandomEnabled')) syncExternalReferenceVisibility(settings);
    if (String(settings.independentConnectionProfileId || '').trim()) settings.independentApiKey = '';
    globalThis.__rabbitMirrorPerfDiag?.mark?.('settings.saveScheduled', { source: 'updateSettings', keys: keys.join(',') });
    saveSettingsDebounced();
}

export function resetSettings() {
    extension_settings[MODULE_NAME] = cloneDefaultSettings();
    syncExternalReferenceVisibility(extension_settings[MODULE_NAME]);
    saveSettingsDebounced();
}
