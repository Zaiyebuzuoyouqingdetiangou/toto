import { clamp, luminanceFromRgb, classifyPaletteSamples } from './paletteObservation.js?rmv=1.62.93';
import { activeRoleColorHtml, bindRolePaletteCode } from './roleColorVariants.js?rmv=1.62.93';
import { detectCompositionFingerprint, VISUAL_SKELETON_MAX_CHARS } from './compositionFingerprint.js?rmv=1.62.93';
import { visualSceneryEnabled } from './presentationMode.js?rmv=1.62.93';
import { presentationModeFields } from './presentationMode.js?rmv=1.62.93';
import { getCurrentChatKey, commitFollowVisualHistory, bindVisualHistoryTarget } from './storage.js?rmv=1.62.93';
import { consumeInjectedFeedbackForSuccessfulRabbitMirror } from './feedbackCat.js?rmv=1.62.93';
import { getSettings } from './settings.js?rmv=1.62.93';
import { applyRabbitMirrorBannedWordsToDom } from './bannedWords.js?rmv=1.62.93';
import {
    commitRabbitMirrorFollowBatch,
    captureRabbitMirrorGenerationSnapshots,
    getRabbitMirrorGenerationSnapshot,
    getRabbitMirrorFollowBatchSources,
    getRabbitMirrorFollowBatchTargetIndexes,
    inspectRabbitMirrorGenerationSource,
    releaseRabbitMirrorFollowBatch,
    releaseRabbitMirrorFollowBatchAtMessage,
} from './generationGuard.js?rmv=1.62.93';
import {
    clearSanitizedRabbitMirrorFaceProof,
    getSanitizedRabbitMirrorFaceProof,
    markSanitizedRabbitMirrorFace,
    rabbitMirrorMultifaceSourceHash,
} from './multifaceProof.js?rmv=1.62.93';
import { detectMissingVisualProgram } from './presentationQuality.js?rmv=1.62.93';
import { createMultifaceFailureSlot, MULTIFACE_FAILURE_ATTR, parseMultifaceOutput } from './multifaceProtocol.js?rmv=1.62.93';
import { saveFollowPartialResult } from './followPartialResults.js?rmv=1.62.93';
import { PRESENTATION_FORMATS } from '../data/structured/presentationIndex.js?rmv=1.62.93';

export const FOLLOW_MULTIFACE_COMMITTED_EVENT = 'rabbit-mirror:follow-multiface-committed';
export const FOLLOW_MULTIFACE_REJECTED_EVENT = 'rabbit-mirror:follow-multiface-rejected';
export const FOLLOW_GENERATION_SETTLED_EVENT = 'rabbit-mirror:follow-generation-settled';

const TOTO_RE = new RegExp('<toto\\b[^>]*(?:data-rabbit-mirror|data-rabbit-' + 'h' + 'ole)=[\"\']true[\"\'][^>]*>[\\s\\S]*?<\\/toto>', 'i');
let lastScannedHash = '';
let lastScanAttempts = 0;
let visualScannerSubscriptions = [];
let visualScannerTimers = new Set();
let visualScannerCaptureTimer = 0;
const followBatchScanAttempts = new Map();
const terminalFollowMessageIndexes = new Set();
const followBatchScansInFlight = new Set();
// Runtime-only exact-owner tombstones; never persist source text in diagnostics.
const rejectedFollowBatches = new Map();
const followPartialStorageWarnings = new Set();
let followBatchSanitizerModulePromise = null;
let visualScannerLifecycle = 0;

function hashText(text) {
    let hash = 0;
    const input = String(text || '');
    for (let i = 0; i < input.length; i += 1) {
        hash = ((hash << 5) - hash + input.charCodeAt(i)) | 0;
    }
    return String(hash);
}

function stripTags(html) {
    return String(html || '')
        .replace(/<script[\s\S]*?<\/script>/gi, '')
        .replace(/<style[\s\S]*?<\/style>/gi, '')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

function count(re, text) {
    return (String(text || '').match(re) || []).length;
}

function extractStyleFingerprints(html) {
    const styles = [...String(html || '').matchAll(/<([a-z0-9-]+)\b[^>]*\sstyle=["']([^"']+)["'][^>]*>/gi)];
    const normalized = styles.map(match => {
        const tag = match[1].toLowerCase();
        const props = match[2]
            .toLowerCase()
            .split(';')
            .map(part => part.trim().split(':')[0])
            .filter(Boolean)
            .sort()
            .join('|');
        return `${tag}:${props}`;
    }).filter(Boolean);
    const buckets = new Map();
    for (const item of normalized) buckets.set(item, (buckets.get(item) || 0) + 1);
    const repeated = [...buckets.values()].filter(v => v >= 3).length;
    const maxRepeat = Math.max(0, ...buckets.values());
    return { repeated, maxRepeat };
}

function parseToto(html) {
    try {
        if (typeof DOMParser === 'undefined') return null;
        const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
        const legacyAttr = 'data-rabbit-' + 'h' + 'ole';
        return doc.querySelector(`toto[data-rabbit-mirror="true"], toto[${legacyAttr}="true"]`) || doc.querySelector('toto');
    } catch {
        return null;
    }
}

function elementDepth(el) {
    if (!el || !el.children || !el.children.length) return 0;
    return 1 + Math.max(...[...el.children].map(child => elementDepth(child)));
}

function stylePropSet(el) {
    const style = (el?.getAttribute?.('style') || '').toLowerCase();
    return new Set(style.split(';').map(part => part.trim().split(':')[0]).filter(Boolean));
}

function setOverlapRatio(a, b) {
    if (!a.size && !b.size) return 1;
    let hit = 0;
    for (const item of a) if (b.has(item)) hit += 1;
    return hit / Math.max(1, Math.min(a.size, b.size));
}

function areSimilarBlocks(a, b) {
    if (!a || !b || a.nodeType !== 1 || b.nodeType !== 1) return false;
    const tagClose = a.tagName === b.tagName;
    const childClose = Math.abs(a.children.length - b.children.length) <= 1;
    const depthClose = Math.abs(elementDepth(a) - elementDepth(b)) <= 1;
    const styleClose = setOverlapRatio(stylePropSet(a), stylePropSet(b)) >= 0.45;
    const textA = (a.textContent || '').trim().length;
    const textB = (b.textContent || '').trim().length;
    const textClose = Math.abs(textA - textB) <= Math.max(60, Math.max(textA, textB) * 0.45);
    return tagClose && childClose && depthClose && (styleClose || textClose);
}

function analyzeDomStructure(html) {
    const toto = parseToto(html);
    if (!toto) return { maxSimilarRun: 0, summaryLength: 0, summaryFlags: [] };
    const summary = toto.querySelector('summary');
    const summaryLength = (summary?.textContent || '').replace(/\s+/g, '').length;
    const summaryFlags = [];
    if (summaryLength > 80) summaryFlags.push('summary疑似伪装正文承载区');
    else if (summaryLength > 60) summaryFlags.push('summary标题栏冗长');
    else if (summaryLength > 40) summaryFlags.push('summary标题偏长');

    let maxSimilarRun = 0;
    const containers = [toto, ...[...toto.querySelectorAll('details, div, section, article, main')].slice(0, 80)];
    for (const container of containers) {
        const children = [...container.children].filter(el => !['SUMMARY', 'STYLE', 'SCRIPT'].includes(el.tagName));
        let run = 1;
        for (let i = 1; i < children.length; i += 1) {
            if (areSimilarBlocks(children[i - 1], children[i])) {
                run += 1;
                maxSimilarRun = Math.max(maxSimilarRun, run);
            } else {
                run = 1;
            }
        }
    }
    return { maxSimilarRun, summaryLength, summaryFlags };
}


function textLengthBucket(len) {
    if (len < 60) return 'short';
    if (len < 180) return 'medium';
    return 'long';
}

function blockFeature(el) {
    const style = (el?.getAttribute?.('style') || '').toLowerCase();
    const text = (el?.textContent || '').replace(/\s+/g, '').trim();
    return {
        tag: el?.tagName || '',
        hasBg: /background(?:-color)?\s*:/.test(style),
        hasBorder: /border\s*:/.test(style) || /border-left\s*:/.test(style),
        hasRadius: /border-radius\s*:/.test(style),
        hasShadow: /box-shadow\s*:/.test(style),
        hasPadding: /padding\s*:/.test(style),
        hasHeading: !!el?.querySelector?.('h1,h2,h3,h4,strong,b'),
        childBucket: Math.min(4, el?.children?.length || 0),
        textBucket: textLengthBucket(text.length),
    };
}

function featureSimilarity(a, b) {
    const keys = ['tag', 'hasBg', 'hasBorder', 'hasRadius', 'hasShadow', 'hasPadding', 'hasHeading', 'childBucket', 'textBucket'];
    let same = 0;
    for (const key of keys) {
        if (a?.[key] === b?.[key]) same += 1;
    }
    return same / keys.length;
}

function getBlockCandidates(root) {
    if (!root?.querySelectorAll) return [];
    return [...root.querySelectorAll('div, section, article, li')]
        .filter(el => {
            const text = (el.textContent || '').replace(/\s+/g, '').trim();
            if (text.length < 24) return false;
            const style = (el.getAttribute('style') || '').toLowerCase();
            const hasBoxSignal = /border\s*:|border-left\s*:|border-radius\s*:|background(?:-color)?\s*:|box-shadow\s*:|padding\s*:/.test(style);
            return hasBoxSignal;
        })
        .slice(0, 80);
}

function detectSameBlockStack(root, html = '') {
    const candidates = getBlockCandidates(root);
    if (candidates.length < 3) return false;
    const features = candidates.map(blockFeature);
    let similarPairs = 0;
    let totalPairs = 0;
    for (let i = 0; i < features.length; i += 1) {
        for (let j = i + 1; j < features.length; j += 1) {
            totalPairs += 1;
            if (featureSimilarity(features[i], features[j]) >= 0.72) similarPairs += 1;
        }
    }
    const similarRatio = totalPairs ? similarPairs / totalPairs : 0;
    const htmlText = String(html || '').toLowerCase();
    const verticalStackSignal = /flex-direction\s*:\s*column|gap\s*:|margin-bottom\s*:|<h[1-4]\b/i.test(htmlText);
    const repeatedBoxSignal = count(/border-radius\s*:/gi, htmlText) >= 3 || count(/border\s*:/gi, htmlText) >= 3 || count(/background(?:-color)?\s*:/gi, htmlText) >= 4;
    return candidates.length >= 4 && repeatedBoxSignal && (verticalStackSignal || similarRatio >= 0.55) && similarRatio >= 0.38;
}

function candidateSimilarityRatio(candidates = []) {
    if (!Array.isArray(candidates) || candidates.length < 2) return 0;
    const features = candidates.map(blockFeature);
    let similarPairs = 0;
    let totalPairs = 0;
    for (let i = 0; i < features.length; i += 1) {
        for (let j = i + 1; j < features.length; j += 1) {
            totalPairs += 1;
            if (featureSimilarity(features[i], features[j]) >= 0.68) similarPairs += 1;
        }
    }
    return totalPairs ? similarPairs / totalPairs : 0;
}

function detectSameGridCardRisk(root, html = '') {
    const text = String(html || '').toLowerCase();
    const gridSignal = /display\s*:\s*grid|grid-template|grid-template-columns|repeat\s*\(/i.test(text);
    if (!gridSignal) return false;
    const candidates = getBlockCandidates(root);
    if (candidates.length < 4) return false;
    const ratio = candidateSimilarityRatio(candidates);
    const boxSignals = count(/border\s*:/gi, text) + count(/border-radius\s*:/gi, text) + count(/background(?:-color)?\s*:/gi, text);
    return ratio >= 0.30 && boxSignals >= 8;
}

function detectCatalogPageRisk(root, html = '', plain = '') {
    const text = `${html || ''}\n${plain || ''}`;
    const catalogSignal = /图鉴|目录|标本|物件|编号|条目|清单|列表|收藏|catalog|index|specimen|item|collection/i.test(text);
    if (!catalogSignal) return false;
    const candidates = getBlockCandidates(root);
    const gridSignal = /display\s*:\s*grid|grid-template|grid-template-columns|repeat\s*\(/i.test(String(html || ''));
    return candidates.length >= 4 && (gridSignal || candidateSimilarityRatio(candidates) >= 0.30);
}

function detectVisualPromiseWithoutMechanism(html = '', plain = '') {
    const text = `${html || ''}\n${plain || ''}`;
    const promisesMotion = /运动|变化|推进|实时|动态|连续|滚动|轮播|闪烁|流动|播放|抽取中|倒计时|漂浮|旋转|震动|呼吸|脉冲|弹幕/i.test(text);
    if (!promisesMotion) return false;
    const hasMechanism = /animation\s*:|@keyframes|transition\s*:|transform\s*:|<svg\b|<animate\b|<marquee\b|stroke-dasharray|offset-path/i.test(String(html || ''));
    return !hasMechanism;
}


function hasMeaningfulStateRule(html = '', statePseudo = ':checked') {
    const styles = [...String(html || '').matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi)]
        .map(match => match[1])
        .join('\n');
    if (!styles || !styles.toLowerCase().includes(statePseudo.toLowerCase())) return false;
    const ruleRe = /([^{}]+)\{([^{}]*)\}/g;
    let match;
    while ((match = ruleRe.exec(styles))) {
        const selector = String(match[1] || '');
        if (!selector.toLowerCase().includes(statePseudo.toLowerCase())) continue;
        const declarations = String(match[2] || '')
            .split(';')
            .map(part => part.trim())
            .filter(Boolean)
            .map(part => {
                const colon = part.indexOf(':');
                if (colon < 0) return null;
                return {
                    property: part.slice(0, colon).trim().toLowerCase(),
                    value: part.slice(colon + 1).trim().toLowerCase(),
                };
            })
            .filter(Boolean);
        if (!declarations.length) continue;
        const cosmeticOnly = declarations.every(({ property, value }) => {
            if (property.startsWith('--')) return true;
            if (property === 'transform') {
                // 3D 翻面可改变正反面内容；普通位移/缩放只算选中反馈。
                return !/(?:rotate[xy]|perspective)\s*\(/i.test(value);
            }
            return property === 'color'
                || property === 'background' || property.startsWith('background-')
                || property === 'border' || property.startsWith('border-')
                || property === 'box-shadow' || property === 'text-shadow'
                || property === 'outline' || property.startsWith('outline-')
                || property === 'fill' || property === 'stroke'
                || property === 'filter' || property === 'backdrop-filter'
                || property === 'cursor'
                || property === 'font-weight' || property === 'font-style'
                || property === 'text-decoration' || property === 'letter-spacing'
                || property === 'translate' || property === 'rotate' || property === 'scale'
                || property === 'transition' || property.startsWith('transition-')
                || property === 'transform-origin';
        });
        if (!cosmeticOnly) return true;
    }
    return false;
}

function detectEffectiveInteraction(html = '') {
    const text = String(html || '');
    const innerDetails = count(/<details\b/gi, text) >= 2 && /<summary\b/i.test(text);
    const hasCheckInput = /<input\b[^>]*type\s*=\s*["']?(?:checkbox|radio)\b/i.test(text);
    const checkedRoute = hasCheckInput && hasMeaningfulStateRule(text, ':checked');
    const targetRoute = /href\s*=\s*["']#[^"']+["']/i.test(text) && hasMeaningfulStateRule(text, ':target');
    const popoverRoute = /\bpopovertarget\s*=|\bcommandfor\s*=/i.test(text) && /\bpopover(?:\s|=|>)/i.test(text);
    return innerDetails || checkedRoute || targetRoute || popoverRoute;
}

function detectInteractionSignals(html = '', plain = '') {
    const text = `${html || ''}\n${plain || ''}`;
    return /:hover|:active|:focus|transition\s*:|cursor\s*:\s*pointer|<button\b|<label\b|点击|选择|切换|开关|解锁|探索|查看|操作|按钮/i.test(text);
}

function interactionFamilyRecord(id = 'none', label = '未识别交互家族', confidence = 0, details = {}) {
    return {
        id: String(id || 'none'),
        label: String(label || '未识别交互家族'),
        confidence: Math.max(0, Math.min(1, Number(confidence) || 0)),
        controlCount: Math.max(0, Number(details.controlCount) || 0),
        panelCount: Math.max(0, Number(details.panelCount) || 0),
    };
}

function labelsForControls(root, controls = []) {
    if (!root?.querySelectorAll || !controls.length) return [];
    const labels = new Set();
    for (const control of controls) {
        const id = String(control?.id || '').trim();
        if (id) {
            try {
                root.querySelectorAll(`label[for="${globalThis.CSS?.escape ? globalThis.CSS.escape(id) : id.replace(/["\\]/g, '\\$&')}"]`).forEach(label => labels.add(label));
            } catch {
                root.querySelectorAll('label').forEach(label => {
                    if (String(label.getAttribute('for') || '') === id) labels.add(label);
                });
            }
        }
        const parentLabel = control?.closest?.('label');
        if (parentLabel) labels.add(parentLabel);
    }
    return [...labels];
}

function detectInteractionFamily(root, html = '') {
    const text = String(html || '');
    const lower = text.toLowerCase();
    const innerDetailsCount = Math.max(0, count(/<details\b/gi, text) - 1);
    const rotateFlip = /rotate[xy]\s*\(\s*(?:-?180|180deg)/i.test(text)
        && /backface-visibility|transform-style\s*:\s*preserve-3d|perspective\s*:/i.test(text);
    if (rotateFlip) return interactionFamilyRecord('flip_card_family', '翻面／双面切换', 0.96, { controlCount: count(/<input\b/gi, text), panelCount: 2 });

    const controls = root?.querySelectorAll
        ? [...root.querySelectorAll('input[type="radio"], input[type="checkbox"]')]
        : [];
    const radios = controls.filter(input => String(input.type || '').toLowerCase() === 'radio');
    const checkboxes = controls.filter(input => String(input.type || '').toLowerCase() === 'checkbox');
    const checkedRules = count(/:checked\b/gi, text);

    const groups = new Map();
    for (const radio of radios) {
        const key = String(radio.getAttribute('name') || '').trim() || `__ungrouped__:${radio.id || groups.size}`;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(radio);
    }
    const largestRadioGroup = [...groups.values()].sort((a, b) => b.length - a.length)[0] || [];
    const groupLabels = labelsForControls(root, largestRadioGroup);
    const sameLayerPanelSignal = /grid-area\s*:\s*1\s*\/\s*1|position\s*:\s*absolute[\s\S]{0,220}(?:opacity\s*:\s*0|visibility\s*:\s*hidden)/i.test(lower);
    const tabLanguageSignal = /tab|tabs|panel|pane|频道|标签页|选项卡|结局\s*0?1|档位|模式\s*[一二三123]/i.test(`${lower} ${stripTags(text)}`);
    if (largestRadioGroup.length >= 3 && groupLabels.length >= 3 && checkedRules >= 3) {
        return interactionFamilyRecord('tabbed_radio_family', '并列标签／多按钮切页', sameLayerPanelSignal || tabLanguageSignal ? 0.99 : 0.94, {
            controlCount: largestRadioGroup.length,
            panelCount: Math.max(largestRadioGroup.length, checkedRules),
        });
    }
    if (largestRadioGroup.length >= 2 && groupLabels.length >= 2 && checkedRules >= 2 && (sameLayerPanelSignal || tabLanguageSignal)) {
        return interactionFamilyRecord('tabbed_radio_family', '并列标签／多按钮切页', 0.92, {
            controlCount: largestRadioGroup.length,
            panelCount: Math.max(largestRadioGroup.length, checkedRules),
        });
    }
    if (controls.length >= 3 && labelsForControls(root, controls).length >= 3 && checkedRules >= 2) {
        return interactionFamilyRecord('multi_control_panel_family', '多控件状态面板', 0.86, {
            controlCount: controls.length,
            panelCount: checkedRules,
        });
    }
    if (checkboxes.length === 1 && checkedRules >= 1) {
        return interactionFamilyRecord('checkbox_reveal_family', '单入口揭示／展开', 0.90, { controlCount: 1, panelCount: 1 });
    }
    if (checkboxes.length >= 2 && checkedRules >= 2) {
        return interactionFamilyRecord('multi_checkbox_family', '多点揭示／清单状态', 0.84, { controlCount: checkboxes.length, panelCount: checkedRules });
    }
    if (innerDetailsCount >= 1) {
        return interactionFamilyRecord('inner_details_family', '内部折叠／分层阅读', 0.88, { controlCount: innerDetailsCount, panelCount: innerDetailsCount });
    }
    if (/href\s*=\s*["']#[^"']+["']/i.test(text) && /:target\b/i.test(text)) {
        return interactionFamilyRecord('target_navigation_family', '锚点／目标状态切换', 0.86, { controlCount: count(/href\s*=\s*["']#/gi, text), panelCount: count(/:target\b/gi, text) });
    }
    if (/\bpopovertarget\s*=|\bcommandfor\s*=/i.test(text)) {
        return interactionFamilyRecord('popover_family', '弹层／局部浮出', 0.88, { controlCount: count(/popovertarget|commandfor/gi, text), panelCount: count(/\bpopover(?:\s|=|>)/gi, text) });
    }
    if (detectEffectiveInteraction(text)) {
        return interactionFamilyRecord('css_state_family', '其他 CSS 状态交互', 0.58, { controlCount: controls.length, panelCount: checkedRules });
    }
    return interactionFamilyRecord();
}

function detectInteractionMissing(html = '') {
    return !detectEffectiveInteraction(html);
}

// Record structures actually present in this face, independently of the draw.
// This is not a verdict that the interaction runs or has meaningful content.
function observedRecipeIds(root, family) {
    if (!root?.querySelectorAll) return [];
    const ids = new Set();
    const outer = root.querySelector('details');
    if ([...root.querySelectorAll('details')].some(node => node !== outer && node.querySelector('summary'))) ids.add('fold');
    if (family.id === 'flip_card_family') ids.add('flip');
    const popovers = new Set([...root.querySelectorAll('[popover]')].map(node => node.id).filter(Boolean));
    if ([...root.querySelectorAll('button[popovertarget]')].some(node => popovers.has(node.getAttribute('popovertarget')))) ids.add('popup');
    const contracts = {
        effect: ['trigger-effect', ['button[data-rm-fire]', '[data-rm-part]']],
        drag: ['drag-combine', ['[data-rm-item]']],
        adjust: ['continuous-adjust', ['input[type="range"]']],
        reveal: ['local-reveal', ['[data-rm-cover]']],
        view: ['viewport-explore', ['[data-rm-part]']],
        input: ['input-draw', ['input, textarea', 'output']],
        draw: ['input-draw', ['svg[data-rm-canvas]']],
        motion: ['progress-control', ['[data-rm-part]', 'button[data-rm-play], button[data-rm-reverse], input[type="range"]']],
        hold: ['hold-preview', ['button[data-rm-hold]']],
        follow: ['pointer-follow', ['[data-rm-surface]']],
        reorder: ['reorder', ['[data-rm-item]']],
        accumulate: ['accumulate', ['button[data-rm-step]']],
    };
    for (const group of root.querySelectorAll('[data-rm-ui]')) {
        const type = group.getAttribute('data-rm-ui');
        const contract = Object.hasOwn(contracts, type) ? contracts[type] : null;
        if (!contract) continue;
        const own = selector => [...group.querySelectorAll(selector)].filter(node => node.closest('[data-rm-ui]') === group);
        if (!contract[1].every(selector => own(selector).length)) continue;
        if (type === 'input' && !own('input, textarea').some(node => node.matches('textarea') ||
            ['', 'text', 'password'].includes(String(node.getAttribute('type') || '').toLowerCase()))) continue;
        if (type === 'reorder' && !own('[data-rm-item]').some((item, index, items) =>
            items.some((other, otherIndex) => index !== otherIndex && item.parentElement === other.parentElement))) continue;
        ids.add(contract[0]);
    }
    return [...ids];
}

function detectFakeInteraction(html = '', plain = '') {
    return !detectEffectiveInteraction(html) && detectInteractionSignals(html, plain);
}

function detectWeakSpatialComplexity(html = '', plain = '') {
    const text = String(html || '');
    const spatialSignals = count(/position\s*:\s*absolute|display\s*:\s*grid|grid-template|grid-area|transform\s*:|clip-path\s*:|mask\s*:|z-index\s*:|<svg\b|<path\b|radial-gradient|conic-gradient|repeating-gradient|aspect-ratio/gi, text);
    const visualSignals = count(/box-shadow\s*:|linear-gradient|radial-gradient|filter\s*:|backdrop-filter|clip-path|mask\s*:|transform\s*:|<svg\b/gi, text);
    const textHeavy = String(plain || '').length > 520;
    return textHeavy && spatialSignals < 2 && visualSignals < 3;
}

function detectFlatVerticalFlow(html = '', root = null) {
    const text = String(html || '');
    const columnSignals = count(/flex-direction\s*:\s*column|margin-bottom\s*:|<br\s*\/?>(?![^<]*<svg)|<li\b/gi, text);
    const divs = count(/<div\b/gi, text);
    const absolute = /position\s*:\s*absolute|display\s*:\s*grid|grid-template|clip-path\s*:|mask\s*:|<svg\b/i.test(text);
    const candidates = root ? getBlockCandidates(root) : [];
    const ratio = candidateSimilarityRatio(candidates);
    return divs >= 8 && columnSignals >= 2 && !absolute && (candidates.length >= 3 || ratio >= 0.25);
}

function detectRepeatedUnitShape(root, html = '') {
    const candidates = root ? getBlockCandidates(root) : [];
    if (candidates.length < 3) return false;
    const ratio = candidateSimilarityRatio(candidates);
    const text = String(html || '');
    const repeatedVisualProps = count(/border-radius\s*:|padding\s*:|background(?:-color)?\s*:|border\s*:/gi, text);
    return ratio >= 0.42 && repeatedVisualProps >= 8;
}

function visualSceneryAuditExpected(html = '') {
    if (/data-rm-visual-scenery\s*=\s*["']true["']/i.test(String(html || ''))) return true;
    try { return visualSceneryEnabled(getSettings()); } catch { return false; }
}

function inspectVisualSceneryMotion(html = '', spatialSignalCount = 0) {
    const text = String(html || '');
    if (!visualSceneryAuditExpected(text)) return [];
    const flags = [];
    const hasMarker = /data-rm-visual-scenery\s*=\s*["']true["']/i.test(text);
    const keyframeCount = count(/@(?:-webkit-)?keyframes\b/gi, text);
    const animationDeclarationCount = count(/(?:^|[;{])\s*(?:-webkit-)?animation(?:-name)?\s*:/gi, text);
    const infiniteCount = count(/\binfinite\b/gi, text);
    const meaningfulKeyframeMotion = /@(?:-webkit-)?keyframes[\s\S]{0,2400}?(?:translate(?:3d|x|y)?\s*\(|rotate(?:3d|x|y)?\s*\(|scale(?:3d|x|y)?\s*\(|clip-path\s*:|mask(?:-position|-size)?\s*:|background-position\s*:|stroke-dashoffset\s*:|offset-distance\s*:)/i.test(text);
    const layeredSceneSignals = count(/position\s*:\s*absolute|z-index\s*:|grid-area\s*:|clip-path\s*:|mask\s*:|radial-gradient|linear-gradient|<svg\b/gi, text);

    if (!hasMarker) flags.push('visual_scenery_marker_missing');
    if (keyframeCount < 1 || animationDeclarationCount < 1 || infiniteCount < 1 || !meaningfulKeyframeMotion) {
        flags.push('weak_visual_scenery_motion');
    }
    if (animationDeclarationCount < 2 || spatialSignalCount < 3 || layeredSceneSignals < 4) {
        flags.push('weak_visual_scenery_layers');
    }
    return flags;
}

function detectRiskFlags({ root, html, plain, dom, repeated, spatialSignalCount, composition }) {
    const flags = [];
    const sameBlockStack = detectSameBlockStack(root, html);
    const sameGridCard = detectSameGridCardRisk(root, html);
    const catalogPage = detectCatalogPageRisk(root, html, plain);

    const flatVerticalFlow = detectFlatVerticalFlow(html, root);
    const repeatedUnitShape = detectRepeatedUnitShape(root, html);
    const weakSpatialComplexity = detectWeakSpatialComplexity(html, plain);
    // Reuse the bounded DOM/CSS binding proof: a persistent object state is
    // effective even when its only change is 2D geometry. Raw transform text
    // still cannot exempt control styling, hover feedback or missing targets.
    const objectStateChange = composition?.operation_family === 'object_state_change';
    const interactionMissing = !objectStateChange && detectInteractionMissing(html);
    const fakeInteraction = !objectStateChange && detectFakeInteraction(html, plain);
    const missingVisualProgram = detectMissingVisualProgram(html, plain);
    if (sameBlockStack) flags.push('same_block_stack');
    if (sameGridCard) flags.push('same_grid_card_risk');
    if (catalogPage) flags.push('catalog_page_risk');
    if (flatVerticalFlow) flags.push('flat_vertical_flow');
    if (repeatedUnitShape) flags.push('repeated_unit_shape');

    if (sameBlockStack || sameGridCard || catalogPage || flatVerticalFlow || repeatedUnitShape || (dom?.maxSimilarRun || 0) >= 3 || (repeated?.maxRepeat || 0) >= 4) flags.push('info_page_degrade');
    if (spatialSignalCount < 2 && String(plain || '').length > 520 && (sameBlockStack || sameGridCard || catalogPage || repeatedUnitShape || (repeated?.maxRepeat || 0) >= 3)) flags.push('weak_media_body');
    if (weakSpatialComplexity) flags.push('weak_spatial_complexity');
    if (interactionMissing) flags.push('missing_interaction');
    if (fakeInteraction) flags.push('fake_interaction');
    if (missingVisualProgram) flags.push('missing_visual_program');
    if (detectVisualPromiseWithoutMechanism(html, plain)) flags.push('visual_promise_unfulfilled');
    flags.push(...inspectVisualSceneryMotion(html, spatialSignalCount));
    return [...new Set(flags)];
}

function expandHexColor(hex) {
    const raw = String(hex || '').replace('#', '').trim();
    if (/^[0-9a-f]{3}$/i.test(raw)) {
        return raw.split('').map(x => x + x).join('');
    }
    if (/^[0-9a-f]{6}$/i.test(raw)) return raw;
    return '';
}

function colorValueLuminance(value) {
    const v = String(value || '').toLowerCase();
    if (/\bblack\b/.test(v)) return 0;
    if (/\bwhite\b/.test(v)) return 255;
    const rgba = v.match(/rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})(?:\s*,\s*([0-9.]+))?\s*\)/);
    if (rgba) {
        const alpha = rgba[4] === undefined ? 1 : Number(rgba[4]);
        if (!Number.isNaN(alpha) && alpha < 0.25) return null;
        return luminanceFromRgb(Number(rgba[1]), Number(rgba[2]), Number(rgba[3]));
    }
    const hexes = [...v.matchAll(/#([0-9a-f]{3}|[0-9a-f]{6})\b/gi)]
        .map(m => expandHexColor(m[1]))
        .filter(Boolean);
    if (hexes.length) {
        const values = hexes.map(hex => {
            const r = parseInt(hex.slice(0, 2), 16);
            const g = parseInt(hex.slice(2, 4), 16);
            const b = parseInt(hex.slice(4, 6), 16);
            return luminanceFromRgb(r, g, b);
        });
        // For gradients, average the first two stops; for flat color, use the first.
        const sample = values.slice(0, Math.min(2, values.length));
        return sample.reduce((a, b) => a + b, 0) / sample.length;
    }
    return null;
}

function extractBackgroundValues(html) {
    const values = [];
    const input = String(html || '');
    const re = /(?:^|[;{\s"'])background(?:-color|-image)?\s*:\s*([^;}"']+)/gi;
    let match;
    while ((match = re.exec(input))) {
        const value = String(match[1] || '').trim();
        if (value) values.push(value);
    }
    return values;
}

function detectBaseColor(html) {
    const values = extractBackgroundValues(html);
    const luminances = values.map(colorValueLuminance).filter(v => typeof v === 'number' && !Number.isNaN(v));

    // The first explicit background usually belongs to the main container. Give it priority
    // so a dark outer shell cannot be mislabelled as white because of light inner cards.
    if (luminances.length) {
        const first = luminances[0];
        if (first < 90) return '暗色高对比底盘';
        if (first > 190) return '浅色纸面/白底底盘';
        const darkCount = luminances.filter(v => v < 90).length;
        const lightCount = luminances.filter(v => v > 190).length;
        if (darkCount > lightCount) return '暗色高对比底盘';
        if (lightCount > darkCount) return '浅色纸面/白底底盘';
    }

    if (/radial-gradient|conic-gradient|linear-gradient/i.test(html)) return '渐变/混合色底盘';
    return '中性或混合底盘';
}

function detectContrastFamily(html) {
    const values = extractBackgroundValues(html);
    const luminances = values.map(colorValueLuminance).filter(v => typeof v === 'number' && !Number.isNaN(v));
    if (!luminances.length) return 'contrast: mixed_or_unspecified';
    const first = luminances[0];
    if (first < 90) return 'contrast: dark_weighted';
    if (first > 190) return 'contrast: light_weighted';
    return 'contrast: mid_tone_or_mixed';
}


// Standard named sRGB colours: https://www.w3.org/TR/css-color-4/#named-colors
const NAMED_PALETTE_COLORS = Object.freeze({
    aliceblue: '#f0f8ff', antiquewhite: '#faebd7', aqua: '#00ffff', aquamarine: '#7fffd4',
    azure: '#f0ffff', beige: '#f5f5dc', bisque: '#ffe4c4', black: '#000000',
    blanchedalmond: '#ffebcd', blue: '#0000ff', blueviolet: '#8a2be2', brown: '#a52a2a',
    burlywood: '#deb887', cadetblue: '#5f9ea0', chartreuse: '#7fff00', chocolate: '#d2691e',
    coral: '#ff7f50', cornflowerblue: '#6495ed', cornsilk: '#fff8dc', crimson: '#dc143c',
    cyan: '#00ffff', darkblue: '#00008b', darkcyan: '#008b8b', darkgoldenrod: '#b8860b',
    darkgray: '#a9a9a9', darkgreen: '#006400', darkgrey: '#a9a9a9', darkkhaki: '#bdb76b',
    darkmagenta: '#8b008b', darkolivegreen: '#556b2f', darkorange: '#ff8c00', darkorchid: '#9932cc',
    darkred: '#8b0000', darksalmon: '#e9967a', darkseagreen: '#8fbc8f', darkslateblue: '#483d8b',
    darkslategray: '#2f4f4f', darkslategrey: '#2f4f4f', darkturquoise: '#00ced1', darkviolet: '#9400d3',
    deeppink: '#ff1493', deepskyblue: '#00bfff', dimgray: '#696969', dimgrey: '#696969',
    dodgerblue: '#1e90ff', firebrick: '#b22222', floralwhite: '#fffaf0', forestgreen: '#228b22',
    fuchsia: '#ff00ff', gainsboro: '#dcdcdc', ghostwhite: '#f8f8ff', gold: '#ffd700',
    goldenrod: '#daa520', gray: '#808080', green: '#008000', greenyellow: '#adff2f',
    grey: '#808080', honeydew: '#f0fff0', hotpink: '#ff69b4', indianred: '#cd5c5c',
    indigo: '#4b0082', ivory: '#fffff0', khaki: '#f0e68c', lavender: '#e6e6fa',
    lavenderblush: '#fff0f5', lawngreen: '#7cfc00', lemonchiffon: '#fffacd', lightblue: '#add8e6',
    lightcoral: '#f08080', lightcyan: '#e0ffff', lightgoldenrodyellow: '#fafad2', lightgray: '#d3d3d3',
    lightgreen: '#90ee90', lightgrey: '#d3d3d3', lightpink: '#ffb6c1', lightsalmon: '#ffa07a',
    lightseagreen: '#20b2aa', lightskyblue: '#87cefa', lightslategray: '#778899', lightslategrey: '#778899',
    lightsteelblue: '#b0c4de', lightyellow: '#ffffe0', lime: '#00ff00', limegreen: '#32cd32',
    linen: '#faf0e6', magenta: '#ff00ff', maroon: '#800000', mediumaquamarine: '#66cdaa',
    mediumblue: '#0000cd', mediumorchid: '#ba55d3', mediumpurple: '#9370db', mediumseagreen: '#3cb371',
    mediumslateblue: '#7b68ee', mediumspringgreen: '#00fa9a', mediumturquoise: '#48d1cc', mediumvioletred: '#c71585',
    midnightblue: '#191970', mintcream: '#f5fffa', mistyrose: '#ffe4e1', moccasin: '#ffe4b5',
    navajowhite: '#ffdead', navy: '#000080', oldlace: '#fdf5e6', olive: '#808000',
    olivedrab: '#6b8e23', orange: '#ffa500', orangered: '#ff4500', orchid: '#da70d6',
    palegoldenrod: '#eee8aa', palegreen: '#98fb98', paleturquoise: '#afeeee', palevioletred: '#db7093',
    papayawhip: '#ffefd5', peachpuff: '#ffdab9', peru: '#cd853f', pink: '#ffc0cb',
    plum: '#dda0dd', powderblue: '#b0e0e6', purple: '#800080', rebeccapurple: '#663399',
    red: '#ff0000', rosybrown: '#bc8f8f', royalblue: '#4169e1', saddlebrown: '#8b4513',
    salmon: '#fa8072', sandybrown: '#f4a460', seagreen: '#2e8b57', seashell: '#fff5ee',
    sienna: '#a0522d', silver: '#c0c0c0', skyblue: '#87ceeb', slateblue: '#6a5acd',
    slategray: '#708090', slategrey: '#708090', snow: '#fffafa', springgreen: '#00ff7f',
    steelblue: '#4682b4', tan: '#d2b48c', teal: '#008080', thistle: '#d8bfd8',
    tomato: '#ff6347', turquoise: '#40e0d0', violet: '#ee82ee', wheat: '#f5deb3',
    white: '#ffffff', whitesmoke: '#f5f5f5', yellow: '#ffff00', yellowgreen: '#9acd32',
});

function hslToRgb(h, s, l) {
    const hue = ((Number(h) % 360) + 360) % 360 / 360;
    const sat = clamp(Number(s), 0, 1);
    const light = clamp(Number(l), 0, 1);
    if (sat === 0) {
        const gray = Math.round(light * 255);
        return [gray, gray, gray];
    }
    const q = light < 0.5 ? light * (1 + sat) : light + sat - light * sat;
    const p = 2 * light - q;
    const hue2rgb = (t) => {
        let x = t;
        if (x < 0) x += 1;
        if (x > 1) x -= 1;
        if (x < 1 / 6) return p + (q - p) * 6 * x;
        if (x < 1 / 2) return q;
        if (x < 2 / 3) return p + (q - p) * (2 / 3 - x) * 6;
        return p;
    };
    return [hue2rgb(hue + 1 / 3), hue2rgb(hue), hue2rgb(hue - 1 / 3)].map(x => Math.round(x * 255));
}

function parseCssColorToken(token) {
    const value = String(token || '').trim().toLowerCase();
    if (!value || value === 'transparent') return null;

    const hex = value.match(/^#([0-9a-f]{3,8})$/i);
    if (hex) {
        let raw = hex[1];
        if (raw.length === 3 || raw.length === 4) raw = raw.split('').map(char => char + char).join('');
        if (raw.length !== 6 && raw.length !== 8) return null;
        const r = parseInt(raw.slice(0, 2), 16);
        const g = parseInt(raw.slice(2, 4), 16);
        const b = parseInt(raw.slice(4, 6), 16);
        const a = raw.length === 8 ? parseInt(raw.slice(6, 8), 16) / 255 : 1;
        return { r, g, b, a };
    }

    const fn = value.match(/^(rgb|rgba|hsl|hsla)\((.*)\)$/s);
    if (fn) {
        const legacy = fn[2].includes(',');
        if (legacy && fn[2].includes('/')) return null;
        const parts = legacy ? fn[2].split(',').map(x => x.trim()) : fn[2].trim().split(/\s*\/\s*/);
        if (legacy ? ![3, 4].includes(parts.length) : parts.length > 2) return null;
        const channels = legacy ? parts.slice(0, 3) : parts[0].split(/\s+/);
        const alphaToken = legacy ? parts[3] : parts[1];
        if (channels.length !== 3) return null;
        const component = token => {
            if (token === 'none' && !legacy) return { n: 0, unit: '' };
            const match = String(token).match(/^([+-]?(?:\d*\.\d+|\d+)(?:e[+-]?\d+)?)(%|deg|grad|rad|turn)?$/);
            if (!match || !Number.isFinite(Number(match[1]))) return null;
            return { n: Number(match[1]), unit: match[2] || '' };
        };
        const c = channels.map(component), alpha = component(alphaToken ?? '1');
        if (c.some(x => !x) || !alpha || !['', '%'].includes(alpha.unit)) return null;
        const a = clamp(alpha.n / (alpha.unit === '%' ? 100 : 1), 0, 1);
        if (fn[1].startsWith('rgb')) {
            if (c.some(x => !['', '%'].includes(x.unit)) || (legacy && new Set(c.map(x => x.unit)).size > 1)) return null;
            const [r, g, b] = c.map(x => clamp(x.n * (x.unit === '%' ? 255 / 100 : 1), 0, 255));
            return { r, g, b, a };
        }
        const angleScale = { '': 1, deg: 1, grad: 0.9, rad: 180 / Math.PI, turn: 360 };
        if (!Object.hasOwn(angleScale, c[0].unit) || c.slice(1).some(x => !['', '%'].includes(x.unit))
            || (legacy && c.slice(1).some(x => x.unit !== '%'))) return null;
        const [r, g, b] = hslToRgb(c[0].n * angleScale[c[0].unit], c[1].n / 100, c[2].n / 100);
        return { r, g, b, a };
    }

    if (Object.hasOwn(NAMED_PALETTE_COLORS, value)) return parseCssColorToken(NAMED_PALETTE_COLORS[value]);
    return null;
}

function paletteCssText(html) {
    const source = String(html || '').replace(/<!--[\s\S]*?-->/g, '');
    const tags = source.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
        .match(/<[a-z][\w:-]*(?:[^>"']|"[^"]*"|'[^']*')*>/gi) || [];
    const blocks = [
        ...[...source.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi)].map(match => match[1]),
        ...tags.flatMap(tag => [...tag.matchAll(/\s([-\w:]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/gi)]
            .filter(match => match[1].toLowerCase() === 'style')
            .map(match => match[2] ?? match[3] ?? match[4])),
    ];
    // Keep declaration boundaries for the first inline variable, and never
    // treat comments, content strings or visible prose as painted colours.
    return blocks.map(block => `{${block}}`).join('\n')
        .replace(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\/\*[\s\S]*?\*\//g, token => token.startsWith('/*') ? '' : '__rm_css_string__');
}

function cssFunctionEnd(value, opening) {
    let depth = 1;
    for (let i = opening + 1; i < value.length; i++) {
        if (value[i] === '(') depth++;
        else if (value[i] === ')' && --depth === 0) return i + 1;
    }
    return -1;
}

function extractCssColors(value, depth = 0) {
    if (depth >= 32) return [];
    const input = String(value || '').toLowerCase()
        .replace(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\/\*[\s\S]*?\*\//g, token => token.startsWith('/*') ? '' : '__rm_css_string__');
    const colors = [], re = /#[\w-]+|[-a-z_][\w-]*/g;
    let match;
    while ((match = re.exec(input))) {
        if (match.index > 0 && /[\w-]/.test(input[match.index - 1])) continue;
        let token = match[0];
        if (input[re.lastIndex] === '(') {
            const end = cssFunctionEnd(input, re.lastIndex);
            if (end < 0) break;
            if (/^(?:repeating-)?(?:linear|radial|conic)-gradient$/.test(token)) {
                colors.push(...extractCssColors(input.slice(re.lastIndex + 1, end - 1), depth + 1));
            } else {
                // Unknown functions (e.g. color-mix, light-dark and URLs) are
                // not a bag of equally weighted colour words or fallback ink.
                const color = parseCssColorToken(input.slice(match.index, end));
                if (color && color.a >= 0.08) colors.push(color);
            }
            re.lastIndex = end;
        } else {
            const color = parseCssColorToken(token);
            if (color && color.a >= 0.08) colors.push(color);
        }
    }
    return colors;
}



function mainBackgroundSamples(backgroundColor, backgroundImage, resolve = value => value) {
    // An image/gradient covers the base paint. Do not record an obscured base
    // as the main colour; unreadable images remain unknown.
    const image = String(backgroundImage || '').trim();
    return extractCssColors(resolve(image && !/^(?:none|initial|unset|revert(?:-layer)?)$/i.test(image)
        ? image : backgroundColor) || '');
}

function withMainPaletteColors(fingerprint, colors) {
    if (!fingerprint) return null;
    // Persist observed carrier colours, never an averaged/invented swatch.
    // Translucent-only backgrounds need compositing evidence; leave unknown.
    const mainColors = [...new Set((colors || []).filter(color => color.a === 1
        && [color.r, color.g, color.b].every(Number.isFinite)).map(color => '#'
        + [color.r, color.g, color.b].map(value => Math.round(clamp(value, 0, 255))
            .toString(16).padStart(2, '0')).join('').toUpperCase()))];
    return { ...fingerprint, mainColors };
}

function paletteContentRoots(toto) {
    if (!toto?.querySelector) return [];
    const details = toto.tagName === 'DETAILS' ? toto
        : [...(toto.children || [])].find(child => child?.tagName === 'DETAILS') || toto.querySelector('details');
    const parent = details || toto;
    const roots = [...(parent.children || [])].filter(node =>
        !['SUMMARY', 'STYLE', 'SCRIPT', 'TEMPLATE', 'LINK', 'META', 'INPUT', 'BUTTON', 'LABEL', 'SELECT', 'TEXTAREA', 'RM-THINK', 'RM-TICKET'].includes(node.tagName)
        && !node.hidden && !node.hasAttribute?.('data-rabbit-mirror-tool-entry-host'));
    return roots.length ? roots : [parent];
}

function findRenderedPaletteRoot(toto) {
    if (!toto?.querySelector) return toto || null;
    // A hidden radio or short introductory label is not the scene's carrier.
    // This runs only inside the existing observation, without mounting or polling.
    return paletteContentRoots(toto).map(node => ({ node, area: elementArea(node) }))
        .sort((a, b) => b.area - a.area)[0]?.node || toto;
}

function elementArea(element) {
    try {
        const rect = element?.getBoundingClientRect?.();
        if (!rect) return 0;
        return Math.max(0, Number(rect.width) || 0) * Math.max(0, Number(rect.height) || 0);
    } catch {
        return 0;
    }
}

function renderedPaletteFingerprint(toto) {
    const root = findRenderedPaletteRoot(toto);
    if (!root?.querySelectorAll) return null;
    const view = root.ownerDocument?.defaultView || globalThis;
    const getStyle = view?.getComputedStyle?.bind(view) || globalThis.getComputedStyle?.bind(globalThis);
    if (typeof getStyle !== 'function') return null;

    const rootArea = elementArea(root);
    if (!rootArea) return null; // Detached/closed faces have no measured palette; use the source fallback.
    const candidates = [root, ...root.querySelectorAll('div,section,article,main,aside,label,li,figure,svg')]
        .map((element, index) => ({ element, index, area: elementArea(element) }))
        .filter(item => item.index === 0 || item.area >= Math.max(64, rootArea * 0.015))
        .sort((a, b) => b.area - a.area)
        .slice(0, 28);

    const samples = [];
    let mainBackgroundFound = false;
    let mainColors = null;
    for (const item of candidates) {
        let style;
        try {
            style = getStyle(item.element);
        } catch {
            continue;
        }
        if (!style || style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || 1) < 0.05) continue;
        const colors = [
            ...extractCssColors(style.backgroundColor),
            ...extractCssColors(style.backgroundImage),
        ];
        if (!colors.length) continue;
        if (!mainColors) mainColors = mainBackgroundSamples(style.backgroundColor, style.backgroundImage);
        const isRoot = item.element === root;
        if (isRoot) mainBackgroundFound = true;
        const area = item.area || rootArea * 0.08;
        const baseWeight = isRoot ? rootArea * 2.2 : Math.min(area, rootArea * 0.48);
        const colorWeight = baseWeight / colors.length;
        colors.forEach(color => samples.push({ color, weight: colorWeight }));
    }
    return withMainPaletteColors(classifyPaletteSamples(samples, 'rendered', mainBackgroundFound), mainColors);
}

// Raw independent results are scanned before mounting, so computed styles are
// unavailable. Resolve only locally unambiguous custom properties used by a
// background. Unused tokens are not colour evidence; conflicting scopes stay
// unknown until a rendered scan can observe the actual cascade.
function rawPaletteVariableResolver(html) {
    const css = paletteCssText(html);
    const definitions = new Map();
    for (const match of css.matchAll(/(?:^|[;{])\s*(--[\w-]+)\s*:\s*([^;}]+)/g)) {
        const value = match[2].replace(/\s*!important\s*$/i, '').trim();
        if (!definitions.has(match[1])) definitions.set(match[1], value);
        else if (definitions.get(match[1]) !== value) definitions.set(match[1], null);
    }
    // A cycle invalidates its variables even when its edge is in an unused
    // fallback. This remains a conservative local scan, not a cascade engine.
    const cyclic = new Set(), visited = new Set(), visiting = [];
    function visit(name) {
        const at = visiting.indexOf(name);
        if (at >= 0) { visiting.slice(at).forEach(key => cyclic.add(key)); return; }
        if (visited.has(name) || visiting.length >= 32 || typeof definitions.get(name) !== 'string') return;
        visiting.push(name);
        for (const match of definitions.get(name).matchAll(/var\(\s*(--[\w-]+)/gi)) visit(match[1]);
        visiting.pop(); visited.add(name);
    }
    for (const name of definitions.keys()) visit(name);
    function resolve(value, trail = new Set()) {
        let output = '', offset = 0;
        const re = /var\(/gi;
        let match;
        while ((match = re.exec(value))) {
            output += value.slice(offset, match.index);
            let depth = 1, end = re.lastIndex, comma = -1;
            for (; end < value.length && depth; end++) {
                if (value[end] === '(') depth++;
                else if (value[end] === ')') depth--;
                else if (value[end] === ',' && depth === 1 && comma < 0) comma = end;
            }
            if (depth) return null;
            const name = value.slice(re.lastIndex, comma < 0 ? end - 1 : comma).trim();
            if (!/^--[\w-]+$/.test(name)) return null;
            if (trail.has(name) || trail.size >= 32) return undefined;
            // undefined means unknown scope/cascade, not missing/invalid. A
            // fallback cannot resolve conflicting local definitions.
            if (definitions.has(name) && definitions.get(name) === null) return undefined;
            const raw = definitions.get(name);
            let resolved;
            if (raw === undefined || cyclic.has(name) || /^initial$/i.test(raw)) resolved = null;
            else if (/^(?:inherit|unset|revert|revert-layer)$/i.test(raw)) resolved = undefined;
            else resolved = resolve(raw, new Set([...trail, name]));
            if (resolved === null && comma >= 0) resolved = resolve(value.slice(comma + 1, end - 1), trail);
            if (resolved == null) return resolved;
            output += resolved;
            offset = end;
            re.lastIndex = end;
        }
        return output + value.slice(offset);
    }
    return resolve;
}

// Inspect only local, top-level rules. Conditional/layer rules are left for the
// rendered observer; keyframes and pseudo-elements do not paint the carrier.
function paletteSourceRules(root) {
    const rules = [];
    for (const element of root.querySelectorAll('style')) {
        const css = String(element.textContent || '').replace(/\/\*[\s\S]*?\*\//g, '');
        let start = 0, opening = -1, depth = 0, quote = '';
        for (let i = 0; i < css.length; i++) {
            const ch = css[i];
            if (quote) { if (ch === '\\') i++; else if (ch === quote) quote = ''; continue; }
            if (ch === '"' || ch === "'") { quote = ch; continue; }
            if (ch === '{') { if (depth++ === 0) opening = i; }
            else if (ch === '}' && depth && --depth === 0) {
                const selector = css.slice(start, opening).trim();
                if (selector && !selector.startsWith('@')) rules.push({ selector, declarations: paletteSourceDeclarations(css.slice(opening + 1, i)) });
                start = i + 1;
            } else if (!depth && ch === ';') start = i + 1;
        }
    }
    return rules;
}

function paletteSourceDeclarations(text) {
    const css = String(text || '').replace(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\/\*[\s\S]*?\*\//g,
        token => token.startsWith('/*') ? '' : '__rm_css_string__');
    return [...css.matchAll(/(?:^|;)\s*(background(?:-color|-image)?|(?:-webkit-)?backdrop-filter|display|visibility|opacity)\s*:\s*([^;{}]+)/gi)]
        .map(match => ({ property: match[1].toLowerCase(), value: match[2].replace(/\s*!important\s*$/i, '').trim(),
            important: /!important\s*$/i.test(match[2]) }));
}

function paletteSelectorWeight(selector) {
    const simple = selector.replace(/\[[^\]]*\]/g, '.attribute');
    return [(simple.match(/#[\w-]+/g) || []).length,
        (simple.match(/\.[\w-]+|:[\w-]+/g) || []).length,
        (simple.match(/(?:^|[\s>+~])[a-z][\w-]*/gi) || []).length];
}

function paletteBackgroundParts(value) {
    const images = [], colors = [];
    const functions = /[-a-z][\w-]*\(/gi;
    let offset = 0, match;
    while ((match = functions.exec(value))) {
        const end = cssFunctionEnd(value, functions.lastIndex - 1);
        if (end < 0) return { color: '', image: '' };
        colors.push(value.slice(offset, match.index));
        const token = value.slice(match.index, end);
        (/^(?:rgba?|hsla?)\(/i.test(token) ? colors : images).push(token);
        offset = end;
        functions.lastIndex = end;
    }
    colors.push(value.slice(offset));
    return { color: colors.join(' '), image: images.join(' ') };
}

function paletteSourceProperties(html, root) {
    const rules = paletteSourceRules(root), resolve = rawPaletteVariableResolver(html), cache = new WeakMap();
    const properties = node => {
        if (cache.has(node)) return cache.get(node);
        const winners = new Map();
        const add = (declarations, specificity) => {
            for (const declaration of declarations) {
                const rank = [Number(declaration.important), ...specificity];
                const names = declaration.property === 'background' ? ['background-color', 'background-image'] : [declaration.property];
                const value = /var\(/i.test(declaration.value) ? resolve(declaration.value) || '' : declaration.value;
                const background = declaration.property === 'background' ? paletteBackgroundParts(value) : null;
                for (const name of names) {
                    const prior = winners.get(name);
                    const different = prior ? rank.findIndex((n, i) => n !== prior.rank[i]) : -1;
                    if (!prior || different < 0 || rank[different] > prior.rank[different]) winners.set(name, {
                        value: background ? background[name === 'background-color' ? 'color' : 'image'] : value, rank });
                }
            }
        };
        for (const rule of rules) {
            for (const selector of rule.selector.split(',')) {
                // Avoid inventing specificity for functional selector lists.
                if (/::|:(?:is|where|not|has)\(/i.test(selector)) continue;
                try { if (node.matches(selector.trim())) add(rule.declarations, [0, ...paletteSelectorWeight(selector)]); } catch {}
            }
        }
        add(paletteSourceDeclarations(node.getAttribute?.('style')), [1, 0, 0, 0]);
        const values = Object.fromEntries([...winners].map(([key, item]) => [key, item.value]));
        cache.set(node, values);
        return values;
    };
    return properties;
}

function sourcePaletteFingerprint(html, root, sourceProperties = null) {
    if (!root?.querySelectorAll) return undefined;
    const properties = sourceProperties || paletteSourceProperties(html, root), resolve = rawPaletteVariableResolver(html);
    const visible = node => {
        for (let current = node; current && root.contains(current); current = current.parentElement) {
            if (current.hidden || current.matches('summary,rm-think,rm-ticket,[data-rabbit-mirror-tool-entry-host]')) return false;
            const p = properties(current);
            if (p.display === 'none' || p.visibility === 'hidden' || (p.opacity !== undefined && Number(p.opacity) < 0.05)) return false;
        }
        return true;
    };
    const roots = paletteContentRoots(root);
    const nodes = [...new Set(roots.flatMap(node => [node, ...node.querySelectorAll('div,section,article,main,aside,figure,table,svg')]))].slice(0, 180);
    // Prefer structural content over short labels; an unpainted wrapper lets
    // its real child surface supply the colour. Outer details is a last resort.
    const carriers = nodes.filter(node => /^(DIV|SECTION|ARTICLE|MAIN|ASIDE|FIGURE|TABLE|SVG)$/i.test(node.tagName));
    carriers.push(...roots.filter(node => !carriers.includes(node)), root.querySelector('details'), root);
    const painted = [];
    let mainColors = null;
    for (const node of [...new Set(carriers)].filter(Boolean)) {
        if (!visible(node)) continue;
        const p = properties(node);
        const colors = [...new Set([p['background-color'], p['background-image']].filter(Boolean))]
            .flatMap(value => extractCssColors(/var\(/i.test(value) ? resolve(value) || '' : value));
        if (colors.length) {
            if (!mainColors) mainColors = mainBackgroundSamples(p['background-color'], p['background-image'],
                value => /var\(/i.test(value) ? resolve(value) || '' : value);
            painted.push(colors);
        }
        if (painted.length >= 24) break;
    }
    if (!painted.length) return null;
    const samples = painted.flatMap((colors, index) => colors.map(color => ({ color,
        weight: (index === 0 ? 8 : 2 / Math.max(1, painted.length - 1)) / colors.length })));
    return withMainPaletteColors(classifyPaletteSamples(samples, 'raw', true), mainColors);
}

function rawPaletteFingerprint(html, sourceRoot = null, sourceProperties = null) {
    const matched = sourcePaletteFingerprint(html, sourceRoot || parseToto(html), sourceProperties);
    if (matched !== undefined) return matched;
    // Non-DOM callers retain the legacy observation path. Browsers always use
    // actual matched carriers above; unknown CSS remains unknown, not a colour.
    const values = extractBackgroundValues(paletteCssText(html));
    const resolve = rawPaletteVariableResolver(html);
    const samples = [];
    values.slice(0, 24).forEach((value, index) => {
        const colors = extractCssColors(/var\(/i.test(value) ? resolve(value) || '' : value);
        const baseWeight = index === 0 ? 5 : (index < 5 ? 1.5 : 0.7);
        colors.forEach(color => samples.push({ color, weight: baseWeight / Math.max(1, colors.length) }));
    });
    return classifyPaletteSamples(samples, 'raw', values.length > 0);
}

function detectPaletteFingerprint(html, renderedToto = null, sourceRoot = null, sourceProperties = null) {
    return renderedPaletteFingerprint(renderedToto) || rawPaletteFingerprint(html, sourceRoot, sourceProperties);
}

// Material history must describe the carrier, not every decorative alpha stop,
// badge, hidden panel or unused selector in the work. Reuse the palette's local
// cascade reader; this runs during the existing scan, with no DOM writes/timers.
function surfaceCarrierEvidence(html, root, sourceProperties = null) {
    if (!root?.querySelectorAll) {
        // Source-only callers cannot match stylesheet selectors. Stay local to
        // the first structural carrier instead of promoting global CSS to fact.
        const tags = [...String(html).replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
            .matchAll(/<(div|section|article|main|aside|figure|table)\b([^>]*)>([^<]*)/gi)];
        const chosen = tags.find(match => /\sstyle\s*=\s*(["'])[^"']*(?:background|backdrop-filter)\s*:/i.test(match[2])) || tags[0];
        const css = chosen?.[2].match(/\sstyle\s*=\s*(["'])([\s\S]*?)\1/i)?.[2] || '';
        const props = {};
        for (const { property, value } of paletteSourceDeclarations(css)) {
            if (property === 'background') {
                const parts = paletteBackgroundParts(value);
                props['background-color'] = parts.color; props['background-image'] = parts.image;
            } else props[property] = value;
        }
        return { props, text: chosen?.[3] || '' };
    }
    const properties = sourceProperties || paletteSourceProperties(html, root);
    const visible = node => {
        for (let current = node; current && root.contains(current); current = current.parentElement) {
            if (current.hidden || current.matches('summary,rm-think,rm-ticket,[data-rabbit-mirror-tool-entry-host]')) return false;
            const p = properties(current);
            if (p.display === 'none' || p.visibility === 'hidden' || (p.opacity !== undefined && Number(p.opacity) < 0.05)) return false;
        }
        return true;
    };
    const painted = p => extractCssColors(p['background-color']).length
        || extractCssColors(p['background-image']).length || /blur\(/i.test(p['backdrop-filter'] || p['-webkit-backdrop-filter'] || '');
    const roots = paletteContentRoots(root);
    const nodes = [...new Set(roots.flatMap(node => [node, ...node.querySelectorAll('div,section,article,main,aside,figure,table,svg')]))].slice(0, 180);
    const carriers = nodes.filter(node => /^(DIV|SECTION|ARTICLE|MAIN|ASIDE|FIGURE|TABLE|SVG)$/i.test(node.tagName));
    carriers.push(...roots.filter(node => !carriers.includes(node)), root.querySelector('details'), root);
    const candidates = [...new Set(carriers)].filter(node => node && visible(node));
    const carrier = candidates.find(node => painted(properties(node))) || candidates[0];
    if (!carrier) return { props: {}, text: '' };
    // Read carrier-owned prose, not separately painted objects or controls.
    let textNodes = 0;
    const ownText = (node, depth = 0) => {
        if (depth > 4 || textNodes >= 180) return '';
        return [...(node.childNodes || [])].map(child => {
            if (textNodes++ >= 180) return '';
            if (child.nodeType === 3) return child.textContent || '';
            if (child.nodeType !== 1 || !visible(child)
                || child.matches('style,script,template,button,label,input,select,textarea')
                || painted(properties(child))) return '';
            return ownText(child, depth + 1);
        }).join(' ');
    };
    return { props: properties(carrier), text: ownText(carrier) };
}

function detectSurfaceFamily(html, plain = '', sourceRoot = null, sourceProperties = null) {
    const source = String(html || '');
    // CSS property names, classes and internal selection/planning tags are not
    // evidence of a paper material (letter-spacing, tool-menu, rm-ticket).
    const content = source.replace(/<!--[\s\S]*?-->/g, '')
        .replace(/<(rm-think|rm-ticket)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, '');
    const { props, text: carrierText } = surfaceCarrierEvidence(content, sourceRoot || parseToto(content), sourceProperties);
    const text = carrierText.toLowerCase();
    const backgrounds = [props['background-color'], props['background-image']].filter(Boolean).join('\n');
    const base = detectBaseColor(`background:${backgrounds};`);
    const color = extractCssColors(props['background-color'])[0];
    const imageColors = extractCssColors(props['background-image']);
    const opaqueImage = imageColors.length > 0 && imageColors.every(item => item.a === 1);
    const translucentCarrier = !opaqueImage && (color ? color.a < 1
        : /blur\(/i.test(props['backdrop-filter'] || props['-webkit-backdrop-filter'] || ''));
    if (/纸|信笺|便签|票据|菜单|说明书|羊皮纸|报纸|签文|\b(?:paper|newspaper|tickets?|menus?|manuals?|letters?)\b/i.test(text)) return 'surface: paper_or_document_surface';
    if (/玻璃|磨砂|透明|\b(?:glass|frosted|translucent)\b/i.test(text)
        || translucentCarrier) return 'surface: glass_or_translucent_surface';
    if (/金属|铁|铜|钢|铝|\b(?:metal|chrome|silver|bronze)\b/i.test(text)) return 'surface: metallic_or_hard_surface';
    if (/木|布|织物|陶瓷|皮革|石|\b(?:wood|fabric|ceramic|leather|stone)\b/i.test(text)) return 'surface: physical_material_surface';
    if (/radial-gradient|conic-gradient|linear-gradient|repeating-gradient/i.test(backgrounds)) return 'surface: gradient_or_light_surface';
    if (/暗色|黑|夜|\b(?:neon|glow|console|screen)\b|霓虹|发光|屏幕|控制台|监控/i.test(text) || base.includes('暗色')) return 'surface: digital_dark_surface';
    if (base.includes('浅色')) return 'surface: light_plain_surface';
    return 'surface: mixed_or_unspecified_surface';
}

function detectContourFamily(html, dom) {
    const text = String(html || '');
    if (/clip-path\s*:|polygon\(|path\(|<svg\b|mask\s*:/i.test(text)) return 'contour: cutout_or_irregular_shape';
    if (/border-radius\s*:\s*50%|border-radius\s*:\s*999/i.test(text)) return 'contour: circular_or_pill_shape';
    if (count(/border-radius\s*:/gi, text) >= 4 && count(/<div\b/gi, text) >= 8) return 'contour: rounded_panel_cluster';
    if ((dom?.maxSimilarRun || 0) >= 2) return 'contour: repeated_rectangular_blocks';
    if (/position\s*:\s*absolute|transform\s*:/i.test(text)) return 'contour: layered_freeform_overlay';
    return 'contour: simple_or_mixed_outline';
}

function detectSpaceFamily(html, spatialSignalCount) {
    // An SVG path is a shape, not a depth layer. Count positioned HTML layers
    // separately from the broader drawing signals used by the quality scanner.
    const text = String(html || '').replace(/<svg\b[^>]*>[\s\S]*?<\/svg>/gi, '');
    const positionedLayers = count(/position\s*:\s*absolute/gi, text);
    const depthLayers = count(/z-index\s*:/gi, text);
    if (positionedLayers >= 3 || (positionedLayers >= 2 && depthLayers >= 2)) return 'space: layered_depth_or_spatial_scene';
    if (/display\s*:\s*grid|grid-template/i.test(text)) return 'space: grid_plane';
    if (/display\s*:\s*flex/i.test(text)) return 'space: flex_plane';
    if (positionedLayers > 0) return 'space: shallow_layered_surface';
    return 'space: flat_content_surface';
}

function detectLayout(html, dom, spatialSignalCount) {
    const text = String(html || '');
    const grid = /display\s*:\s*grid|grid-template|grid-area/i.test(text);
    const flexColumn = /display\s*:\s*flex;[^"']*flex-direction\s*:\s*column/i.test(text);
    const flexRow = /display\s*:\s*flex/i.test(text) && !flexColumn;
    const absolute = /position\s*:\s*absolute/i.test(text);
    const summary = /<summary\b/i.test(text);
    if (absolute && spatialSignalCount >= 4) return '空间锚点/浮层式布局';
    if (grid) return '网格分区布局';
    if (summary && (dom?.maxSimilarRun || 0) >= 2) return '顶部折叠标题栏 + 多区块堆叠布局';
    if (flexColumn || count(/<div\b/gi, text) >= 10) return '纵向分组堆叠布局';
    if (flexRow) return '横向并列/分栏布局';
    return '自由排版布局';
}

function detectReadingPath(html, spatialSignalCount) {
    const text = String(html || '');
    if (/timeline|left\s*:\s*\d+%|top\s*:\s*\d+%|position\s*:\s*absolute/i.test(text) && spatialSignalCount >= 3) return '按视觉锚点跳读';
    if (/display\s*:\s*grid|grid-template/i.test(text)) return '按网格分区扫描';
    if (/flex-direction\s*:\s*column|<ul\b|<li\b/i.test(text)) return '自上而下分段扫描';
    return '中心内容向外扩散阅读';
}

function detectInfoUnit(html, dom, repeated) {
    const text = String(html || '');
    if (/<table\b|display\s*:\s*table/i.test(text)) return '表格/清单单元';
    if (/position\s*:\s*absolute/i.test(text) && count(/<span\b/gi, text) >= 5) return '浮动碎片/弹幕单元';
    if ((dom?.maxSimilarRun || 0) >= 2 || (repeated?.maxRepeat || 0) >= 3) return '矩形信息块/卡片化条目';
    if (/<li\b/i.test(text)) return '列表条目单元';
    return '段落与装饰节点混合单元';
}

function detectMood(html, plain) {
    const text = `${html || ''}\n${plain || ''}`.toLowerCase();
    const hasArchive = /档案|记录|备忘|日志|检索|搜索|警告|通报|报告|情报|archive|log|memo|record|warning/i.test(text);
    const hasControl = /监控|后台|控制台|直播|弹幕|播放|录像|screen|console|control|live|video/i.test(text);
    const hasPaper = /报纸|新闻|信笺|便签|票据|菜单|说明书|纸|paper|newspaper|menu|ticket|manual/i.test(text);
    const hasNeon = /neon|霓虹|glow|发光|box-shadow|filter\s*:\s*drop-shadow|高饱和/i.test(text);
    if (hasArchive && hasControl) return '档案/后台/监控混合气质';
    if (hasArchive) return '档案/记录/警告气质';
    if (hasControl) return '监控/直播/控制台气质';
    if (hasPaper) return '纸面/印刷物气质';
    if (hasNeon) return '霓虹/发光/电子气质';
    if (/wood|木|铜|金属|玻璃|磨砂|羊皮纸|陶瓷|织物|布/i.test(text)) return '明确材质化媒介气质';
    return '综合情绪化 UI 气质';
}

function buildVisualSkeleton(html, plain, metrics) {
    const composition = metrics.composition;
    return [
        ...Object.entries(composition).map(([key, value]) => `${key}: ${value}`),
        `surface_family: ${detectSurfaceFamily(html, plain, metrics.root, metrics.sourceProperties)}`,
        `contrast_family: ${detectContrastFamily(html)}`,
        `contour_family: ${detectContourFamily(html, metrics.dom)}`,
        `reading_family: ${detectReadingPath(html, metrics.spatialSignalCount)}`,
        `unit_family: ${detectInfoUnit(html, metrics.dom, metrics.repeated)}`,
        `space_family: ${detectSpaceFamily(html, metrics.spatialSignalCount)}`,
        `interaction_family: ${metrics.interactionFamily?.label || '未识别交互家族'}`,
        `mood: ${detectMood(html, plain)}`,
    ].join('；');
}

function detectGlobalCssRisk(html) {
    const styles = [...String(html || '').matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi)].map(m => m[1]).join('\n');
    if (!styles) return false;
    return /(^|[}\s,])(html|body|:root|\*|\.mes|\.message|\.chat|\.content|\.ts-message-container|#chat|#send_form)\s*[{,]/i.test(styles);
}


function detectInnerDetailsUsed(root, html = '') {
    if (root?.querySelectorAll) {
        const outerDetails = root.matches?.('details')
            ? root
            : root.querySelector?.(':scope > details') || root.querySelector?.('details');
        return [...root.querySelectorAll('details')].some(details => details !== outerDetails);
    }
    return (String(html || '').match(/<details\b/gi) || []).length >= 2;
}

export function scanRabbitMirrorHtml(messageHtml, renderedToto = null) {
    const match = activeRoleColorHtml(messageHtml).match(TOTO_RE);
    if (!match) return { signature: '', skeleton: '', riskFlags: [], paletteFingerprint: null, interactionFamily: interactionFamilyRecord() };
    const html = match[0];
    const plain = stripTags(html);
    const tagCount = count(/<\w+\b/g, html);
    const divCount = count(/<div\b/gi, html);
    const repeated = extractStyleFingerprints(html);
    const dom = analyzeDomStructure(html);
    const root = parseToto(html);
    const textDensity = plain.length > 900 && tagCount < 65 ? '文本密度过高' : plain.length > 520 ? '文本密度中高' : '文本密度适中';

    const spatialSignalCount = count(/position\s*:\s*absolute|grid-area\s*:|grid-template|display\s*:\s*grid|transform\s*:|clip-path\s*:|mask\s*:|z-index\s*:|<svg\b|<path\b|radial-gradient|conic-gradient|repeating-gradient|aspect-ratio/gi, html);
    const effects = [];
    if (/animation\s*:|@keyframes|<marquee\b|<animate\b/i.test(html)) effects.push('动态效果有');
    else effects.push('动态效果无');
    if (/linear-gradient|radial-gradient|conic-gradient|box-shadow|filter\s*:|backdrop-filter|mix-blend-mode|mask|clip-path/i.test(html)) effects.push('高级CSS有');
    else effects.push('高级CSS弱');
    if (spatialSignalCount >= 4) effects.push('空间构造信号强');
    else if (spatialSignalCount >= 2) effects.push('空间构造信号中');
    else effects.push('空间构造信号弱');

    const structural = [];
    if (dom.maxSimilarRun >= 3) structural.push('连续同构兄弟区块明显/卡片化倾向高');
    else if (dom.maxSimilarRun >= 2) structural.push('存在连续同构兄弟区块');
    if (repeated.maxRepeat >= 4 || repeated.repeated >= 2) structural.push('存在重复同构内容块/卡片化倾向高');
    else if (repeated.maxRepeat >= 3) structural.push('存在重复同构内容块');
    if (/display\s*:\s*flex;[^"']*flex-direction\s*:\s*column/i.test(html) && divCount >= 10) structural.push('纵向分组结构明显');
    if (spatialSignalCount < 2 && plain.length > 520 && (dom.maxSimilarRun >= 2 || repeated.maxRepeat >= 3 || divCount >= 10)) structural.push('主要依赖纵向文本流/媒介轮廓偏弱');
    if (count(/border-radius\s*:/gi, html) >= 4 && count(/padding\s*:/gi, html) >= 6) structural.push('圆角容器密集');
    if (count(/<!--/g, html) > 0) structural.push('HTML注释残留');
    if (/<pre\b|<code\b|```/i.test(html)) structural.push('代码块风险');
    if (detectGlobalCssRisk(html)) structural.push('全局CSS污染风险');
    const composition = detectCompositionFingerprint(root);
    const riskFlags = detectRiskFlags({ root, html, plain, dom, repeated, spatialSignalCount, composition });
    if (detectInnerDetailsUsed(root, html)) riskFlags.unshift('inner_details_used');
    if (riskFlags.includes('same_block_stack')) structural.push('同构信息块堆叠风险');
    if (riskFlags.includes('same_grid_card_risk')) structural.push('同构网格信息块风险');
    if (riskFlags.includes('catalog_page_risk')) structural.push('图鉴/目录式承载风险');
    if (riskFlags.includes('flat_vertical_flow')) structural.push('单向纵向阅读路径风险');
    if (riskFlags.includes('repeated_unit_shape')) structural.push('重复内容单元形状风险');
    if (riskFlags.includes('info_page_degrade')) structural.push('信息页降级风险');
    if (riskFlags.includes('weak_media_body')) structural.push('媒介本体偏弱风险');
    if (riskFlags.includes('weak_spatial_complexity')) structural.push('空间复杂度偏弱风险');
    if (riskFlags.includes('missing_interaction')) structural.push('缺少有效内部交互');
    if (riskFlags.includes('fake_interaction')) structural.push('伪交互/仅悬停装饰风险');
    if (riskFlags.includes('visual_promise_unfulfilled')) structural.push('视觉承诺未兑现风险');
    if (riskFlags.includes('missing_visual_program')) structural.push('有效视觉程序缺失／浏览器默认样式风险');
    structural.push(...dom.summaryFlags);

    const mediaStrength = (/clip-path|mask|<svg\b|<path\b|position\s*:\s*absolute|transform\s*:|border-radius\s*:\s*50%|aspect-ratio|radial-gradient|conic-gradient/i.test(html) && tagCount >= 35)
        ? '媒介轮廓中强'
        : (tagCount >= 40 ? '媒介轮廓中等' : '媒介轮廓弱');
    const summary = [mediaStrength, ...structural.slice(0, 6), textDensity, ...effects]
        .filter(Boolean)
        .join('；');
    const interactionFamily = detectInteractionFamily(root, html);
    interactionFamily.observedRecipeIds = observedRecipeIds(root, interactionFamily);
    const sourceProperties = root ? paletteSourceProperties(html, root) : null;
    const skeleton = buildVisualSkeleton(html, plain, { root, sourceProperties, dom, repeated, spatialSignalCount, interactionFamily, composition });
    const paletteFingerprint = detectPaletteFingerprint(html, renderedToto, root, sourceProperties);
    return { signature: summary.slice(0, 280), skeleton: skeleton.slice(0, VISUAL_SKELETON_MAX_CHARS), riskFlags, paletteFingerprint, interactionFamily };
}

function normalizedText(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
}

function rawSummaryText(messageHtml) {
    const match = String(messageHtml || '').match(/<summary\b[^>]*>([\s\S]*?)<\/summary>/i);
    return match ? normalizedText(stripTags(match[1])) : '';
}

function renderedSummaryText(root) {
    const summary = root?.querySelector?.('summary');
    if (!summary) return '';
    const clone = summary.cloneNode(true);
    clone.querySelectorAll?.('button, [data-rabbit-mirror-maintenance-rabbit], [data-rabbit-mirror-feedback-cat], [data-rabbit-mirror-tool-entry-host]')
        ?.forEach?.(node => node.remove());
    return normalizedText(clone.textContent || '');
}

function isRenderedRabbitMirrorDetails(details) {
    if (!details?.matches?.('details')) return false;
    const title = renderedSummaryText(details);
    return /^【兔子镜[:：]/.test(title) || title.includes('兔子镜');
}

function findMirrorRootInScope(scope) {
    if (!scope?.querySelector) return null;
    const wrapped = scope.querySelector('toto[data-rabbit-mirror="true"], toto[data-rabbit-hole="true"]');
    if (wrapped) return wrapped;
    const details = [...scope.querySelectorAll('details')].filter(isRenderedRabbitMirrorDetails);
    return details[details.length - 1] || null;
}

function findRenderedToto(message, chat, messageHtml) {
    if (typeof document === 'undefined') return null;
    const messageIndex = Array.isArray(chat) ? chat.lastIndexOf(message) : -1;
    const scopes = [];
    if (messageIndex >= 0) {
        for (const selector of [
            `.mes[mesid="${messageIndex}"]`,
            `.mes[data-message-id="${messageIndex}"]`,
            `.mes[data-messageid="${messageIndex}"]`,
        ]) {
            try {
                const scope = document.querySelector(selector);
                if (scope) scopes.push(scope);
            } catch {
                // Ignore host selector differences.
            }
        }
    }
    for (const scope of scopes) {
        const found = findMirrorRootInScope(scope);
        if (found) return found;
    }

    const expectedSummary = rawSummaryText(messageHtml);
    const wrapped = [...document.querySelectorAll('toto[data-rabbit-mirror="true"], toto[data-rabbit-hole="true"]')];
    const orphanDetails = [...document.querySelectorAll('details')]
        .filter(isRenderedRabbitMirrorDetails)
        .filter(details => !details.closest('toto[data-rabbit-mirror="true"], toto[data-rabbit-hole="true"]'));
    const all = [...wrapped, ...orphanDetails];
    if (expectedSummary) {
        const matched = all.filter(root => renderedSummaryText(root) === expectedSummary);
        if (matched.length) return matched[matched.length - 1];
    }
    return all[all.length - 1] || null;
}

function exactMessageScopes(chat, messageIndex) {
    if (typeof document === 'undefined' || !Number.isInteger(messageIndex) || messageIndex < 0) return [];
    const scopes = [];
    const seen = new Set();
    for (const selector of [
        `.mes[mesid="${messageIndex}"]`,
        `.mes[data-message-id="${messageIndex}"]`,
        `.mes[data-messageid="${messageIndex}"]`,
    ]) {
        try {
            for (const scope of [...document.querySelectorAll(selector)].slice(0, 8)) {
                if (scope?.isConnected && !seen.has(scope)) { seen.add(scope); scopes.push(scope); }
            }
        } catch {}
    }
    return scopes;
}

function terminalFollowOwnerKey(chat, messageIndex) {
    return `${getCurrentChatKey(Array.isArray(chat) ? chat : [])}\u0000${Number(messageIndex)}`;
}

function followOwnerStillCurrent(set, chat) {
    const owner = set?.owner;
    const message = Array.isArray(chat) ? chat[owner?.messageIndex] : null;
    const swipeId = Number.isInteger(message?.swipe_id) ? message.swipe_id : -1;
    return !!owner && owner.chatKey === getCurrentChatKey(Array.isArray(chat) ? chat : [])
        && message === owner.message
        && swipeId === owner.swipeId
        && rabbitMirrorMultifaceSourceHash(message?.mes || '') === owner.sourceHash;
}

export function getRabbitMirrorFollowBatchFailure(chat, messageIndex) {
    const key = terminalFollowOwnerKey(chat, messageIndex);
    const entry = rejectedFollowBatches.get(key);
    if (!entry || !followOwnerStillCurrent(entry, chat)) return null;
    return { ...entry.failure };
}

function clearFollowBatchFailure(chat, messageIndex) {
    const key = terminalFollowOwnerKey(chat, messageIndex);
    const entry = rejectedFollowBatches.get(key);
    entry?.notice?.remove?.();
    rejectedFollowBatches.delete(key);
}

function followMultifaceRejection(code, terminalFace, message) {
    const error = new Error(String(message || '本批兔子镜未通过净化后检查。'));
    error.rabbitMirrorFollowRejection = true;
    error.code = String(code || 'multiface-sanitized-invalid');
    error.terminalFace = Number.isInteger(terminalFace) ? terminalFace : null;
    return error;
}

function rejectFollowBatch(set, chat, error) {
    if (!followOwnerStillCurrent(set, chat)) return false;
    const key = terminalFollowOwnerKey(chat, set.owner.messageIndex);
    clearFollowBatchFailure(chat, set.owner.messageIndex);
    const failure = {
        kind: 'follow-multiface-rejected',
        chatKey: set.owner.chatKey,
        messageIndex: Number(set.owner.messageIndex),
        swipeId: set.owner.swipeId,
        sourceHash: String(set.owner.sourceHash || ''),
        batchId: String(set.batchId || ''),
        operationId: String(set.identity?.operationId || ''),
        code: String(error.code || 'multiface-sanitized-invalid'),
        terminalFace: error.terminalFace,
        expectedFaceCount: set.faces.length,
        requestCount: 1,
        message: String(error.message || '本批兔子镜未通过净化后检查。'),
    };
    const entry = { owner: { ...set.owner }, failure, notice: null };
    // A rejection never mounts any partial prepared face or changes message.mes.
    // Only hide a whole rendered batch when its original/display titles prove
    // the exact source owner; absent or ambiguous host DOM is not borrowed.
    const scopes = exactMessageScopes(chat, set.owner.messageIndex);
    const proven = scopes.map(scope => ({ scope, matched: matchRenderedFollowFaces(scope, set, error.preparedFaces) }))
        .filter(item => item.matched);
    if (proven.length === 1) {
        const { matched } = proven[0];
        for (const item of matched) {
            clearSanitizedRabbitMirrorFaceProof(item.root);
            item.root.remove();
        }
    }
    const noticeScope = proven.length === 1 ? proven[0].scope : scopes.length === 1 ? scopes[0] : null;
    if (noticeScope) {
        const notice = document.createElement('div');
        notice.setAttribute('data-rabbit-mirror-follow-failure', 'true');
        notice.setAttribute('role', 'status');
        notice.textContent = `兔子镜本批生成失败${failure.terminalFace ? `（第 ${failure.terminalFace}/${failure.expectedFaceCount} 面）` : ''}：${failure.message} 本轮只发送了 1 次请求，不会自动重发。`;
        noticeScope.appendChild(notice);
        entry.notice = notice;
    }
    if (rejectedFollowBatches.size >= 32) rejectedFollowBatches.delete(rejectedFollowBatches.keys().next().value);
    rejectedFollowBatches.set(key, entry);
    releaseRabbitMirrorFollowBatch({ batchId: set.batchId, operationId: set.identity?.operationId });
    terminalFollowMessageIndexes.delete(key);
    try {
        globalThis.dispatchEvent?.(new CustomEvent(FOLLOW_MULTIFACE_REJECTED_EVENT, { detail: { ...failure } }));
    } catch {}
    return true;
}

const FOLLOW_TOTO_SELECTOR = 'toto[data-rabbit-mirror="true"]';

function directDetailsChild(root) {
    if (!root?.children) return null;
    const matches = [...root.children].filter(child => String(child?.tagName || '').toLowerCase() === 'details');
    return matches.length === 1 ? matches[0] : null;
}

function directSummaryChild(details) {
    if (!details?.children) return null;
    const matches = [...details.children].filter(child => String(child?.tagName || '').toLowerCase() === 'summary');
    return matches.length === 1 ? matches[0] : null;
}

function isUsableSanitizedDetails(details) {
    if (!details || !directSummaryChild(details)) return false;
    return [...(details.childNodes || [])].some(node => {
        if (node?.nodeType === 3) return normalizedText(node.textContent || '').length > 0;
        if (node?.nodeType !== 1) return false;
        return !new Set(['summary', 'style', 'script', 'template', 'link', 'meta']).has(String(node.tagName || '').toLowerCase());
    });
}

function topLevelFollowTotos(scope) {
    if (!scope?.querySelectorAll) return [];
    return [...scope.querySelectorAll(FOLLOW_TOTO_SELECTOR)].filter(root => {
        const ancestor = root.parentElement?.closest?.(FOLLOW_TOTO_SELECTOR);
        return !ancestor || !scope.contains(ancestor);
    });
}

function sourceFaceTitle(face) {
    if (typeof document === 'undefined') return normalizedText(stripTags(face?.summaryHtml || ''));
    const template = document.createElement('template');
    template.innerHTML = String(face?.html || '');
    const details = directDetailsChild(templateSingleFollowRoot(template));
    return details ? renderedSummaryText(details) : '';
}

const followPresentationFormatsById = new Map(PRESENTATION_FORMATS.map(item => [String(item.id), item]));
function followSelectedFormatDescriptors(metadata = {}) {
    const external = new Map((Array.isArray(metadata.formatDescriptors) ? metadata.formatDescriptors : []).slice(0, 8)
        .filter(item => item && typeof item.id === 'string' && item.id.startsWith('ext:')).map(item => [item.id, item]));
    return (Array.isArray(metadata.formatIds) ? metadata.formatIds : []).map(id => {
        const builtin = followPresentationFormatsById.get(String(id));
        if (builtin) return { id: String(id), title: String(builtin.title || ''), summary: String(builtin.summary || ''), tags: Array.isArray(builtin.tags) ? [...builtin.tags] : [] };
        const item = external.get(String(id));
        return { id: String(id), title: String(item?.title || '').slice(0, 160), summary: String(item?.summary || '').slice(0, 210), tags: Array.isArray(item?.tags) ? item.tags.filter(tag => typeof tag === 'string').slice(0, 4).map(tag => tag.slice(0, 64)) : [] };
    });
}

function matchRenderedFollowFaces(scope, set, preparedFaces = null) {
    const faces = Array.isArray(set?.faces) ? set.faces : [];
    const titles = faces.map(sourceFaceTitle);
    if (titles.some(title => !title) || new Set(titles).size !== titles.length) return null;
    const displayTitles = faces.map((face, index) => preparedFaces?.[index]?.expectedTitle || titles[index]);
    const candidates = topLevelFollowTotos(scope)
        .map(root => ({ root, details: directDetailsChild(root) }))
        .filter(item => item.details && scope.contains(item.root));
    if (candidates.length !== faces.length) return null;

    const matched = [];
    const used = new Set();
    for (let faceIndex = 0; faceIndex < faces.length; faceIndex += 1) {
        const matches = candidates.filter(item => !used.has(item.root)
            && [titles[faceIndex], displayTitles[faceIndex]].includes(renderedSummaryText(item.details)));
        if (matches.length !== 1) return null;
        used.add(matches[0].root);
        matched.push({ ...matches[0], sourceFace: faces[faceIndex], faceIndex });
    }

    const parent = matched[0]?.root?.parentElement;
    if (!parent || matched.some(item => item.root.parentElement !== parent)) return null;
    const positions = matched.map(item => [...parent.children].indexOf(item.root));
    if (positions.some(position => position < 0)) return null;
    if (positions.some((position, index) => index > 0 && position <= positions[index - 1])) return null;
    return matched;
}

function templateSingleFollowRoot(template) {
    const significant = [...(template?.content?.childNodes || [])].filter(node => {
        if (node?.nodeType === 1) return true;
        return node?.nodeType === 3 && normalizedText(node.textContent || '').length > 0;
    });
    if (significant.length !== 1 || significant[0]?.nodeType !== 1) return null;
    const root = significant[0];
    return root.matches?.(FOLLOW_TOTO_SELECTOR) ? root : null;
}

function loadFollowBatchSanitizer() {
    if (!followBatchSanitizerModulePromise) {
        followBatchSanitizerModulePromise = import('./outputSanitizer.js?rmv=1.62.93').catch(error => {
            followBatchSanitizerModulePromise = null;
            console.debug('[RabbitMirror] follow multiface sanitizer unavailable:', error);
            return null;
        });
    }
    return followBatchSanitizerModulePromise;
}

function verifyMountedFollowFaces(scope, prepared) {
    if (!scope || !Array.isArray(prepared) || prepared.length < 2 || prepared.length > 5) return false;
    const parent = prepared[0]?.newRoot?.parentElement;
    if (!parent || prepared.some(item => item.newRoot.parentElement !== parent || !scope.contains(item.newRoot))) return false;
    const positions = prepared.map(item => [...parent.children].indexOf(item.newRoot));
    if (positions.some(position => position < 0)) return false;
    if (positions.some((position, index) => index > 0 && position <= positions[index - 1])) return false;
    return prepared.every(item => {
        const details = directDetailsChild(item.newRoot);
        return details === item.newDetails
            && isUsableSanitizedDetails(details)
            && renderedSummaryText(details) === item.expectedTitle;
    });
}

function rollbackMountedFollowFaces(prepared) {
    for (let index = prepared.length - 1; index >= 0; index -= 1) {
        const item = prepared[index];
        clearSanitizedRabbitMirrorFaceProof(item.newRoot);
        if (item.newRoot?.parentNode === item.parent) {
            try { item.parent.replaceChild(item.oldRoot, item.newRoot); } catch {}
        }
        if(item.createdRoot&&item.oldRoot?.parentNode===item.parent) item.oldRoot.remove();
    }
}

function prepareFollowFaces(set, sanitizer) {
    if (!sanitizer?.sanitizeRabbitMirrorUntrustedTemplate
        || !sanitizer?.compactTotoBlock
        || !sanitizer?.isolateRabbitMirrorInteractionIds
        || !sanitizer?.refreshRabbitMirrorToolsInScope) return null;
    const prepared = [];
    for (let faceIndex = 0; faceIndex < set.faces.length; faceIndex += 1) {
        const sourceFace = set.faces[faceIndex];
        try {
        if (sourceFace.failure) throw followMultifaceRejection(sourceFace.failure.code, faceIndex + 1, '这一面不完整。');
        const template = document.createElement('template');
        template.innerHTML = String(sourceFace?.html || '');
        // This entry point handles newly generated source only, never trusted
        // prepared history. A model cannot declare its own runtime CSS scope.
        if (template.content.querySelector(`[data-rabbit-mirror-css-scope], [${MULTIFACE_FAILURE_ATTR}]`)) {
            throw followMultifaceRejection('multiface-untrusted-css-scope', faceIndex + 1,
                '生成内容携带了保留的样式隔离标记；本批结果不会保存。');
        }
        // Rebuild from the proven source, including the same per-mirror CSS and
        // keyframe isolation as independent output, before the common sanitizer.
        template.innerHTML = sanitizer.compactTotoBlock(bindRolePaletteCode(String(sourceFace?.html || ''), sourceFace.metadata));
        if (!sanitizer.sanitizeRabbitMirrorUntrustedTemplate(template)) {
            throw followMultifaceRejection('multiface-sanitizer-rejected', faceIndex + 1,
                '这一面未通过安全净化；本批结果不会保存。');
        }
        const newRoot = templateSingleFollowRoot(template);
        const newDetails = directDetailsChild(newRoot);
        if (!newRoot || !newDetails || !isUsableSanitizedDetails(newDetails)) {
            throw followMultifaceRejection('multiface-sanitized-invalid', faceIndex + 1,
                '净化后缺少独立完整的标题或内容；本批结果不会保存。');
        }
        // Match the actual TextNode-filtered DOM, not a flattened title string:
        // a banned phrase spanning <b>/<span> nodes must not become a new match.
        const expectedTitle = renderedSummaryText(newDetails);
        const item = { sourceFace, faceIndex, expectedTitle, newRoot, newDetails,
            sourceHash: rabbitMirrorMultifaceSourceHash(sourceFace.html) };
        prepared.push(item);
        if (!expectedTitle || prepared.slice(0, -1).some(other => other.expectedTitle === expectedTitle)) {
            const error = followMultifaceRejection(!expectedTitle ? 'multiface-sanitized-empty-summary' : 'multiface-sanitized-duplicate-summary',
                faceIndex + 1, '过滤后出现空标题或相同标题，无法确认每面的身份；本批结果不会保存。');
            error.preparedFaces = prepared;
            throw error;
        }
        // Complete safe faces are accepted regardless of visual complexity.
        // The existing commit scan records appearance for cooldown, not refusal.
        } catch (error) {
            if (!error?.rabbitMirrorFollowRejection) throw error;
            if (prepared.at(-1)?.faceIndex === faceIndex) prepared.pop();
            const code=String(error.code || 'multiface-postprocess');
            const html=createMultifaceFailureSlot(faceIndex,code);
            const template=document.createElement('template'); template.innerHTML=html;
            const newRoot=templateSingleFollowRoot(template),newDetails=directDetailsChild(newRoot);
            prepared.push({sourceFace,faceIndex,newRoot,newDetails,expectedTitle:renderedSummaryText(newDetails),
                sourceHash:rabbitMirrorMultifaceSourceHash(sourceFace.html),failure:{faceIndex,status:'failed',code}});
        }
    }
    if(prepared.every(item=>item.failure)) throw followMultifaceRejection('multiface-all-failed',null,'所有面均未通过检查；不会自动补发请求。');
    return prepared;
}

function sanitizeAndMountFollowFaces(scope, set, sanitizer, preparedFaces = null) {
    const detached = preparedFaces || prepareFollowFaces(set, sanitizer);
    if (!detached) return null;
    let matched = matchRenderedFollowFaces(scope, set, detached);
    // A terminal truncated suffix may have no usable details or no root at all.
    // Match only this exact owner's top-level ordinal roots; never DOM-repair
    // the malformed suffix or consume another message's/sibling's content.
    if(!matched && set.partial && set.owner){
        const candidates=topLevelFollowTotos(scope);
        const parent=candidates[0]?.parentNode;
        const ordinals=candidates.map(root=>Number(root.getAttribute('data-rm-face'))-1);
        if(parent&&candidates.length<=detached.length&&new Set(ordinals).size===ordinals.length
            && candidates.every((root,index)=>root.parentNode===parent&&Number.isInteger(ordinals[index])&&ordinals[index]>=0&&ordinals[index]<detached.length)){
            const trusted=detached.every(item=>{
                const root=candidates[ordinals.indexOf(item.faceIndex)];
                return item.sourceFace.failure || (root&&[sourceFaceTitle(item.sourceFace),item.expectedTitle].includes(renderedSummaryText(directDetailsChild(root))));
            });
            if(trusted){
                matched=detached.map(item=>{
                    let root=candidates[ordinals.indexOf(item.faceIndex)];
                    const createdRoot=!root;
                    if(createdRoot){root=document.createElement('toto');parent.append(root);}
                    return {root,createdRoot,details:directDetailsChild(root),sourceFace:item.sourceFace,faceIndex:item.faceIndex};
                });
            }
        }
    }
    if (!matched) return null;
    const prepared = matched.map((item, index) => {
        const safe = detached[index];
        if (item.details?.open) safe.newDetails.open = true;
        else safe.newDetails.removeAttribute('open');
        return { ...item, ...safe, persistedHtml:safe.newRoot.outerHTML, parent: item.root.parentNode, oldRoot: item.root };
    });

    if (prepared.length !== set.faces.length || prepared.some(item => !item.parent || !item.oldRoot.isConnected)) return null;
    let mounted = 0;
    try {
        for (const item of prepared) {
            if (item.oldRoot.parentNode !== item.parent) throw new Error('follow multiface DOM owner changed');
            item.parent.replaceChild(item.newRoot, item.oldRoot);
            mounted += 1;
        }
        for (const item of prepared) {
            sanitizer.isolateRabbitMirrorInteractionIds(item.newRoot);
            sanitizer.refreshRabbitMirrorToolsInScope(item.newRoot);
        }
        if (!verifyMountedFollowFaces(scope, prepared)) throw new Error('follow multiface mounted structure mismatch');
        const failedFaces=prepared.filter(item=>item.failure).map(item=>item.failure);
        if(failedFaces.length&&set.owner){
            const persistedFaces=prepared.map(item=>item.failure?createMultifaceFailureSlot(item.faceIndex,item.failure.code):item.persistedHtml);
            const html=persistedFaces.join('\n');
            if(!saveFollowPartialResult(set.owner.chat,set.owner.messageIndex,set.owner,html,failedFaces,getSettings()?.rabbitMirrorBannedWords||[])){
                const error=new Error('follow partial result persistence failed');
                error.code='follow-partial-storage-failed';
                throw error;
            }
            for(const item of prepared){
                item.sourceHash=rabbitMirrorMultifaceSourceHash(persistedFaces[item.faceIndex]);
                item.sourceFace={...item.sourceFace,html:persistedFaces[item.faceIndex]};
            }
        }
        for (const item of prepared) {
            if (!markSanitizedRabbitMirrorFace(item.newRoot, {
                faceIndex: item.faceIndex,
                faceCount: prepared.length,
                sourceHash: item.sourceHash,
                origin: 'follow',
                ...presentationModeFields(item.sourceFace.metadata),
            })) throw new Error('follow multiface proof rejected');
        }
        if (prepared.some(item => {
            const proof = getSanitizedRabbitMirrorFaceProof(item.newRoot);
            return !proof || proof.origin !== 'follow'
                || proof.faceIndex !== item.faceIndex
                || proof.faceCount !== prepared.length
                || proof.sourceHash !== item.sourceHash;
        })) throw new Error('follow multiface proof mismatch');
        return prepared.map(item => ({
            root: item.newRoot,
            details: item.newDetails,
            proof: getSanitizedRabbitMirrorFaceProof(item.newRoot),
            sourceFace: item.sourceFace,
            failure: item.failure || null,
        }));
    } catch (error) {
        rollbackMountedFollowFaces(prepared.slice(0, mounted));
        if(error?.code==='follow-partial-storage-failed'&&followOwnerStillCurrent(set,set.owner?.chat)){
            const owner=set.owner;
            const key=JSON.stringify([owner.chatKey,owner.messageIndex,owner.swipeId,owner.sourceHash]);
            if(!followPartialStorageWarnings.has(key)&&typeof globalThis.toastr?.warning==='function'){
                if(followPartialStorageWarnings.size>=32) followPartialStorageWarnings.delete(followPartialStorageWarnings.values().next().value);
                followPartialStorageWarnings.add(key);
                try{globalThis.toastr.warning('兔子镜本地保存失败，未覆盖原消息或原结果，也不会自动补发请求。请检查浏览器存储空间或访问权限，不要清除站点数据。');}catch{}
            }
        }
        console.debug('[RabbitMirror] follow multiface transactional mount skipped:', error);
        return null;
    }
}

function provenRenderedFollowFaces(set, chat, sanitizer) {
    const messageIndex = set?.owner?.messageIndex;
    if (!set || !Array.isArray(set.faces) || set.faces.length < 2 || set.faces.length > 5) return null;
    if (!followOwnerStillCurrent(set, chat)) return null;
    const prepared = prepareFollowFaces(set, sanitizer);
    if (!prepared) return null;
    const scopes = exactMessageScopes(chat, messageIndex)
        .filter(scope => set.partial || !!matchRenderedFollowFaces(scope, set, prepared));
    if (scopes.length !== 1) return null;
    return sanitizeAndMountFollowFaces(scopes[0], set, sanitizer, prepared);
}

async function scanFollowBatches(chat, lifecycle = visualScannerLifecycle) {
    let committed = 0;
    const terminalMessageIndexes=getRabbitMirrorFollowBatchTargetIndexes(chat).filter(index=>terminalFollowMessageIndexes.has(terminalFollowOwnerKey(chat,index)));
    const sets = getRabbitMirrorFollowBatchSources(chat,{terminalMessageIndexes});
    const sanitizer = sets.length ? await loadFollowBatchSanitizer() : null;
    if (lifecycle !== visualScannerLifecycle) return committed;
    for (const set of sets) {
        if (lifecycle !== visualScannerLifecycle) break;
        if (followBatchScansInFlight.has(set.batchId)) continue;
        const previousFailure = getRabbitMirrorFollowBatchFailure(chat, set.owner.messageIndex);
        if (previousFailure?.batchId === set.batchId) continue;
        if (rejectedFollowBatches.has(terminalFollowOwnerKey(chat, set.owner.messageIndex))) {
            clearFollowBatchFailure(chat, set.owner.messageIndex);
        }
        followBatchScansInFlight.add(set.batchId);
        const attemptKey = `${set.batchId}\u0000${set.owner.sourceHash}`;
        const attempts = Number(followBatchScanAttempts.get(attemptKey) || 0) + 1;
        if (!followBatchScanAttempts.has(attemptKey) && followBatchScanAttempts.size >= 24) {
            followBatchScanAttempts.delete(followBatchScanAttempts.keys().next().value);
        }
        followBatchScanAttempts.set(attemptKey, attempts);
        try {
            // Detached preparation, exact-owner mount and aggregate commit stay
            // in one task; do not yield after mounting before owner validation.
            const rendered = provenRenderedFollowFaces(set, chat, sanitizer);
            if (!rendered || lifecycle !== visualScannerLifecycle || !followOwnerStillCurrent(set, chat)) continue;
            const scans = rendered.map(({ sourceFace, root, failure }, faceIndex) => failure?null:({
                faceIndex,
                ...scanRabbitMirrorHtml(root.outerHTML, root),
            }));
            if (scans.length !== set.faces.length) continue;
            if (commitRabbitMirrorFollowBatch(set.batchId, chat, scans, {...set.owner,partial:scans.some(scan=>scan===null)})) {
                committed += 1;
                rendered.forEach(({root,details,failure},faceIndex)=>{
                    if(failure)return;
                    const ref={batchId:set.batchId,faceIndex};
                    bindVisualHistoryTarget(root,ref);
                    if(details)bindVisualHistoryTarget(details,ref);
                });
                followBatchScanAttempts.delete(attemptKey);
                terminalFollowMessageIndexes.delete(terminalFollowOwnerKey(chat, set.owner.messageIndex));
                try {
                    globalThis.dispatchEvent?.(new CustomEvent(FOLLOW_MULTIFACE_COMMITTED_EVENT, {
                        detail:{messageIndex:Number(set.owner.messageIndex),sourceHash:String(set.owner.sourceHash||''),batchId:String(set.batchId||'')},
                    }));
                } catch {}
                const feedbackResult = consumeInjectedFeedbackForSuccessfulRabbitMirror(set.owner.message);
                if (feedbackResult?.consumed) console.debug('[RabbitMirror] feedback cat consumed:', feedbackResult.remainingRounds);
                console.debug('[RabbitMirror] follow multiface visual batch committed:', set.batchId, scans.length);
            }
        } catch (error) {
            if (error?.rabbitMirrorFollowRejection && lifecycle === visualScannerLifecycle) {
                rejectFollowBatch(set, chat, error);
                followBatchScanAttempts.delete(attemptKey);
            } else {
                console.debug('[RabbitMirror] follow multiface preparation unavailable:', error);
            }
        } finally {
            followBatchScansInFlight.delete(set.batchId);
        }
    }
    for (const messageIndex of getRabbitMirrorFollowBatchTargetIndexes(chat)) {
        const ownerKey = terminalFollowOwnerKey(chat, messageIndex);
        if (!terminalFollowMessageIndexes.has(ownerKey)) continue;
        const key = `terminal\u0000${ownerKey}`;
        const attempts = Number(followBatchScanAttempts.get(key) || 0) + 1;
        followBatchScanAttempts.set(key, attempts);
        if (attempts >= 2) {
            releaseRabbitMirrorFollowBatchAtMessage(chat, messageIndex);
            terminalFollowMessageIndexes.delete(ownerKey);
            followBatchScanAttempts.delete(key);
        }
    }
    return committed;
}


function messageIntegritySources(message) {
    const candidates = [];
    const seen = new Set();
    const push = source => {
        if (typeof source !== 'string') return;
        const text = source.trim();
        if (!text || seen.has(text)) return;
        seen.add(text);
        candidates.push(text);
    };
    const swipeIndex = Number.isInteger(message?.swipe_id) ? message.swipe_id : -1;
    if (swipeIndex >= 0) push(message?.swipes?.[swipeIndex]);
    push(message?.mes);
    push(message?.extra?.display_text);
    return candidates;
}

function successfulRabbitMirrorSource(message, chat) {
    for (const source of messageIntegritySources(message)) {
        const inspection = inspectRabbitMirrorGenerationSource(source);
        if (!inspection.complete) continue;
        return { source, inspection, fromSnapshot: false };
    }
    const messageIndex = Array.isArray(chat) ? chat.lastIndexOf(message) : -1;
    const title = rawSummaryText(message?.mes || '');
    const snapshot = getRabbitMirrorGenerationSnapshot(message, chat, messageIndex, title);
    if (!snapshot?.source) return null;
    const inspection = inspectRabbitMirrorGenerationSource(snapshot.source, title);
    if (!inspection.complete) return null;
    return {
        source: `<toto data-rabbit-mirror="true">${snapshot.source}</toto>`,
        inspection,
        fromSnapshot: true,
    };
}

async function scanLatestAssistantMessage(mod) {
    const lifecycle = visualScannerLifecycle;
    const chat = mod?.chat || globalThis.chat;
    if (!Array.isArray(chat) || !chat.length) return;
    captureRabbitMirrorGenerationSnapshots(chat);
    await scanFollowBatches(chat, lifecycle);
    if (lifecycle !== visualScannerLifecycle) return;
    const message = [...chat].reverse().find(item => !item?.is_user && typeof item?.mes === 'string');
    if (!message || !/(?:<toto\b|<details\b)[\s\S]*?兔子镜/i.test(message.mes)) {
        console.debug('[RabbitMirror] visual commit skipped: latest assistant message has no RabbitMirror source');
        return;
    }
    if (/\bdata-rm-face\s*=/i.test(message.mes)) return;
    const successful = successfulRabbitMirrorSource(message, chat);
    if (!successful) {
        console.debug('[RabbitMirror] visual commit skipped: incomplete RabbitMirror source');
        return;
    }
    const sourceForScan = successful.source;
    const sigHash = hashText(sourceForScan);
    if (sigHash !== lastScannedHash) {
        lastScannedHash = sigHash;
        lastScanAttempts = 0;
    } else if (lastScanAttempts >= 2) {
        return;
    }
    lastScanAttempts += 1;

    const renderedToto = findRenderedToto(message, chat, message.mes);
    if (!renderedToto) return;
    const bannedWords = getSettings()?.rabbitMirrorBannedWords;
    if (renderedToto && Array.isArray(bannedWords) && bannedWords.length) {
        applyRabbitMirrorBannedWordsToDom(renderedToto, bannedWords);
    }
    renderedToto.querySelectorAll?.('rm-think, rm-ticket').forEach(node => node.remove());
    const result = scanRabbitMirrorHtml(renderedToto.outerHTML, renderedToto);
    const signature = result?.signature || '';
    const skeleton = result?.skeleton || '';
    const riskFlags = Array.isArray(result?.riskFlags) ? result.riskFlags : [];
    const paletteFingerprint = result?.paletteFingerprint && typeof result.paletteFingerprint === 'object'
        ? result.paletteFingerprint
        : null;
    const interactionFamily = result?.interactionFamily && typeof result.interactionFamily === 'object'
        ? result.interactionFamily
        : null;
    if (signature || skeleton || riskFlags.length || paletteFingerprint || interactionFamily) {
        const historyOwner=commitFollowVisualHistory(message,chat,sourceForScan,result);
        if(historyOwner){
            bindVisualHistoryTarget(renderedToto,historyOwner);
            const details=renderedToto.matches?.('details')?renderedToto:renderedToto.querySelector?.('details');
            if(details)bindVisualHistoryTarget(details,historyOwner);
        }
        const feedbackResult = consumeInjectedFeedbackForSuccessfulRabbitMirror(message);
        if (feedbackResult?.consumed) {
            console.debug('[RabbitMirror] feedback cat consumed:', feedbackResult.remainingRounds);
        }
        console.debug('[RabbitMirror] visual signature:', signature, skeleton, riskFlags, paletteFingerprint, interactionFamily);
    }
}

function clearVisualScannerTimers() {
    if (visualScannerCaptureTimer) {
        clearTimeout(visualScannerCaptureTimer);
        visualScannerCaptureTimer = 0;
    }
    for (const timer of visualScannerTimers) clearTimeout(timer);
    visualScannerTimers.clear();
}

export function destroyVisualScanner() {
    visualScannerLifecycle += 1;
    clearVisualScannerTimers();
    for (const { eventSource, eventName, handler } of visualScannerSubscriptions) {
        try { eventSource?.off?.(eventName, handler); } catch {}
    }
    visualScannerSubscriptions = [];
    followBatchScanAttempts.clear();
    terminalFollowMessageIndexes.clear();
    followBatchScansInFlight.clear();
    for (const entry of rejectedFollowBatches.values()) entry.notice?.remove?.();
    rejectedFollowBatches.clear();
    if (globalThis.__rabbitMirrorVisualScannerCleanup === destroyVisualScanner) delete globalThis.__rabbitMirrorVisualScannerCleanup;
}

export async function initVisualScanner() {
    try {
        try { globalThis.__rabbitMirrorVisualScannerCleanup?.(); } catch {}
        globalThis.__rabbitMirrorVisualScannerCleanup = destroyVisualScanner;
        const mod = await import('../../../../../script.js');
        const eventSource = mod?.eventSource;
        const eventTypes = mod?.event_types || {};
        if (!eventSource?.on) return;
        const captureNow = () => {
            const finishCapture = globalThis.__rabbitMirrorPerfDiag?.begin?.('visualScanner.captureNow', {}, 0);
            if (visualScannerCaptureTimer) {
                clearTimeout(visualScannerCaptureTimer);
                visualScannerCaptureTimer = 0;
            }
            try {
                captureRabbitMirrorGenerationSnapshots(mod?.chat || globalThis.chat);
            } catch (error) {
                console.debug('[RabbitMirror] generation snapshot capture skipped:', error);
            } finally {
                finishCapture?.();
            }
        };
        const scheduleCapture = (delay = 140) => {
            if (visualScannerCaptureTimer) clearTimeout(visualScannerCaptureTimer);
            visualScannerCaptureTimer = setTimeout(captureNow, Math.max(0, Number(delay) || 0));
        };
        const scheduleTimer = (handler, delay) => {
            const timer = setTimeout(() => {
                visualScannerTimers.delete(timer);
                handler();
            }, delay);
            visualScannerTimers.add(timer);
        };
        const generationMessageIndex = payload => {
            for (const value of [payload, payload?.messageId, payload?.message_id, payload?.mesid, payload?.id, mod?.streamingProcessor?.messageId]) {
                const index = Number(value);
                if (Number.isInteger(index) && index >= 0) return index;
            }
            return null;
        };
        const scheduleScan = (payload = null, eventName = '') => {
            globalThis.__rabbitMirrorPerfDiag?.mark?.('visualScanner.scheduleScan');
            const messageIndex = generationMessageIndex(payload);
            const eventChat = mod?.chat || globalThis.chat;
            const ownerKey = Number.isInteger(messageIndex) ? terminalFollowOwnerKey(eventChat, messageIndex) : '';
            if (Number.isInteger(messageIndex) && eventName === eventTypes.GENERATION_STOPPED) {
                releaseRabbitMirrorFollowBatchAtMessage(eventChat, messageIndex);
                terminalFollowMessageIndexes.delete(ownerKey);
                try {
                    globalThis.dispatchEvent?.(new CustomEvent(FOLLOW_GENERATION_SETTLED_EVENT, {
                        detail: { messageIndex, cancelled: true },
                    }));
                } catch {}
            } else if (Number.isInteger(messageIndex) && eventName === eventTypes.GENERATION_ENDED) {
                if (terminalFollowMessageIndexes.size >= 8) terminalFollowMessageIndexes.delete(terminalFollowMessageIndexes.values().next().value);
                terminalFollowMessageIndexes.add(ownerKey);
            }
            // Multiple SillyTavern end events can fire for the same reply. Keep
            // only one early and one settled scan instead of stacking another
            // pair for every event.
            for (const timer of visualScannerTimers) clearTimeout(timer);
            visualScannerTimers.clear();
            captureNow();
            scheduleCapture(120);
            scheduleTimer(() => scanLatestAssistantMessage(mod), 650);
            scheduleTimer(() => {
                void scanLatestAssistantMessage(mod).then(() => {
                    if (!Number.isInteger(messageIndex)) return;
                    if (eventName === eventTypes.GENERATION_STOPPED) return;
                    try {
                        globalThis.dispatchEvent?.(new CustomEvent(FOLLOW_GENERATION_SETTLED_EVENT, {
                            detail: { messageIndex, cancelled: false },
                        }));
                    } catch {}
                });
            }, 1750);
        };
        const subscribe = (eventName, handler) => {
            if (!eventName) return;
            eventSource.on(eventName, handler);
            visualScannerSubscriptions.push({ eventSource, eventName, handler });
        };
        const captureEvents = [
            eventTypes.CHARACTER_MESSAGE_RENDERED,
        ].filter(Boolean);
        for (const eventName of [...new Set(captureEvents)]) {
            const handler = () => scheduleCapture(140);
            subscribe(eventName, handler);
        }
        const generationEvents = [eventTypes.MESSAGE_RECEIVED, eventTypes.GENERATION_STOPPED, eventTypes.GENERATION_ENDED].filter(Boolean);
        for (const eventName of [...new Set(generationEvents)]) subscribe(eventName, payload => scheduleScan(payload, eventName));
        // CHAT_CHANGED and MESSAGE_UPDATED can fire while a long history/reply is
        // still arriving. Final rendered/received/end events own the settled scan;
        // never rescan a growing正文 on every token or an empty chat boundary.
        console.debug('[RabbitMirror] visual scanner initialized');
    } catch (error) {
        console.debug('[RabbitMirror] visual scanner disabled:', error);
    }
}
