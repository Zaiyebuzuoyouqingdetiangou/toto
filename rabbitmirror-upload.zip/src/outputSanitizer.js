// Compatibility barrel. Callers may keep importing outputSanitizer.js.
export { repairRabbitMirrorPersistedExclusiveGridSpan, repairRabbitMirrorSelectorPanelGridSpan } from './outputSanitizer/checkedStateRescue.js?rmv=1.62.99';
export { validateRabbitMirrorRecoveredStyleAssignments } from './outputSanitizer/renderedStateRescue.js?rmv=1.62.99';
export {
    isolateRabbitMirrorInteractionIds,
    rearmRabbitMirrorSerializedInteractionRoot,
    activateRabbitMirrorInteractionRescue,
    armRabbitMirrorFirstUseInteraction,
    repairRabbitMirrorScopedClassAliasesInScope,
} from './outputSanitizer/idsAndRearm.js?rmv=1.62.99';
export { triggerInteractionDiagnosticOnce } from './outputSanitizer/diagnostics.js?rmv=1.62.99';
export { rehydrateRabbitMirrorMaintenanceRepairs } from './outputSanitizer/choiceRescue.js?rmv=1.62.99';
export {
    validateRabbitMirrorMarkupLexicalBudget,
    validateRabbitMirrorTemplateStructuralBudget,
    sanitizeRabbitMirrorUntrustedTemplate,
    rescueDamagedDataUriRabbitMirrorOutput,
    repairMalformedRabbitMirrorMarkup,
    rescuePlainTextRabbitMirrorOutput,
    compactTotoBlock,
    cleanRabbitMirrorOutput,
} from './outputSanitizer/markup.js?rmv=1.62.99';
export {
    getRabbitMirrorFacePosition,
    activateRabbitMirrorIndependentMobileSpatialRescue,
    clearRabbitMirrorHorizontalClipArtifacts,
    installMaintenanceHorizontalClipRescue,
} from './outputSanitizer/layoutRescue.js?rmv=1.62.99';
export {
    refreshMaintenanceRabbits,
    refreshFeedbackCats,
    refreshRecipeButtons,
    refreshRabbitMirrorToolsInScope,
} from './outputSanitizer/toolsChrome.js?rmv=1.62.99';
export { configureMaintenanceAutoSafeMode, initOutputSanitizer, destroyOutputSanitizer } from './outputSanitizer/lifecycle.js?rmv=1.62.99';
