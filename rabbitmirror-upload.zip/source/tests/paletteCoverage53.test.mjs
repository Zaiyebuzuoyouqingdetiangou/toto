import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';
import { captureFinalPrompt } from './helpers/finalPromptCapture.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const names = JSON.parse(readFileSync(new URL('./fixtures/cssNamedColours53.json', import.meta.url)));
const wrap = (css, body = '<div class="reader">正文</div>') => `<toto data-rabbit-mirror="true"><details><summary>兔子镜</summary><style>${css}</style>${body}</details></toto>`;
async function fixture(run) {
    const rt = await createDomRuntime(root);
    try {
        const { scanRabbitMirrorHtml } = await rt.load('src/visualScanner.js');
        const scan = (css, body) => scanRabbitMirrorHtml(wrap(css, body)).paletteFingerprint;
        await run({ rt, scan, fullScan: scanRabbitMirrorHtml, color: value => scan(`.reader{background:${value}}`) });
    } finally { await rt.close(); }
}

test('all 148 standard colour names agree with their numeric sRGB values', () => fixture(({ color }) => {
    const failures = Object.entries(names).filter(([name, hex]) => JSON.stringify(color(name)) !== JSON.stringify(color(hex))).map(([name]) => name);
    assert.deepEqual(failures, []);
}));

test('eight chromatic families and neutrals retain hue through hex, rgb, hsl and local variables', () => fixture(({ scan, color }) => {
    for (const [hue, hex, h] of [['red','#cc3333',0],['orange','#cc8033',30],['yellow','#cccc33',60],['green','#33cc33',120],['cyan','#33b3cc',190],['blue','#3333cc',240],['purple','#8033cc',270],['pink','#cc33cc',300]]) {
        const expected = color(hex);
        assert.equal(expected.hueFamily, hue);
        for (const value of [hex, `hsl(${h}deg 60% 50%)`, `hsl(${h / 360}turn 60% 50%)`, `var(--tone)`]) {
            const actual = scan(`.reader{--tone:${hex};background:${value}}`);
            assert.equal(actual?.hueFamily, hue, `${hue}: ${value}`);
        }
    }
    for (const value of ['#eee', '#eeeeee', 'rgb(238 238 238)', 'hsl(0 0% 93.333333%)']) assert.equal(color(value)?.hueFamily, 'neutral', value);
}));

test('percentage channels, alpha and hue units are parsed independently', () => fixture(({ color }) => {
    for (const [a, b] of [
        ['rgb(100% 64 64 / 1)', 'rgb(255 64 64)'],
        ['rgb(128,64,64,50%)', 'rgba(128,64,64,.5)'],
        ['hsl(270 50% 1% / 1)', '#030104'],
        ['rgb(1% 0% 0% / 1)', 'rgb(2.55 0 0)'],
        ['hsl(.75turn 50% 50%)', 'hsl(270 50% 50%)'],
        ['hsl(300grad 50% 50%)', 'hsl(270 50% 50%)'],
        ['hsl(3.141592653589793rad 50% 50%)', 'hsl(180 50% 50%)'],
        ['rgb(1.28e2 64 64 / 5e-1)', 'rgba(128,64,64,.5)'],
    ]) assert.deepEqual(color(a), color(b), a);
    assert.equal(color('hsl(0 100% 50% / 1%)'), null);
}));

test('CSS comments, prose, strings, URLs and unsupported nested functions do not invent background colours', () => fixture(({ scan, color }) => {
    const plain = scan('.reader{background:#eee}');
    for (const css of [
        '/* .unused{background:purple} */ .reader{background:#eee}',
        '.reader:before{content:"background:purple"}.reader{background:#eee}',
        '.reader{--unused-background:purple;background:#eee}',
    ]) assert.deepEqual(scan(css), plain, css);
    assert.deepEqual(scan('.reader{background:#eee}', '<div class="reader">例子 background:purple;</div>'), plain);
    assert.deepEqual(scan('.reader{background:#eee}', '<div class="reader">例子 style="background:purple";</div>'), plain);
    assert.deepEqual(scan('.reader{background:#eee}', `<div class="reader" title='style="background:purple"'>正文</div>`), plain);
    assert.equal(color('url(https://example.test/blue.svg#fff)'), null);
    assert.equal(color('url("data:image/svg+xml,<svg fill=\'red\'></svg>")'), null);
    assert.deepEqual(color('url("blue.svg") #eee'), color('#eee'));
    assert.equal(color('color-mix(in srgb, red 99%, blue 1%)'), null);
    assert.equal(color('light-dark(white,black)'), null);
    assert.equal(color('rgb(1..2 0 0)'), null);
    assert.equal(color('rgba(10%,20,30,.5)'), null);
}));

test('inline initial variables and invalid alias fallbacks work without guessing conflicting scopes', () => fixture(({ scan, color }) => {
    assert.deepEqual(scan('.reader{color:black}', '<div class="reader" style="--tone:orange;background:var(--tone)">正文</div>'), color('orange'));
    for (const css of [
        '.reader{--a:var(--missing);background:var(--a,orange)}',
        '.reader{--a:initial;background:var(--a,orange)}',
        '.reader{--a:var(--b);--b:var(--a);background:var(--a,orange)}',
        '.reader{--a:var(--a,red);background:var(--a,orange)}',
        '.reader{--b:blue;--a:var(--b,var(--a));background:var(--a,orange)}',
    ]) assert.deepEqual(scan(css), color('orange'), css);
    assert.equal(scan('.a{--tone:red}.b{--tone:blue}.reader{background:var(--tone,green)}'), null);
    assert.equal(scan('.reader{--tone:2px;background:var(--tone,green)}'), null);
}));

test('rendered details roots scan the main body, not an inner folding panel; zero geometry falls back to source', () => fixture(({ rt, fullScan }) => {
    const html = wrap('', '<div class="reader" style="background:#3a6f9f">主体<details><summary>附注</summary><div style="background:#33cc33">小附注</div></details></div>');
    rt.window.document.body.innerHTML = html;
    const toto = rt.window.document.querySelector('toto');
    const details = toto.querySelector('details');
    const main = details.querySelector('.reader');
    for (const node of [toto, details, main, ...main.querySelectorAll('*')]) node.getBoundingClientRect = () => ({ width: node === main || node === details || node === toto ? 360 : 10, height: node === main || node === details || node === toto ? 300 : 10 });
    assert.equal(fullScan(html, details).paletteFingerprint?.hueFamily, 'blue');
    assert.deepEqual(fullScan(html, details).paletteFingerprint, fullScan(html, toto).paletteFingerprint);
    for (const node of [toto, ...toto.querySelectorAll('*')]) node.getBoundingClientRect = () => ({ width: 0, height: 0 });
    assert.equal(fullScan(html, details).paletteFingerprint?.source, 'raw');
}));

test('all colour families reach existing cooldown, with warm off-whites sharing one group', () => fixture(async ({ rt, color }) => {
    const { observedPaletteGroup } = await rt.load('src/paletteRecipes.js');
    const { buildPaletteCooldownRule } = await rt.load('src/paletteCooldown.js');
    for (const [value, group, label] of [['crimson','red','红色系'],['darkorange','orange','橙色系'],['gold','yellow','黄色系'],['lime','green','绿色系'],['turquoise','cyan','青色系'],['royalblue','blue','蓝色系'],['rebeccapurple','purple','紫色系'],['hotpink','pink','粉色系'],['silver','cool_neutral','中性色'],['black','dark_neutral','深中性色']]) {
        const record = { historyId: value, paletteFingerprint: color(value) };
        assert.equal(observedPaletteGroup(record), group, value);
        rt.context.localStorage.setItem('rabbit_mirror_theater:last_combo:v11', JSON.stringify([record]));
        assert.ok(buildPaletteCooldownRule({darkVisualMode:false},{includeIndexedFamily:true}).includes(label), value);
    }
    for (const value of ['#fff8e7','#faf5e9','#f5f5dc','#eee6d5','ivory','cornsilk','oldlace']) assert.equal(observedPaletteGroup({paletteFingerprint:color(value)}), 'warm_neutral', value);
}));

test('corrected observations reach real final request composition in both beauty modes and mixed faces', () => fixture(async ({ color }) => {
    const samples = [['crimson','红色系'],['darkorange','橙色系'],['gold','黄色系'],['lime','绿色系'],['turquoise','青色系'],['royalblue','蓝色系'],['rebeccapurple','紫色系'],['hotpink','粉色系'],['ivory','暖浅中性色']];
    for (const [value, label] of samples) for (const visualDesignMode of ['guided1553', 'reference1553']) {
        const result = await captureFinalPrompt(root, { history: [{ historyId:value, paletteFingerprint:color(value) }], overrides: {visualDesignMode, rabbitMirrorFaceCount:2, rabbitMirrorPresentationModes:['html','longtext']} });
        const request = result.messages.map(m => m.content).join('\n');
        assert.ok(request.includes(label), `${visualDesignMode}: ${value}`);
        assert.equal(result.dispatches, 1);
        assert.doesNotMatch(request, /生成配色参考【|生成后换色【/);
    }
}));
