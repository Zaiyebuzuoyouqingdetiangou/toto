import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';

const root = process.env.RM_TEST_SOURCE_ROOT || fileURLToPath(new URL('..', import.meta.url));
const evidence = readFileSync(new URL('./fixtures/independentSiblingStyleEvidence.html', import.meta.url), 'utf8');
const css = html => [...String(html).matchAll(/<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi)].map(match => match[1]);
const face = (name, color) => `<style>.${name}{color:${color}}</style><details open><summary>【兔子镜：${name}】</summary><div class="${name}">内容</div></details>`;
const withRuntime = fn => async () => {
    const rt = await createDomRuntime(root);
    try { await fn(rt, await rt.load('src/independentApi/geometry.js'), await rt.load('src/independentApi/faceSwipe.js')); }
    finally { rt.close(); }
};

test('exact after-sanitize evidence retains author CSS when saving interaction baselines', withRuntime(async (rt, g) => {
    const saved = g.scrubIndependentInteractionState(evidence, evidence);
    assert.deepEqual(css(saved), css(evidence));
    assert.equal((saved.match(/@keyframes\b/g) || []).length, 5);
    assert.equal((saved.match(/:checked/g) || []).length, 7);
}));

test('saved real scene mounts with hidden control, author text color and state selectors intact', withRuntime(async (rt, g) => {
    const saved = g.scrubIndependentInteractionState(evidence, evidence);
    const host = g.buildExternalHost('offline:94:1', saved, 'ready', 'independent', true);
    rt.window.document.body.append(host);
    assert.deepEqual([...host.querySelectorAll('style')].map(node => node.textContent), css(evidence));
    const control = host.querySelector('input[type=checkbox]');
    assert.equal(rt.window.getComputedStyle(control).display, 'none');
    const title = host.querySelector('[class$="rm-status-unlocked"] [class$="rm-title"]');
    assert.equal(rt.window.getComputedStyle(title).color.toLowerCase(), '#ffe7b3');
    assert.equal(host.querySelector('label').htmlFor, control.id);
    const locked = host.querySelector('[class$="rm-status-locked"]');
    assert.equal(rt.window.getComputedStyle(locked).opacity, '0');
    control.checked = true;
    // happy-dom caches computed style across checked-property changes. Verify
    // the real state selector against this DOM and its parsed CSS declaration;
    // do not claim browser animation/state rendering from this DOM-only runner.
    const matches = [...host.querySelector('style').sheet.cssRules].filter(rule =>
        rule.selectorText?.includes(':checked') && locked.matches(rule.selectorText));
    assert.equal(matches.length, 1);
    assert.equal(matches[0].style.opacity, '1');
    control.checked = false;
    assert.equal(locked.matches(matches[0].selectorText), false);
}));

test('face version seed, append and merge retain the exact author stylesheet', withRuntime(async (rt, g, f) => {
    const sw = await rt.load('src/swipeVersions.js');
    f.seedIndependentFaceSwipes('offline:94:1', evidence);
    const seed = sw.readFaceSwipe('offline:94:1', 0).versions[0];
    assert.deepEqual(css(seed.html), css(evidence));
    assert.deepEqual(css(seed.initialHtml), css(evidence));
    const second = evidence.replaceAll('强咽雷霆锁杀意', '雷霆终息化春风');
    f.appendIndependentFaceSwipe('offline:94:1', 0, second);
    const versions = sw.readFaceSwipe('offline:94:1', 0).versions;
    assert.equal(versions.length, 2);
    assert.deepEqual(css(f.mergeFaceDetailsIntoHtml(evidence, 0, versions[1].html)), css(evidence));
}));

test('styles before, inside and after a details retain their cascade order', withRuntime(async (rt, g, f) => {
    const html = '<style>.x{color:red}</style><details><summary>【兔子镜：顺序】</summary><style>.x{color:green}</style><p class="x">字</p></details><style>.x{color:blue}</style>';
    for (const result of [g.scrubIndependentInteractionState(html, html), f.scrubSwipeDetailsHtml(html), g.extractReadyDetails(html, true).outerHTML]) {
        assert.deepEqual(css(result).map(sheet => sheet.match(/color:(red|green|blue)/)?.[1]), ['red', 'green', 'blue']);
        const template = rt.window.document.createElement('template'); template.innerHTML = result;
        assert.equal(template.content.querySelector('details').firstElementChild.tagName, 'SUMMARY');
    }
}));

test('multiface storage preserves each face CSS and a replacement leaves the other face unchanged', withRuntime(async (rt, g, f) => {
    const request = await rt.load('src/independentApi/request.js');
    const protocol = await rt.load('src/multifaceProtocol.js');
    const first = request.wrapIndependentFace(face('甲', 'red'), 0);
    const second = request.wrapIndependentFace(face('乙', 'blue'), 1);
    const html = first + '\n' + second;
    const saved = g.scrubIndependentInteractionState(html, html);
    assert.equal(protocol.parseMultifaceOutput(saved).ok, true);
    const faces = f.faceDetailsListFromHtml(saved);
    assert.equal(faces.length, 2);
    assert.deepEqual(css(faces[0].detailsHtml), ['.甲{color:red}']);
    assert.deepEqual(css(faces[1].detailsHtml), ['.乙{color:blue}']);
    const merged = f.mergeFaceDetailsIntoHtml(html, 1, face('丙', 'purple'));
    const parsed = protocol.parseMultifaceOutput(merged);
    assert.equal(parsed.faces[0].html, first);
    assert.deepEqual(css(parsed.faces[1].inner), ['.丙{color:purple}']);
}));

test('extracting one explicit toto does not import another face or nested details stylesheet', withRuntime(async (rt, g, f) => {
    const one = '<toto>' + face('甲', 'red') + '</toto>';
    const two = '<toto>' + face('乙', 'blue') + '</toto>';
    assert.deepEqual(css(f.scrubSwipeDetailsHtml(one + two)), ['.甲{color:red}']);
    const nested = '<style>.outer{color:red}</style><details><summary>【兔子镜：层级】</summary><details><summary>内页</summary><style>.inner{color:blue}</style></details></details>';
    const saved = g.scrubIndependentInteractionState(nested, nested);
    const template = rt.window.document.createElement('template'); template.innerHTML = saved;
    assert.equal(template.content.querySelector('details > details > style').textContent, '.inner{color:blue}');
    assert.equal(template.content.querySelectorAll('style').length, 2);
}));

test('save still removes runtime-only style and controls while restoring the original checked state', withRuntime(async (rt, g) => {
    const baseline = '<style>.author{color:red}</style><details><summary>【兔子镜：状态】</summary><input id="a" type="checkbox"><div class="author">字</div></details>';
    const current = baseline.replace('<input id="a"', '<input checked id="a"').replace('</details>', '<style data-rabbit-mirror-checked-pseudo-rule-rescue>.runtime{color:blue}</style><button data-rabbit-mirror-maintenance-rabbit>维修</button></details>');
    const saved = g.scrubIndependentInteractionState(current, baseline);
    assert.deepEqual(css(saved), ['.author{color:red}']);
    assert.doesNotMatch(saved, /checked|\.runtime|>维修</);
}));

test('already self-contained details and repeated save cycles do not duplicate author CSS', withRuntime(async (rt, g, f) => {
    let html = evidence;
    for (let i = 0; i < 3; i++) {
        html = g.scrubIndependentInteractionState(html, html);
        html = f.faceDetailsListFromHtml(html)[0].detailsHtml;
        assert.deepEqual(css(html), css(evidence));
    }
}));

test('markup preparation still removes scripts and event handlers before a style-preserving save', withRuntime(async (rt, g) => {
    const unsafe = face('安全', 'red').replace('</details>', '<script>alert(1)</script><button onclick="alert(2)">操作</button></details>');
    const prepared = g.prepareIndependentReadyHtml(unsafe);
    const saved = g.scrubIndependentInteractionState(prepared, prepared);
    assert.doesNotMatch(saved, /<script\b|\bonclick=/i);
    assert.equal(css(saved).length, 1);
}));

test('inline-only plain reading face preserves its own styling and gains no interaction', withRuntime(async (rt, g, f) => {
    const html = '<details><summary>【兔子镜：书信】</summary><p style="color:#123456;background:#ffffff">正文</p></details>';
    assert.equal(g.scrubIndependentInteractionState(html, html), html);
    assert.equal(f.scrubSwipeDetailsHtml(html), html);
}));

test('visual detection retains the source palette, animation and interaction evidence after saving', withRuntime(async (rt, g) => {
    const scanner = await rt.load('src/visualScanner.js');
    const wrap = html => `<toto data-rabbit-mirror="true">${html}</toto>`;
    const source = scanner.scanRabbitMirrorHtml(wrap(evidence));
    const saved = scanner.scanRabbitMirrorHtml(wrap(g.scrubIndependentInteractionState(evidence, evidence)));
    assert.deepEqual(saved, source);
    assert.match(saved.signature, /动态效果有/);
    assert.equal(saved.paletteFingerprint.hueFamily, 'orange');
    assert(!saved.riskFlags.includes('missing_visual_program'));
}));

test('save, mount, interaction rescue and current-face export keep the full real stylesheet', withRuntime(async (rt, g) => {
    const saved = g.scrubIndependentInteractionState(evidence, evidence);
    const host = g.buildExternalHost('offline:94:1', saved, 'ready', 'independent', true);
    rt.window.document.body.append(host);
    const ids = await rt.load('src/outputSanitizer/idsAndRearm.js');
    ids.activateRabbitMirrorInteractionRescue(host.querySelector('details'));
    const diagnostics = await rt.load('src/outputSanitizer/diagnostics.js');
    const panel = rt.window.document.createElement('div');
    panel.innerHTML = '<button>复制</button><div data-rm-copy-html-status></div>';
    rt.window.document.body.append(panel);
    let exported = '';
    rt.context.navigator = { clipboard: { writeText: async value => { exported = value; } } };
    await diagnostics.copyRabbitMirrorCurrentFaceHtml(host.querySelector('details'), panel.firstChild, panel);
    assert.equal(css(exported).length, 1);
    assert.equal((exported.match(/@keyframes\b/g) || []).length, 5);
    assert.equal((exported.match(/:checked/g) || []).length, 7);
    assert.match(exported, /#FFE7B3/);
    assert.doesNotMatch(exported, /data-rabbit-mirror-tool-entry-host/);
}));
