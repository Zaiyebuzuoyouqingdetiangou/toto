import test from 'node:test';
import assert from 'node:assert/strict';
import { INTERACTION_RECIPES } from '../data/structured/interactionIndex.js';
import { INTERACTION_MECHANISMS, resolveInteractionDetail } from '../data/raw/rawInteractionRecipes.js';
import { COLOR_FAMILIES } from '../data/structured/generationPaletteIndex.js';
import { COLOR_SCALES } from '../data/structured/generationColorScales.js';
import { composeGenerationPalette } from '../src/generationPalettes.js';
import { eligibleInteractionRecipes, selectInteractionRecipe, interactionRecipeFields, attachInteractionRecipes } from '../src/interactionRecipes.js';

test('64 object/state/result recipes cover eight families with known native mechanisms', () => {
    assert.equal(INTERACTION_RECIPES.length, 64);
    assert.equal(new Set(INTERACTION_RECIPES.map(recipe => recipe.id)).size, 64);
    assert.equal(new Set(INTERACTION_RECIPES.map(recipe => recipe.family)).size, 8);
    for (const recipe of INTERACTION_RECIPES) {
        assert.ok(INTERACTION_MECHANISMS[recipe.mechanism]);
        const detail = resolveInteractionDetail(recipe.id);
        assert.ok(detail.action.trim() && detail.result.trim(), `${recipe.id} needs an operation and a visible result`);
        assert.ok(recipe.universal || recipe.fit.length);
    }
});

test('book form gets native reading/inspection choices rather than unrelated mechanical or weather operations', () => {
    const ids = eligibleInteractionRecipes({ formats: [{ title: '书册', summary: '正文翻阅' }] }).map(recipe => recipe.id);
    assert.ok(ids.includes('page-turn') && ids.includes('marginal-notes'));
    assert.ok(!ids.includes('weather-scene') && !ids.includes('combination-lock') && !ids.includes('motion-reverse'));
    assert.deepEqual(eligibleInteractionRecipes({ presentationMode: 'text' }), []);
});

test('recent selected recipe and within-menu duplicates yield when compatible alternatives exist; exhausted pool still draws', () => {
    const combo = { formats: [{ title: '未见过的外部形式' }] };
    const pool = eligibleInteractionRecipes(combo);
    const first = selectInteractionRecipe(combo, { randomUnit: () => 0 });
    assert.ok(first);
    const next = selectInteractionRecipe(combo, { recent: [{ interactionRecipeId: first.id }], randomUnit: () => 0 });
    assert.notEqual(next.id, first.id);
    assert.ok(selectInteractionRecipe(combo, { usedIds: pool.map(recipe => recipe.id), recent: pool.map(recipe => ({ interactionRecipeId: recipe.id })) }));
});

test('combination ticket affinity uses the actual medium, not its shared scenery base', () => {
    const combo = { visualSceneryCombination: true, atmosphereMenu: Array.from({ length: 4 }, () => ({
        formatIds: ['10.2.2', 'book'], formatFullLines: ['10.2.2 Visual Scenery 风景', 'book 书册'],
    })) };
    attachInteractionRecipes(combo, { randomUnit: () => .9999 });
    for (const ticket of combo.atmosphereMenu) {
        assert.ok(!['weather-scene', 'scroll-panorama', 'motion-play'].includes(ticket.interactionRecipeId));
    }
    assert.equal(new Set(combo.atmosphereMenu.map(ticket => ticket.interactionRecipeId)).size, 4);
});

test('untrusted or obsolete IDs cannot become arbitrary prompt or UI material', () => {
    for (const id of ['<script>bad</script>', '__proto__', 'toString', 'not-in-catalogue', null]) {
        assert.deepEqual(interactionRecipeFields({ interactionRecipeId: id }), {});
    }
    assert.deepEqual(interactionRecipeFields({ interactionRecipeId: 'page-turn', presentationMode: 'text' }), {});
});

function luminance(hex) {
    const channels = hex.slice(1).match(/../g).map(s => parseInt(s, 16) / 255)
        .map(v => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4);
    return channels[0] * .2126 + channels[1] * .7152 + channels[2] * .0722;
}
test('744 source swatches compose readable body, secondary and accent text in both modes', () => {
    assert.equal(COLOR_FAMILIES.length, 31);
    assert.equal(Object.keys(COLOR_SCALES).length, 31);
    let combinations = 0;
    const ratio = (a, b) => (Math.max(luminance(a), luminance(b)) + .05) / (Math.min(luminance(a), luminance(b)) + .05);
    for (const family of COLOR_FAMILIES) for (const mode of ['light', 'dark']) {
        assert.equal(COLOR_SCALES[family.id][mode].length, 12);
        for (const hex of COLOR_SCALES[family.id][mode]) assert.match(hex, /^#[0-9A-F]{6}$/);
        for (const surfaceId of new Set([family.id, family.neutral, 'gray'])) for (const supportId of family.companions) {
            const palette = composeGenerationPalette(family.id, supportId, mode, surfaceId);
            const p = palette.roles;
            for (const ink of [p.text, p.muted]) for (const bg of [p.background, p.surface, p.hover, p.selected]) {
                assert.ok(ratio(ink, bg) >= 4.5, `${palette.id}: ${ink}/${bg} = ${ratio(ink,bg)}`);
            }
            for (const [ink, bg] of [[p.onAccent, p.accent], [p.onAccentHover, p.accentHover], [p.onCompanion, p.companion]]) {
                assert.ok(ratio(ink, bg) >= 4.5, `${palette.id}: filled accent ${ink}/${bg}`);
            }
            assert.ok(mode === 'light' ? luminance(p.background) > .7 : luminance(p.background) < .1);
            combinations++;
        }
    }
    assert.ok(combinations > 400, 'composable references must extend beyond the previous 24 fixed skins');
    assert.equal(composeGenerationPalette('__proto__', 'blue'), null);
});
