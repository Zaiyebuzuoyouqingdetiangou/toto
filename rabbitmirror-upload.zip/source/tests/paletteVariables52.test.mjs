import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const wrap = css => `<toto data-rabbit-mirror="true"><details><summary>兔子镜</summary><style>${css}</style><div class="reader"><p>示例正文</p></div></details></toto>`;
const variableCss = `.reader {--rm-bg-main:#F7F5F9;--rm-text-main:#2D2833;--rm-text-dim:#6B6077;--rm-accent:#7E6399;--rm-accent-light:rgba(126,99,153,.1);--rm-comment-bg:#EBE6F2;--rm-border:#DED8E6;background-color:var(--rm-bg-main)} .header{background:linear-gradient(to bottom,#FFFFFF,var(--rm-bg-main))}.trigger{background:var(--rm-accent-light)}.trigger:hover{background:rgba(126,99,153,.15)}.open{background:var(--rm-accent)}.panel{background:var(--rm-comment-bg)}.badge{background:rgba(126,99,153,.15)}`;
const literalCss = `.reader{background-color:#F7F5F9}.header{background:linear-gradient(to bottom,#FFFFFF,#F7F5F9)}.trigger{background:rgba(126,99,153,.1)}.trigger:hover{background:rgba(126,99,153,.15)}.open{background:#7E6399}.panel{background:#EBE6F2}.badge{background:rgba(126,99,153,.15)}`;

test('variable-based purple sample has the same fingerprint and cooldown as equivalent literal colours', async () => {
    const rt = await createDomRuntime(root);
    try {
        const { scanRabbitMirrorHtml: scan } = await rt.load('src/visualScanner.js');
        const actual = scan(wrap(variableCss)).paletteFingerprint;
        assert.equal(actual.hueFamily, 'purple');
        assert.deepEqual(actual, scan(wrap(literalCss)).paletteFingerprint);
        rt.context.localStorage.setItem('rabbit_mirror_theater:last_combo:v11', JSON.stringify([{historyId:'variable-purple',paletteFingerprint:actual}]));
        const { buildPaletteCooldownRule } = await rt.load('src/paletteCooldown.js');
        assert.match(buildPaletteCooldownRule({darkVisualMode:false},{includeIndexedFamily:true}), /紫色系/);
    } finally { await rt.close(); }
});

test('only referenced variables count; aliases, nested fallback and case-sensitive names resolve', async () => {
    const rt = await createDomRuntime(root);
    try {
        const { scanRabbitMirrorHtml: scan } = await rt.load('src/visualScanner.js');
        const css = `.reader{--unused-background:#8b2635;--Tone:#7E6399;--tone:#113322;--alias:var(--Tone);background:linear-gradient(var(--alias),var(--missing,var(--Tone,rgb(1,2,3))))}`;
        assert.deepEqual(scan(wrap(css)).paletteFingerprint, scan(wrap('.reader{background:linear-gradient(#7E6399,#7E6399)}')).paletteFingerprint);
    } finally { await rt.close(); }
});

test('conflicting scopes and cyclic variables do not invent an observed palette', async () => {
    const rt = await createDomRuntime(root);
    try {
        const { scanRabbitMirrorHtml: scan } = await rt.load('src/visualScanner.js');
        for (const css of ['.a{--x:#ff0000}.b{--x:#00ff00}.reader{background:var(--x)}', '.reader{--x:var(--y);--y:var(--x);background:var(--x)}', '.reader{--unused:#663399;background:var(--unknown)}']) {
            assert.equal(scan(wrap(css)).paletteFingerprint, null);
        }
        assert.deepEqual(scan(wrap('.reader{background:var(--missing,rgb(126,99,153))}')).paletteFingerprint, scan(wrap('.reader{background:rgb(126,99,153)}')).paletteFingerprint);
    } finally { await rt.close(); }
});
