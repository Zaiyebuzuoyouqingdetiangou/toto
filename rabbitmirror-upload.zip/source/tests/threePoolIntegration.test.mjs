import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

// A saved trial setting now migrates to model-original guidance. Keep the
// selection, history, safety and scope invariants while checking that retirement.
const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));
const count = (text, marker) => text.split(marker).length - 1;
async function fixture() {
    const rt = createRuntime(root);
    const builder = await rt.load('src/promptBuilder.js');
    const picker = await rt.load('src/picker.js');
    const storage = await rt.load('src/storage.js');
    const atmosphere = await rt.load('src/atmosphereChoice.js');
    const { defaultSettings } = await rt.load('src/settings.js');
    const settings = { ...copy(defaultSettings), visualDesignMode:'current', postGenerationRecolor:false, userDirectivePriority: false,
        lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100, enhancedVisualDrawing: true,
        rabbitMirrorFaceCount: 1, rabbitMirrorPresentationModes: ['html'] };
    return { rt, builder, picker, storage, atmosphere, settings };
}

for (const route of ['normal', 'independent']) for (const kind of ['ordinary', 'scenery', 'combination']) {
    test(`${route}/${kind}: four frozen triples with no palette reference`, async () => {
        const f = await fixture();
        const plan = f.builder.planRabbitMirrorPromptDetails({ ...f.settings,
            forceVisualScenery: kind === 'scenery', visualSceneryCombination: kind === 'combination' }, route, null, 'triple');
        const out = f.builder.renderRabbitMirrorPromptPlan(plan);
        const menu = out.metadata.atmosphereMenu;
        assert.equal(menu.length, 4);
        assert.ok(menu.every(ticket => ticket.interactionRecipeId), 'each candidate needs its own third draw');
        assert.equal(new Set(menu.map(ticket => ticket.interactionRecipeId)).size, 4);
        assert.equal(count(out.prompt, '交互构造库【'), 1);
        assert.equal(count(out.prompt, '生成配色参考【'), 0);
        assert.equal(count(out.executionLock, '生成配色参考【'), 0);
        assert.equal(count(out.prompt, '复杂交互视觉核心:'), kind === 'ordinary' ? 1 : 0);
        const snapshot = copy(out);
        f.settings.darkVisualMode = true;
        f.storage.setPendingCombo({ themeIds: ['F.0'], formatIds: ['3.3.1'] }, 'other');
        assert.deepEqual(copy(f.builder.renderRabbitMirrorPromptPlan(plan)), snapshot, 'rendering a frozen plan cannot redraw');
    });
}

test('classic original-selection rewrite keeps theme/form while redrawing interaction without a palette', async () => {
    const f = await fixture();
    const result = f.builder.buildRabbitMirrorPromptDetails({ ...f.settings, lotteryMethod: 'classic' }, 'independent', null, 'single');
    assert.ok(result.metadata.interactionRecipeId);
    const repeated = f.picker.pickCombinationForMultifaceResay(f.settings, { preserveSelection: true, faceIndex: 0, faces: [result.metadata] });
    assert.notEqual(repeated.combo.interactionRecipeId, result.metadata.interactionRecipeId);
    assert.equal(repeated.combo.paletteRecipeId,undefined);assert.equal(result.metadata.paletteRecipeId,undefined);
    assert.deepEqual(copy(repeated.combo.themeIds), copy(result.metadata.themeIds));
    assert.deepEqual(copy(repeated.combo.formatIds), copy(result.metadata.formatIds));
});

test('chosen ticket ID reaches compact recipe and completed history, not the unchosen first ticket', async () => {
    const f = await fixture();
    const plan = f.builder.planRabbitMirrorPromptDetails(f.settings, 'independent', null, 'history');
    const result = f.builder.renderRabbitMirrorPromptPlan(plan);
    const chosen = result.metadata.atmosphereMenu[2].interactionRecipeId;
    assert.ok(chosen);
    const applied = f.atmosphere.applyAtmosphereNotes(result.metadata, '<rm-ticket>3</rm-ticket>');
    assert.equal(applied.interactionRecipeId, chosen);
    assert.equal(f.atmosphere.compactAtmosphereMenu(result.metadata.atmosphereMenu)[2].interactionRecipeId, chosen);
    const selection = f.storage.createVisualHistorySelection(f.builder.promptPlanSelections(plan)[0].combo, 'history');
    const resolved = f.storage.resolveVisualHistorySelection(selection, 2);
    assert.equal(resolved.interactionRecipeId, chosen);
    assert.equal(f.storage.commitVisualHistorySelection(resolved, { visualSignature: 'observed' }), true);
    assert.equal(f.storage.getComboHistory(5).at(-1).interactionRecipeId, chosen);
    assert.equal(f.storage.getComboHistory(5).at(-1).interactionFamily, undefined, 'a requested recipe is not observed compliance');
});

test('long text and pure order do not receive random interactions or palette references', async () => {
    const f = await fixture();
    const text = f.builder.buildRabbitMirrorPromptDetails({ ...f.settings, rabbitMirrorPresentationModes: ['longtext'] }, 'independent', null, 'text');
    const order = f.builder.buildRabbitMirrorPromptDetails(f.settings, 'independent', null, 'order', {
        multifaceResay: { pureOrder: true, faceIndex: 0, presentationOverride: 'html', orderText: '按要求画信纸' },
    });
    for (const out of [text, order]) {
        assert.doesNotMatch(out.prompt, /交互构造库【|生成配色参考【/);
        assert.equal(out.metadata.interactionRecipeId, undefined);
    }
});

test('five-round dark cooldown and dark mode survive removal of palette references', async () => {
    const f = await fixture();
    f.rt.store.setItem('rabbit_mirror_theater:last_combo:v11', JSON.stringify([{ paletteFingerprint: {
        brightness: 'dark', confidence: .9, darkAreaRatio: .9, averageLuminance: 20,
    } }]));
    const ordinary = f.builder.buildRabbitMirrorPromptDetails(f.settings, 'independent', null, 'colors');
    const night = f.builder.buildRabbitMirrorPromptDetails({ ...f.settings, darkVisualMode: true }, 'independent', null, 'colors');
    assert.match(ordinary.prompt, /普通模式深色冷却【剩余 5 轮/);
    assert.doesNotMatch(ordinary.prompt, /生成配色参考【/);
    assert.equal(ordinary.metadata.paletteReferenceIds,undefined);
    assert.equal(night.metadata.paletteReferenceIds,undefined);
    assert.doesNotMatch(night.prompt, /普通模式深色冷却/);
    const withoutPalette = menu => copy(menu).map(({ paletteRecipeId, ...ticket }) => ticket);
    assert.deepEqual(withoutPalette(ordinary.metadata.atmosphereMenu), withoutPalette(night.metadata.atmosphereMenu));
});

test('mixed batch commits chosen recipes; re-say varies interaction but retains original form', async () => {
    const f = await fixture();
    const result = f.builder.buildRabbitMirrorPromptDetails({ ...f.settings, rabbitMirrorFaceCount: 3,
        rabbitMirrorPresentationModes: ['html', 'longtext', 'html'] }, 'independent', null, 'independent:mixed',
        { batchIdentity: { mesid: 8, swipeId: 0, sourceHash: 'body' } });
    assert.equal(count(result.prompt, '交互构造库【'), 1);
    assert.doesNotMatch(result.prompt, /生成配色参考【/);
    assert.doesNotMatch(result.prompt.split('交互构造库【')[1].split('\n\n')[0], /第 2 面/);
    assert.equal(result.metadata.faces[1].interactionRecipeId, undefined);
    const menus = result.metadata.faces.map(face => face.atmosphereMenu);
    const applied = f.atmosphere.applyAtmosphereNotes(result.metadata,
        '<toto data-rm-face="1"><rm-ticket>4</rm-ticket></toto><toto data-rm-face="2">故事</toto><toto data-rm-face="3"><rm-ticket>2</rm-ticket></toto>');
    const plan = result.batchPlan;
    assert.equal(f.storage.markPendingBatchAttempt(plan, { transient: true }), true);
    const scanned = plan.faces.map((face, faceIndex) => ({ faceIndex, visualSignature: `actual-${faceIndex}` }));
    assert.equal(f.storage.commitPendingComboBatch(scanned, { ...plan, chosenTickets: [3, null, 1] }), true);
    const history = f.storage.getComboHistory(5);
    assert.equal(history[0].interactionRecipeId, menus[0][3].interactionRecipeId);
    assert.equal(history[1].interactionRecipeId, undefined);
    assert.equal(history[2].interactionRecipeId, menus[2][1].interactionRecipeId);
    const blacklist = await f.rt.load('src/blacklist.js');
    const recipe = blacklist.recipeFromSelectionMetadata(applied, { faceIndex: 2 });
    assert.equal(recipe.interactionRecipeId, menus[2][1].interactionRecipeId);
    const resay = f.picker.pickCombinationForMultifaceResay(f.settings, { preserveSelection: true, faces: applied.faces, faceIndex: 2 });
    assert.notEqual(resay.combo.interactionRecipeId, recipe.interactionRecipeId);
    assert.deepEqual(copy(resay.combo.formatIds), copy(recipe.formatIds));
});

test('legacy pending ticket resolution preserves chosen recipe and no heavy catalogue enters completed history', async () => {
    const f = await fixture();
    const out = f.builder.buildRabbitMirrorPromptDetails(f.settings, 'normal', null, 'follow');
    assert.equal(f.storage.retargetPendingAtmosphereTicket(1), true);
    assert.equal(f.storage.commitPendingCombo('observed'), true);
    const last = f.storage.getComboHistory(1)[0];
    assert.equal(last.interactionRecipeId, out.metadata.atmosphereMenu[1].interactionRecipeId);
    for (const key of ['themes', 'formats', 'atmosphereMenu', 'action', 'result', 'mechanisms']) assert.equal(last[key], undefined);
});

test('explicit HTML/long-text override never leaks an interaction into prose or omits a new HTML draw', async () => {
    const f = await fixture();
    const out = f.builder.buildRabbitMirrorPromptDetails({ ...f.settings, lotteryMethod: 'classic' }, 'independent', null, 'override');
    const asText = f.picker.pickCombinationForMultifaceResay(f.settings, { faceIndex: 0, faces: [out.metadata], presentationOverride: 'longtext' });
    assert.equal(asText.combo.presentationMode, 'text');
    assert.equal(asText.combo.interactionRecipeId, undefined);
    const asHtml = f.picker.pickCombinationForMultifaceResay(f.settings, { faceIndex: 0, faces: [asText.combo], presentationOverride: 'html' });
    assert.equal(asHtml.combo.presentationMode, 'html');
    assert.ok(asHtml.combo.interactionRecipeId || asHtml.combo.atmosphereMenu?.every(ticket=>ticket.interactionRecipeId));
});
