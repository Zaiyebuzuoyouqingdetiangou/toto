import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const modes = {
    ordinary: {},
    visual: { forceVisualScenery: true },
    combined: { forceVisualScenery: true, visualSceneryCombination: true },
    enhanced: { enhancedVisualDrawing: true },
    combinedEnhanced: { forceVisualScenery: true, visualSceneryCombination: true, enhancedVisualDrawing: true },
};
for (const type of ['normal', 'independent']) for (const [name, options] of Object.entries(modes)) {
    test(`${type} actual ${name} draw supplies four complete story candidates`, async () => {
        const rt = createRuntime(root);
        const config = await rt.load('src/settings.js');
        const builder = await rt.load('src/promptBuilder.js');
        const settings = { ...structuredClone(config.defaultSettings), userDirectivePriority: false,
            lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100,
            rabbitMirrorPresentationModes: ['html'], ...options };
        const plan = builder.planRabbitMirrorPromptDetails(settings, type, null, 'same-story-and-switches');
        const rendered = builder.renderRabbitMirrorPromptPlan(plan);
        const menu = rendered.metadata.atmosphereMenu;
        assert.equal(menu?.length, 4);
        assert.equal(new Set(menu.map(t => JSON.stringify([t.themeIds, t.formatIds]))).size, 4);
        assert.match(rendered.prompt, /按正文挑签/);
        for (const ticket of menu) {
            assert.ok(ticket.themeIds.length > 0);
            assert.ok(ticket.formatIds.length > 0);
            if (options.forceVisualScenery) assert.ok(ticket.formatIds.includes('10.2.2'));
            if (options.visualSceneryCombination) assert.ok(ticket.formatIds.some(id => id !== '10.2.2'));
            for (const line of ticket.formatLines) assert.ok(rendered.prompt.includes(line.split('：')[0]));
        }
        const choice = await rt.load('src/atmosphereChoice.js');
        const html = '<toto><rm-think data-source="story">本轮正文的动作与第四签的形式相符。</rm-think><rm-ticket data-source="story">4</rm-ticket><details>正文</details></toto>';
        const saved = choice.applyAtmosphereNotes(rendered.metadata, html);
        assert.equal(saved.atmosphereChoice, 3);
        assert.equal(saved.atmosphereReason, '本轮正文的动作与第四签的形式相符。');
        assert.deepEqual([...saved.formatIds], [...menu[3].formatIds]);
        assert.doesNotMatch(choice.stripAtmosphereChoiceMarkup(html), /rm-think|rm-ticket|本轮正文的动作/);
    });
}

async function makePlan(overrides = {}, configure) {
    const rt = createRuntime(root);
    const config = await rt.load('src/settings.js');
    const builder = await rt.load('src/promptBuilder.js');
    const settings = { ...structuredClone(config.defaultSettings), userDirectivePriority: false,
        lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100, singlePairSampling: true,
        rabbitMirrorPresentationModes: ['html','html','html','html','html'], ...overrides };
    const materials = configure ? await configure(rt,settings) : undefined;
    const plan = builder.planRabbitMirrorPromptDetails(settings, 'independent', null, 'boundary-story',
        { batchIdentity: {mesid:8, swipeId:0, sourceHash:'same-body'} });
    return { rt, plan, result: builder.renderRabbitMirrorPromptPlan(plan, materials) };
}

test('five dynamic combination faces each keep their own menus and selected reasons', async () => {
    const f = await makePlan({rabbitMirrorFaceCount:5, forceVisualScenery:true, visualSceneryCombination:true});
    const faces = f.result.metadata.faces;
    assert.equal(faces.length,5);
    for (const face of faces) {
        assert.equal(face.atmosphereMenu?.length,4);
        for (const ticket of face.atmosphereMenu) assert.ok(ticket.formatIds.includes('10.2.2'));
    }
    const choices = await f.rt.load('src/atmosphereChoice.js');
    const selected = choices.applyAtmosphereNotes(f.result.metadata, faces.map((_,i)=>
        `<toto data-rm-face="${i+1}"><rm-think class="choice">第${i+1}面理由</rm-think><rm-ticket>${i%4+1}</rm-ticket><details>作品</details></toto>`).join(''));
    selected.faces.forEach((face,i)=>{
        assert.equal(face.atmosphereChoice,i%4);
        assert.equal(face.atmosphereReason,`第${i+1}面理由`);
        assert.deepEqual([...face.formatIds],[...faces[i].atmosphereMenu[i%4].formatIds]);
    });
});

test('format-only plus fixed scenery does not invent four identical choices', async () => {
    const f = await makePlan({samplingMode:'format_only', forceVisualScenery:true});
    assert.equal(f.result.metadata.atmosphereMenu,undefined);
    assert.deepEqual([...f.result.metadata.formatIds],['10.2.2']);
});

test('format-only combination still offers four distinct variable forms', async () => {
    const f = await makePlan({samplingMode:'format_only', forceVisualScenery:true,visualSceneryCombination:true});
    const menu=f.result.metadata.atmosphereMenu;
    assert.equal(menu?.length,4);
    assert.ok(menu.every(ticket=>ticket.themeIds.length===0 && ticket.formatIds.includes('10.2.2')));
    assert.equal(new Set(menu.flatMap(ticket=>ticket.formatIds.filter(id=>id!=='10.2.2'))).size,4);
});

test('small theme pool stops at real distinct candidates without dropping fixed scenery', async () => {
    const f=await makePlan({forceVisualScenery:true},async(rt,settings)=>{
        const {THEMATIC_CATEGORIES}=await rt.load('data/structured/thematicIndex.js');
        const keep=new Set(THEMATIC_CATEGORIES.filter(item=>!item.tags.includes('if')).slice(0,2).map(item=>item.id));
        settings.blacklistedThemeIds=THEMATIC_CATEGORIES.filter(item=>!keep.has(item.id)).map(item=>item.id);
    });
    assert.equal(f.result.metadata.atmosphereMenu?.length,2);
});

test('random method and IF branch remain local selections without story menus', async () => {
    for (const switches of [{lotteryMethod:'random'}, {atmosphereStoryPercent:0}]) {
        const f=await makePlan({...switches,forceVisualScenery:true});
        assert.equal(f.result.metadata.atmosphereMenu,undefined);
        assert.doesNotMatch(f.result.prompt,/按正文挑签：/);
    }
});

test('external-only candidate pools honor in-menu exclusions even with no builtin entries', async () => {
    for (const size of [2,12]) for (const options of [{}, {forceVisualScenery:true}, {forceVisualScenery:true,visualSceneryCombination:true}]) {
        const f=await makePlan({...options,externalWorldBookRandomEnabled:true,externalWorldBookMixMode:'external-only'},async(rt,settings)=>{
            const pool=await rt.load('src/externalWorldBook/externalPool.js');
            const {THEMATIC_CATEGORIES}=await rt.load('data/structured/thematicIndex.js');
            const {PRESENTATION_FORMATS}=await rt.load('data/structured/presentationIndex.js');
            settings.blacklistedThemeIds=THEMATIC_CATEGORIES.map(item=>item.id);
            settings.blacklistedFormatIds=PRESENTATION_FORMATS.filter(item=>item.id!=='10.2.2').map(item=>item.id);
            const items = ['theme','format'].flatMap(classification=>Array.from({length:size},(_,i)=>({
                    externalId:`ext:fixture:${classification}:${i}`,classification,enabled:true,userConfirmed:true,
                    localTitle:`${classification}${i}`,summary:'测试条目',sourceKeywords:[],rawContent:'可核对的外部母本文本',
                })));
            pool.setExternalPoolSnapshot([{libraryId:'fixture',enabled:true}],new Map([['fixture',items]]));
            return new Map(items.map(item=>[item.externalId,item]));
        });
        const menu=f.result.metadata.atmosphereMenu;
        assert.equal(menu?.length,Math.min(4,size),JSON.stringify(options));
        assert.equal(new Set(menu.flatMap(ticket=>ticket.themeIds)).size,menu.length);
        if (!options.forceVisualScenery || options.visualSceneryCombination)
            assert.equal(new Set(menu.flatMap(ticket=>ticket.formatIds.filter(id=>id!=='10.2.2'))).size,menu.length);
    }
});
