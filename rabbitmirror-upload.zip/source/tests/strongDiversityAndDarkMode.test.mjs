import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';

// A saved trial setting now migrates to model-original guidance. Keep the
// selection, history, safety and scope invariants while checking that retirement.
const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
async function fixture() {
    const rt = createRuntime(root);
    const config = await rt.load('src/settings.js');
    const storage = await rt.load('src/storage.js');
    const builder = await rt.load('src/promptBuilder.js');
    return { rt, config, storage, builder, settings: { ...structuredClone(config.defaultSettings), visualDesignMode:'current',
        userDirectivePriority: false, visualPromptEditingEnabled: false, avoidRepeat: false,
        behaviorRuleMode: 'off', rabbitMirrorPresentationModes: ['html'] } };
}
function record(f, palette, recipe = {}) {
    f.storage.setPendingCombo({ themeIds: ['C.1.5'], formatIds: ['6.1.1'], ...recipe });
    f.storage.commitPendingCombo('actual completed face',
        'surface_family: surface: paper_or_document_surface；space_family: space: layered_depth_or_spatial_scene',
        [], palette, { id: 'tabbed_radio_family', label: '并列标签／多按钮切页', confidence: 1 });
}
const palette = { brightness: 'light', hueFamily: 'yellow', temperature: 'warm', saturation: 'low', confidence: .9,
    averageLuminance: 220, darkAreaRatio: 0 };

test('legacy false migrates to strong default; dark mode saves independently of visual editor', async () => {
    const f = await fixture();
    assert.equal(f.config.getSettings().darkVisualMode, false);
    f.config.updateSettings({ avoidRepeat: false, darkVisualMode: true, visualPromptEditingEnabled: false,
        visualExtraPrompt: '深色墨绿，保留木质纹理' });
    const saved = f.config.getSettings();
    assert.equal(saved.avoidRepeat, true);
    assert.equal(saved.darkVisualMode, true);
    assert.equal(saved.visualPromptEditingEnabled, false);
    assert.equal(saved.visualExtraPrompt, '深色墨绿，保留木质纹理');
    f.config.updateSettings({ darkVisualMode: false });
    assert.equal(f.config.getSettings().darkVisualMode, false);
    assert.equal(f.config.getSettings().avoidRepeat, true);
});

test('dark control is visible in drawing settings and its real handler saves', async () => {
    const f = await fixture();
    const ui = readFileSync(root + '/src/ui.js', 'utf8');
    const template = readFileSync(root + '/src/ui/settingsTemplate.js', 'utf8');
    assert.doesNotMatch(template, /id="rh_avoid_repeat"/);
    assert.match(template, /id="rh_dark_visual_mode"/);
    assert.match(readFileSync(root + '/src/settingsAppearance.js', 'utf8'), /withNote\('rh_dark_visual_mode','drawing'\)/);
    const handler = ui.match(/^\s*\$\('#rh_dark_visual_mode'\)\.on\('change'.*$/m)?.[0];
    assert.ok(handler);
    let change;
    vm.runInNewContext(handler, { $: () => ({ on: (_event, callback) => { change = callback; } }), updateSettings: f.config.updateSettings });
    change({ target: { checked: true } });
    assert.equal(f.config.getSettings().darkVisualMode, true);
    change({ target: { checked: false } });
    assert.equal(f.config.getSettings().darkVisualMode, false);
});

test('a single warm palette enters avoidance; a dark face does not ban future dark backgrounds', async () => {
    const f = await fixture();
    const p = await f.rt.load('src/paletteCooldown.js');
    record(f, palette);
    assert.match(p.buildPaletteCooldownRule({ avoidRepeat: false }), /高明度暖黄低饱和/);
    record(f, { ...palette, brightness: 'dark', hueFamily: 'blue', temperature: 'cool', averageLuminance: 50, darkAreaRatio: .8 });
    const rule = p.buildPaletteCooldownRule({ darkVisualMode: true });
    assert.match(rule, /低明度冷蓝低饱和/);
    assert.doesNotMatch(rule, /低明度主承载仍|禁止再次使用大面积深色|深色只作局部/);
});

for (const route of ['normal', 'independent']) for (const modes of [['html'], ['html', 'html'], ['html', 'longtext'], ['longtext']]) {
    test(`strong diversity and dark mode reach ${route} ${modes.join('+')} with visual editor off`, async () => {
        const f = await fixture(); record(f, palette);
        const result = f.builder.buildRabbitMirrorPromptDetails({ ...f.settings, darkVisualMode: true,
            rabbitMirrorFaceCount: modes.length, rabbitMirrorPresentationModes: modes }, route, null, 'same-body');
        assert.equal((result.prompt.match(/默认强避重【/g) || []).length, 1);
        assert.equal((result.prompt.match(/深色生成模式【/g) || []).length, 1);
        const historyMarker = modes.includes('html') ? /配色短冷却【/g : /配色短冷却【/g;
        assert.equal((result.prompt.match(historyMarker) || []).length, 1, 'actual palette history is shared once across HTML and text');
        assert.match(result.prompt, /高明度暖黄低饱和/);
        assert.match(result.executionLock, /深色模式/);
        assert.match(result.prompt, /材质/);
        assert.doesNotMatch(result.prompt + result.executionLock, /至少一面.*(?:明亮|中高明度)|低明度主承载仍/);
        assert.equal(result.metadata.darkVisualMode, true);
        assert.equal(result.metadata.strongDiversity, true);
    });
}

test('locked scenery and enhanced drawing remain, four story tickets keep their selection protocol', async () => {
    const f = await fixture();
    record(f, palette, { formatIds: ['10.2.2'] });
    const result = f.builder.buildRabbitMirrorPromptDetails({ ...f.settings, darkVisualMode: true,
        forceVisualScenery: true, visualSceneryCombination: true, enhancedVisualDrawing: true,
        lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100 }, 'independent', null, 'story');
    assert.equal(result.metadata.atmosphereMenu.length, 4);
    for (const ticket of result.metadata.atmosphereMenu) assert.ok(ticket.formatIds.includes('10.2.2'));
    assert.match(result.prompt, /按正文挑签/);
    assert.equal((result.prompt.match(/增强视觉绘制：/g) || []).length, 1);
    assert.match(result.prompt, /可自由组合 HTML、CSS 与安全内联 SVG/);
    assert.match(result.prompt, /保留用户指定、视觉偏好、形式固有特征与已启用能力/);
});

test('random selection excludes a recent family before favorite weights, legacy false cannot disable it', async () => {
    const f = await fixture();
    const picker = await f.rt.load('src/picker.js');
    const { PRESENTATION_FORMATS: formats } = await f.rt.load('data/structured/presentationIndex.js');
    const { THEMATIC_CATEGORIES: themes } = await f.rt.load('data/structured/thematicIndex.js');
    const usable = themes.filter(item => !item.tags.includes('if'));
    const family = id => id.split('.').slice(0, 2).join('.');
    const first = usable.find(item => usable.some(other => other.id !== item.id && family(other.id) === family(item.id)));
    const sibling = usable.find(item => item.id !== first.id && family(item.id) === family(first.id));
    const different = usable.find(item => family(item.id) !== family(first.id));
    const themeIds = [first.id, sibling.id, different.id];
    record(f, palette, { themeIds: [first.id], formatIds: ['1.9'] });
    f.rt.context.crypto = { getRandomValues(array) { array.fill(0); return array; } };
    const selected = picker.pickCombination({ ...f.settings, singlePairSampling: true,
        blacklistedFormatIds: formats.filter(item => !['1.9', '1.9.1', '8.3'].includes(item.id)).map(item => item.id),
        blacklistedThemeIds: themes.filter(item => !themeIds.includes(item.id)).map(item => item.id),
        favoriteFormatIds: ['1.9.1'], favoriteFormatMultipliers: { '1.9.1': 50 },
        favoriteThemeIds: [sibling.id], favoriteThemeMultipliers: { [sibling.id]: 50 },
    }, 'strong-random').combo;
    assert.deepEqual([...selected.formatIds], ['8.3']);
    assert.deepEqual([...selected.themeIds], [different.id]);
    const restored = picker.pickCombinationForMultifaceResay(f.settings, { preserveSelection: true, faceIndex: 0, faces: [{
        themeIds: [first.id], formatIds: ['1.9'], presentationMode: 'html', requestedPresentationMode: 'html', samplingMode: 'classic',
    }] }).combo;
    assert.deepEqual([...restored.formatIds], ['1.9'], 'user-restored exact recipe is exempt');
    assert.deepEqual([...restored.themeIds], [first.id]);
});

test('small pools consume the remaining fresh format before reopening history to fill slots', async () => {
    const f = await fixture();
    const picker = await f.rt.load('src/picker.js');
    const { PRESENTATION_FORMATS: formats } = await f.rt.load('data/structured/presentationIndex.js');
    record(f, palette, { formatIds: ['1.9', '3.7'] });
    const settings = { ...f.settings, formatsMin: 2, formatsMax: 2,
        blacklistedFormatIds: formats.filter(item => !['1.9', '3.7', '8.3'].includes(item.id)).map(item => item.id) };
    const selected = picker.pickCombination(settings, 'exhausted').combo;
    assert.equal(selected.formatIds.length, 2);
    assert.ok(selected.formatIds.includes('8.3'));
    assert.equal(new Set(selected.formatIds).size, 2);
    settings.blacklistedFormatIds = formats.filter(item => item.id !== '1.9').map(item => item.id);
    const single = picker.pickCombination(settings, 'single-entry').combo;
    assert.deepEqual([...single.formatIds], ['1.9']);
});

test('pure order retains requested format and gets dark mode without drawing new tickets', async () => {
    const f = await fixture();
    const result = f.builder.buildRabbitMirrorPromptDetails({ ...f.settings, darkVisualMode: true }, 'independent', null, 'order',
        { multifaceResay: { faceIndex: 0, pureOrder: true, presentationOverride: 'html', orderText: '只做一本可以阅读的木刻书' } });
    assert.match(result.prompt, /深色生成模式/);
    assert.match(result.executionLock, /深色模式/);
    assert.equal(result.metadata.atmosphereMenu, undefined);
});

test('generic depth, darkness and gradient are diagnostics, never capability cooldowns', async () => {
    const f = await fixture();
    for (const surface of ['surface: digital_dark_surface', 'surface: gradient_or_light_surface']) {
        const cooled = f.storage.visualFamilyForCooldown({ surface_family: surface,
            contrast_family: 'contrast: dark_weighted', space_family: 'space: layered_depth_or_spatial_scene',
            reading_family: '同位置切页' });
        assert.deepEqual(Object.keys(cooled), ['reading_family']);
    }
});

test('dark mode is frozen per request, invalidates early preparation, and is present in evidence', async () => {
    const f = await fixture();
    const settings = { ...f.settings, darkVisualMode: true };
    const plan = f.builder.planRabbitMirrorPromptDetails(settings, 'independent', null, 'frozen');
    settings.darkVisualMode = false;
    const result = f.builder.renderRabbitMirrorPromptPlan(plan);
    assert.equal(result.metadata.darkVisualMode, true);
    assert.match(result.prompt, /深色生成模式/);
    const next = f.builder.buildRabbitMirrorPromptDetails(settings, 'independent', null, 'next');
    assert.equal(next.metadata.darkVisualMode, false);
    assert.doesNotMatch(next.prompt, /深色生成模式【/);
    const source = readFileSync(root + '/src/independentApi/mount.js', 'utf8');
    const fn = source.match(/^(?:export )?function earlyBodyConfigSignature\([^]*?^}\r?$/m)?.[0]?.replace(/^export /, '');
    assert.ok(fn);
    const context = vm.createContext({});
    vm.runInContext(fn, context);
    assert.notEqual(context.earlyBodyConfigSignature(settings), context.earlyBodyConfigSignature({ ...settings, darkVisualMode: true }));
    const evidence = await f.rt.load('src/generationEvidence.js');
    evidence.armGenerationEvidence();
    evidence.claimGenerationEvidence({ settings: { ...settings, darkVisualMode: true, avoidRepeat: true } });
    const saved = JSON.parse(evidence.exportGenerationEvidence());
    assert.equal(saved.context.settings.darkVisualMode, true);
    assert.equal(saved.context.settings.avoidRepeat, true);
});
