import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

test('update entry visibly reports the loaded runtime version independently of button/status text', async () => {
    const root = fileURLToPath(new URL('..', import.meta.url));
    const rt = createRuntime(root);
    const ui = await rt.load('src/ui/settingsTemplate.js');
    const runtime = await rt.load('src/ui/runtime.js');
    const manifest = JSON.parse(readFileSync(root+'/manifest.json','utf8'));
    const html = ui.buildRabbitMirrorSettingsDialogHtml();
    const label = html.match(/<span\b[^>]*id="rh_current_version"[^>]*>([^<]+)<\/span>/);
    assert.ok(label);
    assert.equal(label[1], `当前页面版本：${runtime.RUNTIME_VERSION}`);
    assert.equal(runtime.RUNTIME_VERSION,manifest.version);
    assert.doesNotMatch(label[0], /\bhidden\b|display:\s*none/);
    assert.match(html, /<button id="rh_update_now"[^>]*>检查并更新<\/button>/);
});
