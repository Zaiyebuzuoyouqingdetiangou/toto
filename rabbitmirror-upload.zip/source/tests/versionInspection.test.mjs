import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const source = readFileSync(path.join(root, 'src/extensionUpdater.js'), 'utf8');
const updater = await import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'));
const moduleUrl = 'https://host.invalid/scripts/extensions/third-party/toto/src/extensionUpdater.js?rmv=1';
const reply = body => new Response(JSON.stringify(body), { headers: { 'Content-Type': 'application/json' } });

test('version inspection identifies stale runtime versus installed files and current branch without updating', async () => {
    const calls = [];
    const result = await updater.inspectRabbitMirrorVersion({ moduleUrl, pageVersion: '1.62.21', uiVersion: '1.62.21', apiVersion: '1.62.21',
        getHeaders: () => ({ 'X-Test-CSRF': 'test' }), fetchImpl: async (url, init) => {
            calls.push({ url, init });
            if (url.includes('/manifest.json?')) { assert.equal(init.cache, 'no-store'); return reply({ version: '1.62.22' }); }
            if (url === '/api/extensions/discover') return reply([{ name: 'third-party/toto', type: 'global' }, { name: 'third-party/toto', type: 'local' }]);
            assert.equal(url, '/api/extensions/version');
            assert.deepEqual(JSON.parse(init.body), { extensionName: 'toto', global: false });
            return reply({ currentBranchName: 'from-nancy-test', currentCommitHash: 'b2911a5c6648cd77ce12125434fbdb8d7e35d04d' });
        } });
    assert.equal(result.installedVersion, '1.62.22');
    assert.equal(result.apiVersion, '1.62.21');
    assert.equal(result.branch, 'from-nancy-test');
    assert.equal(result.installType, 'local');
    assert.match(updater.formatRabbitMirrorVersionStatus(result), /版本不一致/);
    assert.equal(calls.length, 3);
    assert.ok(calls.every(c => !/\/(?:update|delete|install|switch)/.test(c.url)));
});

test('unsupported host Git inspection does not hide the served installation version', async () => {
    const result = await updater.inspectRabbitMirrorVersion({ moduleUrl, pageVersion: '1.62.22', uiVersion: '1.62.22', apiVersion: '1.62.22',
        fetchImpl: async url => url.includes('/manifest.json?') ? reply({ version: '1.62.22' }) : new Response('', { status: 404 }) });
    assert.equal(result.installedVersion, '1.62.22');
    assert.equal(result.warnings.length, 1);
    assert.match(updater.formatRabbitMirrorVersionStatus(result), /分支：未知/);
});

test('missing manifest or missing runtime is not reported as a confirmed match', async () => {
    const result = await updater.inspectRabbitMirrorVersion({ moduleUrl, apiVersion: '1.62.22',
        fetchImpl: async () => new Response('', { status: 404 }) });
    assert.equal(result.installedVersion, '');
    assert.match(updater.formatRabbitMirrorVersionStatus(result), /暂不能确认/);
});

test('wrong installation URL is rejected before any host request', async () => {
    let calls = 0;
    await assert.rejects(updater.inspectRabbitMirrorVersion({ moduleUrl: 'https://host.invalid/other/updater.js',
        fetchImpl: async () => { calls++; return reply({}); } }), /无法确认当前安装目录/);
    assert.equal(calls, 0);
});
