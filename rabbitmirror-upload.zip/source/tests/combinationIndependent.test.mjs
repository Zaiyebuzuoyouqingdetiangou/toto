import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const clone = value => JSON.parse(JSON.stringify(value));
async function fixture(overrides = {}) {
    const rt = createRuntime(root);
    const config = await rt.load('src/settings.js');
    const builder = await rt.load('src/promptBuilder.js');
    const settings = { ...clone(config.defaultSettings), enabled: true, autoRabbitMirrorInjection: true,
        mode: 'all', userDirectivePriority: false, forceVisualScenery: false, visualSceneryCombination: true,
        rabbitMirrorPresentationModes: ['html'], formatsMin: 1, formatsMax: 1, ...overrides };
    return { rt, config, builder, settings };
}
for (const route of ['normal', 'independent']) for (const lotteryMethod of ['random', 'atmosphere']) {
    test(`combination alone fixes scenery and retains other formats: ${route}/${lotteryMethod}`, async () => {
        const f = await fixture({ lotteryMethod, atmosphereStoryPercent: 100, enhancedVisualDrawing: true });
        const before = JSON.stringify(f.settings);
        const plan = f.builder.planRabbitMirrorPromptDetails(f.settings, route, null, 'combination-alone');
        const result = f.builder.renderRabbitMirrorPromptPlan(plan);
        assert.equal(result.metadata.forcedVisualScenery, true);
        assert.equal(result.metadata.visualSceneryCombination, true);
        const tickets = result.metadata.atmosphereMenu || [result.metadata];
        if (lotteryMethod === 'atmosphere') assert.equal(tickets.length, 4);
        for (const t of tickets) {
            assert.equal(t.formatIds.filter(id => id === '10.2.2').length, 1);
            assert.ok(t.formatIds.some(id => id !== '10.2.2'), 'another format must still be drawn');
        }
        assert.equal(result.prompt.split('动态视觉组合【本面冻结').length - 1, 1);
        assert.equal(result.prompt.split('增强视觉绘制：').length - 1, 1);
        assert.equal(JSON.stringify(f.settings), before, 'do not rewrite saved flags');
        f.settings.visualSceneryCombination = false;
        assert.equal(f.builder.renderRabbitMirrorPromptPlan(plan).prompt, result.prompt, 'in-flight plan stays frozen');
    });
}
test('combination-only mixed batch fixes the visual item for every HTML face, never longtext', async () => {
    const f = await fixture({ rabbitMirrorFaceCount: 3, rabbitMirrorPresentationModes: ['html', 'longtext', 'html'] });
    const result = f.builder.buildRabbitMirrorPromptDetails(f.settings, 'independent', null, 'combined-mixed',
        { batchIdentity: { mesid: 10, swipeId: 0, sourceHash: 'fixed' } });
    assert.equal(result.metadata.faces.length, 3);
    for (const i of [0, 2]) {
        assert.equal(result.metadata.faces[i].forcedVisualScenery, true);
        assert.ok(result.metadata.faces[i].formatIds.includes('10.2.2'));
        assert.ok(result.metadata.faces[i].formatIds.some(id => id !== '10.2.2'));
    }
    assert.equal(result.metadata.faces[1].presentationMode, 'text');
    assert.equal(result.metadata.faces[1].forcedVisualScenery, false);
    assert.notEqual(result.metadata.faces[1].visualSceneryCombination, true);
});
test('pure order keeps its no-lottery boundary even when combination alone is set', async () => {
    const f = await fixture();
    const picker = await f.rt.load('src/picker.js');
    const result = picker.buildPureOrderSelection(f.settings, { presentationOverride: 'html', orderText: '做一封信' });
    assert.equal(result.combo.forcedVisualScenery, false);
    assert.equal(result.combo.formatIds.length, 0);
});

test('combination-only changes invalidate the early-body configuration snapshot',()=>{
    const source=readFileSync(root+'/src/independentApi/mount.js','utf8');
    const code=source.match(/^export function earlyBodyConfigSignature\([^]*?^}\r?$/m)?.[0];
    assert.ok(code);
    const context=vm.createContext({});
    vm.runInContext(code.replace(/^export /,''),context);
    const a=context.earlyBodyConfigSignature({forceVisualScenery:false,visualSceneryCombination:false});
    const b=context.earlyBodyConfigSignature({forceVisualScenery:false,visualSceneryCombination:true});
    assert.notEqual(a,b);
});
