import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_TEST_SOURCE_ROOT || fileURLToPath(new URL('..', import.meta.url));

test('all 16 new interactions are reachable by a random index draw, resolve by ID, and yield to fresh alternatives', async () => {
  const rt = createRuntime(root);
  const { INTERACTION_RECIPES } = await rt.load('data/structured/interactionIndex.js');
  const api = await rt.load('src/interactionRecipes.js');
  const { resolveInteractionDetail } = await rt.load('data/raw/rawInteractionRecipes.js');
  const added = INTERACTION_RECIPES.filter(item => Number(item.code.slice(2)) >= 49);
  assert.equal(added.length, 16);
  for (const item of added) {
    const combo = { formats: [{ title: item.fit.join(' ') }] };
    const draws = new Set(Array.from({ length: 201 }, (_, i) => api.selectInteractionRecipe(combo, { randomUnit: () => i / 201 }).id));
    assert.ok(draws.has(item.id), item.id + ' is reachable');
    const detail = resolveInteractionDetail(item.id);
    assert.ok(detail.action && detail.result);
    for (const random of [0, .2, .5, .8, .999]) {
      const next = api.selectInteractionRecipe(combo, { randomUnit: () => random, recent: [{ interactionRecipeIds: [item.id] }] });
      assert.notEqual(next.id, item.id, item.id + ' cools down when alternatives exist');
    }
  }
});

test('a newly selected ID sends only its indexed summary or detail; full mode adds its native mechanism once', async () => {
  const rt = createRuntime(root);
  const { INTERACTION_RECIPES } = await rt.load('data/structured/interactionIndex.js');
  const { buildInteractionRecipeRule } = await rt.load('src/interactionRecipes.js');
  for (const item of INTERACTION_RECIPES.slice(48)) {
    for (const rawPolicy of ['compact', 'balanced', 'full']) {
      const prompt = buildInteractionRecipeRule([{ combo: { interactionRecipeIds: [item.id] } }], rawPolicy);
      const codes = [...new Set(prompt.match(/I\.\d{2}/g))];
      assert.deepEqual(codes, [item.code]);
      assert.ok(prompt.includes(item.summary));
      if (rawPolicy === 'compact') assert.doesNotMatch(prompt, /操作：|可见结果：|本轮实现依据/);
      else assert.match(prompt, /操作：.*\n可见结果：/);
      if (rawPolicy === 'full') assert.equal((prompt.match(/本轮实现依据/g) || []).length, 1);
    }
  }
});

test('the expanded pool still isolates text and pure orders and binds different candidate sets', async () => {
  const rt = createRuntime(root);
  const api = await rt.load('src/interactionRecipes.js');
  assert.equal(api.eligibleInteractionRecipes({ presentationMode: 'text' }).length, 0);
  assert.equal(api.eligibleInteractionRecipes({ pureOrder: true }).length, 0);
  const combo = { atmosphereMenu: Array.from({ length: 4 }, () => ({ formatIds: ['10.2.2'], formatFullLines: ['Visual Scenery 风景 场景 物件'] })) };
  let n = 0;
  api.attachInteractionRecipes(combo, { randomUnit: () => [0.95, 0.2, 0.7, 0.99][n++ % 4] });
  assert.equal(combo.interactionRecipeId, undefined);
  const firsts = combo.atmosphereMenu.map(ticket => ticket.interactionRecipeIds[0]);
  assert.equal(new Set(firsts).size, 4);
});
