import assert from 'node:assert/strict';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const skip = !process.env.RM_TEST_DOM_MODULE;

test('evidence UI and exported report show duration and clear safely', { skip }, async () => {
    const rt = await createDomRuntime(root);
    try {
        const e = await rt.load('src/generationEvidence.js'), ui = await rt.load('src/ui/generationEvidence.js');
        const container = rt.window.document.createElement('div');
        container.innerHTML = ['start', 'download', 'copy', 'clear'].map(id => `<button id="rh_generation_evidence_${id}"></button>`).join('')
            + '<div id="rh_generation_evidence_status"></div><textarea id="rh_generation_evidence_output"></textarea>';
        rt.window.document.body.appendChild(container);
        ui.mountGenerationEvidenceUi(container, () => ({ generationSource: 'independent' }));
        e.armGenerationEvidence(); const handle = e.claimGenerationEvidence({ owner: { mesid: 94 } });
        handle.request({ messages: [{ role: 'user', content: '固定正文' }] });
        rt.setNow(1790805495654); handle.response({ text: '<toto>回复</toto>' });
        rt.setNow(1790805495691); handle.processed('<details>处理完成</details>');
        rt.setNow(1790805495692); handle.finish();
        assert.match(container.querySelector('#rh_generation_evidence_status').textContent, /取证完成.*40\.9 秒/);
        const exported = JSON.parse(e.exportGenerationEvidence());
        assert.equal(exported.timing.requestToResponseMs, 40893);
        assert.equal(exported.timing.responseToProcessedMs, 37);
        assert.equal(container.querySelector('#rh_generation_evidence_download').disabled, false);
        e.clearGenerationEvidence();
        assert.match(container.querySelector('#rh_generation_evidence_status').textContent, /未开启/);
        assert.equal(container.querySelector('#rh_generation_evidence_download').disabled, true);
        ui.destroyGenerationEvidenceUi();
    } finally { await rt.close(); }
});

// These are structural/CSSOM preservation checks, not a real browser or TT
// acceptance test and not a reproduction of the user's complete 7,975-char reply.
test('sibling CSS survives real prepare, mount, rescue and current-face export', { skip }, async () => {
    const rt = await createDomRuntime(root);
    try {
        const g = await rt.load('src/independentApi/geometry.js');
        const input = '<style>.scene{position:relative;height:520px;background:#16120C;color:#FFE7B3}.switch{display:none}.ring{border:2px solid #FFC53D;animation:spin 3s infinite}@keyframes spin{to{transform:rotate(360deg)}}</style><details open><summary>【兔子镜：场景】</summary><div class="scene"><input class="switch" id="toggle" type="checkbox"><label for="toggle">触碰</label><div class="ring">金环</div></div></details>';
        const prepared = g.prepareIndependentReadyHtml(input);
        const host = g.buildExternalHost('offline:94:1', prepared, 'ready', 'independent', true);
        rt.window.document.body.appendChild(host);
        const details = host.querySelector('details');
        assert.equal(details.querySelectorAll('style').length, 1);
        const ids = await rt.load('src/outputSanitizer/idsAndRearm.js');
        ids.activateRabbitMirrorInteractionRescue(details);
        assert.equal(details.querySelectorAll('style').length, 1);
        assert.equal(rt.window.getComputedStyle(details.querySelector('input')).display, 'none');
        const diagnostics = await rt.load('src/outputSanitizer/diagnostics.js');
        const panel = rt.window.document.createElement('div');
        panel.innerHTML = '<button>复制</button><div data-rm-copy-html-status></div>';
        rt.window.document.body.appendChild(panel);
        let exported = '';
        rt.context.navigator = { clipboard: { writeText: async value => { exported = value; } } };
        await diagnostics.copyRabbitMirrorCurrentFaceHtml(details, panel.firstChild, panel);
        assert.match(exported, /<style>/);
        assert.match(exported, /animation:/);
        assert.match(exported, /@keyframes/);
        assert.equal(details.querySelectorAll('style').length, 1, 'export does not mutate live CSS');
    } finally { await rt.close(); }
});

test('unsupported script/event CSS remain sanitized instead of bypassing black-screen investigation', { skip }, async () => {
    const rt = await createDomRuntime(root);
    try {
        const g = await rt.load('src/independentApi/geometry.js');
        const input = '<toto><style>.scene{background:#16120C;color:#FFE7B3}</style><details><summary>【兔子镜：场景】</summary><div class="scene" onclick="alert(1)">内容</div><script>alert(2)</script></details></toto>';
        const output = g.prepareIndependentReadyHtml(input);
        assert.doesNotMatch(output, /<script|onclick=/);
        assert.match(output, /<style>/);
    } finally { await rt.close(); }
});
