import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const requestSource = readFileSync(new URL('../src/independentApi/request.js', import.meta.url), 'utf8');
const connectionSource = readFileSync(new URL('../src/independentApi/connection.js', import.meta.url), 'utf8');
const functionsOnly = source => source.replace(/^import\b[\s\S]*?;\r?$/gm, '').replace(/^export /gm, '');
const fn = (source, name) => {
    const match = source.match(new RegExp('^(?:export )?(?:async )?function ' + name + '\\([^]*?^}\\r?$', 'm'));
    assert.ok(match, name); return match[0].replace(/^export /, '');
};
const RAW = ' \n<toto><details><summary>兔子镜：监控</summary><style>.scene{background:#173a50}</style><div>镜头 A</div></details></toto>\n ';
const USER = '【当前聊天逐轮正文】\n[96 ASSISTANT]\n正文保持原样。\n<兔子镜近输出短锁 data-source="independent-api-near-output">只输出一面。</兔子镜近输出短锁>';
const report = evidence => JSON.parse(evidence.exportGenerationEvidence());

async function fixture({ armed = true, host = false, stream = false, format = 'json', fail = false, failAfterFrame = false, raw = RAW, owner = 96, elapsedMs = 40893, preflight = false, cancelled = false } = {}) {
    const calls = [];
    let clock = 1790805454761;
    const fetch = async (url, init) => {
        calls.push({url, init});
        clock += elapsedMs;
        if (cancelled) controller.abort();
        if (fail) throw new Error('network interrupted');
        if (format === 'sse') return new Response('data: '+JSON.stringify({choices:[{delta:{content:raw},finish_reason:'stop'}]})+'\n\ndata: [DONE]\n\n', {headers:{'content-type':'text/event-stream'}});
        if (format === 'ndjson') return new Response(JSON.stringify({choices:[{delta:{content:raw},finish_reason:'stop'}]})+'\n', {headers:{'content-type':'application/x-ndjson'}});
        return new Response(JSON.stringify({choices:[{message:{content:raw,reasoning_content:'PRIVATE_REASONING'},finish_reason:'stop'}]}), {headers:{'content-type':'application/json'}});
    };
    const rt = createRuntime(root, {fetch, now: () => clock});
    const evidence = await rt.load('src/generationEvidence.js');
    const guard = await rt.load('src/independentSecurityGuard.js');
    const advanced = await rt.load('src/advancedRequestOptions.js');
    const formats = await rt.load('data/structured/presentationIndex.js');
    const timing = await rt.load('src/generationTiming.js');
    if (armed) evidence.armGenerationEvidence();
    let consumed = false;
    const controller = new AbortController();
    const lease = {consume(){ if(consumed || preflight)return false;consumed=true;return true; },consumed:()=>consumed};
    const settings = {generationSource:'independent',independentApiModel:'offline-model',independentApiTemperature:.8,
        independentApiMaxTokens:16000,independentApiBaseUrl:'https://test.invalid',independentApiKey:'PRIVATE_API_KEY',
        independentConnectionProfileId:host?'profile-one':'',enhancedVisualDrawing:true,visualPromptEditingEnabled:false};
    const hostRuntime = {id:'profile-one',profile:{},apiMap:{source:'custom'},ctx:{ConnectionManagerRequestService:{
        async sendRequest(...args){
            calls.push({serviceArgs:args});
            clock += elapsedMs;
            if (cancelled) controller.abort();
            if(fail)throw new Error('network interrupted');
            if(stream)return async function*(){
                yield {text:raw,reasoning:'PRIVATE_REASONING',finish_reason:failAfterFrame?null:'stop'};
                if(failAfterFrame)throw new Error('network interrupted');
            };
            return {content:raw,reasoning_content:'PRIVATE_REASONING',finish_reason:'stop'};
        },
    }}};
    const sandbox = {console,Response,Headers,TextEncoder,TextDecoder,URL,AbortController,Date:rt.context.Date,
        ...evidence,...guard,...advanced,...formats,...timing,RUNTIME_VERSION:'1.62.22',
        INDEPENDENT_RAW_MARKUP_BUDGET_CHARS:2000000,INDEPENDENT_MAX_TAGS:10000,INDEPENDENT_MAX_ATTRIBUTES:20000,
        INDEPENDENT_MAX_APPROX_DEPTH:100,INDEPENDENT_MAX_CSS_CHARS:1000000,INDEPENDENT_MAX_CSS_RULES:10000,
        INDEPENDENT_MAX_DATA_URI_CHARS:2000000,INDEPENDENT_HTML_BUDGET_BYTES:2000000,
        API_PROFILE_ORDER:[stream?'chat_system_user_full':'chat_system_user_full_nostream'],
        getSettings:()=>settings, getRememberedApiProfile:()=>'',getStagedApiProfile:()=>'',
        normalizeIndependentConnectionText:value=>String(value??''),endpoint:(base,suffix)=>base+suffix,
        profileUsesStreaming:name=>!name.includes('nostream'),profileUsesSystemMessage:()=>true,profileTokenField:()=> 'max_tokens',
        normalizedConfiguredTemperature:st=>st.independentApiTemperature,independentDiagnosticBase:()=>'(local test)',
        publishIndependentApiRequestDiagnostic:value=>value,stageNextApiProfile(){},forgetRememberedApiProfileIfMatches(){},
        independentLocalPreflightFailure:error=>String(error?.code||'').includes('BOUNDARY')?error:null,
        headers:()=>({Authorization:'Bearer PRIVATE_API_KEY'}), validatedIndependentConnectionProfile:async()=>hostRuntime,
        independentConnectionProxyPresets:async()=>[],independentConnectionPayload:()=>({}),
        customApiBaseFromUrl:()=>settings.independentApiBaseUrl,serverRequestHeaders:async()=>({'Content-Type':'application/json'}),
        customHeaderYaml:()=> 'Authorization: Bearer PRIVATE_API_KEY',ST_CUSTOM_GENERATE_ENDPOINT:'/api/backends/chat-completions/generate',
        ST_CUSTOM_STATUS_ENDPOINT:'/api/backends/chat-completions/status',fetch,
        safeJson:value=>JSON.stringify(value),byteLength:value=>new TextEncoder().encode(value).length,
    };
    vm.createContext(sandbox);
    vm.runInContext(functionsOnly(requestSource),sandbox);
    vm.runInContext(fn(connectionSource,'fetchIndependentUrl'),sandbox);
    const run = () => sandbox.requestIndependentCompletion(settings,'固定的完整视觉要求',USER,{dispatchLease:lease,
        signal:controller.signal,diagnosticContext:{mesid:owner,swipe:2,sourceHash:'body-96',chatKeyHash:'chat-A'},evidenceFaceIndex:2,evidenceSerial:host});
    return {rt,evidence,guard,sandbox,settings,calls,run};
}

test('disabled evidence does not read settings or retain completion data',async()=>{
    const rt=createRuntime(root),e=await rt.load('src/generationEvidence.js');
    assert.equal(e.claimGenerationEvidence({settings:new Proxy({},{get(){throw Error('must not read');}})}),null);
    const f=await fixture({armed:false});await f.run();
    assert.equal(f.evidence.exportGenerationEvidence(),'');assert.equal(f.calls.length,1);
});

for(const options of [{},{stream:true,format:'sse'},{stream:true,format:'ndjson'},{host:true},{host:true,stream:true}]){
    test('real request assembly/parser captures the same dispatch and raw text '+JSON.stringify(options),async()=>{
        const f=await fixture(options),result=await f.run(),r=report(f.evidence);
        assert.equal(f.calls.length,1);
        assert.equal(r.context.owner.mesid,96);assert.equal(r.context.owner.swipe,2);
        assert.equal(r.response.text,RAW);assert.equal(r.context.settings.enhancedVisualDrawing,true);
        assert.equal(r.context.settings.visualPromptEditingEnabled,false);
        assert.equal(r.request.boundary,options.host?'connection-manager':'sillytavern-proxy');
        assert.equal(r.request.body.messages[1].content,USER);
        assert(!f.evidence.exportGenerationEvidence().includes('PRIVATE_API_KEY'));
        assert(!f.evidence.exportGenerationEvidence().includes('PRIVATE_REASONING'));
        assert(f.evidence.generationEvidenceFor(result.result));
        assert.equal(result.requestDiagnostic.requestElapsedMs, 40893);
        assert.equal(result.requestDiagnostic.requestTimingEnd, 'response');
        assert.equal(r.timing.requestToResponseMs, 40893);
        if(!options.host){
            const sent=JSON.parse(f.calls[0].init.body);
            assert.equal(JSON.stringify(sent.messages),JSON.stringify(r.request.body.messages));
            assert.equal(Object.hasOwn(f.calls[0].init,'rabbitMirrorRequestObserver'),false);
        }
    });
}

test('switching evidence on leaves the serialized request and result unchanged',async()=>{
    for(const host of [false,true]){
        const off=await fixture({armed:false,host}),on=await fixture({armed:true,host});
        const a=await off.run(),b=await on.run();
        assert.equal(JSON.stringify(a),JSON.stringify(b));
        if(host)assert.equal(JSON.stringify(off.calls[0]),JSON.stringify(on.calls[0]));
        else assert.equal(off.calls[0].init.body,on.calls[0].init.body);
    }
});

test('failed transport is recorded once without a retry or leaked exception text',async()=>{
    for(const host of [false,true]){
        const f=await fixture({host,fail:true});await assert.rejects(f.run(), error => {
            assert.equal(error.rabbitMirrorRequestDiagnostic.requestElapsedMs, 40893);
            assert.equal(error.rabbitMirrorRequestDiagnostic.requestTimingEnd, 'failure'); return true;
        });
        const r=report(f.evidence);assert.equal(r.status,'failed');assert.equal(r.outcome.phase,'transport');
        assert.equal(r.response,null);assert.equal(f.calls.length,1);
    }
});

test('preflight failure has no request duration or extra dispatch', async () => {
    for (const host of [false, true]) {
        const f = await fixture({host,preflight:true});
        await assert.rejects(f.run(), error => {
            assert.equal(error.rabbitMirrorRequestDiagnostic.requestElapsedMs, null);
            assert.equal(error.rabbitMirrorRequestDiagnostic.requestCount, 0); return true;
        });
        assert.equal(f.calls.length, 0);
        assert.equal(report(f.evidence).timing.requestToResponseMs, null);
    }
});

test('explicit cancellation keeps failure duration without claiming a complete response', async () => {
    const f = await fixture({fail:true,cancelled:true});
    await assert.rejects(f.run(), error => {
        assert.equal(error.rabbitMirrorRequestDiagnostic.requestElapsedMs, 40893);
        assert.equal(error.rabbitMirrorRequestDiagnostic.requestTimingEnd, 'failure');
        assert.equal(error.rabbitMirrorRequestDiagnostic.semanticFailure, 'local-cancel'); return true;
    });
    assert.equal(f.calls.length, 1);
});

test('an interrupted stream retains its partial visible reply and original failure',async()=>{
    const f=await fixture({host:true,stream:true,failAfterFrame:true,raw:'<toto>partial'});
    await assert.rejects(f.run(),error=>{
        assert.match(error.message,/副 API/);assert(!/ReferenceError|TypeError/.test(error.name));return true;
    });
    const r=report(f.evidence);
    assert.equal(r.status,'failed');assert.equal(r.outcome.phase,'transport');
    assert.equal(r.response.text,'<toto>partial');assert.equal(r.response.partial,true);
    assert.equal(r.processed,null);assert.equal(f.calls.length,1);
    assert(!f.evidence.exportGenerationEvidence().includes('PRIVATE_REASONING'));
});

test('original visible whitespace is preserved without retaining hidden provider fields',async()=>{
    const rt=createRuntime(root),e=await rt.load('src/generationEvidence.js');e.armGenerationEvidence();
    const h=e.claimGenerationEvidence({});
    h.response({text:'visible',streamed:false,payload:{
        candidates:[{content:{parts:[{thought:true,text:'HIDDEN'},{text:'  visible\n'}]}}],
        reasoning_content:'HIDDEN',
    }});
    const r=report(e);
    assert.equal(r.response.text,'  visible\n');assert.equal(r.response.parserText,'visible');
    assert(!e.exportGenerationEvidence().includes('HIDDEN'));
});

test('an invalid or already-consumed lease never calls the request observer',async()=>{
    const f=await fixture({armed:false});let observed=0;
    const body={messages:[{role:'user',content:USER}]};
    await assert.rejects(f.guard.fetchRabbitMirrorIndependentCompletion('/api/backends/chat-completions/generate',{
        method:'POST',body:JSON.stringify(body),rabbitMirrorDispatchLease:{consume:()=>false},rabbitMirrorRequestObserver:()=>observed++,
    }));
    assert.equal(observed,0);assert.equal(f.calls.length,0);
});

test('throwing observers cannot change the guarded request or response',async()=>{
    const f=await fixture({armed:false});const body=JSON.stringify({messages:[{role:'user',content:USER}]});
    const response=await f.guard.fetchRabbitMirrorIndependentCompletion('/api/backends/chat-completions/generate',{
        method:'POST',body,rabbitMirrorDispatchLease:{consume:()=>true},rabbitMirrorRequestObserver(){throw Error('observer');},
    });
    assert.equal(response.status,200);assert.equal(f.calls.length,1);assert.equal(f.calls[0].init.body,body);
});

test('next request, concurrent request, and stale callbacks cannot overwrite the armed report',async()=>{
    const rt=createRuntime(root),e=await rt.load('src/generationEvidence.js');e.armGenerationEvidence();
    const a=e.claimGenerationEvidence({owner:{mesid:58}});
    assert.equal(e.claimGenerationEvidence({owner:{mesid:96}}),null);
    a.request({messages:[{content:'A'}]});a.response({text:'raw A'});a.processed('HTML A');a.finish();
    assert.equal(e.claimGenerationEvidence({owner:{mesid:96}}),null);
    assert.equal(report(e).processed.html,'HTML A');
    e.clearGenerationEvidence();e.armGenerationEvidence();
    const b=e.claimGenerationEvidence({owner:{mesid:96}});b.request({messages:[{content:'B'}]});
    a.processed('late A');a.fail('late',Error());
    assert.equal(report(e).context.owner.mesid,96);assert.equal(report(e).processed,null);
});

test('missing observer data is labelled incomplete, and clear releases all report data',async()=>{
    const rt=createRuntime(root),e=await rt.load('src/generationEvidence.js');e.armGenerationEvidence();
    const a=e.claimGenerationEvidence({});a.response({text:RAW});a.processed('HTML');a.finish();
    assert.equal(report(e).status,'incomplete');e.clearGenerationEvidence();assert.equal(e.exportGenerationEvidence(),'');
});

// Exercise the actual post-response portion of callIndependentApi. The host
// sanitizer is a controlled boundary here: its deliberately different return
// lets the test detect accidentally recording raw HTML in both fields.
for(const [faces,fails] of [[1,false],[3,false],[1,true]])test('postprocess evidence for '+faces+' face(s), failure='+fails,async()=>{
    const f=await fixture();const completed=await f.run();
    const history=await f.rt.load('src/storage.js');
    const start=requestSource.indexOf(' const {response:r,result,profile,attempts,requestDiagnostic,semanticError}=await requestIndependentCompletion(st,systemPrompt,userPrompt');
    const end=requestSource.indexOf('\nexport function externalOwnerMesid',start);
    const tail=requestSource.slice(start,end).replace(/}\s*$/,'');
    const prepared='<details><summary>净化完成</summary><div>OUTPUT '+faces+'</div></details>';
    const box={...f.sandbox,st:f.settings,systemPrompt:'',userPrompt:'',signal:null,requestOptions:{},
        requestSelectionDiagnostic:{},dispatchLease:null,advancedSettings:{},assertAdvancedCurrent(){},
        resay:null,activeFeedback:null,feedbackPrompt:'',executionLock:'lock',details:{metadata:{}},faceCount:faces,
        historySelection:history.createVisualHistorySelection({themeIds:['F.0'],formatIds:['7.6']}), resolveVisualHistorySelection:history.resolveVisualHistorySelection,
        requestIndependentCompletion:async()=>completed,atmosphereNotesFromHtml:()=>[],stripAtmosphereChoiceMarkup:x=>x,
        assertIndependentMarkupComplexityWithDiagnostic(){},rememberApiProfile(){},independentMirrorBodyEvidence:()=>true,
        bindRolePaletteCode:x=>x,extractMirrorInner:x=>x,prepareIndependentReadyHtml:()=>{if(fails)throw new Error('SANITIZER_FIXTURE_FAILURE');return prepared;},
        prepareIndependentMultifaceResult:()=>({html:prepared,completedFaces:faces,failedFaces:[]}),
        settleAtmosphereMultiface:x=>x,settleAtmosphereSingle(){},
    };
    vm.createContext(box);vm.runInContext('async function verifyPostprocess(){\n'+tail+'\n}',box);
    if(fails){
        await assert.rejects(box.verifyPostprocess(),/SANITIZER_FIXTURE_FAILURE/);
        const r=report(f.evidence);assert.equal(r.response.text,RAW);assert.equal(r.processed,null);
        assert.equal(r.status,'failed');assert.equal(r.outcome.phase,'postprocess');return;
    }
    const returned=await box.verifyPostprocess(),r=report(f.evidence);
    assert.equal(r.response.text,RAW);assert.equal(r.processed.html,returned.html);
    assert.equal(r.processed.html,prepared);assert.equal(r.status,'complete');
});
