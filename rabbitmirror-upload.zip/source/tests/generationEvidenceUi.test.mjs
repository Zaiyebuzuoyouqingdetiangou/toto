import assert from 'node:assert/strict';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
async function fixture() {
    const rt = createRuntime(root), blobs = [], revoked = [], links = [], clipboard = [];
    const node = () => ({ handlers: new Set(), value: '', hidden: false, disabled: false,
        addEventListener(type, fn) { assert.equal(type, 'click'); this.handlers.add(fn); },
        removeEventListener(type, fn) { this.handlers.delete(fn); },
        async click() { if (!this.disabled) for (const fn of this.handlers) await fn(); },
        focus() {}, select() {}, remove() {},
        set innerHTML(value) { throw Error('Never render captured HTML'); },
    });
    const nodes = Object.fromEntries(['start', 'download', 'copy', 'clear', 'status', 'output'].map(key => [key, node()]));
    const dom = { querySelector: selector => nodes[selector.replace('#rh_generation_evidence_', '')] };
    rt.context.Blob = Blob;
    rt.context.URL = { createObjectURL(blob) { blobs.push(blob); return 'blob:evidence-' + blobs.length; },
        revokeObjectURL(url) { revoked.push(url); } };
    rt.context.document = { createElement(tag) { assert.equal(tag, 'a'); const link = node(); links.push(link); return link; },
        body: { appendChild() {} }, execCommand: () => false };
    rt.context.navigator = { clipboard: { async writeText(text) { clipboard.push(text); } } };
    const evidence = await rt.load('src/generationEvidence.js'), ui = await rt.load('src/ui/generationEvidence.js');
    const settings = { generationSource: 'independent' };
    const mount = () => ui.mountGenerationEvidenceUi(dom, () => settings);
    const complete = () => {
        const h = evidence.claimGenerationEvidence({ owner: { mesid: 96 } });
        h.request({ messages: [{ role: 'user', content: 'same request' }] });
        h.response({ text: '<toto>RAW</toto>' }); h.processed('<details>processed</details>'); h.finish();
    };
    mount(); return { rt, evidence, ui, nodes, settings, mount, complete, blobs, revoked, links, clipboard };
}

test('evidence UI arms once, exports and copies the same report, and clears retained data', async () => {
    const f = await fixture();
    assert(f.nodes.download.disabled); await f.nodes.start.click();
    assert(f.evidence.getGenerationEvidenceState().armed); assert.equal(f.nodes.start.textContent, '取消等待');
    f.complete(); await f.nodes.download.click(); await f.nodes.copy.click();
    const text = f.evidence.exportGenerationEvidence();
    assert.equal(await f.blobs[0].text(), text); assert.equal(f.clipboard[0], text);
    assert(f.links[0].download.endsWith('.json'));
    await f.nodes.clear.click();
    assert.equal(f.evidence.exportGenerationEvidence(), ''); assert.equal(f.nodes.output.value, '');
    assert.deepEqual(f.revoked, ['blob:evidence-1']); assert(f.nodes.download.disabled);
});

test('clipboard fallback is inert text and closing the UI retains one report without duplicate listeners', async () => {
    const f = await fixture(); await f.nodes.start.click(); f.complete();
    f.rt.context.navigator = {}; await f.nodes.copy.click();
    assert.equal(f.nodes.output.value, f.evidence.exportGenerationEvidence()); assert.equal(f.nodes.output.hidden, false);
    f.ui.destroyGenerationEvidenceUi();
    for (const key of ['start', 'download', 'copy', 'clear']) assert.equal(f.nodes[key].handlers.size, 0);
    assert(f.evidence.getGenerationEvidenceState().hasReport);
    f.mount();
    for (const key of ['start', 'download', 'copy', 'clear']) assert.equal(f.nodes[key].handlers.size, 1);
    await f.nodes.start.click(); assert.equal(f.nodes.output.value, '');
    await f.nodes.start.click(); assert.equal(f.evidence.getGenerationEvidenceState().armed, false);
});

test('follow mode is explained without changing settings or arming independent evidence', async () => {
    const f = await fixture(); f.settings.generationSource = 'follow';
    await f.nodes.start.click();
    assert.equal(f.evidence.getGenerationEvidenceState().armed, false);
    assert.equal(f.settings.generationSource, 'follow'); assert.match(f.nodes.status.textContent, /跟随正文/);
});
