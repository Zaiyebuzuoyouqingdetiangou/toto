import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';
import { captureFinalPrompt } from './helpers/finalPromptCapture.mjs';

const root = process.env.RM_TEST_SOURCE_ROOT || fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));
const scenery = { id: '10.2.2', title: 'Visual Scenery', summary: '动态场景', tags: ['visual'] };
const ordinary = { id: '4.5.2', title: '物品时间轴', summary: '物品的变化', tags: [] };
async function fixture() {
    const rt = createRuntime(root);
    const settings = { ...copy((await rt.load('src/settings.js')).defaultSettings),
        enabled: true, autoRabbitMirrorInjection: true, mode: 'all', userDirectivePriority: false,
        lotteryMethod: 'random', rabbitMirrorFaceCount: 1, rabbitMirrorPresentationModes: ['html'],
        forceVisualScenery: false, visualSceneryCombination: false, enhancedVisualDrawing: true,
        behaviorRuleMode: 'off', externalWorldBookRandomEnabled: false };
    return { rt, settings, builder: await rt.load('src/promptBuilder.js'),
        picker: await rt.load('src/picker.js'), interaction: await rt.load('src/interactionRecipes.js') };
}

for (const lotteryMethod of ['random', 'atmosphere']) for (const combination of [false, true]) {
    test(`${lotteryMethod}/${combination ? 'combination' : 'scenery'}: final request restores indexed interactions and retains scene rules`, async () => {
        const result = await captureFinalPrompt(root, { overrides: { lotteryMethod,
            atmosphereStoryPercent: 100, forceVisualScenery: !combination, visualSceneryCombination: combination } });
        const sent = result.messages.map(message => message.content).join('\n');
        assert.match(sent, /交互构造库【/);
        assert.match(sent, /第三池/);
        assert.match(sent, combination ? /交互依抽中的形式自然产生/ : /完整交互链使内容、关系、结构/);
        assert.match(sent, /data-rm-visual-scenery/);
        assert.match(sent, /先确定具体的视觉风格、主体焦点和阅读顺序/);
        assert.match(sent, /打开即循环|打开后立即循环|打开后必须通过完整、持续/);
        for (const { combo } of result.selections) for (const chosen of combo.atmosphereMenu || [combo]) {
            assert.ok(chosen.interactionRecipeId);
            assert.ok(chosen.interactionRecipeIds.length > 0);
        }
        assert.equal(result.dispatches, 1);
    });
}

test('naturally drawn dynamic forms use the restored pool while held recipes remain stable', async () => {
    const { interaction } = await fixture();
    const ordinaryCombo = { presentationMode: 'html', formats: [ordinary], formatIds: [ordinary.id] };
    const held = interaction.selectInteractionRecipe(ordinaryCombo, { randomUnit: () => .2 }).id;
    for (const formats of [[scenery], [scenery, ordinary]]) {
        const combo = { presentationMode: 'html', formats, formatIds: formats.map(item => item.id),
            interactionRecipeId: held, interactionRecipeIds: [held] };
        let draws = 0;
        interaction.attachInteractionRecipes(combo, { randomUnit: () => { draws++; return .9; } });
        assert.equal(combo.interactionRecipeId, held);
        assert.deepEqual(copy(combo.interactionRecipeIds), [held]);
        assert.equal(draws, 0);
        assert.ok(interaction.eligibleInteractionRecipes(combo).length > 0);
        delete combo.interactionRecipeId; delete combo.interactionRecipeIds;
        interaction.attachInteractionRecipes(combo, { randomUnit: () => { draws++; return .9; } });
        assert.ok(draws > 0);
        assert.ok(combo.interactionRecipeIds.length > 0);
    }
    // A theme mentioning scenery must not disable an ordinary form's pool.
    ordinaryCombo.themes = [scenery];
    interaction.attachInteractionRecipes(ordinaryCombo, { randomUnit: () => .9 });
    assert.ok(ordinaryCombo.interactionRecipeId);
});

test('mixed candidate and face scopes give dynamic and ordinary HTML their own interactions and exclude text', async () => {
    const { interaction } = await fixture();
    const id = interaction.selectInteractionRecipe({ formats: [ordinary] }, { randomUnit: () => .1 }).id;
    const face = format => ({ combo: { presentationMode: 'html', formats: [format], formatIds: [format.id], interactionRecipeId: id } });
    const mixed = { combo: { presentationMode: 'html' }, atmosphereFaces: [face(scenery), face(ordinary), face(scenery), face(ordinary)] };
    const prompt = interaction.buildInteractionRecipeRule([mixed, face(scenery), { textPresentation: true, combo: {} }, face(ordinary)], 'balanced', '构造范围检查');
    assert.match(prompt, /共用适用规则【第 1 面 HTML；第 2 面 HTML；第 4 面 HTML】/);
    assert.doesNotMatch(prompt, /第 3 面/);
    for (let index = 1; index <= 4; index++) assert.ok(prompt.includes(`第 1 面／仅选签 ${index} 时`));
    assert.match(prompt, /第 2 面：/);
    assert.match(prompt, /第 4 面：/);
    assert.match(interaction.buildInteractionRecipeRule([face(scenery)], 'full', '构造范围检查'), /交互构造库【/);
    assert.match(interaction.interactionExecutionReminder({ ...face(ordinary).combo,
        atmosphereMenu: [face(scenery).combo, face(scenery).combo] }), /取选中签已抽好的构造/);
});

test('frozen mixed menu retains each ticket recipe in material, lock and metadata without changing the source', async () => {
    const { builder, picker, interaction, settings } = await fixture();
    const selected = copy(picker.pickCombination(settings, 'mixed-menu'));
    const id = interaction.selectInteractionRecipe({ formats: [ordinary] }, { randomUnit: () => .1 }).id;
    selected.combo.atmosphereMenu = [scenery, ordinary, scenery, ordinary].map(format => ({
        themeIds: selected.combo.themeIds, formatIds: [format.id], interactionRecipeId: id, interactionRecipeIds: [id] }));
    const saved = JSON.stringify(selected);
    const plan = builder.planRabbitMirrorPromptDetails(settings, 'independent', null, 'mixed-pinned', { pinnedSelections: [selected] });
    const result = builder.renderRabbitMirrorPromptPlan(plan);
    assert.equal(result.metadata.atmosphereMenu.length, 4);
    assert.match(result.prompt, /共用适用规则【第 1 面 HTML】/);
    assert.match(result.executionLock, /第三池同签执行/);
    for (let i = 0; i < 4; i++) {
        const ticket = result.metadata.atmosphereMenu[i];
        assert.equal(ticket.interactionRecipeId, id);
        const section = result.prompt.split(`签 ${i + 1}（以下材料仅在选中本签时适用）：`)[1].split(/\n签 \d（|\n\n展现形式落地/)[0];
        assert.match(section, /交互构造：/);
    }
    assert.equal(JSON.stringify(selected), saved);
});

test('pinned dynamic recipes reach sending metadata without rewriting saved artwork or selection', async () => {
    const { builder, picker, interaction, settings } = await fixture();
    const selection = copy(picker.pickCombination(settings, 'pinned-original'));
    const id = interaction.selectInteractionRecipe({ formats: [ordinary] }, { randomUnit: () => .1 }).id;
    Object.assign(selection.combo, { formats: [scenery], formatIds: [scenery.id],
        interactionRecipeId: id, interactionRecipeIds: [id] });
    const before = JSON.stringify(selection);
    const plan = builder.planRabbitMirrorPromptDetails(settings, 'independent', null, 'pinned', { pinnedSelections: [selection] });
    const result = builder.renderRabbitMirrorPromptPlan(plan);
    assert.match(result.prompt, /交互构造库【/);
    assert.match(result.executionLock, /第三池/);
    assert.equal(result.metadata.interactionRecipeId, id);
    assert.equal(builder.promptPlanSelections(plan)[0].combo.interactionRecipeId, id);
    assert.equal(JSON.stringify(selection), before);
    assert.deepEqual(copy(result.metadata.formatIds), [scenery.id]);
    assert.deepEqual(copy(result.metadata.themeIds), selection.combo.themeIds);
    assert.deepEqual(copy(builder.renderRabbitMirrorPromptPlan(plan)), copy(result));
});

test('original-selection resay and exact continuation keep dynamic theme/form with restored interaction selection', async () => {
    const { builder, picker, interaction, settings } = await fixture();
    const result = builder.buildRabbitMirrorPromptDetails({ ...settings, forceVisualScenery: true }, 'independent', null, 'first');
    const oldFace = { ...copy(result.metadata), interactionRecipeId: interaction.selectInteractionRecipe({ formats: [ordinary] }, { randomUnit: () => .1 }).id };
    oldFace.interactionRecipeIds = [oldFace.interactionRecipeId];
    for (const resay of [{ preserveSelection: true }, { preserveVariation: true }]) {
        const selection = picker.pickCombinationForMultifaceResay(settings, { ...resay, faceIndex: 0, faces: [oldFace] });
        assert.ok(selection.combo.interactionRecipeId);
        if (resay.preserveVariation) assert.deepEqual(copy(selection.combo.interactionRecipeIds), oldFace.interactionRecipeIds);
        assert.deepEqual(copy(selection.combo.themeIds), oldFace.themeIds);
        assert.deepEqual(copy(selection.combo.formatIds), oldFace.formatIds);
    }
    assert.ok(oldFace.interactionRecipeId, 'saved metadata remains intact');
});
