import assert from 'node:assert/strict';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const familyId = 'tabbed_radio_family';
const familyLabel = '并列标签／多按钮切页';
const count = (text, value) => text.split(value).length - 1;

async function generate(presentationModes, route) {
    const rt = createRuntime(root);
    const storage = await rt.load('src/storage.js');
    storage.setPendingCombo({ themeIds: ['F.0'], formatIds: ['7.6'] });
    storage.commitPendingCombo('completed text-panel switching', '', [], null, {
        id: familyId, label: familyLabel, confidence: 1,
        controlCount: 3, panelCount: 3, textPanelSwitch: true,
    });
    const { defaultSettings } = await rt.load('src/settings.js');
    const { buildRabbitMirrorPromptDetails } = await rt.load('src/promptBuilder.js');
    const settings = {
        ...structuredClone(defaultSettings),
        generationSource: route === 'normal' ? 'follow' : 'independent',
        rabbitMirrorFaceCount: presentationModes.length,
        rabbitMirrorPresentationModes: presentationModes,
        lotteryMethod: 'random', userDirectivePriority: false,
        visualPromptEditingEnabled: false, behaviorRuleMode: 'off',
    };
    return buildRabbitMirrorPromptDetails(settings, route, null, 'single-history-source', {
        batchIdentity: { mesid: 23, swipeId: 0, sourceHash: 'completed-story' },
    });
}

for (const route of ['normal', 'independent']) {
    for (const mixed of [false, true]) {
        test(`${route}: ${mixed ? 'mixed text/HTML' : 'all HTML'} batch sends recent interaction history once`, async () => {
            const result = await generate(mixed ? ['html', 'longtext', 'html'] : ['html', 'html', 'html'], route);
            const completeRules = result.prompt + '\n' + result.executionLock;
            assert.equal(count(result.prompt, '交互形态冷却【'), 1);
            assert.equal(count(completeRules, familyLabel), 1, 'the recent family is listed by shared history only');
            assert.doesNotMatch(completeRules, /近期使用的「[^」]+」进入冷却/);
            assert.equal(count(result.prompt, '本批交互分散：'), 1);
            assert.match(result.prompt, /同一主交互家族尽量不超过/);
            assert.match(result.prompt, /可行机制不足时允许自然复用/);
            const faces = result.batchPlan.faces;
            assert.equal(faces.length, 3);
            const htmlIndices = mixed ? [0, 2] : [0, 1, 2];
            for (const index of htmlIndices) {
                const plan = faces[index].combo.interactionDiversity;
                assert.deepEqual([...plan.recentAvoidFamilyIds], [familyId], 'frozen comparison metadata is retained');
                assert.deepEqual([...plan.compareWithFaceIndices], htmlIndices.filter(other => other < index));
                assert.equal(plan.allowNativeRepeat, true);
            }
            if (mixed) {
                assert.equal(faces[1].combo.presentationMode, 'text');
                assert.equal(faces[1].combo.interactionDiversity ?? null, null);
                assert.match(result.prompt, /仅在第 1、3 面 HTML 作品之间对照/);
                assert.match(result.prompt, /文本面不参与交互比较/);
            } else {
                assert.match(result.prompt, /从第 2 面起对照此前各面/);
            }
        });
    }
    test(`${route}: one HTML face with text faces has shared history but no batch interaction requirement`, async () => {
        const result = await generate(['longtext', 'html', 'longtext'], route);
        assert.equal(count(result.prompt, '交互形态冷却【'), 1);
        assert.equal(count(result.prompt + result.executionLock, familyLabel), 1);
        assert.doesNotMatch(result.prompt, /本批交互分散：/);
        assert.deepEqual(Array.from(result.batchPlan.faces, face => face.combo.presentationMode), ['text', 'html', 'text']);
        for (const face of result.batchPlan.faces) assert.equal(face.combo.interactionDiversity ?? null, null);
    });
}
