import assert from 'node:assert/strict';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_SAMPLING_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));

async function fixture(overrides = {}) {
    const runtime = createRuntime(root);
    const { defaultSettings } = await runtime.load('src/settings.js');
    const picker = await runtime.load('src/picker.js');
    const storage = await runtime.load('src/storage.js');
    const { PRESENTATION_FORMATS: formats } = await runtime.load('data/structured/presentationIndex.js');
    const settings = { ...copy(defaultSettings), userDirectivePriority: false, singlePairSampling: true,
        avoidRepeat: false, rabbitMirrorPresentationModes: ['html'], ...overrides };
    let next = 0;
    function random(value) {
        runtime.context.crypto = { getRandomValues(array) {
            array.fill(Math.floor(value * 0x100000000)); return array;
        } };
    }
    function draw(value, { clear = true } = {}) {
        if (clear) runtime.store.clear();
        random(value);
        return picker.pickCombination(settings, `uniform-${next++}`).combo;
    }
    return { runtime, picker, storage, formats, settings, random, draw };
}

test('every builtin format has an equal probability interval without history or preference', async () => {
    const f = await fixture();
    // Cover three interior points of EVERY equal interval, not a noisy Monte
    // Carlo threshold. The real picker and its real 255-entry pool are used.
    for (let index = 0; index < f.formats.length; index++) {
        for (const offset of [0.1, 0.5, 0.9]) {
            const combo = f.draw((index + offset) / f.formats.length);
            assert.deepEqual([...combo.formatIds], [f.formats[index].id],
                `equal interval ${index}, offset ${offset}: ${f.formats[index].title}`);
        }
    }
});

test('a filtered pool gives parent, child and other-group formats the same base chance', async () => {
    const f = await fixture();
    const ids = ['1.9', '1.9.1', '8.3'];
    f.settings.blacklistedFormatIds = f.formats.filter(item => !ids.includes(item.id)).map(item => item.id);
    const ordered = f.formats.filter(item => ids.includes(item.id));
    for (const mode of ['html', 'longtext']) {
        f.settings.rabbitMirrorPresentationModes = [mode];
        for (let index = 0; index < ordered.length; index++) {
            assert.deepEqual([...f.draw((index + 0.5) / ordered.length).formatIds], [ordered[index].id]);
        }
    }
});

test('the existing favorite multiplier applies on top of equal base weights', async () => {
    const f = await fixture();
    const ids = ['1.9', '8.3'];
    f.settings.blacklistedFormatIds = f.formats.filter(item => !ids.includes(item.id)).map(item => item.id);
    f.settings.favoriteFormatIds = ['1.9'];
    f.settings.favoriteFormatMultipliers = { '1.9': 3 };
    const hits = new Map(ids.map(id => [id, 0]));
    for (let index = 0; index < 40; index++) {
        const [id] = f.draw((index + 0.5) / 40).formatIds;
        assert.ok(hits.has(id), 'a blacklisted entry cannot return');
        hits.set(id, hits.get(id) + 1);
    }
    assert.equal(hits.get('1.9'), 30);
    assert.equal(hits.get('8.3'), 10);
});

test('recent exact exclusion still works and a small pool can reopen after exhaustion', async () => {
    const f = await fixture({ avoidRepeat: true });
    const ids = ['1.9', '3.7', '8.3'];
    f.settings.blacklistedFormatIds = f.formats.filter(item => !ids.includes(item.id)).map(item => item.id);
    const selected = [];
    for (let index = 0; index < 4; index++) {
        const combo = f.draw(0.5, { clear: index === 0 });
        assert.equal(combo.formatIds.length, 1);
        assert.ok(ids.includes(combo.formatIds[0]));
        selected.push(combo.formatIds[0]);
        f.storage.setPendingCombo(combo);
        f.storage.commitPendingCombo(`completed-${index}`);
    }
    assert.equal(new Set(selected.slice(0, 3)).size, 3);
});

test('explicit recipe restoration still preserves the exact selected format', async () => {
    const f = await fixture();
    const original = f.draw(0.75);
    const restored = f.picker.pickCombinationForMultifaceResay(f.settings, { preserveSelection: true, faceIndex: 0, faces: [copy(original)] });
    assert.deepEqual([...restored.combo.formatIds], [...original.formatIds]);
    assert.deepEqual([...restored.combo.themeIds], [...original.themeIds]);
});

test('five-face sampling keeps all faces and exact-format separation', async () => {
    const f = await fixture({ avoidRepeat: true, rabbitMirrorFaceCount: 5 });
    const batch = f.picker.pickCombinationBatch(f.settings, 'uniform-five',
        { batchPlanningOnly: true, batchIdentity: { mesid: 0, swipeId: 0, sourceHash: 'body' } }, 5);
    assert.equal(batch.length, 5);
    assert.equal(new Set(batch.flatMap(face => [...face.combo.formatIds])).size, 5);
    assert.ok(batch.every(face => face.combo.interactionDiversity.faceCount === 5));
});

test('atmosphere sampling retains all four distinct candidates per face', async () => {
    const f = await fixture({ rabbitMirrorFaceCount: 5, lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100 });
    const batch = f.picker.pickCombinationBatch(f.settings, 'uniform-atmosphere-five',
        { batchPlanningOnly: true, batchIdentity: { mesid: 0, swipeId: 0, sourceHash: 'body' } }, 5);
    assert.equal(batch.length, 5);
    const ids = [];
    for (const face of batch) {
        assert.equal(face.combo.atmosphereMenu.length, 4);
        for (const ticket of face.combo.atmosphereMenu) ids.push(...ticket.formatIds);
    }
    assert.equal(ids.length, 20);
    assert.equal(new Set(ids).size, 20);
});
