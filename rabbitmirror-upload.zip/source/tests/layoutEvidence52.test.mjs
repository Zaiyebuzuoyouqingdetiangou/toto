import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';
const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));

test('one-shot report retains actual narrow carrier and flex minimums without altering controls or artwork', async () => {
    const rt = await createDomRuntime(root);
    try {
        rt.window.document.body.innerHTML = '<details open><summary>兔子镜</summary><div style="display:flex;flex-wrap:wrap"><article style="flex:1;min-width:300px">正文甲</article><article style="flex:1;min-width:300px"><input type="checkbox" checked>正文乙</article></div></details>';
        const details = rt.window.document.querySelector('details');
        // Supplied geometry exercises diagnostic reporting, not browser layout.
        for (const node of [details, ...details.querySelectorAll('*')]) node.getBoundingClientRect = () => ({width:node.tagName==='ARTICLE'?180:360,height:900});
        const before = details.outerHTML;
        const {diagnosticLayoutEvidence} = await rt.load('src/outputSanitizer/diagnostics.js');
        const lines = diagnosticLayoutEvidence(details).join('\n');
        assert.match(lines, /mirror=360×900/);
        assert.match(lines, /min=300px.*wrap=/);
        assert.match(lines, /box=180×900/);
        assert.equal(details.outerHTML, before);
        assert.equal(details.querySelector('input').checked, true);
    } finally { await rt.close(); }
});

test('missing and oversized diagnostic inputs are reported without an unbounded traversal', async () => {
    const rt = await createDomRuntime(root);
    try {
        const {diagnosticLayoutEvidence} = await rt.load('src/outputSanitizer/diagnostics.js');
        assert.equal(diagnosticLayoutEvidence(null).length, 0);
        const root = rt.window.document.createElement('details');
        root.innerHTML = '<div></div>'.repeat(170);
        assert.match(diagnosticLayoutEvidence(root).join('\n'), /子项尺寸未采集/);
    } finally { await rt.close(); }
});
