import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
import {createRuntime} from './helpers/vmLoader.mjs';

const root=fileURLToPath(new URL('..',import.meta.url));
const source=rel=>readFileSync(new URL('../'+rel,import.meta.url),'utf8');
const fn=(s,name)=>{
    const match=s.match(new RegExp('^(?:export )?(?:async )?function '+name+'\\([^]*?^}\\r?$','m'));
    assert.ok(match,name);return match[0].replace(/^export /,'');
};

test('independent scan collects each face and never consumes the global pending slot',async()=>{
    const rt=createRuntime(root),storage=await rt.load('src/storage.js');
    storage.setPendingCombo({themeIds:['old'],formatIds:['7.6']});storage.commitPendingCombo('old');
    storage.setPendingCombo({themeIds:['pending'],formatIds:['4.3'],atmosphereMenu:[{},{}]});
    const before=[...rt.store.values];
    const calls=[],box={console,hasMultifaceMarkup:s=>s==='batch',
        parseMultifaceOutput:()=>({ok:true,faces:[{inner:'A',index:0},{inner:'B',index:1}]}),
        wrapIndependentFace:s=>s,wrappedIndependentMirrorHtml:s=>s,
        scanRabbitMirrorHtml:s=>({signature:s,paletteFingerprint:{hueFamily:s}}),
        updateLatestVisualSignature(){throw new Error('Unowned history write');}};
    vm.createContext(box);vm.runInContext(fn(source('src/independentApi/request.js'),'commitIndependentVisualResult'),box);
    assert.equal(box.commitIndependentVisualResult('batch',(scan,index)=>calls.push([scan.signature,index])).hueFamily,'A');
    assert.deepEqual(calls,[['A',0],['B',1]]);
    assert.equal(box.commitIndependentVisualResult('single',scan=>calls.push(scan.signature)).hueFamily,'single');
    assert.deepEqual([...rt.store.values],before);
});

test('a missing face keeps its original history coordinates when remapped into the full result',async()=>{
    const rt=createRuntime(root), storage=await rt.load('src/storage.js'), merge=await rt.load('src/missingFaceMerge.js');
    const first={themeIds:['F.0'],formatIds:['7.6'],visualHistoryBatchId:'old-batch',visualHistoryFaceIndex:0};
    const next={themeIds:['C.0'],formatIds:['4.3'],visualHistoryBatchId:'new-batch',visualHistoryFaceIndex:0};
    const metadata=merge.mergeRetrySelectionDiagnostic([first,null],{faces:[next]},[1],2);
    const nodes=[{},{}],host={dataset:{rmSourceHash:'body'}}, owners=new WeakMap();
    const box={externalPresentationMetadata:owners,completeReadyFaceDetails:()=>nodes,
        markSanitizedRabbitMirrorFace(){},externalFacePresentation:()=>({}),bindVisualHistoryTarget:storage.bindVisualHistoryTarget};
    vm.createContext(box);vm.runInContext(fn(source('src/independentApi/geometry.js'),'markMountedFaceProofs'),box);
    box.markMountedFaceProofs(host,'independent',metadata);
    assert.deepEqual(JSON.parse(JSON.stringify(storage.visualHistoryTarget(nodes[0]))),{batchId:'old-batch',faceIndex:0});
    assert.deepEqual(JSON.parse(JSON.stringify(storage.visualHistoryTarget(nodes[1]))),{batchId:'new-batch',faceIndex:0});
    rt.store.setItem('rabbit_mirror_theater:last_combo:v11',JSON.stringify([
        {batchId:'old-batch',faceIndex:0,visualSignature:'old'},
        {batchId:'new-batch',faceIndex:0,visualSignature:'new'}]));
    storage.updateLatestVisualSignature('rendered-new','',[],null,null,storage.visualHistoryTarget(nodes[1]));
    assert.equal(storage.getComboHistory()[0].visualSignature,'old');
    assert.equal(storage.getComboHistory()[1].visualSignature,'rendered-new');
    box.markMountedFaceProofs(host,'independent',{faces:[first,{...next,visualHistoryId:'resay-face'}]});
    assert.equal(storage.visualHistoryTarget(nodes[1]).historyId,'resay-face');
    box.markMountedFaceProofs(host,'favorite',null);
    assert.equal(storage.visualHistoryTarget(nodes[0]),null);
    assert.equal(storage.visualHistoryTarget(nodes[1]),null);
});

test('single missing-face completion uses that face scan instead of the last retained face',()=>{
    const mount=source('src/independentApi/mount.js');
    const start=mount.indexOf('   let completedVisualScan=null;'),end=mount.indexOf('  if(result?.feedbackId',start);
    const fragment=mount.slice(start,end)+'\nresult.captured=completedVisualScan;';
    const box={multifaceResay:null,replacementVisualHtml:'',html:'full batch',result:{mergedFromMissingRetry:true,
        historySelection:{historyId:'new-first'},requestDiagnostic:{faces:[{visualHistoryId:'new-first'},{visualHistoryId:'old-second'}]}},
        commitIndependentVisualResult(html,callback){callback({signature:'new-first'},0);callback({signature:'old-second'},1);return {};}};
    vm.createContext(box);vm.runInContext(fragment,box);
    assert.equal(box.result.captured.signature,'new-first');
});

test('serial scan exceptions cannot reject completed output or trigger another request',async()=>{
    let requests=0;
    const box={console,promptPlanSelections:()=>[{combo:{}},{combo:{}}],markPendingBatchAttempt:()=>true,
        callIndependentApi:async()=>{requests++;return {html:'complete'};},stripAtmosphereChoiceMarkup:x=>x,
        wrapSerialFace:(html,index)=>html+index,scanRabbitMirrorHtml(){throw Error('scan failure');},
        createMultifaceFailureSlot:()=>'',automaticRerollEnabled:()=>false};
    vm.createContext(box);vm.runInContext(fn(source('src/independentApi/request.js'),'runIndependentSerialFaces'),box);
    const result=await box.runIndependentSerialFaces({ctx:{},index:0,msg:{},requestOptions:{},promptPlan:{},st:{},
        details:{batchPlan:{batchId:'serial-batch'},metadata:{faceCount:2,faces:[{},{}]}}});
    assert.equal(result.completedFaces,2);
    assert.equal(result.html,'complete0\ncomplete1');
    assert.equal(requests,2);
    assert.equal(result.faceScans[0].faceIndex,0);
    assert.equal(result.faceScans[1].faceIndex,1);
});
