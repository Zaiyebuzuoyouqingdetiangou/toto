import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

// A saved trial setting now migrates to model-original guidance. Keep the
// selection, history, safety and scope invariants while checking that retirement.
const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));
const count = (value, marker) => value.split(marker).length - 1;

// These are transmission/selection contracts, not evidence of model visual quality.
async function fixture() {
    const rt = createRuntime(root);
    const { defaultSettings } = await rt.load('src/settings.js');
    const builder = await rt.load('src/promptBuilder.js');
    const { PRESENTATION_FORMATS } = await rt.load('data/structured/presentationIndex.js');
    const { THEMATIC_CATEGORIES } = await rt.load('data/structured/thematicIndex.js');
    const theme = THEMATIC_CATEGORIES.find(item => item.id === 'F.0');
    const format = id => PRESENTATION_FORMATS.find(item => item.id === id);
    const menu = ['4.3', '7.6', '6.3.4', '10.2.9'].map(id => ({ themeIds: [theme.id], formatIds: [id] }));
    const make = (presentation = 'html', scenery = false, combination = false) => {
        const tickets = menu.map(item => ({ ...item, formatIds: scenery
            ? (combination ? ['10.2.2', ...item.formatIds] : ['10.2.2']) : [...item.formatIds] }));
        return { themes: [theme], themeIds: [theme.id], formats: tickets[0].formatIds.map(format),
            formatIds: tickets[0].formatIds, atmosphereMenu: tickets,
            requestedPresentationMode: presentation, presentationMode: presentation === 'html' ? 'html' : 'text',
            forcedVisualScenery: scenery, visualSceneryCombination: combination };
    };
    const render = (type, faces = [make()], overrides = {}) => builder.renderRabbitMirrorPromptPlan(
        builder.planRabbitMirrorPromptDetails({ ...copy(defaultSettings), visualDesignMode:'current', avoidRepeat: false,
            userDirectivePriority: false, lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100,
            rabbitMirrorFaceCount: faces.length, rabbitMirrorPresentationModes: faces.map(f => f.requestedPresentationMode),
            ...overrides }, type, null, 'form-execution-fixed',
        { pinnedSelections: faces.map(combo => ({ combo, directive: null })) }));
    return { make, render };
}

for (const type of ['normal', 'independent']) for (const enhanced of [false, true]) {
    test(`${type}: form execution order applies with enhancement ${enhanced}, without selecting ticket one`, async () => {
        const f = await fixture();
        const combo = f.make();
        const frozen = JSON.stringify(combo);
        const result = f.render(type, [combo], { enhancedVisualDrawing: enhanced });
        const active = type === 'independent' ? result.executionLock : result.prompt;
        assert.equal(count(active, '形式执行顺序：'), 1);
        const order = active.split('\n').find(line => line.startsWith('形式执行顺序：'));
        assert.ok(order.indexOf('本体') < order.indexOf('操作对象'));
        assert.match(order, /内容承载位置/);
        assert.match(order, /状态机制与反馈/);
        assert.match(order, /条目原意/);
        assert.equal(count(result.prompt, '增强视觉绘制：'), enhanced ? 1 : 0);
        assert.equal(count(result.prompt, '按正文挑签：'), 1);
        for (let i = 1; i <= 4; i++) assert.equal(count(result.prompt, `签 ${i}（以下材料仅在选中本签时适用）：`), 1);
        assert.match(result.prompt, /<rm-think>/);
        assert.match(active, /选中签的形式/);
        assert.doesNotMatch(result.executionLock, /短检：主形式 4\.3/);
        assert.equal(JSON.stringify(combo), frozen);
        assert.equal(result.metadata.atmosphereMenu.length, 4);
        assert.doesNotMatch(order, /跑团|骰子|棋盘|报纸|信纸|至少|最多|不超过/);
    });
}

for (const type of ['normal', 'independent']) for (const mixed of [false, true]) {
    test(`${type}: ${mixed ? 'mixed' : 'HTML'} batch shares execution order without repeating per candidate`, async () => {
        const f = await fixture();
        const faces = mixed ? [f.make('longtext'), f.make(), f.make()] : [f.make(), f.make(), f.make()];
        const result = f.render(type, faces, { enhancedVisualDrawing: true });
        const active = type === 'independent' ? result.executionLock : result.prompt;
        assert.equal(count(active, '形式执行顺序：'), 1);
        assert.equal(count(result.prompt, '增强视觉绘制：'), 1);
        assert.equal(count(result.prompt, '按正文挑签：'), faces.length);
        if (mixed) {
            assert.match(active, /以下形式执行顺序仅作用于 HTML 面（第 2、3 面）/);
            const textRule = result.prompt.match(/<兔子镜文本面规则[^>]*>[\s\S]*?<\/兔子镜文本面规则>/)?.[0];
            assert.ok(textRule);
            assert.doesNotMatch(textRule, /形式执行顺序：|增强视觉绘制：/);
            for (const block of result.prompt.matchAll(/<兔子镜HTML面规则[^>]*>[\s\S]*?<\/兔子镜HTML面规则>/g)) {
                assert.doesNotMatch(block[0], /形式执行顺序：/, 'the shared order is not trapped inside one face scope');
            }
        }
    });
}

for (const type of ['normal', 'independent']) {
    test(`${type}: enhancement stays independent and does not duplicate animation rules`, async () => {
        const f = await fixture();
        const combo = f.make('html', true, true);
        const overrides = { forceVisualScenery: true, visualSceneryCombination: true };
        const off = f.render(type, [combo], { ...overrides, enhancedVisualDrawing: false });
        const on = f.render(type, [combo], { ...overrides, enhancedVisualDrawing: true });
        const paragraph = on.prompt.split('\n').find(line => line.startsWith('增强视觉绘制：'));
        assert.match(paragraph, /用真实 CSS 落实/);
        assert.match(paragraph, /轮廓|内部结构/);
        assert.match(paragraph, /材质/);
        assert.match(on.prompt, /至少一条主动画和一条协同环境动画/);
        assert.doesNotMatch(paragraph, /主动画|辅助动画|每面最多/);
        assert.equal(on.prompt.replace(paragraph + '\n\n', ''), off.prompt);
        assert.equal(on.executionLock, off.executionLock);
        assert.deepEqual(copy(on.metadata), copy(off.metadata));
        assert.equal(count(on.prompt, '动态视觉组合【本面冻结'), 1);
    });
    test(`${type}: longtext receives no HTML execution workflow or enhancement`, async () => {
        const f = await fixture();
        const out = f.render(type, [f.make('longtext')], { enhancedVisualDrawing: true });
        assert.doesNotMatch(out.prompt + out.executionLock, /形式执行顺序：|增强视觉绘制：/);
        assert.match(out.prompt, /长文本呈现规则/);
    });
}
