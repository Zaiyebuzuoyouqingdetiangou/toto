import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';
const root=process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..',import.meta.url));
const copy=x=>JSON.parse(JSON.stringify(x));

test('interaction draws exhaust fresh compatible families before reusing a recent family',async()=>{
 const rt=createRuntime(root), m=await rt.load('src/interactionRecipes.js');
 const pool=await rt.load('data/structured/interactionIndex.js');
 const byId=new Map(pool.INTERACTION_RECIPES.map(x=>[x.id,x]));
 const combo={formats:[{title:'书册信件档案纸张'}]};
 const recent=[{interactionRecipeId:'hinged-open'}];
 for(const n of [0,.1,.3,.5,.7,.9,.9999]){
  const result=m.selectInteractionRecipe(combo,{recent,randomUnit:()=>n});
  assert.notEqual(byId.get(result.id).family,'opening');
 }
});

test('observed text switching steers toward object or spatial effects without banning radio controls',async()=>{
 const rt=createRuntime(root),m=await rt.load('src/interactionRecipes.js');
 const combo={formats:[{title:'机械模型书册地图'}]};
 const recent=[{visualSkeleton:'layout_family:illustration_above_text；operation_family:text_panel_switch'}];
 for(const n of [0,.2,.5,.8,.9999]){
  const r=m.selectInteractionRecipe(combo,{recent,randomUnit:()=>n});
  assert.ok(['object_state','spatial_scroll'].includes(r.effect),r.id);
 }
});

test('ordinary user re-say redraws the three active pools without a palette',async()=>{
 const rt=createRuntime(root),picker=await rt.load('src/picker.js');
 const {defaultSettings}=await rt.load('src/settings.js');
 const settings={...copy(defaultSettings), visualDesignMode:'current', postGenerationRecolor:false,lotteryMethod:'classic',userDirectivePriority:false};
 const first=picker.pickCombination(settings,'first').combo;
 const next=picker.pickCombinationForMultifaceResay(settings,{faceIndex:0,faces:[first]}).combo;
 assert.ok(next.themeIds.every(id=>!first.themeIds.includes(id)));
 assert.ok(next.formatIds.every(id=>!first.formatIds.includes(id)));
 assert.notEqual(next.interactionRecipeId,first.interactionRecipeId);
 assert.equal(first.paletteRecipeId,undefined);
 assert.equal(next.paletteRecipeId,undefined);
});

test('palette index drawing consumes entropy and treats cream/beige as one observed family',async()=>{
 const rt=createRuntime(root),m=await rt.load('src/paletteRecipes.js');
 const combo={formats:[{title:'纸本收藏'}]};
 const recent=[{paletteFingerprint:{brightness:'light',saturation:'low',temperature:'warm',hueFamily:'yellow',confidence:.9}}];
 const ids=new Set();
 for(const n of [0,.1,.2,.3,.4,.5,.6,.7,.8,.9,.9999]){
  const p=m.selectPaletteRecipe(combo,{recent,darkCooldown:true,randomUnit:()=>n});
  ids.add(p.id);assert.notEqual(p.colorGroup,'warm_neutral');assert.notEqual(p.surfaceGroup,'warm_neutral');
  assert.equal(p.brightness,'light');assert.equal(p.colors,undefined);
 }
 assert.ok(ids.size>5);
 const cream={brightness:'light',saturation:'low',temperature:'warm',hueFamily:'neutral',confidence:.9};
 assert.equal(m.observedPaletteGroup({paletteFingerprint:cream}),'warm_neutral');
});

async function fixture(){
 const rt=createRuntime(root),builder=await rt.load('src/promptBuilder.js'),storage=await rt.load('src/storage.js');
 const {defaultSettings}=await rt.load('src/settings.js');
 return {rt,builder,storage,settings:{...copy(defaultSettings), visualDesignMode:'current', postGenerationRecolor:false,userDirectivePriority:false,lotteryMethod:'atmosphere',atmosphereStoryPercent:100,rabbitMirrorFaceCount:1,rabbitMirrorPresentationModes:['html']}};
}
for(const route of ['normal','independent'])test(`${route}: frozen candidates bind three pools and only actual colour observations enter history`,async()=>{
 const f=await fixture(),plan=f.builder.planRabbitMirrorPromptDetails(f.settings,route,null,'quad');
 const out=f.builder.renderRabbitMirrorPromptPlan(plan),menu=out.metadata.atmosphereMenu;
 assert.equal(menu.length,4);assert.ok(menu.every(x=>x.interactionRecipeId&&!x.paletteRecipeId));
 assert.equal(out.metadata.paletteReferenceIds,undefined);
 assert.doesNotMatch(out.prompt,/生成配色参考【|P\.\d{3}/);
 const snapshot=out.prompt;
 f.settings.darkVisualMode=true;
 assert.equal(f.builder.renderRabbitMirrorPromptPlan(plan).prompt,snapshot);
 const selection=f.storage.createVisualHistorySelection(out.metadata);
 const resolved=f.storage.resolveVisualHistorySelection(selection,2);
 assert.equal(resolved.paletteRecipeId,menu[2].paletteRecipeId);
 assert.equal(f.storage.commitVisualHistorySelection(resolved,{}),true);
 const history=f.storage.getRecentDiversityHistory(3),last=history.at(-1);
 assert.equal(last.paletteRecipeId,menu[2].paletteRecipeId);
 assert.equal(last.paletteFingerprint,undefined);
 for(const key of ['roles','colors','scales','atmosphereMenu','paletteReferenceIds'])assert.equal(last[key],undefined);
 const m=await f.rt.load('src/paletteRecipes.js'),groups=new Set(m.recentPaletteGroups(history));
 const next=m.selectPaletteRecipe({formats:[{title:'书'}]},{recent:history,randomUnit:()=>.2});
 assert.ok(!groups.has(next.colorGroup)&&!groups.has(next.surfaceGroup));
});

test('legacy pinned input is not redrawn or mutated; missing-face continuation preserves prepared variation',async()=>{
 const f=await fixture(),picker=await f.rt.load('src/picker.js');
 const first=picker.pickCombination({...f.settings,lotteryMethod:'classic'},'single').combo;
 const continued=picker.pickCombinationForMultifaceResay(f.settings,{faceIndex:0,faces:[first],preserveVariation:true}).combo;
 assert.equal(continued.paletteRecipeId,first.paletteRecipeId);
 assert.equal(continued.interactionRecipeId,first.interactionRecipeId);
 const pinned={combo:copy(first)};delete pinned.combo.paletteRecipeId;
 const before=JSON.stringify(pinned);
 f.builder.planRabbitMirrorPromptDetails(f.settings,'independent',null,'legacy',{pinnedSelections:[pinned]});
 assert.equal(JSON.stringify(pinned),before);
});

test('palette exhaustion degrades preference without blocking; invalid IDs and prose cannot inject palette material',async()=>{
 const rt=createRuntime(root),m=await rt.load('src/paletteRecipes.js');
 const {GENERATION_PALETTE_INDEX}=await rt.load('data/structured/generationPaletteIndex.js');
 assert.equal(GENERATION_PALETTE_INDEX.length,516);
 assert.equal(new Set(GENERATION_PALETTE_INDEX.map(x=>x.code)).size,516);
 for(const p of GENERATION_PALETTE_INDEX) assert.equal(p.colors,undefined);
 const recent=GENERATION_PALETTE_INDEX.map(x=>({paletteRecipeId:x.id}));
 assert.ok(m.selectPaletteRecipe({},{recent,usedIds:GENERATION_PALETTE_INDEX.map(x=>x.id),randomUnit:()=>.5}));
 for(const id of ['__proto__','<script>','radix-made-up-light'])assert.deepEqual(copy(m.generationPaletteFields({paletteRecipeId:id})),{});
 assert.deepEqual(copy(m.generationPaletteFields({paletteRecipeId:GENERATION_PALETTE_INDEX?.[0]?.id,presentationMode:'text'})),{});
});

test('observed paging does not trap an unfamiliar form in the sole generic physical recipe',async()=>{
 const rt=createRuntime(root),m=await rt.load('src/interactionRecipes.js');
 const recent=[{interactionRecipeId:'step-process',visualSkeleton:'operation_family:text_panel_switch'}];
 const ids=new Set();
 for(const n of [0,.2,.4,.6,.8,.9999]){
  const recipe=m.selectInteractionRecipe({formats:[{title:'未见过的外部媒介'}]},{recent,randomUnit:()=>n});
  assert.notEqual(recipe.id,'step-process');ids.add(recipe.id);
 }
 assert.ok(ids.size>1);
});
