import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';

const root = process.env.RM_TEST_SOURCE_ROOT || fileURLToPath(new URL('..', import.meta.url));
const requestSource = readFileSync(path.join(root, 'src/independentApi/request.js'), 'utf8');
const slice = (start, end) => requestSource.slice(requestSource.indexOf(start), requestSource.indexOf(end));
const draft = '<toto><details><summary>【兔子镜：窗前】</summary><!-- 内部结构 --></details></toto>';
const work = `<toto><style>.leaf{animation:fall 3s linear infinite;fill:#558844}
@keyframes fall{from{transform:translateY(-20px)}to{transform:translateY(80px)}}
#open:checked~svg .leaf{fill:#aa6633}</style><details open><summary>【兔子镜：窗前】</summary>
<input id="open" type="checkbox"><label for="open">推窗</label>
<svg viewBox="0 0 100 100"><path class="leaf" d="M20 20Q60 0 70 40Q40 60 20 20Z"/></svg>
<details><summary>附页</summary><p>树叶落到窗沿。</p></details></details></toto>`;
const prose = name => `<toto><details><summary>【兔子镜：${name}】</summary><p>${name}正文。</p></details></toto>`;
const withRuntime = fn => async () => {
    const rt = await createDomRuntime(root);
    try {
        const sanitizer = await rt.load('src/outputSanitizer.js');
        const request = await rt.load('src/independentApi/request.js');
        const geometry = await rt.load('src/independentApi/geometry.js');
        Object.assign(rt.context, {
            cleanRabbitMirrorOutput: sanitizer.cleanRabbitMirrorOutput,
            wrappedIndependentMirrorHtml: request.wrappedIndependentMirrorHtml,
        });
        vm.runInContext(slice('function extractMirrorInner(', 'function responseFinishReason(')
            + '\n' + slice('function independentMirrorBodyEvidence(', 'function independentVisualProgramIntegrity('), rt.context);
        await fn(rt, geometry, request);
    } finally { await rt.close(); }
};

test('skip a fenced empty draft and keep the complete work from the same visible response', withRuntime(async (rt, geometry) => {
    const raw = '先列结构。\n```html\n' + draft + '\n```\n完整作品：\n```html\n' + work + '\n```';
    const inner = rt.context.extractMirrorInner(raw);
    assert.equal(rt.context.independentMirrorBodyEvidence(inner), true);
    const ready = geometry.prepareIndependentReadyHtml(inner);
    const doc = new rt.window.DOMParser().parseFromString(ready, 'text/html');
    assert.equal(doc.querySelectorAll('details').length, 2, 'nested appendix remains inside the selected work');
    assert.equal(doc.querySelectorAll('svg path').length, 1);
    assert.equal(doc.querySelectorAll('style').length, 1, 'selected sibling CSS survives');
    assert.match(ready, /@keyframes/);
    assert.match(ready, /animation:[^;}]*infinite/);
    assert.match(ready, /:checked/);
    assert.equal(doc.querySelector('label').htmlFor, doc.querySelector('input').id);
    assert.doesNotMatch(ready, /先列结构|完整作品/);
}));

test('skip any number of title, comment and style-only drafts without borrowing their styles', withRuntime(async (rt) => {
    const styleOnly = '<toto><style>.unused{color:red}</style><details><summary>草稿</summary></details></toto>';
    const inner = rt.context.extractMirrorInner(draft + styleOnly + draft + prose('成品'));
    assert.match(inner, /成品正文/);
    assert.doesNotMatch(inner, /unused|color:red|草稿|窗前/);
}));

test('keep the first usable work when later works are longer or newer', withRuntime(async (rt) => {
    const inner = rt.context.extractMirrorInner(prose('首份') + draft + prose('后份'.repeat(100)));
    assert.match(inner, /首份正文/);
    assert.doesNotMatch(inner, /后份/);
}));

test('an ordinary single prose work keeps its content and adds no animation', withRuntime(async (rt, geometry) => {
    const ready = geometry.prepareIndependentReadyHtml(rt.context.extractMirrorInner(prose('书信')));
    assert.match(ready, /书信正文/);
    assert.doesNotMatch(ready, /@keyframes|<svg/);
}));

test('a visible media-only work after a draft counts as body', withRuntime(async (rt) => {
    const media = '<toto><details><summary>花瓣</summary><svg viewBox="0 0 10 10"><path d="M0 0L10 10"/></svg></details></toto>';
    const inner = rt.context.extractMirrorInner(draft + media);
    assert.equal(rt.context.independentMirrorBodyEvidence(inner), true);
    assert.match(inner, /<svg/);
}));

test('empty-only output keeps the existing empty-body failure boundary', withRuntime(async (rt) => {
    const inner = rt.context.extractMirrorInner(draft + draft);
    assert.ok(inner, 'preserve existing empty-shell diagnostic, not incomplete-output fallback');
    assert.equal(rt.context.independentMirrorBodyEvidence(inner), false);
}));

test('an incomplete later wrapper does not displace the closed empty draft', withRuntime(async (rt) => {
    const inner = rt.context.extractMirrorInner(draft + '<toto><details><summary>未完</summary><p>还在写');
    assert.equal(rt.context.independentMirrorBodyEvidence(inner), false);
    assert.doesNotMatch(inner, /还在写/);
}));

test('selected work still goes through normal script event and URL sanitation', withRuntime(async (rt, geometry) => {
    const unsafe = prose('安全').replace('</details>', '<script>alert(1)</script><a href="javascript:alert(2)" onclick="alert(3)">查看</a></details>');
    const ready = geometry.prepareIndependentReadyHtml(rt.context.extractMirrorInner(draft + unsafe));
    assert.match(ready, /安全正文/);
    assert.doesNotMatch(ready, /<script\b|onclick\s*=|javascript:/i);
}));

test('transport abort salvage can use the later complete work but never overrides local cancellation', withRuntime(async (rt) => {
    const abort = Object.assign(new Error('transport stopped'), { name: 'AbortError' });
    const raw = draft + work;
    assert.equal(rt.context.recoverableCompletedIndependentAbort(abort, { aborted: false }, raw), true);
    assert.match(rt.context.extractMirrorInner(raw), /<svg/);
    assert.equal(rt.context.recoverableCompletedIndependentAbort(abort, { aborted: true }, raw), false);
    assert.equal(rt.context.recoverableCompletedIndependentAbort({ ...abort, rabbitMirrorLocalAbort: true }, null, raw), false);
    assert.equal(rt.context.recoverableCompletedIndependentAbort({ ...abort, code: 'RABBIT_MIRROR_RESPONSE_TOO_LARGE' }, null, raw), false);
}));

test('actual single-face postprocess uses one received reply and records the sanitized full work', withRuntime(async (rt, geometry, request) => {
    const raw = draft + work;
    let requests = 0, processed;
    const start = requestSource.indexOf(' const {response:r,result,profile,attempts,requestDiagnostic,semanticError}=await requestIndependentCompletion(st,systemPrompt,userPrompt');
    const tail = requestSource.slice(start, requestSource.indexOf('\nexport function externalOwnerMesid', start)).replace(/}\s*$/, '');
    Object.assign(rt.context, {
        st: {}, systemPrompt: '', userPrompt: '', signal: null, requestOptions: { serialChild: true },
        requestSelectionDiagnostic: {}, dispatchLease: null, advancedSettings: {}, assertAdvancedCurrent() {},
        resay: null, activeFeedback: null, feedbackPrompt: '', executionLock: '', details: { metadata: {} }, faceCount: 1,
        evidence: { response() {}, processed(html) { processed = html; }, finish() {}, fail() {} },
        generationEvidenceFor: () => rt.context.evidence,
        requestIndependentCompletion: async () => { requests++; return { response: { ok: true }, result: { text: raw }, profile: 'offline', attempts: 1, requestDiagnostic: {} }; },
        atmosphereNotesFromHtml: () => [], stripAtmosphereChoiceMarkup: value => value,
        assertIndependentMarkupComplexityWithDiagnostic: request.assertIndependentMarkupComplexityWithDiagnostic, rememberApiProfile() {},
        bindRolePaletteCode: value => value, prepareIndependentReadyHtml: geometry.prepareIndependentReadyHtml,
        republishIndependentSemanticFailure() {},
    });
    vm.runInContext('async function runPostprocess(){\n' + tail + '\n}', rt.context);
    const result = await rt.context.runPostprocess();
    assert.equal(requests, 1);
    assert.equal(processed, result.html);
    assert.match(result.html, /<svg/);
    assert.match(result.html, /@keyframes/);
}));
