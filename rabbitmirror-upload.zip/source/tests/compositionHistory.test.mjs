import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readFileSync, existsSync } from 'node:fs';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';
import { el, mirror } from './helpers/domFixture.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const prose = '这是画面外的正文内容。人物与事件可以改变，但同样的位置与阅读方式并没有改变。';
export const scene = (prefix='s', colour='red') => el('div',{class:prefix,style:'position:relative;min-height:160px'},
    el('div',{class:'body',style:`position:absolute;width:40px;height:80px;background:${colour}`}),
    el('div',{class:'lamp',style:'position:absolute;width:20px;height:20px;background:blue'}));
export function pages(prefix='p', colour='red', n=3, device=false) {
    return mirror(Array.from({length:n},(_,i)=>`#${prefix}${i}:checked ~ .read .page${i}{display:block}` ).join('') +
        (device?`#${prefix}1:checked ~ .stage .body{transform:rotate(20deg)}`:''),
        ...Array.from({length:n},(_,i)=>el('input',{id:prefix+i,type:'radio',name:prefix})),
        scene('stage',colour),
        el('nav',{},...Array.from({length:n},(_,i)=>el('label',{for:prefix+i},'切换'+i))),
        el('div',{class:'read'},...Array.from({length:n},(_,i)=>el('article',{class:'page'+i},prose))));
}
async function fixture(){
    const rt=createRuntime(root); const storage=await rt.load('src/storage.js');
    Object.assign(rt.context, await rt.load('src/roleColorVariants.js'),await rt.load('src/presentationQuality.js'));
    const scannerSource=readFileSync(root+'/src/visualScanner.js','utf8');
    if(existsSync(root+'/src/compositionFingerprint.js')) Object.assign(rt.context,await rt.load('src/compositionFingerprint.js'));
    const pure=scannerSource.slice(0,scannerSource.indexOf('function normalizedText')).replace(/^import[\s\S]*?;\r?\n/gm,'').replace(/^export /gm,'');
    vm.runInContext(pure,rt.context);
    const scanner={scanRabbitMirrorHtml:rt.context.scanRabbitMirrorHtml};
    const settings=(await rt.load('src/settings.js')).defaultSettings;
    // Deterministic detached DOM host; never claims browser layout verification.
    function scan(node){rt.context.DOMParser=class{parseFromString(){return{querySelector:()=>node};}};return scanner.scanRabbitMirrorHtml(node.outerHTML);}
    const commit=(id,node)=>{storage.setPendingCombo({themeIds:[id],formatIds:['7.6']});const s=scan(node);storage.commitPendingCombo(s.signature,s.skeleton,s.riskFlags,s.paletteFingerprint,s.interactionFamily);return s;};
    return {rt,storage,scanner,scan,commit,settings:{...structuredClone(settings), postGenerationRecolor:false,userDirectivePriority:false,visualPromptEditingEnabled:false,behaviorRuleMode:'off'}};
}
test('outer scene/prose split survives recolour, content changes and renamed control ids',async()=>{
    const f=await fixture(); const a=pages(), b=pages('renamed','blue',2); const before=a.outerHTML;
    const one=f.storage.parseVisualFamilySkeleton(f.scan(a).skeleton),two=f.storage.parseVisualFamilySkeleton(f.scan(b).skeleton);
    assert.equal(one.layout_family,'scene_above_text'); assert.equal(two.layout_family,one.layout_family);
    assert.equal(one.operation_family,'text_panel_switch'); assert.equal(two.operation_family,one.operation_family);
    assert.equal(a.outerHTML,before);
});
test('scene-state controls are distinguished from text-only switching even with identical labels',async()=>{
    const f=await fixture(); const value=f.storage.parseVisualFamilySkeleton(f.scan(pages('device','red',3,true)).skeleton);
    assert.equal(value.layout_family,'scene_above_text'); assert.equal(value.operation_family,'object_state_change');
    assert.equal(f.storage.visualFamilyForCooldown(value).operation_family,undefined);
});
test('stacked native details are a prose-reveal operation, not a control-count ban',async()=>{
    const f=await fixture(); const node=mirror('',scene(),el('section',{},...[1,2,3].map(i=>el('details',{},el('summary',{},'选择'+i),el('p',{},prose)))));
    const value=f.storage.parseVisualFamilySkeleton(f.scan(node).skeleton);
    assert.equal(value.layout_family,'scene_above_text'); assert.equal(value.operation_family,'text_disclosure_stack');
});

test('independent checkbox text entries use disclosure history, not exclusive panel switching',async()=>{
    const f=await fixture();
    for(const n of [2,3,5]) {
        const node=mirror('.check:checked ~ .discovery{display:block}.discovery{display:none}',
            el('section',{},...Array.from({length:n},(_,i)=>el('div',{class:'pocket'},
                el('input',{type:'checkbox',id:'item-'+i,class:'check'}),
                el('label',{for:'item-'+i,class:'same'},'翻找'+i),
                el('div',{class:'discovery'},prose.repeat(2))))));
        const before=node.outerHTML;
        assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(node).skeleton).operation_family,'text_disclosure_stack');
        assert.equal(node.outerHTML,before);
    }
});

test('unnamed radios and overlapping independent prose states are not assumed mutually exclusive',async()=>{
    const f=await fixture();
    for(const kind of ['radio','checkbox']) {
        const node=mirror('#a:checked~.one{display:block}#b:checked~.two{display:block}.one,.two{position:absolute}',
            el('input',{id:'a',type:kind}),el('input',{id:'b',type:kind}),
            el('article',{class:'one'},prose),el('article',{class:'two'},prose));
        assert.notEqual(f.storage.parseVisualFamilySkeleton(f.scan(node).skeleton).operation_family,'text_panel_switch');
    }
});
test('A B remains in rolling history: colour/text changes are not a new structure',async()=>{
    const f=await fixture();f.commit('A',pages());
    const b=mirror('',el('section',{},el('article',{},prose),scene()));f.commit('B',b);
    const builder=await f.rt.load('src/promptBuilder.js');
    const result=builder.buildRabbitMirrorPromptDetails(f.settings,'independent',null,'aba');
    assert.match(result.prompt,/上画下文/);assert.match(result.prompt,/上文下画/);
    assert.match(result.prompt,/不因中间换过其他骨架而清零/);
    assert.equal((result.prompt.match(/近期结构记录【/g)||[]).length,1);
});
test('shared HTML rules do not repeat across mixed faces or four candidates',async()=>{
    const f=await fixture(); f.commit('A',pages()); const builder=await f.rt.load('src/promptBuilder.js');
    for(const route of ['normal','independent']){
        const result=builder.buildRabbitMirrorPromptDetails({...f.settings,rabbitMirrorFaceCount:3,
            rabbitMirrorPresentationModes:['html','longtext','html'],forceVisualScenery:true,visualSceneryCombination:true,
            enhancedVisualDrawing:true,lotteryMethod:'atmosphere',atmosphereStoryPercent:100},route,null,'mixed');
        for(const label of ['默认强避重【','近期结构记录【','交互形态冷却【','视觉短冷却【','真实视觉纠偏【','增强视觉绘制：','全局视觉完成度下限']){
            assert.ok((result.prompt.split(label).length-1)<=1,label);
        }
        assert.match(result.prompt,/按正文挑签/);
    }
});

test('three independent checkbox device controls never enter prose-switch cooldown',async()=>{
    const f=await fixture();const node=mirror('#x:checked~.scene .body{transform:rotate(20deg)}#y:checked~.scene .lamp{opacity:.5}#z:checked~.scene{filter:brightness(.7)}',
        ...['x','y','z'].map(id=>el('input',{id,type:'checkbox'})),...['x','y','z'].map(id=>el('label',{for:id,class:'same'},id)),scene('scene'));
    f.commit('device',node);
    assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(node).skeleton).operation_family,'object_state_change');
    assert.deepEqual([...f.storage.getRecentInteractionFamilies(5)],[]);
    const builder=await f.rt.load('src/promptBuilder.js'); const p=builder.buildRabbitMirrorPromptDetails(f.settings,'normal',null,'device');
    assert.doesNotMatch(p.prompt,/交互形态冷却【|近期交互家族：|交互骨架：多控件/);
});

test('large SVG scene is observed but a small icon above an article is not a scene',async()=>{
    const f=await fixture();
    for(const [size,expected] of [[24,undefined],[200,'scene_above_text']]){
        const n=mirror('',el('svg',{viewBox:`0 0 ${size} ${size}`},el('path',{d:'M0 0L20 20'})),el('article',{},prose));
        assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(n).skeleton).layout_family,expected);
    }
});

test('controls moving an SVG path or drawing group retain native object operations',async()=>{
    const f=await fixture();
    for(const group of [false,true]){
        const needle=el('path',{class:group?'blade':'needle',d:'M80 80 L80 20'});
        const n=mirror('#a:checked~.read .one{display:block}#b:checked~.read .two{display:block}#b:checked~svg .needle{transform:rotate(40deg)}',
            el('input',{id:'a',type:'radio',name:'n'}),el('input',{id:'b',type:'radio',name:'n'}),
            el('svg',{viewBox:'0 0 200 160'},group?el('g',{class:'needle'},needle):needle),
            el('section',{class:'read'},el('article',{class:'one'},prose),el('article',{class:'two'},prose)));
        f.commit('svg-device-'+group,n);
        assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(n).skeleton).operation_family,'object_state_change');
        assert.equal(f.storage.getRecentInteractionFamilies(5).length,0);
    }
});

test('external layout wins over absolute layers; integrated labels do not create external prose',async()=>{
    const f=await fixture(); const n=mirror('',scene());
    assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(n).skeleton).layout_family,undefined);
    const side=mirror('',el('section',{style:'display:flex'},scene(),el('article',{},prose)));
    assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(side).skeleton).layout_family,'scene_beside_text');
    const reverse=mirror('',el('section',{style:'display:flex;flex-direction:column-reverse'},scene(),el('article',{},prose)));
    assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(reverse).skeleton).layout_family,'text_above_scene');
});

test('stylesheet classes and responsive layout report structural separation without inventing direction',async()=>{
    const f=await fixture();const n=mirror('.stage{position:relative;min-height:180px}.stage .body{position:absolute;width:80px;height:80px;background:red}.stage .prop{position:absolute;width:60px;height:60px;background:blue}@media(max-width:500px){.layout{display:flex;flex-direction:column}}',
        el('section',{class:'layout'},el('div',{class:'stage'},el('div',{class:'body'}),el('div',{class:'prop'})),el('article',{},prose)));
    assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(n).skeleton).layout_family,'separate_scene_text');
});

test('renamed scoped IDs, class selectors and :has bind to actual panels',async()=>{
    const f=await fixture(); const n=mirror('[data-rabbit-mirror="true"] [id="a"]:checked ~ .read .one{display:block}[data-rabbit-mirror="true"] [id="b"]:checked ~ .read .two{display:block}',
        el('input',{id:'a',type:'radio',name:'n'}),el('input',{id:'b',type:'radio',name:'n'}),el('label',{for:'a'},'甲'),el('label',{for:'b'},'乙'),
        el('section',{class:'read'},el('article',{class:'one'},prose),el('article',{class:'two'},prose)));
    assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(n).skeleton).operation_family,'text_panel_switch');
    const has=mirror('.host:has(#a:checked) .one{display:block}.host:has(#b:checked) .two{display:block}',el('section',{class:'host'},
        el('input',{id:'a',type:'radio',name:'n'}),el('input',{id:'b',type:'radio',name:'n'}),el('article',{class:'one'},prose),el('article',{class:'two'},prose)));
    assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(has).skeleton).operation_family,'text_panel_switch');
});

test('labels alone, missing selector targets, and picture disclosures are not classified as prose routes',async()=>{
    const f=await fixture();const cases=[
        mirror('',...[1,2,3].map(i=>el('button',{class:'same'},'入口'+i))),
        mirror('#a:checked~.missing{display:block}',el('input',{id:'a',type:'checkbox'}),el('article',{},prose)),
        mirror('',...[1,2,3].map(i=>el('details',{},el('summary',{},'入口'+i),scene()))),
    ];
    for(const n of cases)assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(n).skeleton).operation_family,undefined);
});

test('history survives reload; unknown faces consume positions and expire A after five newer faces',async()=>{
    const f=await fixture();f.commit('A',pages());
    for(let i=0;i<4;i++){f.storage.setPendingCombo({themeIds:['other-'+i],formatIds:['8.3']});f.storage.commitPendingCombo('unknown','','',null,null);}
    const reloaded=createRuntime(root,{store:f.rt.store});const saved=await reloaded.load('src/storage.js');
    assert.ok(saved.getRecentStructuralCooldown(5).some(item=>item.value==='scene_above_text'));
    assert.ok(saved.getRecentInteractionFamilies(5).some(item=>item.id==='tabbed_radio_family'));
    saved.setPendingCombo({themeIds:['new-fifth'],formatIds:['8.3']});saved.commitPendingCombo('unknown','','',null,null);
    assert.equal(saved.getRecentStructuralCooldown(5).length,0);
    assert.equal(saved.getRecentInteractionFamilies(5).length,0);
});

test('all recent interaction families remain in prompt and multi-face plan, not just the first two',async()=>{
    const f=await fixture();const names=['tabbed_radio_family','checkbox_reveal_family','inner_details_family','flip_card_family'];
    for(const id of names){f.storage.setPendingCombo({themeIds:[id],formatIds:['7.6']});f.storage.commitPendingCombo('family','',[],null,{id,label:id,confidence:1});}
    const policy=await f.rt.load('src/interactionCooldown.js');assert.equal(policy.recentInteractionCooldowns(f.storage.getRecentInteractionFamilies(5)).length,4);
    const batch=await f.rt.load('src/batchInteractionDiversity.js');const plan=batch.planBatchInteractionDiversity(3,{enabled:true,recentFamilies:f.storage.getRecentInteractionFamilies(5)});
    assert.equal(plan[0].recentAvoidFamilyIds.length,4);
    assert.ok(plan[0].recentAvoidFamilyIds.includes('flip_card_family'));
    const batchRule=batch.buildBatchInteractionDiversityRule(plan.map(interactionDiversity=>({interactionDiversity})),f.settings);
    assert.doesNotMatch(batchRule,/近期使用的|翻面／双面切换/,'recent history is rendered only by the shared cooldown');
    assert.match(batchRule,/同一主交互家族/,'same-batch diversity remains active');
});

test('structural observations never mutate or reject complete safe repeated output',async()=>{
    const f=await fixture();const node=pages();const before=node.outerHTML;const scan=f.scan(node);
    const gate=await f.rt.load('src/independentQualityGate.js');assert.equal(gate.evaluateIndependentPostSanitizeQuality(before,scan).ok,true);
    assert.equal(node.outerHTML,before);
});

test('changing scene colours or a no-op opacity does not excuse a text-only tab skeleton',async()=>{
    const f=await fixture();const n=pages();
    const style=n.querySelector('style');style.nodes.push('#p1:checked ~ .stage .body{background:gold;filter:brightness(1.2);opacity:1}');
    assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(n).skeleton).operation_family,'text_panel_switch');
});

test('new fingerprints persist together with complete legacy visual dimensions',async()=>{
    const f=await fixture();const scan=f.commit('full-history',pages());
    const extended=scan.skeleton+'；diagnostic-note: '+'x'.repeat(200);
    assert.ok(extended.length>420);
    f.storage.updateLatestVisualSignature(scan.signature,extended,scan.riskFlags,scan.paletteFingerprint,scan.interactionFamily,{historyId:f.storage.getComboHistory(1)[0].historyId});
    const stored=f.storage.getComboHistory(1)[0].visualSkeleton;
    assert.equal(stored,extended.slice(0,640));
    assert.match(stored,/space_family:.*；interaction_family:.*；mood:/);
});

test('a marked CSS-only scenery surface also records the external prose layout',async()=>{
    const f=await fixture();const n=mirror('',el('div',{'data-rm-visual-scenery':'true',style:'min-height:150px;background:linear-gradient(red,blue)'},'雾中的站台'),el('article',{},prose));
    assert.equal(f.storage.parseVisualFamilySkeleton(f.scan(n).skeleton).layout_family,'scene_above_text');
});

test('two five-face batches cannot evict A before the third generation, including palette',async()=>{
    const f=await fixture();const rows=[];
    for(const [batchId,node,hueFamily] of [['round-A',pages(),'blue'],['round-B',mirror('',el('article',{},prose),scene()),'red']]){
        const scan=f.scan(node);
        for(let faceIndex=0;faceIndex<5;faceIndex++)rows.push({batchId,faceIndex,ts:100+rows.length,themeIds:[batchId],formatIds:['7.6'],
            visualSkeleton:scan.skeleton,interactionFamily:scan.interactionFamily,
            paletteFingerprint:{confidence:1,brightness:'dark',hueFamily,temperature:'cool',saturation:'low'}});
    }
    f.rt.store.setItem('rabbit_mirror_theater:last_combo:v11',JSON.stringify(rows));
    const structure=f.storage.getRecentStructuralCooldown(5);
    assert.ok(structure.some(x=>x.value==='scene_above_text'));
    assert.ok(structure.some(x=>x.value==='text_above_scene'));
    const policy=await f.rt.load('src/interactionCooldown.js');
    assert.ok(policy.recentInteractionCooldowns(f.storage.getRecentInteractionFamilies(5,{preserveEmpty:true})).some(x=>x.id==='tabbed_radio_family'));
    const palette=await f.rt.load('src/paletteCooldown.js');
    assert.match(palette.buildPaletteCooldownRule({darkVisualMode:true}),/冷蓝/);
    assert.match(palette.buildPaletteCooldownRule({darkVisualMode:true}),/冷红/);
});
