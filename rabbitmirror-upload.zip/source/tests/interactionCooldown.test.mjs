import assert from 'node:assert/strict';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const family = id => ({ id, label: id, confidence: 0.95, controlCount: 3, panelCount: 3,
    ...(id === 'tabbed_radio_family' ? { textPanelSwitch: true } : {}) });
async function fixture(history = [], overrides = {}) {
    const rt = createRuntime(root);
    const { defaultSettings } = await rt.load('src/settings.js');
    const storage = await rt.load('src/storage.js');
    for (let i = 0; i < history.length; i++) {
        storage.setPendingCombo({ themeIds: [`test-${i}`], formatIds: ['7.6'] });
        storage.commitPendingCombo('fixture', '', [], null, history[i]);
    }
    const prompt = await rt.load('src/promptBuilder.js');
    const settings = { ...JSON.parse(JSON.stringify(defaultSettings)), userDirectivePriority: false, ...overrides };
    return { rt, settings, prompt, storage };
}

test('fresh HTML has no fixed trigger count or permanent horizontal/vertical tab ban', async () => {
    const f = await fixture();
    const result = f.prompt.buildRabbitMirrorPromptDetails(f.settings, 'normal', null, 'fresh');
    assert.doesNotMatch(result.prompt, /触发器最多 2 个|硬性禁止“切页骨架”|即使媒介看起来像频道、档位、案卷或分页也不例外/);
    assert.doesNotMatch(result.prompt, /交互形态冷却/);
    assert.match(result.prompt, /实际使用过程成立的翻阅、档位与折叠照常保留/);
    assert.match(result.prompt, /控件数量不限/);
    assert.match(result.prompt, /不能以频道或分页命名豁免/);
});

test('recent tab observations activate strong cooldown with legacy family recognition', async () => {
    const f = await fixture([family('tabbed_radio_family'), family('tabbed_radio_family')]);
    const result = f.prompt.buildRabbitMirrorPromptDetails(f.settings, 'independent', null, 'recent');
    assert.match(result.prompt, /交互形态冷却/);
    assert.match(result.prompt, /多个同组 radio＋并列标签／按钮只切换同位置的长文字面板/);
    assert.match(result.prompt, /交互数量服从内容/);
    assert.doesNotMatch(result.prompt, /触发器最多 2 个/);
    assert.match(result.executionLock, /交互避用/);
});

test('one tab observation remains cooled across intervening unknown faces within five', async () => {
    const f = await fixture([family('tabbed_radio_family'), null, null, null]);
    const result = f.prompt.buildRabbitMirrorPromptDetails(f.settings, 'normal', null, 'expired');
    assert.match(result.prompt, /交互形态冷却/);
    const batch = await f.rt.load('src/batchInteractionDiversity.js');
    const hints = batch.planBatchInteractionDiversity(2, { enabled: true,
        recentFamilies: f.storage.getRecentInteractionFamilies(5, { preserveEmpty: true }) });
    assert.deepEqual([...hints[0].recentAvoidFamilyIds], ['tabbed_radio_family']);
});

test('legacy false does not suppress strong cooldown; native details remain allowed', async () => {
    const f = await fixture([family('tabbed_radio_family')], { avoidRepeat: false });
    f.storage.setPendingCombo({ themeIds: ['details'], formatIds: ['7.6'] });
    f.storage.commitPendingCombo('details', '', ['inner_details_used'], null, family('inner_details_family'));
    const result = f.prompt.buildRabbitMirrorPromptDetails(f.settings, 'normal', null, 'off');
    assert.match(result.prompt, /交互形态冷却/);
    assert.match(result.prompt, /正常装置控件/);
    assert.doesNotMatch(result.prompt, /内部折叠冷却/);
});

test('one internal details occurrence does not globally ban that HTML mechanism', async () => {
    const f = await fixture();
    f.storage.setPendingCombo({ themeIds: ['detail'], formatIds: ['7.6'] });
    f.storage.commitPendingCombo('details', '', ['inner_details_used'], null, family('inner_details_family'));
    const result = f.prompt.buildRabbitMirrorPromptDetails(f.settings, 'normal', null, 'one-detail');
    assert.doesNotMatch(result.prompt, /本轮禁止在最外层兔子镜内部再次使用 details|details\/summary 冷却/);
});

test('safe repeated-tab results stay accepted; cooldown never becomes a new failure gate', async () => {
    const f = await fixture();
    const quality = await f.rt.load('src/independentQualityGate.js');
    const html = '<toto><details><summary>唱片机</summary><section>' +
        [1, 2, 3].map(i => `<input type="radio" name="track" id="t${i}"><label for="t${i}">曲目${i}</label><p>回忆${i}</p>`).join('') +
        '</section></details></toto>';
    const result = quality.evaluateIndependentPostSanitizeQuality(html,
        { interactionFamily: family('tabbed_radio_family'), riskFlags: ['flat_vertical_flow', 'weak_spatial_complexity'] });
    assert.equal(result.ok, true);
});

test('multiface final locks do not revive the removed details prohibition', async () => {
    const f = await fixture([], { rabbitMirrorFaceCount: 3 });
    f.storage.setPendingCombo({ themeIds: ['detail'], formatIds: ['7.6'] });
    f.storage.commitPendingCombo('details', '', ['inner_details_used'], null, family('inner_details_family'));
    const result = f.prompt.buildRabbitMirrorPromptDetails(f.settings, 'independent', null, 'details-batch',
        { batchIdentity: { mesid: 3, swipeId: 0, sourceHash: 'body' } });
    assert.doesNotMatch(result.executionLock, /details\/summary 冷却/);
});

test('unknown and low-confidence mechanisms stay exempt; reliable latest use enters cooldown', async () => {
    const f = await fixture();
    const policy = await f.rt.load('src/interactionCooldown.js');
    assert.deepEqual([...policy.recentInteractionCooldowns([family('unknown_player')])], []);
    assert.deepEqual([...policy.recentInteractionCooldowns([{ ...family('tabbed_radio_family'), confidence: 0.4 }])], []);
    assert.equal(policy.recentInteractionCooldowns([family('inner_details_family')]).length, 1);
    assert.equal(policy.recentInteractionCooldowns([family('inner_details_family'), family('inner_details_family')])[0].id, 'inner_details_family');
});
