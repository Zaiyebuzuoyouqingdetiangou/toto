import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';
import { captureFinalPrompt } from './helpers/finalPromptCapture.mjs';

// A saved trial setting now migrates to model-original guidance. Keep the
// selection, history, safety and scope invariants while checking that retirement.
const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));
const count = (text, part) => text.split(part).length - 1;
const historyKey = 'rabbit_mirror_theater:last_combo:v11';
const history = [
    { historyId: 'dark', paletteFingerprint: { brightness: 'dark', confidence: .9, averageLuminance: 25,
        darkAreaRatio: .9, hueFamily: 'blue', temperature: 'cool', saturation: 'medium' } },
    { historyId: 'warm', paletteFingerprint: { brightness: 'light', confidence: .9, averageLuminance: 237,
        averageChroma: .13, hueFamily: 'yellow', temperature: 'warm', saturation: 'low' } },
    { historyId: 'unknown' },
];

async function fixture() {
    const rt = createRuntime(root);
    const config = await rt.load('src/settings.js');
    const builder = await rt.load('src/promptBuilder.js');
    const { THEMATIC_CATEGORIES } = await rt.load('data/structured/thematicIndex.js');
    const { PRESENTATION_FORMATS } = await rt.load('data/structured/presentationIndex.js');
    const theme = THEMATIC_CATEGORIES.find(x => x.id === 'F.0');
    const form = PRESENTATION_FORMATS.find(x => x.id === '3.3.1');
    const combo = { themeIds: [theme.id], themes: [theme], formatIds: [form.id], formats: [form],
        presentationMode: 'html', requestedPresentationMode: 'html', samplingMode: 'classic',
        interactionRecipeIds: ['hinged-open'], interactionRecipeId: 'hinged-open',
        paletteRecipeId: 'radix-sky-sky-pink-light' };
    const settings = { ...copy(config.defaultSettings), visualDesignMode:'current', postGenerationRecolor:false, behaviorRuleMode: 'off', visualPromptEditingEnabled: false,
        enhancedVisualDrawing: true, userDirectivePriority: false, rawPolicy: 'compact',
        rabbitMirrorFaceCount: 1, rabbitMirrorPresentationModes: ['html'] };
    rt.store.setItem(historyKey, JSON.stringify(history));
    const render = (overrides = {}, selected = combo, type = 'independent') => builder.renderRabbitMirrorPromptPlan(
        builder.planRabbitMirrorPromptDetails({ ...settings, ...overrides }, type, null, 'dedup-fixed',
            { pinnedSelections: [{ combo: copy(selected), directive: null }] }));
    return { rt, config, builder, combo, render, settings };
}

for (const editing of [false, true]) test(`saved palette is removed from sending copy; editing ${editing}`, async () => {
    const f = await fixture();
    const out = f.render({ visualPromptEditingEnabled: editing });
    assert.equal(count(out.prompt, '色彩组织:'), 1);
    assert.equal(count(out.prompt, '配色短冷却【'), 1);
    assert.equal(count(out.prompt, '色族避重【'), 1);
    assert.equal(count(out.prompt, '生成配色参考【'), 0);
    assert.equal(count(out.prompt, '普通模式深色冷却【剩余 3 轮'), 1);
    assert.match(out.prompt, /米白|暖浅中性/);
    assert.match(out.prompt, /不得只调亮暗或换一处强调色/);
    assert.equal(count(out.prompt, '近期选材与视觉参考（共用一份）'), 0);
    assert.doesNotMatch(out.prompt, /近期主题：未记录|固定场景或未记录/);
});

test('all saved tickets lose trial palette IDs, while shared colour rules and four choices remain', async () => {
    const f = await fixture();
    const combo = { ...f.combo, atmosphereMenu: [
        { themeIds: ['F.0'], formatIds: ['3.3.1'], paletteRecipeId: f.combo.paletteRecipeId },
        { themeIds: ['F.0'], formatIds: ['7.6'] },
        { themeIds: ['F.0'], formatIds: ['4.3'], paletteRecipeId: 'missing-palette-id' },
        { themeIds: ['F.0'], formatIds: ['8.3'], paletteRecipeId: f.combo.paletteRecipeId },
    ] };
    const frozen = JSON.stringify(combo);
    const out = f.render({}, combo);
    assert.equal(count(out.prompt, '色彩组织:'), 1);
    assert.doesNotMatch(out.prompt,/生成配色参考【/);
    assert.ok(out.metadata.atmosphereMenu.every(ticket=>!ticket.paletteRecipeId));
    assert.equal(count(out.prompt, '普通模式深色冷却【'), 1);
    assert.equal(out.metadata.atmosphereMenu.length, 4);
    assert.equal(JSON.stringify(combo), frozen);
});

test('an unassigned legacy HTML face retains the original color and history fallback', async () => {
    const f = await fixture();
    const out = f.render({}, { ...f.combo, paletteRecipeId: undefined });
    assert.equal(count(out.prompt, '生成配色参考【'), 0);
    assert.equal(count(out.prompt, '色彩组织:'), 1);
    assert.equal(count(out.prompt, '配色短冷却【'), 1);
    assert.equal(count(out.prompt, '普通模式深色冷却【'), 1);
});

test('explicit visual edits are retained verbatim and do not become factory fallback', async () => {
    const f = await fixture();
    const custom = f.config.DEFAULT_VISUAL_PROMPT + '\n用户自己保存的规则：花瓣粉用于主体。';
    const out = f.render({ visualPromptEditingEnabled: true, visualPrompt: custom });
    assert.ok(out.prompt.includes(custom));
    assert.equal(count(out.prompt, '色彩组织:'), 1, 'custom text remains user-owned');
});

test('normal flow lives once in HTML safety and narrow-screen is checked once again in the lock', async () => {
    const f = await fixture();
    const out = f.render();
    assert.equal(count(out.prompt, '正常文档流'), 1);
    assert.equal(count(out.prompt, '360px'), 1);
    assert.equal(count(out.executionLock, '360px'), 1);
    const drawing = out.prompt.split('\n').find(x => x.startsWith('增强视觉绘制：'));
    assert.match(drawing, /主体轮廓与阅读焦点/);
    assert.match(drawing, /可自由组合 HTML、CSS 与安全内联 SVG。/);
    assert.doesNotMatch(drawing, /正常文档流|360px/);
    assert.equal(count(out.prompt, '媒介内交互构造：'), 1);
    assert.match(out.prompt, /频道.*分页.*豁免/);
    assert.match(out.prompt, /控件数量不限/);
    const order = out.executionLock.split('\n').find(x => x.startsWith('形式执行顺序：'));
    assert.ok(order.length <= 130);
});

test('independent order is compact but count, shell, closure and construction boundary remain', async () => {
    const f = await fixture();
    const out = f.render();
    assert.doesNotMatch(out.prompt, /兔子镜输出预留:|兔子镜构思作用域:|上文聊天里如果出现过多面/);
    assert.match(out.prompt, /本轮只输出 1 面/);
    assert.match(out.prompt, /<toto data-rabbit-mirror="true" style="display:block;">/);
    assert.match(out.prompt, /不续写正文/);
    assert.match(out.prompt, /预留输出长度/);
    assert.match(out.prompt, /变量|人物行动|人物/);
    assert.match(out.prompt, /全部闭合|完整闭合/);
    assert.match(out.prompt, /状态栏与其他模块隔离|状态栏隔离/);
    const follow = f.render({}, f.combo, 'normal');
    assert.match(follow.prompt, /不要模仿|不模仿/);
    assert.match(follow.prompt, /状态栏.*之前|状态栏.*最后.*兔子镜|状态栏[^\n]*兔子镜/);
});

test('longtext remains text-only and gets no HTML palette organization, drawing or interaction library', async () => {
    const f = await fixture();
    const out = f.render({}, { ...f.combo, presentationMode: 'text', requestedPresentationMode: 'longtext' });
    assert.match(out.prompt, /长文本呈现规则/);
    assert.doesNotMatch(out.prompt, /色彩组织:|生成配色参考【|交互构造库【|增强视觉绘制：|复杂交互视觉核心:/);
    assert.equal(count(out.prompt, '普通模式深色冷却【'), 1);
});

test('history only drops empty material labels, retaining real structure and recorded themes', async () => {
    const f = await fixture();
    f.rt.store.setItem(historyKey, JSON.stringify([{ historyId: 'known', themeIds: ['F.0'],
        visualSkeleton: 'layout_family: scene_above_text；operation_family: text_panel_switch' }]));
    const out = f.render();
    assert.match(out.prompt, /近期主题：F\.0/);
    assert.doesNotMatch(out.prompt, /未记录/);
    assert.match(out.prompt, /近期结构记录【|实际构图/);
});

test('only an entirely new install defaults creative supplement to off', async () => {
    const fresh = createRuntime(root), config = await fresh.load('src/settings.js');
    assert.equal(config.getSettings().behaviorRuleMode, 'off');
    assert.equal(config.getSettings().behaviorRuleMode, 'off');
    for (const saved of [{}, { behaviorRuleText: 'old custom' }, { behaviorRuleMode: 'always' },
        { behaviorRuleMode: 'off' }, { behaviorRuleMode: 'adult-only' }]) {
        const rt = createRuntime(root), host = await rt.load('../../../extensions.js');
        host.extension_settings[config.MODULE_NAME] = copy(saved);
        const old = await rt.load('src/settings.js');
        assert.equal(old.getSettings().behaviorRuleMode, saved.behaviorRuleMode ?? 'always');
        if (saved.behaviorRuleText) assert.equal(old.getSettings().behaviorRuleText, saved.behaviorRuleText);
        const snapshot = JSON.stringify(old.getSettings());
        assert.equal(JSON.stringify(old.getSettings()), snapshot, 'reopening does not migrate explicit intent');
    }
});

test('mixed per-face and per-ticket fallback does not inherit another face palette or reach text', async () => {
    const f = await fixture();
    const source = readFileSync(root + '/src/promptBuilder.js', 'utf8');
    const section = name => {
        const start = source.indexOf('function ' + name + '(');
        assert.ok(start >= 0);
        const end = source.indexOf('\nfunction ', start + 1);
        return source.slice(start, end < 0 ? undefined : end);
    };
    const palettes = await f.rt.load('src/generationPalettes.js');
    Object.assign(f.rt.context, f.config, palettes, await f.rt.load('src/paletteRecipes.js'),
        await f.rt.load('src/paletteCooldown.js'), await f.rt.load('src/visualDiversityPolicy.js'));
    for (const name of ['groupScopedRules', 'cleanEditableVisualPrompt', 'sharedPaletteRules']) {
        vm.runInContext(section(name), f.rt.context);
    }
    const face = (combo, textPresentation = false) => ({ combo, textPresentation });
    const faces = [face(f.combo), face({ ...f.combo, paletteRecipeId: undefined }),
        face({ ...f.combo, paletteRecipeId: undefined }, true),
        { ...face(f.combo), atmosphereFaces: [face(f.combo), face({ ...f.combo, paletteRecipeId: undefined })] }];
    const out = f.rt.context.sharedPaletteRules(faces, f.settings, palettes.selectGenerationPalettes(faces));
    const scope = out.match(/共用适用规则【([^\n]+)】\n仅上述范围执行，未选中的签不执行：\n\s*色彩组织:/)?.[1];
    assert.equal(scope, '第 2 面 HTML；第 4 面仅选中签 2 时适用');
    assert.match(out, /第 1 面：P\.413/);
    assert.match(out, /第 4 面／选签 1：P\.413/);
    assert.doesNotMatch(out, /第 2 面：P\.|第 3 面|第 4 面／选签 2：P\./);
    assert.equal(count(out, '普通模式深色冷却【'), 1);
});

for (const lotteryMethod of ['random', 'atmosphere']) for (const kind of ['ordinary', 'scenery', 'combination']) {
    test(`final transport input ${lotteryMethod}/${kind}: one rule body, count + lock preserved`, async () => {
        const out = await captureFinalPrompt(root, { history, overrides: { visualDesignMode:'current', postGenerationRecolor:false, lotteryMethod, atmosphereStoryPercent: 100,
            forceVisualScenery: kind === 'scenery', visualSceneryCombination: kind === 'combination' } });
        const system = out.messages[0].content, user = out.messages[1].content;
        assert.equal(count(system, '生成配色参考【'), 0);
        assert.equal(count(system, '配色共用要求【'), 1);
        assert.equal(count(system, '色彩组织:'), 1);
        assert.equal(count(system, '普通模式深色冷却【'), 1);
        // Main's dynamic block includes its own flow sentence; the shared HTML
        // contract is retained. Ordinary requests still have only one.
        assert.equal(count(system, '正常文档流'), kind === 'ordinary' ? 1 : 2);
        assert.equal(count(system, '360px'), 1);
        assert.equal(count(user, '360px'), 1);
        assert.equal(count(system, '媒介内交互构造：'), 1);
        assert.match(system, /本轮只输出 1 面/);
        assert.match(user, /完整 <toto>\.\.\.<\/toto>/);
        assert.equal(out.dispatches, 1);
        if (lotteryMethod === 'atmosphere') assert.equal(out.meter.metadata.atmosphereMenu.length, 4);
    });
}

test('new install switch can still be enabled, saved, reloaded and turned off', async () => {
    const rt = createRuntime(root), config = await rt.load('src/settings.js');
    config.updateSettings({ behaviorRuleMode: 'always', behaviorRuleText: 'USER_DEFINED_RULE' });
    const saved = copy(config.getSettings());
    const reloaded = createRuntime(root), host = await reloaded.load('../../../extensions.js');
    host.extension_settings[config.MODULE_NAME] = saved;
    const c = await reloaded.load('src/settings.js'), behavior = await reloaded.load('src/behaviorRules.js');
    assert.match(behavior.buildBehaviorRuleBlock(c.getSettings()), /USER_DEFINED_RULE/);
    c.updateSettings({ behaviorRuleMode: 'off' });
    assert.equal(behavior.buildBehaviorRuleBlock(c.getSettings()), '');
    assert.equal(c.getSettings().behaviorRuleText, 'USER_DEFINED_RULE');
});

for (const route of ['normal', 'independent']) test(`${route}: disabling hard startup retains the ordinary length and closure fallback`, async () => {
    const f = await fixture();
    const out = f.render({ hardStartup: false }, f.combo, route);
    assert.doesNotMatch(out.prompt, /预留输出长度/);
    assert.match(out.prompt, /输出长度紧张时/);
    assert.match(out.prompt, /仍须完整输出/);
    assert.match(out.prompt, /本轮只输出 1 面/);
    if (route === 'normal') assert.match(out.prompt, /先收束主回复/);
});
