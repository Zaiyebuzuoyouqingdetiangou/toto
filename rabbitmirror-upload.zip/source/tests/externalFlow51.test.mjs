import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';

const root = process.env.RM_TEST_SOURCE_ROOT || fileURLToPath(new URL('..', import.meta.url));
const dom = fn => async () => {
  const rt = await createDomRuntime(root);
  try {
    rt.window.document.head.innerHTML = '<style>' + readFileSync(root + '/style.css', 'utf8') + '</style>';
    await fn(rt);
  } finally { await rt.close(); }
};
function fixture(rt, html, source = 'independent') {
  const doc = rt.window.document;
  doc.body.innerHTML = `<div id="chat"><div class="rabbit-mirror-external-shell" data-rm-source="${source}" data-rm-placement="external" data-rm-state="ready"><details data-rabbit-mirror-external-details="true" open><summary>镜面</summary>${html}</details><div data-rm-face-swipe-host>1/1</div></div></div>`;
  const host = doc.querySelector('.rabbit-mirror-external-shell'), details = host.querySelector('details');
  return { host, details, body: details.querySelector(':scope > article, :scope > div'), cs: node => rt.window.getComputedStyle(node) };
}

test('the plugin does not impose a scrolling viewport on every generated body', dom(async rt => {
  const { body, cs } = fixture(rt, '<article><p>正常正文</p></article>');
  assert.ok(['', 'visible'].includes(cs(body).overflowY || cs(body).overflow));
  assert.ok(['', 'visible'].includes(cs(body).overflowX || cs(body).overflow));
}));

test('a constrained flow body grows with text and expanded native content without rewriting author CSS or controls', dom(async rt => {
  const { host, details, body, cs } = fixture(rt, '<article style="height:360px;max-height:60vh;overflow:auto;background:#f4faf8"><p>状态和正文</p><details><summary>就地附页</summary><p>补充</p></details><input type="checkbox" checked></article>');
  const original = body.getAttribute('style'), inner = body.querySelector('details'), control = body.querySelector('input');
  const { releaseExternalFlowHeight } = await rt.load('src/independentApi/geometry.js');
  assert.equal(releaseExternalFlowHeight(host, details), 1);
  assert.equal(cs(body).height, 'auto');
  assert.equal(cs(body).maxHeight, 'none');
  assert.equal(cs(body).overflowY || cs(body).overflow, 'visible');
  assert.equal(body.getAttribute('style'), original);
  inner.open = true; inner.append(rt.window.document.createElement('p'));
  assert.equal(cs(body).height, 'auto', 'future content remains in intrinsic flow; no sampled pixel height');
  inner.open = false;
  assert.equal(cs(body).height, 'auto', 'shrinking does not leave a captured tall height');
  assert.equal(control.checked, true);
  assert.equal(details.nextElementSibling.hasAttribute('data-rm-face-swipe-host'), true);
  assert.equal(details.contains(details.nextElementSibling), false);
}));

test('a flow wrapper may grow around a fixed scene while the scene and its animation remain authored', dom(async rt => {
  const { host, details, body, cs } = fixture(rt, '<article data-rm-visual-scenery="true" style="max-height:500px;overflow-y:auto"><div class="stage" style="height:380px;position:relative;overflow:hidden"><div style="position:absolute;animation:drift 4s infinite">绘制主体</div></div><section><p>反馈在画布以外</p></section></article>');
  const stage = body.firstElementChild, style = stage.getAttribute('style');
  (await rt.load('src/independentApi/geometry.js')).releaseExternalFlowHeight(host, details);
  assert.equal(cs(body).maxHeight, 'none');
  assert.equal(stage.getAttribute('style'), style);
  assert.equal(cs(stage).height, '380px');
  assert.match(cs(stage.firstElementChild).animation, /infinite/);
}));

test('absolute scene canvases, horizontal panoramas and nested device screens keep their own viewport', dom(async rt => {
  const { releaseExternalFlowHeight } = await rt.load('src/independentApi/geometry.js');
  for (const html of [
    '<article style="height:380px;overflow:hidden;position:relative"><div style="position:absolute">画面主体</div><label>触碰</label></article>',
    '<article style="height:380px;overflow:auto;scroll-snap-type:x proximity"><section><p>横卷</p></section></article>',
    '<article style="height:380px;overflow:auto;aspect-ratio:1"><section><p>固定比例画布</p></section></article>',
  ]) {
    const { host, details, body, cs } = fixture(rt, html);
    assert.equal(releaseExternalFlowHeight(host, details), 0);
    assert.equal(cs(body).height, '380px');
  }
  const f = fixture(rt, '<article><div class="device" style="height:380px"><section class="screen" style="height:260px;overflow:auto"><p>装置原生滚动</p></section></div><p>装置外说明</p></article>');
  assert.equal(releaseExternalFlowHeight(f.host, f.details), 0);
  assert.equal(f.cs(f.body.querySelector('.screen')).overflowY || f.cs(f.body.querySelector('.screen')).overflow, 'auto');
}));

test('horizontal overflow is protected even without snap; pending, detached, closed and inline shells are untouched', dom(async rt => {
  const { releaseExternalFlowHeight } = await rt.load('src/independentApi/geometry.js');
  const f = fixture(rt, '<article style="height:380px;overflow:auto"><p>横向内容</p></article>');
  Object.defineProperties(f.body, { clientWidth: { value: 360 }, scrollWidth: { value: 1100 } });
  assert.equal(releaseExternalFlowHeight(f.host, f.details), 0);
  for (const state of ['pending', 'closed', 'inline', 'detached']) {
    const g = fixture(rt, '<article style="height:380px;overflow:auto"><p>正文</p></article>');
    if (state === 'pending') g.host.dataset.rmState = 'pending';
    if (state === 'closed') g.details.open = false;
    if (state === 'inline') g.host.dataset.rmPlacement = 'inline';
    if (state === 'detached') g.host.remove();
    assert.equal(releaseExternalFlowHeight(g.host, g.details), 0, state);
  }
}));

test('follow external shells share flow fitting; cached markers are discarded before a new mount', dom(async rt => {
  const f = fixture(rt, '<article style="max-height:300px;overflow:auto"><p>跟随正文的内容</p></article>', 'follow');
  (await rt.load('src/independentApi/geometry.js')).releaseExternalFlowHeight(f.host, f.details);
  assert.equal(f.cs(f.body).maxHeight, 'none');
  const saved = (await rt.load('src/independentApi/geometry.js')).scrubIndependentInteractionState(f.details.outerHTML, f.details.outerHTML);
  assert.doesNotMatch(saved, /data-rm-external-flow-root/);
  assert.match(saved, /max-height:300px/);
  (await rt.load('src/independentApi/mount.js')).stripIndependentTransientLayoutArtifacts(f.details);
  assert.equal(f.body.hasAttribute('data-rm-external-flow-root'), false);
  assert.equal(f.cs(f.body).maxHeight, '300px');
}));

test('first opening a mounted mirror reaches flow fitting through the existing deferred activation', dom(async rt => {
  const f = fixture(rt, '<article style="height:380px;overflow:auto"><p>展开后的正文</p></article>');
  f.details.open = false;
  const callbacks = [];
  rt.context.requestAnimationFrame = fn => { callbacks.push(fn); return callbacks.length; };
  rt.context.setTimeout = fn => { callbacks.push(fn); return callbacks.length; };
  const geometry = await rt.load('src/independentApi/geometry.js');
  geometry.ensureExternalTools(f.host);
  assert.equal(f.body.hasAttribute('data-rm-external-flow-root'), false);
  f.details.open = true;
  f.details.dispatchEvent(new rt.window.Event('toggle'));
  for (let i = 0; callbacks.length && i < 40; i++) callbacks.shift()();
  assert.equal(f.cs(f.body).height, 'auto');
  assert.equal(f.body.hasAttribute('data-rm-external-flow-root'), true);
}));
