import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

// A saved trial setting now migrates to model-original guidance. Keep the
// selection, history, safety and scope invariants while checking that retirement.
const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const count = (text, marker) => text.split(marker).length - 1;

async function fixture(combination = false) {
    const rt = createRuntime(root);
    const { defaultSettings } = await rt.load('src/settings.js');
    const { PRESENTATION_FORMATS } = await rt.load('data/structured/presentationIndex.js');
    const { THEMATIC_CATEGORIES } = await rt.load('data/structured/thematicIndex.js');
    const builder = await rt.load('src/promptBuilder.js');
    const theme = THEMATIC_CATEGORIES.find(item => item.id === 'F.0');
    const format = id => PRESENTATION_FORMATS.find(item => item.id === id);
    const menu = ['10.2.3', '7.6', '8.3', '2.1.7'].map(id => ({
        themeIds: [theme.id], formatIds: combination ? ['10.2.2', id] : ['10.2.2'],
    }));
    const make = (tickets = menu, mode = 'html') => ({ themes: [theme], formats: tickets[0].formatIds.map(format),
        themeIds: [theme.id], formatIds: tickets[0].formatIds, atmosphereMenu: tickets,
        requestedPresentationMode: mode, presentationMode: mode === 'html' ? 'html' : 'text',
        visualSceneryCombination: combination, forcedVisualScenery: true });
    const settings = { ...JSON.parse(JSON.stringify(defaultSettings)), visualDesignMode:'current', lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100, forceVisualScenery: true,
        visualSceneryCombination: combination, avoidRepeat: false, userDirectivePriority: false };
    const render = (combos = [make()], type = 'independent', overrides = {}) => builder.renderRabbitMirrorPromptPlan(
        builder.planRabbitMirrorPromptDetails({ ...settings, rabbitMirrorFaceCount: combos.length,
            rabbitMirrorPresentationModes: combos.map(combo => combo.requestedPresentationMode), ...overrides },
        type, null, 'shared-rules-check', { pinnedSelections: combos.map(combo => ({ combo, directive: null })) }));
    return { render, make, menu, settings };
}

for (const combination of [false, true]) for (const type of ['normal', 'independent']) {
    test(`${type} ${combination ? 'combination' : 'scenery'}: four candidates share one full mode rule`, async () => {
        const f = await fixture(combination);
        const combo = f.make();
        const frozen = JSON.stringify(combo);
        const result = f.render([combo], type);
        const marker = combination ? '动态视觉组合【本面冻结' : 'Visual Scenery 场景优先级';
        assert.equal(count(result.prompt, marker), 1);
        assert.equal(count(result.prompt, '复杂交互视觉核心:'), 0, 'scenery modes use their specialized core');
        assert.equal(count(result.prompt, '按正文挑签：'), 1);
        for (let n = 1; n <= 4; n++) assert.equal(count(result.prompt, `签 ${n}（以下材料仅在选中本签时适用）：`), 1);
        assert.match(result.prompt, /仅选中签 1、2、3、4 时适用/);
        assert.equal(result.metadata.atmosphereMenu.length, 4);
        assert.equal(JSON.stringify(combo), frozen);
        assert.match(result.prompt, /<rm-ticket>序号<\/rm-ticket>/);
    });
}

test('several HTML menus share rules once, with a separate scope for each face', async () => {
    const f = await fixture();
    const result = f.render([f.make(), f.make(), f.make()]);
    assert.equal(count(result.prompt, 'Visual Scenery 场景优先级'), 1);
    assert.equal(count(result.prompt, '按正文挑签：'), 3);
    for (let n = 1; n <= 3; n++) assert.match(result.prompt, new RegExp(`第 ${n} 面：仅选中签 1、2、3、4 时适用`));
});

test('mixed visual and ordinary candidates retain distinct rule scopes', async () => {
    const f = await fixture();
    const menu = f.menu.map((ticket, i) => ({ ...ticket, formatIds: i % 2 ? ['7.6'] : ['10.2.2'] }));
    const result = f.render([f.make(menu)], 'independent', { forceVisualScenery: false });
    assert.equal(count(result.prompt, 'Visual Scenery 场景优先级'), 1);
    assert.equal(count(result.prompt, '复杂交互视觉核心:'), 1);
    assert.match(result.prompt, /仅选中签 1、3 时适用】[\s\S]*?Visual Scenery/);
    assert.match(result.prompt, /仅选中签 2、4 时适用】[^]*?复杂交互视觉核心/);
    assert.match(result.prompt, /共用适用规则【第 1 面 HTML】[^]*?媒介内交互构造/);
});

test('HTML shared rules and enhancement do not apply to longtext faces', async () => {
    const f = await fixture(true);
    const result = f.render([f.make(), f.make(f.menu, 'longtext'), f.make()], 'independent', { enhancedVisualDrawing: true });
    assert.equal(count(result.prompt, '动态视觉组合【本面冻结'), 1);
    assert.equal(count(result.prompt, '增强视觉绘制：'), 1);
    assert.match(result.prompt, /增强仅作用于 HTML 面（第 1、3 面）/);
    assert.doesNotMatch(result.prompt, /第 2 面：仅选中签/);
    assert.match(result.prompt, /长文本呈现规则/);
    assert.equal(result.metadata.faces.length, 3);
});

test('enhancement toggle changes only its own paragraph on a frozen menu', async () => {
    const f = await fixture(true);
    const combo = f.make();
    const off = f.render([combo], 'independent', { enhancedVisualDrawing: false });
    const on = f.render([combo], 'independent', { enhancedVisualDrawing: true });
    const paragraph = on.prompt.split('\n').find(line => line.startsWith('增强视觉绘制：'));
    assert.ok(paragraph);
    assert.match(paragraph, /可自由组合 HTML、CSS 与安全内联 SVG/);
    assert.match(paragraph, /材质、接缝、光源、阴影与排版层级/);
    assert.doesNotMatch(paragraph, /主动画|辅助动画|每面最多/);
    assert.equal(on.prompt.replace(paragraph + '\n\n', ''), off.prompt);
    assert.equal(on.executionLock, off.executionLock);
    assert.deepEqual(JSON.parse(JSON.stringify(on.metadata.atmosphereMenu)), JSON.parse(JSON.stringify(off.metadata.atmosphereMenu)));
});

test('main combination contract preserves touch interaction and actual media reading paths', async () => {
    const f = await fixture(true);
    const result = f.render();
    assert.match(result.prompt, /交互依抽中的形式自然产生，须真实可触摸并改变内容、关系、结构/);
    assert.match(result.prompt, /书信仍有完整书信、日志仍有实际记录/);
    assert.match(result.prompt, /不能把正文降格为画面说明或删除其阅读路径/);
    assert.doesNotMatch(result.prompt, /第三池|交互构造库/);
});

test('a longtext-only request receives neither shared drawing modes nor enhancement', async () => {
    const f = await fixture(true);
    const result = f.render([f.make(f.menu, 'longtext')], 'independent', { enhancedVisualDrawing: true });
    assert.doesNotMatch(result.prompt, /共用 HTML 模式规则|增强视觉绘制：|动态视觉组合【本面冻结|复杂交互视觉核心:/);
    assert.match(result.prompt, /长文本呈现规则/);
});
