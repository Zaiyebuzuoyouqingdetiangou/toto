import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';
import { createRuntime } from './helpers/vmLoader.mjs';

const root=process.env.RM_TEST_SOURCE_ROOT || fileURLToPath(new URL('..',import.meta.url));
const read=file=>readFileSync(root+'/'+file,'utf8').replaceAll('\r\n','\n');
const dom=fn=>async()=>{const rt=await createDomRuntime(root);try{await fn(rt);}finally{rt.close();}};

test('two beauty modes: removed saved mode and frozen settings cannot reactivate palette generation',async()=>{
 const rt=createRuntime(root), settings=await rt.load('src/settings.js'), design=await rt.load('src/visualDesign.js');
 for(const input of ['current','unknown',undefined]){
  settings.updateSettings({visualDesignMode:input,postGenerationRecolor:true});
  assert.equal(settings.getSettings().visualDesignMode,'guided1553');
  assert.equal(design.visualDesignMode({visualDesignMode:input}),'guided1553');
  assert.equal(design.postGenerationRecolorEnabled({visualDesignMode:input,postGenerationRecolor:true}),false);
 }
 settings.updateSettings({visualDesignMode:'reference1553'});
 assert.equal(settings.getSettings().visualDesignMode,'reference1553');
 const ui=read('src/ui/settingsTemplate.js');
 const modes=ui.match(/<select id="rh_visual_design_mode"[^]*?<\/select>/)[0];
 assert.equal((modes.match(/<option /g)||[]).length,2);
 assert.match(modes,/新美化规则/);assert.match(modes,/旧美化规则/);
 assert.doesNotMatch(ui,/id="rh_post_generation_recolor"/);
});

test('resay chooser retains all options and sends their selections directly once',dom(async rt=>{
 rt.context.innerWidth=360;rt.context.innerHeight=780;rt.context.addEventListener=rt.window.addEventListener.bind(rt.window);rt.context.removeEventListener=rt.window.removeEventListener.bind(rt.window);
 const cfg=await rt.load('src/settings.js');cfg.updateSettings({generationSource:'independent'});
 const {RUNTIME_VERSION}=await rt.load('src/independentApi/runtime.js');
 const calls=[];rt.context.__rabbitMirrorIndependentActionsV1={runtime:RUNTIME_VERSION,canResay:()=>({ok:true}),resay:(...args)=>{calls.push(args);return true;}};
 const tool=await rt.load('src/outputSanitizer/toolsChrome.js'),doc=rt.window.document;
 doc.body.innerHTML='<details open><summary>【兔子镜：春雪】</summary><div>画面</div></details>';
 const face=doc.querySelector('details');
 for(const mode of ['fresh','original','order']){
  assert.equal(tool.openRabbitMirrorResayChooser(face),true);
  const panel=doc.querySelector('[role="dialog"]');
  assert.match(panel.textContent,/跳过.*等待/);
  assert.equal(panel.querySelectorAll('[data-rm-resay-mode]').length,3);
  panel.querySelector(`[data-rm-resay-mode="${mode}"]`).click();
  panel.querySelector('[data-rm-resay-form="html"]').click();
  const note=panel.querySelector('textarea');note.value='雪落在窗沿，保留可展开的信';note.dispatchEvent(new rt.window.Event('input'));
  [...panel.querySelectorAll('button')].find(b=>b.textContent==='开始重说').click();
  assert.equal(calls.at(-1)[0],face);assert.equal(calls.at(-1)[2].mode,mode);
  assert.equal(calls.at(-1)[2].form,'html');assert.equal(calls.at(-1)[2].note,note.value);
 }
 assert.equal(calls.length,3);
 const source=read('src/outputSanitizer/toolsChrome.js');
 assert.doesNotMatch(source,/id: 'quick-resay'/);
 assert.doesNotMatch(source,/intent.type === 'resay' && !quickResayRabbitMirror/);
}));

test('external header takes the actual surface rather than a saturated isolated accent',dom(async rt=>{
 const source=read('src/independentApi/geometry.js');
 const names=['clampShellChannel','parseExternalShellColor','externalShellColorMetrics','mixExternalShellColors','externalShellRgba','externalShellContrastText','averageExternalShellColors','externalShellColorsFromText','externalShellWideTopBand','applyExternalShellIntegration'];
 for(const name of names){
  const match=source.match(new RegExp('^(?:export )?function '+name+'\\([^]*?^}', 'm'));
  if(match) vm.runInContext(match[0].replace(/^export /gm,''),rt.context);
 }
 // Geometry is the browser seam; use a real authored surface in a connected DOM.
 rt.context.independentPrimaryVisualShell=details=>({element:details.querySelector('article'),objectLike:false});
 const doc=rt.window.document;doc.body.innerHTML='<div data-rm-source="independent" data-rm-placement="external"><details data-rabbit-mirror-external-details="true"><summary>题目</summary><article style="background:#21192f;border-radius:12px">画面</article></details></div>';
 const host=doc.body.firstElementChild;
 assert.equal(rt.context.applyExternalShellIntegration(host,{base:{r:33,g:25,b:47},colors:[{r:220,g:20,b:20}]}),true);
 assert.equal(host.style.getPropertyValue('--rm-shell-header-bg'),host.style.getPropertyValue('--rm-shell-surface'));
 assert.equal(doc.querySelector('article').style.backgroundColor,'#21192f','author artwork is not recoloured');
}));

test('external frame encloses only title and face; sibling pager has its own readable surface',dom(async rt=>{
 const doc=rt.window.document;
 doc.head.innerHTML='<style>'+read('style.css')+'</style>';
 doc.body.innerHTML='<div id="chat"><div class="rabbit-mirror-external-shell" data-rm-source="independent" data-rm-placement="external" data-rm-shell-integrated="true" style="--rm-shell-surface:#21192f;--rm-shell-header-bg:#21192f;--rm-shell-header-text:#ffffff"><details data-rabbit-mirror-external-details="true" open><summary data-rm-title-chrome="true">题目<span data-rabbit-mirror-tool-entry-host><span data-rm-face-swipe-bar class="rabbit-mirror-face-swipe-bar"><button>‹</button><span data-rm-face-swipe-label>1/1</span><button>›</button></span></span></summary><article>原始画面</article></details></div></div>';
 const details=doc.querySelector('details'),host=details.parentElement,title=details.querySelector('[data-rabbit-mirror-tool-entry-host]');
 (await rt.load('src/facePagerPlacement.js')).placeFacePager(details,title,'bottom');
 const footer=details.nextElementSibling,cs=e=>rt.window.getComputedStyle(e);
 assert.equal(footer.parentElement,host,'ownership carrier stays stable');
 assert.equal(details.contains(footer),false);
 assert.equal(cs(host).backgroundColor,'transparent');
 assert.equal(cs(host).borderTopWidth,'0px');
 assert.equal(cs(details).borderTopStyle,'solid');
 assert.equal(cs(details.querySelector('summary')).width,'100%');
 assert.equal(cs(details.querySelector('summary')).marginBottom,'0px');
 const bar=footer.firstElementChild;
 assert.equal(cs(bar).backgroundColor,'#ffffff');
 assert.equal(cs(bar).color,'#20242a');
 assert.equal(details.querySelector('article').textContent,'原始画面');
}));
