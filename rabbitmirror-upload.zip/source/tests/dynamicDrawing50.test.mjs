import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { captureFinalPrompt } from './helpers/finalPromptCapture.mjs';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';

const root = process.env.RM_TEST_SOURCE_ROOT || fileURLToPath(new URL('..', import.meta.url));

test('dynamic drawing language reaches actual requests in all detail policies without requiring SVG or sending the whole interaction library', async () => {
  for (const lotteryMethod of ['random', 'atmosphere']) for (const combination of [false, true]) for (const rawPolicy of ['compact', 'balanced', 'full']) {
    const result = await captureFinalPrompt(root, { overrides: { lotteryMethod, rawPolicy,
      forceVisualScenery: !combination, visualSceneryCombination: combination, atmosphereStoryPercent: 100 } });
    const prompt = result.messages.map(message => message.content).join('\n');
    assert.doesNotMatch(prompt, /纯粹利用 CSS 色块|持续动态的 CSS 视觉画面|只写 transition、动画名、SVG、/);
    assert.match(prompt, /按需要组合 HTML、(?:安全)?内联 SVG 与 CSS/);
    assert.match(prompt, /CSS 动画可作用于 HTML 或 SVG/);
    assert.doesNotMatch(prompt, /每轮必须.*SVG|至少\s*\d+\s*(?:个|项).*SVG/);
    const poolSection = result.meter.basePrompt.split('交互构造库【')[1].split('\n\n兔子镜')[0];
    const selectedCodes = new Set((poolSection.match(/I\.\d+/g) || []));
    assert.ok(selectedCodes.size > 0 && selectedCodes.size < 48);
    if (rawPolicy === 'compact') assert.doesNotMatch(poolSection, /\n操作：|\n可见结果：|本轮实现依据/);
    if (rawPolicy === 'balanced') assert.match(poolSection, /\n操作：/);
    if (rawPolicy === 'full') assert.match(poolSection, /本轮实现依据/);
    assert.equal(result.dispatches, 1);
  }
});

test('safe inline SVG retains drawing, CSS animation and a bound interaction through sanitize save mount and export', async () => {
  const rt = await createDomRuntime(root);
  try {
    const source = `<toto data-rabbit-mirror="true"><details open><summary>【兔子镜：窗前的风】</summary>
      <style>.leaf{fill:#357866;animation:leaf-turn 3s ease-in-out infinite alternate;transform-origin:50% 50%}
      @keyframes leaf-turn{from{transform:rotate(-8deg)}to{transform:rotate(8deg)}}
      #open-window:checked~svg .window-pane{transform:translateX(30px)}
      .window-pane{fill:#cadfd7;transition:transform .3s}</style>
      <input type="checkbox" id="open-window"><label for="open-window">推开窗扇</label>
      <svg viewBox="0 0 240 160" width="100%"><g class="window-pane"><path d="M10 10H90V140H10Z"/></g>
      <path class="leaf" d="M120 80Q150 20 180 80Q150 140 120 80Z"/></svg></details></toto>`;
    const geometry = await rt.load('src/independentApi/geometry.js');
    const prepared = geometry.prepareIndependentReadyHtml(source);
    const saved = geometry.scrubIndependentInteractionState(prepared, prepared);
    const host = geometry.buildExternalHost('offline:svg:1', saved, 'ready', 'independent', true);
    rt.window.document.body.append(host);
    const rootNode = host.querySelector('details');
    const rules = [...rootNode.querySelector('style').sheet.cssRules];
    assert.equal(rootNode.querySelector('svg').getAttribute('viewBox'), '0 0 240 160');
    assert.equal(rootNode.querySelectorAll('svg path').length, 2);
    assert.ok(rules.some(rule => rule.type === 7));
    assert.match(rt.window.getComputedStyle(rootNode.querySelector('svg > path')).animation, /infinite/);
    const input = rootNode.querySelector('input');
    assert.equal(rootNode.querySelector('label').htmlFor, input.id);
    input.checked = true;
    const states = rules.filter(rule => rule.selectorText?.includes(':checked') && rootNode.querySelector(rule.selectorText));
    assert.ok(states.some(rule => rule.style.transform === 'translateX(30px)'));
    const panel = rt.window.document.createElement('div');
    panel.innerHTML = '<button>复制</button><div data-rm-copy-html-status></div>';
    rt.window.document.body.append(panel);
    let exported = '';
    rt.context.navigator = { clipboard: { writeText: async value => { exported = value; } } };
    await (await rt.load('src/outputSanitizer/diagnostics.js')).copyRabbitMirrorCurrentFaceHtml(rootNode, panel.firstChild, panel);
    assert.match(exported, /<svg\b/);
    assert.match(exported, /@keyframes/);
    assert.match(exported, /:checked/);
    assert.match(exported, /M120 80Q150 20 180 80Q150 140 120 80Z/);
  } finally { await rt.close(); }
});
