import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));
const scan = color => ({ visualSignature: color, visualSkeleton: 'subject:' + color,
    riskFlags: [], paletteFingerprint: { hueFamily: color, brightness: 'dark', confidence: 1 } });
async function fixture() {
    const rt = createRuntime(root), storage = await rt.load('src/storage.js');
    const config = await rt.load('src/settings.js'), builder = await rt.load('src/promptBuilder.js');
    storage.setPendingCombo({ themeIds: ['D.1'], formatIds: ['6.4.2'] });
    storage.commitPendingCombo('old completed', 'old structure', [], scan('orange').paletteFingerprint);
    const settings = { ...copy(config.defaultSettings), generationSource: 'independent',
        userDirectivePriority: false, lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100,
        rabbitMirrorFaceCount: 1, rabbitMirrorPresentationModes: ['html'] };
    const plan = builder.planRabbitMirrorPromptDetails(settings, 'independent', null, 'independent:test', {chat:[]});
    return { rt, storage, builder, plan, combo: builder.promptPlanSelections(plan)[0].combo };
}

test('an unrelated old-face scan cannot consume an unresolved four-ticket selection or rewrite history', async () => {
    const f = await fixture(), before = copy(f.storage.getComboHistory());
    f.storage.updateLatestVisualSignature('old DOM scan', 'old structure', [], scan('blue').paletteFingerprint);
    assert.deepEqual(copy(f.storage.getComboHistory()), before);
    const pending = JSON.parse(f.rt.store.getItem('rabbit_mirror_theater:pending_combo:v11'));
    assert.equal(pending.atmosphereMenu.length, 4);
    assert.notEqual(pending.atmosphereResolved, true);
});

test('unresolved selection waits instead of being deleted by an explicit legacy commit', async () => {
    const f = await fixture();
    const key = 'rabbit_mirror_theater:pending_combo:v11', pending = f.rt.store.getItem(key);
    f.storage.commitPendingCombo('not the chosen output');
    assert.equal(f.rt.store.getItem(key), pending);
});

test('the chosen ticket and visual result append together even if the pending slot was replaced', async () => {
    const f = await fixture(), selection = f.storage.createVisualHistorySelection(f.combo);
    const wanted = f.combo.atmosphereMenu[3];
    const chosen = f.storage.resolveVisualHistorySelection(selection, 3);
    f.storage.setPendingCombo({themeIds:['unrelated'],formatIds:['7.6']});
    assert.equal(f.storage.commitVisualHistorySelection(chosen, scan('red')), true);
    const history = copy(f.storage.getComboHistory());
    assert.equal(history.length, 2);
    assert.deepEqual(history[0].themeIds, ['D.1']);
    assert.equal(history[0].paletteFingerprint.hueFamily, 'orange');
    assert.deepEqual(history[1].themeIds, copy(wanted.themeIds));
    assert.deepEqual(history[1].formatIds, copy(wanted.formatIds));
    assert.equal(history[1].paletteFingerprint.hueFamily, 'red');
    assert.ok(history[1].signature.includes(JSON.stringify(wanted.formatIds)));
    assert.equal(history[1].atmosphereMenu, undefined);
    assert.equal(history[1].themes, undefined);
    assert.equal(history[1].formats, undefined);
    assert.equal(f.storage.commitVisualHistorySelection(chosen, scan('red')), true);
    assert.equal(f.storage.getComboHistory().length, 2, 'duplicate completion is idempotent');
});

test('two completed generations of the same selection occupy two rounds, while callbacks update exact owners', async () => {
    const f = await fixture(), combo = {themeIds:['F.0'],formatIds:['7.6']};
    const a = f.storage.createVisualHistorySelection(combo), b = f.storage.createVisualHistorySelection(combo);
    assert.notEqual(a.historyId,b.historyId);
    f.storage.commitVisualHistorySelection(a, scan('blue'));
    f.storage.commitVisualHistorySelection(b, scan('green'));
    assert.equal(f.storage.getComboHistory().length,3);
    assert.equal(f.storage.updateLatestVisualSignature('rendered A','A',[],scan('purple').paletteFingerprint,null,{historyId:a.historyId}),true);
    const h = copy(f.storage.getComboHistory());
    assert.equal(h[1].paletteFingerprint.hueFamily,'purple');
    assert.equal(h[2].paletteFingerprint.hueFamily,'green');
    assert.equal(f.storage.updateLatestVisualSignature('unknown','',[],null,null,{historyId:'unknown'}),false);
    assert.deepEqual(copy(f.storage.getComboHistory()),h);
});

test('quota and corrupt history failures preserve pending and prior data without suppressing the output', async () => {
    const f = await fixture(), entry=f.storage.resolveVisualHistorySelection(f.storage.createVisualHistorySelection(f.combo),0);
    const before=f.rt.store.getItem('rabbit_mirror_theater:last_combo:v11');
    f.rt.store.quota=0;
    assert.equal(f.storage.commitVisualHistorySelection(entry,scan('red')),false);
    assert.equal(f.rt.store.getItem('rabbit_mirror_theater:last_combo:v11'),before);
    f.rt.store.quota=Infinity;
    f.rt.store.setItem('rabbit_mirror_theater:last_combo:v11','broken');
    assert.equal(f.storage.commitVisualHistorySelection(entry,scan('red')),false);
    assert.equal(f.rt.store.getItem('rabbit_mirror_theater:last_combo:v11'),'broken');
});

test('runtime DOM ownership is not accepted from attributes and does not hold DOM in a persistent store', async () => {
    const f=await fixture(), node={dataset:{visualHistoryId:'forged'}};
    assert.equal(f.storage.visualHistoryTarget(node),null);
    f.storage.bindVisualHistoryTarget(node,{historyId:'trusted'});
    assert.deepEqual(copy(f.storage.visualHistoryTarget(node)),{historyId:'trusted'});
    f.storage.bindVisualHistoryTarget(node,null);
    assert.equal(f.storage.visualHistoryTarget(node),null);
});

test('follow scans leave old output and another chat alone, then commit the resolved new source once',async()=>{
    const f=await fixture(), old={is_user:false,mes:'old mirror',swipe_id:0}, chat=[old];
    let chatId='follow-A';
    f.rt.context.SillyTavern.getContext=()=>({chatId,chat});
    f.storage.setPendingCombo(f.combo,'follow:generation');
    const pending=f.rt.store.getItem('rabbit_mirror_theater:pending_combo:v11');
    assert.equal(f.storage.commitFollowVisualHistory(old,chat,'<rm-ticket>4</rm-ticket>',scan('red')),null);
    assert.equal(f.rt.store.getItem('rabbit_mirror_theater:pending_combo:v11'),pending);
    const fresh={is_user:false,mes:'new mirror',swipe_id:0};chat.push(fresh);
    chatId='follow-B';
    assert.equal(f.storage.commitFollowVisualHistory(fresh,chat,'<rm-ticket>4</rm-ticket>',scan('red')),null);
    chatId='follow-A';
    assert.equal(f.storage.commitFollowVisualHistory(fresh,chat,'missing ticket',scan('red')),null);
    const ref=f.storage.commitFollowVisualHistory(fresh,chat,'<rm-ticket>4</rm-ticket>',scan('red'));
    assert.ok(ref?.historyId);
    assert.equal(f.storage.getComboHistory().length,2);
    assert.deepEqual(copy(f.storage.getComboHistory()[1].formatIds),copy(f.combo.atmosphereMenu[3].formatIds));
    assert.equal(f.rt.store.getItem('rabbit_mirror_theater:pending_combo:v11'),null);
    f.storage.commitFollowVisualHistory(fresh,chat,'<rm-ticket>4</rm-ticket>',{...scan('purple'),signature:'rendered'});
    assert.equal(f.storage.getComboHistory().length,2);
    assert.equal(f.storage.getComboHistory()[1].paletteFingerprint.hueFamily,'purple');
    f.storage.setPendingCombo(f.combo,'independent:request');
    chat.push({is_user:false,mes:'not the independent output'});
    assert.equal(f.storage.commitFollowVisualHistory(chat.at(-1),chat,'<rm-ticket>1</rm-ticket>',scan('blue')),null);
});

test('completed history stays bounded and holds only accounting after 40 generations',async()=>{
    const f=await fixture();
    for(let i=0;i<40;i++){
        const selection=f.storage.resolveVisualHistorySelection(f.storage.createVisualHistorySelection(f.combo),i%4);
        assert.equal(f.storage.commitVisualHistorySelection(selection,scan(i%2?'green':'red')),true);
    }
    assert.equal(f.storage.getComboHistory(100).length,25);
    assert.ok(f.rt.store.getItem('rabbit_mirror_theater:last_combo:v11').length<60000);
    for(const entry of f.storage.getComboHistory(100)){
        assert.equal(entry.atmosphereMenu,undefined);
        assert.equal(entry.themes,undefined);
        assert.equal(entry.formats,undefined);
    }
});
