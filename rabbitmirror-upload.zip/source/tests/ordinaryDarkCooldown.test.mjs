import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';

// A saved trial setting now migrates to model-original guidance. Keep the
// selection, history, safety and scope invariants while checking that retirement.
const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const historyKey = 'rabbit_mirror_theater:last_combo:v11';
const dark = { brightness: 'dark', confidence: .9, darkAreaRatio: .85, averageLuminance: 30,
    hueFamily: 'blue', temperature: 'cool', saturation: 'medium' };
const light = { ...dark, brightness: 'light', darkAreaRatio: 0, averageLuminance: 220 };
const clone = value => JSON.parse(JSON.stringify(value));
const count = (text, marker) => text.split(marker).length - 1;
async function fixture() {
    const rt = createRuntime(root);
    const storage = await rt.load('src/storage.js');
    const palette = await rt.load('src/paletteCooldown.js');
    const builder = await rt.load('src/promptBuilder.js');
    const { defaultSettings } = await rt.load('src/settings.js');
    return { rt, storage, palette, builder, settings: { ...clone(defaultSettings), visualDesignMode:'current',
        userDirectivePriority: false, visualPromptEditingEnabled: false, darkVisualMode: false,
        lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100 },
        seed: records => rt.store.setItem(historyKey, JSON.stringify(records)),
    };
}

test('one dark completion cools exactly the next five completed rounds, including unknown observations', async () => {
    const f = await fixture();
    for (let completed = 0; completed <= 5; completed++) {
        f.seed([{ historyId: 'dark', paletteFingerprint: dark },
            ...Array.from({ length: completed }, (_, i) => ({ historyId: 'next-' + i,
                ...(i % 2 ? { paletteFingerprint: light } : {}) }))]);
        const result = f.storage.getActivePaletteCooldown(5);
        assert.equal(result.active, completed < 5);
        assert.equal(result.remaining, 5 - completed);
        const rule = f.palette.buildPaletteCooldownRule({ darkVisualMode: false });
        if (completed < 5) assert.match(rule, new RegExp(`普通模式深色冷却【剩余 ${5 - completed} 轮`));
        else assert.doesNotMatch(rule, /普通模式深色冷却/);
    }
});

test('five faces share one round; any dark face in a round triggers the cooldown', async () => {
    const f = await fixture();
    const batch = (id, colors) => colors.map((paletteFingerprint, faceIndex) => ({ batchId: id, faceIndex, paletteFingerprint }));
    f.seed([...batch('A', [dark, light, light, light, light]), ...batch('B', [light, light, light, light, light])]);
    assert.equal(f.storage.getActivePaletteCooldown().remaining, 4);
    f.seed([...batch('A', [dark, light, light, light, light])]);
    assert.equal(f.storage.getActivePaletteCooldown().remaining, 5);
});

test('shared round IDs and nonadjacent faces follow existing completed-round ordering', async () => {
    const f = await fixture();
    f.seed([{ diversityRound: 'A', paletteFingerprint: dark }, { diversityRound: 'B', paletteFingerprint: dark },
        { diversityRound: 'A', paletteFingerprint: light }]);
    assert.equal(f.storage.getActivePaletteCooldown().remaining, 5);
    f.seed([{ diversityRound: 'A', paletteFingerprint: dark },
        ...Array.from({ length: 5 }, (_, i) => ({ diversityRound: 'B', faceIndex: i }))]);
    assert.equal(f.storage.getActivePaletteCooldown().remaining, 4);
});

test('a fresh dark completion resets five rounds; low-confidence and light observations do not trigger', async () => {
    const f = await fixture();
    f.seed([{ paletteFingerprint: dark }, ...Array.from({ length: 4 }, () => ({})), { paletteFingerprint: dark }]);
    assert.equal(f.storage.getActivePaletteCooldown().remaining, 5);
    for (const paletteFingerprint of [light, { ...dark, confidence: .49 }, { ...dark, darkAreaRatio: .1, averageLuminance: 160 }]) {
        f.seed([{ paletteFingerprint }]);
        assert.equal(f.storage.getActivePaletteCooldown().active, false);
        assert.doesNotMatch(f.palette.buildPaletteCooldownRule({}), /普通模式深色冷却/);
    }
    f.seed([{ paletteFingerprint: { ...dark, darkAreaRatio: 0, averageLuminance: 0 } }]);
    assert.equal(f.storage.getActivePaletteCooldown().remaining, 5, 'zero luminance is valid evidence');
});

test('a trigger outside the three-round palette window still cools; dark mode is exempt', async () => {
    const f = await fixture();
    f.seed([{ paletteFingerprint: dark }, {}, {}, {}, {}]);
    const ordinary = f.palette.buildPaletteCooldownRule({ darkVisualMode: false });
    assert.match(ordinary, /普通模式深色冷却【剩余 1 轮/);
    assert.doesNotMatch(ordinary, /不因前一面深色而禁止后续深色|明暗不单独禁用/);
    assert.equal(f.palette.buildPaletteCooldownRule({ darkVisualMode: true }), '');
    assert.doesNotMatch(f.palette.buildPaletteCooldownExecutionLock({ darkVisualMode: true }), /深色冷却/);
    assert.match(f.palette.buildPaletteCooldownExecutionLock({ darkVisualMode: false }), /深色冷却/);
});

test('prompt reads and pending selections cannot consume the cooldown or mutate completed history', async () => {
    const f = await fixture();
    f.seed([{ historyId: 'completed', paletteFingerprint: dark }]);
    const before = f.rt.store.getItem(historyKey);
    for (let i = 0; i < 6; i++) {
        f.storage.setPendingCombo({ themeIds: ['F.0'], formatIds: ['3.3.1'] }, 'independent:pending-' + i);
        f.palette.buildPaletteCooldownRule({});
        assert.equal(f.storage.getActivePaletteCooldown().remaining, 5);
    }
    assert.equal(f.rt.store.getItem(historyKey), before);
    assert.equal(await (await createRuntime(root, { store: f.rt.store }).load('src/storage.js')).getActivePaletteCooldown().remaining, 5);
});

for (const route of ['normal', 'independent']) for (const kind of ['ordinary', 'scenery', 'combination']) {
    test(`${route}/${kind}: all four tickets share one cooldown, dark mode preserves the original core`, async () => {
        const f = await fixture(); f.seed([{ paletteFingerprint: dark }]);
        const render = darkVisualMode => f.builder.buildRabbitMirrorPromptDetails({ ...f.settings, darkVisualMode,
            forceVisualScenery: kind === 'scenery', visualSceneryCombination: kind === 'combination',
            enhancedVisualDrawing: true, rabbitMirrorFaceCount: 1, rabbitMirrorPresentationModes: ['html'] },
        route, null, 'cooldown-same-draw');
        const normal = render(false), night = render(true);
        assert.equal(count(normal.prompt, '普通模式深色冷却【'), 1);
        assert.equal(count(normal.executionLock, '普通模式深色冷却【'), 0, 'shared history is not repeated at the tail');
        assert.doesNotMatch(normal.prompt + normal.executionLock, /不因前一面深色而禁止后续深色/);
        assert.equal(normal.metadata.atmosphereMenu.length, 4);
        const withoutPalette = menu => clone(menu).map(({ paletteRecipeId, ...ticket }) => ticket);
        assert.deepEqual(withoutPalette(normal.metadata.atmosphereMenu), withoutPalette(night.metadata.atmosphereMenu));
        assert.ok(normal.metadata.atmosphereMenu.every(ticket => !ticket.paletteRecipeId));
        assert.ok(night.metadata.atmosphereMenu.every(ticket => !ticket.paletteRecipeId));
        assert.equal(count(normal.prompt, '按正文挑签：'), 1);
        assert.equal(count(normal.prompt, '增强视觉绘制：'), 1);
        assert.equal(count(normal.prompt, '复杂交互视觉核心:'), kind === 'ordinary' ? 1 : 0);
        assert.match(normal.prompt, /具体颜色、构图与工艺由本面决定/);
        assert.match(normal.prompt, /主体轮廓与阅读焦点/);
        assert.doesNotMatch(night.prompt, /普通模式深色冷却/);
        assert.match(night.prompt, /深色生成模式【/);
    });
}

for (const modes of [['html', 'html', 'longtext'], ['longtext']]) {
    test(`palette-only cooldown reaches ${modes.join('+')} without imposing HTML interaction on text`, async () => {
        const f = await fixture(); f.seed([{ paletteFingerprint: dark }]);
        const result = f.builder.buildRabbitMirrorPromptDetails({ ...f.settings,
            rabbitMirrorFaceCount: modes.length, rabbitMirrorPresentationModes: modes }, 'independent', null, 'mixed-color');
        assert.equal(count(result.prompt, '普通模式深色冷却【'), 1);
        if (modes.length === 1) assert.doesNotMatch(result.prompt, /复杂交互视觉核心:|媒介内交互构造：/);
        assert.doesNotMatch(result.prompt, /至少一面.*明亮/);
    });
}

for (const n of [13, 14, 15, 16]) {
    test(`user face ${n}: the existing scanner classifies the exported HTML as dark and triggers five rounds`, async () => {
        const f = await fixture();
        Object.assign(f.rt.context, await f.rt.load('src/roleColorVariants.js'), await f.rt.load('src/presentationQuality.js'), await f.rt.load('src/compositionFingerprint.js'));
        const scannerSource = readFileSync(root + '/src/visualScanner.js', 'utf8');
        vm.runInContext(scannerSource.slice(0, scannerSource.indexOf('function normalizedText'))
            .replace(/^import[\s\S]*?;\r?\n/gm, '').replace(/^export /gm, ''), f.rt.context);
        const source = readFileSync(new URL(`./fixtures/dark-cooldown-samples/face-${n}.html`, import.meta.url), 'utf8');
        const body = source.match(/<body[^>]*>([\s\S]*?)<\/body>/i)?.[1];
        assert.ok(body);
        const scanned = f.rt.context.scanRabbitMirrorHtml(`<toto data-rabbit-mirror="true">${body}</toto>`);
        assert.equal(scanned.paletteFingerprint.brightness, 'dark');
        f.seed([{ paletteFingerprint: scanned.paletteFingerprint }]);
        assert.equal(f.storage.getActivePaletteCooldown().remaining, 5);
        assert.match(f.palette.buildPaletteCooldownRule({}), /普通模式深色冷却【剩余 5 轮/);
    });
}
