import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));
const legacyFloor = '展现形式与媒介本体决定具体长相。成品须主次清楚，比例、空间、材质、信息组织、细节与配色均服务本轮内容；不得把黑／深灰系统面板、蓝色科技 UI、浅暖纸面或通用圆角卡片当作默认高级感模板。';
async function fixture() {
    const rt = createRuntime(root);
    const config = await rt.load('src/settings.js');
    const builder = await rt.load('src/promptBuilder.js');
    const theme = (await rt.load('data/structured/thematicIndex.js')).THEMATIC_CATEGORIES.find(x => x.id === 'F.0');
    const form = (await rt.load('data/structured/presentationIndex.js')).PRESENTATION_FORMATS.find(x => x.id === '3.3.1');
    const combo = { themes:[theme], themeIds:[theme.id], formats:[form], formatIds:[form.id],
        samplingMode:'classic', presentationMode:'html', requestedPresentationMode:'html',
        interactionRecipeId:'hinged-open', interactionRecipeIds:['hinged-open'], paletteRecipeId:'radix-sky-sky-pink-light' };
    const settings = { ...copy(config.defaultSettings), visualDesignMode:'reference1553', postGenerationRecolor:true,
        visualPromptEditingEnabled:false, enhancedVisualDrawing:true, userDirectivePriority:false,
        behaviorRuleMode:'off', rawPolicy:'balanced', rabbitMirrorFaceCount:1, rabbitMirrorPresentationModes:['html'] };
    const render = (overrides={}, selection=combo, route='independent') => builder.renderRabbitMirrorPromptPlan(
        builder.planRabbitMirrorPromptDetails({...settings,...overrides},route,null,'direct-test',
            {pinnedSelections:[{combo:copy(selection),directive:null}]}));
    return {rt,config,builder,combo,settings,render};
}
test('reference restores the actual 1.5.53 visual floor and original colour organization', async () => {
    const f=await fixture(); const out=f.render();
    assert.ok(out.prompt.includes(legacyFloor));
    assert.match(out.prompt,/色彩组织:/);
    assert.match(out.prompt,/用真实 CSS 落实材质、接缝、光源、阴影与排版层级/);
    assert.doesNotMatch(out.prompt,/生成后换色【|生成配色参考【|P\.\d{3}|rm-color-role|radix-sky/);
    assert.equal(out.metadata.paletteRecipeId,undefined);
    assert.equal(f.combo.paletteRecipeId,'radix-sky-sky-pink-light','the saved source recipe stays untouched');
});
test('guided comparison changes only the global design paragraph, never selection, short lock or output protocol', async () => {
    const f=await fixture(); const a=f.render(), b=f.render({visualDesignMode:'guided1553'});
    const extract=s=>s.match(/全局视觉地板【始终适用】：\n([^\n]+)/)?.[1];
    assert.equal(extract(a.prompt),legacyFloor);
    assert.match(extract(b.prompt),/先确定具体的视觉风格/);
    assert.equal(a.prompt.replace(extract(a.prompt),'<DESIGN>'),b.prompt.replace(extract(b.prompt),'<DESIGN>'));
    assert.equal(a.executionLock,b.executionLock);
    assert.deepEqual(copy(a.metadata),copy(b.metadata));
});
test('fresh default and missing visual choice use guidance; explicit choices remain available', async () => {
    const f=await fixture();
    assert.equal(f.config.defaultSettings.visualDesignMode,'guided1553');
    assert.equal(f.config.getSettings().visualDesignMode,'guided1553');
    f.config.updateSettings({visualDesignMode:'guided1553'});
    assert.equal(f.config.getSettings().visualDesignMode,'guided1553');
    delete f.config.getSettings().visualDesignMode;
    assert.equal(f.config.getSettings().visualDesignMode,'guided1553');
    assert.equal(f.config.getSettings().postGenerationRecolor,false,'removed trial cannot restart');
    for (const choice of ['reference1553','guided1553']) {
        f.config.updateSettings({visualDesignMode:choice});
        assert.equal(f.config.getSettings().visualDesignMode,choice,'preserve an explicitly saved choice');
    }
});

for(const route of ['normal','independent']) for(const kind of ['ordinary','scenery','combination']) {
    test(`${route}/${kind}: four frozen tickets retain forms and interactions, with no palette draw or contract`,async()=>{
        const f=await fixture();
        const settings={...f.settings,lotteryMethod:'atmosphere',atmosphereStoryPercent:100,
            forceVisualScenery:kind==='scenery',visualSceneryCombination:kind==='combination'};
        const aPlan=f.builder.planRabbitMirrorPromptDetails(settings,route,null,'four-frozen');
        const a=f.builder.renderRabbitMirrorPromptPlan(aPlan);
        const bPlan=f.builder.planRabbitMirrorPromptDetails({...settings,visualDesignMode:'guided1553'},route,null,'four-frozen');
        const b=f.builder.renderRabbitMirrorPromptPlan(bPlan);
        const selections=f.builder.promptPlanSelections(aPlan);
        assert.equal(selections[0].combo.atmosphereMenu.length,4);
        for(const ticket of selections[0].combo.atmosphereMenu){
            assert.ok(ticket.formatIds.length); assert.ok(ticket.interactionRecipeIds.length);
            assert.equal(ticket.paletteRecipeId,undefined);
        }
        assert.deepEqual(copy(selections),copy(f.builder.promptPlanSelections(bPlan)));
        assert.doesNotMatch(a.prompt+b.prompt,/生成后换色【|生成配色参考【|配色构造：|P\.\d{3}/);
        assert.match(a.prompt,/交互构造库/);
        assert.equal(a.executionLock,b.executionLock);
        const floor=s=>s.match(/全局视觉地板【始终适用】：\n([^\n]+)/)?.[1];
        assert.equal(a.prompt.replace(floor(a.prompt),'<DESIGN>'),b.prompt.replace(floor(b.prompt),'<DESIGN>'));
    });
}

test('mixed HTML/text face scope and frozen settings survive later settings changes',async()=>{
    const f=await fixture();const text={...copy(f.combo),presentationMode:'text',requestedPresentationMode:'longtext'};
    const settings={...f.settings,rabbitMirrorFaceCount:2,rabbitMirrorPresentationModes:['html','longtext']};
    const selections=[{combo:copy(f.combo),directive:null},{combo:text,directive:null}];
    const a=f.builder.planRabbitMirrorPromptDetails(settings,'independent',null,'mixed',{pinnedSelections:selections});
    settings.visualDesignMode='guided1553';
    const b=f.builder.planRabbitMirrorPromptDetails(settings,'independent',null,'mixed',{pinnedSelections:selections});
    settings.visualDesignMode='current';
    const out=f.builder.renderRabbitMirrorPromptPlan(a), guided=f.builder.renderRabbitMirrorPromptPlan(b);
    assert.ok(out.prompt.includes(legacyFloor));assert.doesNotMatch(out.prompt,/先确定具体的视觉风格/);
    const prefix=out.prompt.slice(0,out.prompt.indexOf(legacyFloor));
    assert.match(prefix.slice(prefix.lastIndexOf('共用适用规则【')),/第 1 面HTML/);
    assert.doesNotMatch(prefix.slice(prefix.lastIndexOf('共用适用规则【')),/第 2 面/);
    assert.equal(out.executionLock,guided.executionLock);
    assert.equal(selections[0].combo.paletteRecipeId,'radix-sky-sky-pink-light');
});

test('text and pure-order prompts stay identical across the two comparison modes',async()=>{
    const f=await fixture();
    for(const selected of [{...f.combo,presentationMode:'text',requestedPresentationMode:'longtext'}, {...f.combo,pureOrder:true}]){
        const a=f.render({},selected),b=f.render({visualDesignMode:'guided1553'},selected);
        assert.equal(a.prompt,b.prompt);assert.equal(a.executionLock,b.executionLock);
        assert.doesNotMatch(a.prompt,/先确定具体的视觉风格|增强视觉绘制：/);
    }
});

test('normal dark cooldown is shared once and explicit dark mode remains authoritative',async()=>{
    const f=await fixture();
    f.rt.store.setItem('rabbit_mirror_theater:last_combo:v11',JSON.stringify([{historyId:'dark',paletteFingerprint:{brightness:'dark',confidence:.9,averageLuminance:20,darkAreaRatio:.95,hueFamily:'blue',temperature:'cool',saturation:'medium'}}]));
    const normal=f.render(),dark=f.render({darkVisualMode:true});
    assert.equal((normal.prompt.match(/普通模式深色冷却【/g)||[]).length,1);
    assert.doesNotMatch(dark.prompt,/普通模式深色冷却【/);
    assert.match(dark.prompt,/深色生成模式【/);
    assert.doesNotMatch(normal.prompt+dark.prompt,/生成配色参考【|生成后换色【/);
});

test('user visual preferences remain verbatim and are not replaced by the design experiment',async()=>{
    const f=await fixture();const custom='只用于本次测试的视觉偏好：青铜接缝与冷色侧光';
    for(const visualDesignMode of ['reference1553','guided1553']) {
        const out=f.render({visualDesignMode,visualPromptEditingEnabled:true,visualPrompt:custom,visualExtraPrompt:'保留细线排版'});
        assert.ok(out.prompt.includes(custom));assert.ok(out.prompt.includes('保留细线排版'));
    }
});

test('fresh re-say in original-colour modes still redraws theme, form and interaction without assigning a palette',async()=>{
    for(const visualDesignMode of ['reference1553','guided1553']){
        const f=await fixture(), picker=await f.rt.load('src/picker.js');
        const settings={...f.settings,visualDesignMode,lotteryMethod:'random'};
        const original=picker.pickCombination(settings,'original-colour-first').combo;
        const rewritten=picker.pickCombinationForMultifaceResay(settings,{faceIndex:0,faces:[original]}).combo;
        assert.ok(rewritten.themeIds.every(id=>!original.themeIds.includes(id)));
        assert.ok(rewritten.formatIds.every(id=>!original.formatIds.includes(id)));
        assert.ok(rewritten.interactionRecipeIds.every(id=>!original.interactionRecipeIds.includes(id)));
        assert.equal(original.paletteRecipeId,undefined);
        assert.equal(rewritten.paletteRecipeId,undefined);
    }
});

test('a pinned legacy four-ticket selection loses palette instructions only in the new sending copy',async()=>{
    const f=await fixture();
    const palettePlan=f.builder.planRabbitMirrorPromptDetails({...f.settings,visualDesignMode:'current',lotteryMethod:'atmosphere',atmosphereStoryPercent:100},'independent',null,'legacy-four');
    const selected=copy(f.builder.promptPlanSelections(palettePlan));
    // An old saved recipe carries palette IDs even though new draws no longer do.
    selected[0].combo.paletteRecipeId=f.combo.paletteRecipeId;
    for(const ticket of selected[0].combo.atmosphereMenu)ticket.paletteRecipeId=f.combo.paletteRecipeId;
    const before=copy(selected);
    assert.equal(selected[0].combo.atmosphereMenu.length,4);
    assert.ok(selected[0].combo.atmosphereMenu.every(ticket=>ticket.paletteRecipeId));
    const next=f.builder.planRabbitMirrorPromptDetails(f.settings,'independent',null,'direct-four',{pinnedSelections:selected});
    const nextSelection=copy(f.builder.promptPlanSelections(next));
    const after=f.builder.renderRabbitMirrorPromptPlan(next);
    assert.deepEqual(selected,before);
    assert.ok(nextSelection[0].combo.atmosphereMenu.every(ticket=>!ticket.paletteRecipeId));
    for(let i=0;i<4;i++){
        assert.deepEqual(nextSelection[0].combo.atmosphereMenu[i].formatIds,before[0].combo.atmosphereMenu[i].formatIds);
        assert.deepEqual(nextSelection[0].combo.atmosphereMenu[i].interactionRecipeIds,before[0].combo.atmosphereMenu[i].interactionRecipeIds);
    }
    assert.doesNotMatch(after.prompt,/生成配色参考【|生成后换色【|配色构造：|P\.\d{3}/);
});

test('original-colour mode does not compile even a model-emitted palette marker; CSS animation and controls survive',async t=>{
    const rt=await createDomRuntime(root);t.after(()=>rt.close());
    const config=await rt.load('src/settings.js'),markup=await rt.load('src/outputSanitizer/markup.js');
    const raw='<toto><style>.piece{--rmc-bg:#abcdef;--rmc-ink:#123456;background:var(--rmc-bg);color:var(--rmc-ink);animation:move 2s infinite} @keyframes move{to{transform:translateX(12px)}} input:checked~.piece{opacity:.5}</style><details data-rm-palette="P.100"><summary>【兔子镜：原色检查】</summary><input id="a" type="checkbox"><label for="a">查看</label><div class="piece">正文</div></details></toto>';
    for(const visualDesignMode of ['reference1553','guided1553']){
        config.updateSettings({visualDesignMode,postGenerationRecolor:true});
        const html=markup.cleanRabbitMirrorOutput(raw);
        assert.doesNotMatch(html,/data-rm-color-style|data-rm-color-variant|data-rm-color-inline/);
        assert.match(html,/#abcdef/i);assert.match(html,/#123456/i);
        assert.match(html,/@keyframes/);assert.match(html,/:checked/);assert.match(html,/<label[^>]+for=/);
        const node=rt.window.document.createElement('div');node.innerHTML=html;
        assert.equal(node.querySelectorAll('input').length,1);assert.equal(node.querySelectorAll('style').length,1);
    }
    config.updateSettings({visualDesignMode:'current',postGenerationRecolor:true});
    assert.doesNotMatch(markup.cleanRabbitMirrorOutput(raw),/data-rm-color-style="mapped"/);
});

test('settings choice saves and reopens; removed trial migrates to the new rules',async()=>{
    const f=await fixture(), nodes=new Map(['rh_visual_design_mode','rh_palette_trial_options','rh_post_generation_recolor'].map(id=>[id,{id,handlers:{}}]));
    const $=selector=>{const node=nodes.get(selector.slice(1));return {val:value=>node.value=value,prop:(key,value)=>node[key]=value,on:(event,fn)=>node.handlers[event]=fn};};
    const source=readFileSync(new URL('../src/ui.js',import.meta.url),'utf8');
    const start=source.indexOf("    $('#rh_visual_design_mode').on('change'");
    const end=source.indexOf("    $('#rh_random_preference_section')",start);
    vm.runInNewContext(source.slice(start,end),{$,updateSettings:f.config.updateSettings});
    for(const mode of ['guided1553','current','reference1553']){
        nodes.get('rh_visual_design_mode').handlers.change({target:{value:mode}});
        const expected=mode==='current'?'guided1553':mode;
        assert.equal(f.config.getSettings().visualDesignMode,expected);
        const a=source.indexOf("    $('#rh_visual_design_mode').val(");
        const b=source.indexOf("    checked('#rh_blacklist_enabled'",a);
        vm.runInNewContext(source.slice(a,b),{$,settings:f.config.getSettings()});
        assert.equal(nodes.get('rh_visual_design_mode').value,expected);
    }
});
