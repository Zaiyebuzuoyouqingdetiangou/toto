import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const copy = x => JSON.parse(JSON.stringify(x));

test('the draw pool contains stable numbered functional summaries, not full construction details', async () => {
    const rt = createRuntime(root);
    const { INTERACTION_RECIPES } = await rt.load('data/structured/interactionIndex.js');
    assert.equal(INTERACTION_RECIPES.length, 64);
    assert.equal(new Set(INTERACTION_RECIPES.map(r => r.code)).size, 64);
    for (const r of INTERACTION_RECIPES) {
        assert.match(r.code, /^I\.\d{2}$/);
        assert.ok(r.summary && r.summary.includes('→'), `${r.id}: title must explain action and effect`);
        assert.equal(r.action, undefined);
        assert.equal(r.result, undefined);
    }
});

test('compact uses selected index entries only; balanced adds selected details; full adds only used mechanisms', async () => {
    const rt = createRuntime(root);
    const { buildInteractionRecipeRule } = await rt.load('src/interactionRecipes.js');
    const faces = [{ combo: { interactionRecipeId: 'hinged-open' } }];
    const compact = buildInteractionRecipeRule(faces, 'compact');
    const balanced = buildInteractionRecipeRule(faces, 'balanced');
    const full = buildInteractionRecipeRule(faces, 'full');
    assert.match(compact, /I\.01/);
    assert.doesNotMatch(compact, /实际连接边|内壁、厚度|checkbox|radio/);
    assert.match(balanced, /实际连接边/);
    assert.match(balanced, /内壁、厚度/);
    assert.doesNotMatch(balanced, /:checked ~ \.stage/);
    assert.match(full, /checkbox/);
    assert.doesNotMatch(full, /radio|animation-play-state|配方组合/);
    assert.ok(compact.length < balanced.length && balanced.length < full.length);
});

for (const rawPolicy of ['compact', 'balanced', 'full']) {
    test(`actual frozen prompt builder applies interaction rawPolicy=${rawPolicy}`, async () => {
        const rt = createRuntime(root);
        const builder = await rt.load('src/promptBuilder.js');
        const { defaultSettings } = await rt.load('src/settings.js');
        const settings = { ...copy(defaultSettings), rawPolicy, userDirectivePriority: false,
            lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100, rabbitMirrorFaceCount: 1,
            rabbitMirrorPresentationModes: ['html'] };
        const plan = builder.planRabbitMirrorPromptDetails(settings, 'independent', null, 'indexed-review');
        const out = builder.renderRabbitMirrorPromptPlan(plan);
        const section = out.prompt.split('交互构造库【')[1]?.split('生成配色参考【')[0] || '';
        assert.match(section, /I\.\d{2}/);
        if (rawPolicy === 'compact') assert.doesNotMatch(section, /操作：|可见结果：|实现依据/);
        else assert.match(section, /操作：.*\n可见结果：/);
        if (rawPolicy === 'full') assert.match(section, /实现依据/);
        else assert.doesNotMatch(section, /实现依据/);
        settings.rawPolicy = rawPolicy === 'compact' ? 'full' : 'compact';
        assert.equal(builder.renderRabbitMirrorPromptPlan(plan).prompt, out.prompt);
    });
}

test('palette references vary by independently composed colour roles, with an explicit ink for filled accents', async () => {
    const rt = createRuntime(root);
    const palettes = await rt.load('src/generationPalettes.js');
    const a = palettes.composeGenerationPalette('blue', 'amber', 'light', 'slate');
    const b = palettes.composeGenerationPalette('blue', 'crimson', 'dark', 'slate');
    assert.ok(a && b);
    assert.notEqual(a.id, b.id);
    assert.ok(a.roles.onAccent && a.roles.muted && a.roles.selected && a.roles.companion);
    assert.ok(a.scale.length === 12 && b.scale.length === 12);
    assert.equal(a.brightness, 'light');
    assert.equal(b.brightness, 'dark');
});
