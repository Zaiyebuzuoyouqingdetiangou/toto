import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';

// A saved trial setting now migrates to model-original guidance. Keep the
// selection, history, safety and scope invariants while checking that retirement.
const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));
const count = (text, word) => text.split(word).length - 1;

test('drawing keeps subject detail and the compact visual floor without a dark layout branch',async()=>{
    const f=await fixture(), face=f.make('combination');
    const light=f.render([face],'independent',{darkVisualMode:false});
    const dark=f.render([face],'independent',{darkVisualMode:true});
    const shared=text=>text.split('全局视觉地板【始终适用】：\n')[1]?.split('\n\n')[0];
    assert.ok(shared(light.prompt));
    assert.equal(shared(light.prompt),shared(dark.prompt));
    for(const out of [light,dark]){
        assert.equal(count(out.prompt,'增强视觉绘制：先确定清晰的主体轮廓与阅读焦点'),1);
        assert.equal(count(out.prompt,'材质边缘、受光和阴影遵循同一空间'),1);
        assert.equal(count(out.prompt,'可自由组合 HTML、CSS 与安全内联 SVG。'),1);
        assert.match(out.prompt,/媒介需要的分页、频道、折叠照常使用，控件数量不限/);
        assert.match(out.prompt,/文字的数量、密度和排版由展现形式决定/);
        assert.match(out.prompt,/背景、主体和文字形成清楚的明暗与冷暖关系/);
        assert.doesNotMatch(out.prompt,/SVG 至少|至少.*个 path|不合格.*禁止生成/);
    }
    assert.deepEqual(copy(light.metadata.formatIds),copy(dark.metadata.formatIds));
    const plain=f.render([face],'independent',{enhancedVisualDrawing:false});
    assert.doesNotMatch(plain.prompt,/绘制具体人物时|增强视觉绘制：/);
    assert.equal(shared(plain.prompt),shared(light.prompt));
});
async function fixture() {
    const rt = createRuntime(root);
    const { defaultSettings } = await rt.load('src/settings.js');
    const builder = await rt.load('src/promptBuilder.js');
    const storage = await rt.load('src/storage.js');
    const { PRESENTATION_FORMATS } = await rt.load('data/structured/presentationIndex.js');
    const { THEMATIC_CATEGORIES } = await rt.load('data/structured/thematicIndex.js');
    const theme = THEMATIC_CATEGORIES.find(item => item.id === 'F.0');
    const formats = ['5.2.4', '3.3.1', '3.8', '2.1.4'].map(id => PRESENTATION_FORMATS.find(item => item.id === id));
    const make = (kind = 'ordinary', mode = 'html') => {
        const menu = formats.map(item => ({ themeIds: [theme.id], formatIds: kind === 'combination'
            ? ['10.2.2', item.id] : kind === 'scenery' ? ['10.2.2'] : [item.id] }));
        return { themes: [theme], themeIds: [theme.id],
            formats: menu[0].formatIds.map(id => PRESENTATION_FORMATS.find(item => item.id === id)),
            formatIds: menu[0].formatIds, atmosphereMenu: menu,
            visualSceneryCombination: kind === 'combination', forcedVisualScenery: kind !== 'ordinary',
            requestedPresentationMode: mode, presentationMode: mode === 'html' ? 'html' : 'text' };
    };
    const render = (faces, route = 'independent', settings = {}) => builder.renderRabbitMirrorPromptPlan(
        builder.planRabbitMirrorPromptDetails({ ...copy(defaultSettings), visualDesignMode:'current', userDirectivePriority: false,
            enhancedVisualDrawing: true, rabbitMirrorFaceCount: faces.length,
            rabbitMirrorPresentationModes: faces.map(face => face.requestedPresentationMode), ...settings },
        route, null, 'fixed-visual-construction', faces.length === 1
            ? { pinnedSelections: [{ combo: faces[0], directive: null }] }
            : { batchIdentity: { mesid: 8, swipeId: 0, sourceHash: 'fixed-visual-construction' } }));
    const record = () => {
        storage.setPendingCombo({ themeIds: ['F.0'], formatIds: ['7.6'] });
        storage.commitPendingCombo('sample', 'operation_family: text_panel_switch；layout_family: scene_above_text', [],
            { brightness: 'dark', hueFamily: 'purple', temperature: 'cool', saturation: 'medium',
                averageLuminance: 30, darkAreaRatio: .95, confidence: .95 },
            { id: 'tabbed_radio_family', label: '文字面板切换', confidence: .95, textPanelSwitch: true });
    };
    return { rt, builder, storage, make, render, formats, record };
}

for (const route of ['normal', 'independent']) for (const kind of ['ordinary', 'combination']) {
    test(`${route}/${kind}: every candidate retains its own concrete form check, never a preselected ticket`, async () => {
        const f = await fixture(), face = f.make(kind), before = JSON.stringify(face);
        const out = f.render([face], route);
        const active = route === 'independent' ? out.executionLock : out.prompt;
        for (let i = 0; i < 4; i++) {
            assert.ok(active.includes(`候选 ${i + 1} 核对：`));
            const row = active.split('\n').find(line => line.startsWith(`候选 ${i + 1} 核对：`));
            assert.ok(row.includes(f.formats[i].id + ' ' + f.formats[i].title));
            assert.ok(row.includes(f.formats[i].summary.slice(0, 20)));
            for (let j = 0; j < 4; j++) if (j !== i) assert.ok(!row.includes(f.formats[j].id + ' ' + f.formats[j].title));
        }
        assert.match(active, /首个主体落实两项可见结构证据和真实 CSS/);
        assert.match(active, /只执行选中签/);
        assert.equal(out.metadata.atmosphereMenu.length, 4);
        assert.equal(JSON.stringify(face), before);
        assert.equal(count(out.prompt, '<rm-ticket>序号</rm-ticket>'), 1);
        assert.equal(count(out.prompt, '增强视觉绘制：'), 1);
        assert.doesNotMatch(out.prompt + out.executionLock, /随后完成正文与绘制细节|继续精绘同一作品/);
        assert.match(out.prompt, /增强视觉绘制：先确定清晰的主体轮廓与阅读焦点/);
    });
}

test('real mixed batch shares medium-bound operations once, scoped away from longtext', async () => {
    const f = await fixture();
    const out = f.render([f.make('combination'), f.make('combination'), f.make('combination'), f.make('ordinary', 'longtext')],
        'independent', { lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100, visualSceneryCombination: true });
    assert.equal(out.metadata.faces.length, 4);
    for (const face of out.metadata.faces.slice(0, 3)) {
        assert.equal(face.atmosphereMenu.length, 4);
        for (const ticket of face.atmosphereMenu) assert.ok(ticket.formatIds.includes('10.2.2'));
    }
    assert.equal(count(out.prompt, '媒介内交互构造：'), 1);
    assert.equal(count(out.prompt, '复杂交互视觉核心:'), 0, 'combined HTML uses specialized core, longtext gets neither');
    assert.match(out.prompt, /第 1 面 HTML；第 2 面 HTML；第 3 面 HTML/);
    assert.match(out.prompt, /操作与可见结果安放到实际部件或内容区域/);
    assert.match(out.prompt, /不能以频道或分页命名豁免/);
    assert.match(out.prompt, /控件数量不限/);
    assert.doesNotMatch(out.prompt, /硬性禁止“切页骨架”|触发器最多 2 个/);
    const textLock = out.executionLock.split('第 4 面：')[1];
    assert.ok(textLock);
    assert.doesNotMatch(textLock, /候选 \d 核对：|两项可见结构证据/);
});

test('identical candidate form checks are shared without deleting the four candidate tickets', async () => {
    const f = await fixture();
    const out = f.render([f.make('scenery')]);
    assert.equal(count(out.prompt, '媒介内交互构造：'), 1);
    assert.equal(count(out.executionLock, '候选 1、2、3、4 核对：'), 1);
    assert.equal(count(out.executionLock, '主形式 10.2.2'), 1);
    assert.equal(out.metadata.atmosphereMenu.length, 4);
    for (let n = 1; n <= 4; n++) assert.equal(count(out.prompt, `签 ${n}（以下材料仅在选中本签时适用）：`), 1);
});

test('palette observations occur once; the final lock references shared history before form checks', async () => {
    const f = await fixture(); f.record();
    const out = f.render([f.make('combination')], 'independent', { darkVisualMode: true });
    assert.equal(count(out.prompt + out.executionLock, '低明度冷紫中饱和'), 1);
    assert.equal(count(out.prompt, '近期结构记录【'), 1);
    assert.equal(count(out.prompt, '默认强避重【'), 1);
    assert.equal(count(out.executionLock, '强避重短锁：'), 1);
    assert.ok(out.executionLock.indexOf('强避重短锁：') < out.executionLock.indexOf('候选 1 核对：'));
    assert.match(out.executionLock.trim(), /闭合后结束。\n<\/兔子镜近输出短锁>$/);
    assert.match(out.executionLock, /深色模式/);
});

test('no-history policy stays concise, with enabled drawing capabilities and native controls exempt', async () => {
    const f = await fixture();
    const out = f.render([f.make('combination')]);
    const policy = out.prompt.match(/默认强避重【[^]*?(?=\n\n|\n<\/兔子镜自动注入>)/)?.[0];
    assert.ok(policy && policy.length < 400, 'no history must not expand a long hypothetical cooldown');
    assert.match(policy, /依正文独立构思，同批形成差异/);
    assert.match(policy, /保留用户指定、视觉偏好、形式固有特征与已启用能力/);
    assert.match(policy, /控件数量不限/);
    assert.doesNotMatch(out.prompt, /近期选材与视觉参考|交互形态冷却/);
});

test('actual independent request assembly keeps context then the revised lock and output instruction', async () => {
    const f = await fixture(); f.record();
    const out = f.render([f.make('combination')], 'independent', { darkVisualMode: true });
    const source = readFileSync(root + '/src/independentApi/request.js', 'utf8');
    const start = source.indexOf(' const independentSystemRules='), end = source.indexOf(' const totalRequestChars=', start);
    assert.ok(start > 0 && end > start);
    const ctx = vm.createContext({ st: {}, details: { metadata: out.metadata }, faceCount: 1,
        basePrompt: out.prompt, feedbackBlock: '', keepSelectionRewriteBlock: '', resayNoteBlock: '', executionLock: out.executionLock,
        configuredIndependentMaxRequestChars: () => 100000, characterWorldBookContext: null,
        globalWorldInfoSnapshotFor: () => null, globalWorldInfoContextView: () => null,
        contextBundle: () => ({ targetVisibleChars: 10, text: 'CURRENT_BODY\nCHARACTER\nPERSONA' }),
        ctx: {}, index: 0, msg: {}, readVisible: null });
    vm.runInContext('function assemble(){\n' + source.slice(start, end) + '\nreturn {systemPrompt,userPrompt};\n}', ctx);
    const result = ctx.assemble();
    assert.equal(count(result.systemPrompt + result.userPrompt, '低明度冷紫中饱和'), 1);
    assert.ok(result.userPrompt.indexOf('CURRENT_BODY') < result.userPrompt.indexOf('候选 1 核对：'));
    assert.ok(result.userPrompt.endsWith('直接输出完整 <toto>...</toto>。'));
});
