import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const plain = value => JSON.parse(JSON.stringify(value));

test('request timer begins only at dispatch and finishes once without a ticker', async () => {
    let now = 1000;
    const rt = createRuntime(root, { now: () => now });
    const t = await rt.load('src/generationTiming.js');
    const timer = t.createGenerationTimer();
    assert.equal(timer.finish(), null, 'preflight is not a paid generation');
    timer.start(); now = 2100; timer.start(); now = 41893;
    assert.equal(timer.finish(), 40893);
    now += 9000; assert.equal(timer.finish(), 40893);
});

test('timer prefers a monotonic clock over wall-clock changes', async () => {
    let monotonic = 10, wall = 1000;
    const rt = createRuntime(root, { now: () => wall });
    rt.context.performance = { now: () => monotonic };
    const t = await rt.load('src/generationTiming.js'), timer = t.createGenerationTimer();
    timer.start(); monotonic += 40893; wall -= 60000;
    assert.equal(timer.finish(), 40893);
});

test('missing, backwards or nonnumeric clocks never fabricate a duration', async () => {
    let now = 1000;
    const rt = createRuntime(root, { now: () => now }), t = await rt.load('src/generationTiming.js');
    const timer = t.createGenerationTimer(); timer.start(); now = 999;
    assert.equal(timer.finish(), null);
    for (const value of [null, undefined, NaN, -1, Infinity, '40893']) assert.equal(t.formatGenerationElapsed(value), '未记录');
    assert.equal(t.formatGenerationElapsed(40893), '40.9 秒');
    assert.equal(t.formatGenerationElapsed(64), '64 毫秒');
});

test('evidence distinguishes request, processing and total time in the supplied timestamps', async () => {
    const rt = createRuntime(root), t = await rt.load('src/generationTiming.js');
    const record = { startedAt: '2026-09-30T21:57:34.757Z',
        request: { at: '2026-09-30T21:57:34.761Z' },
        response: { at: '2026-09-30T21:58:15.654Z' },
        processed: { at: '2026-09-30T21:58:15.691Z' },
        finishedAt: '2026-09-30T21:58:15.692Z' };
    assert.deepEqual(plain(t.generationEvidenceTiming(record)), {
        requestToResponseMs: 40893, responseToProcessedMs: 37, totalMs: 40935,
    });
    assert.deepEqual(plain(t.generationEvidenceTiming({})), {
        requestToResponseMs: null, responseToProcessedMs: null, totalMs: null,
    });
    assert.equal(t.generationEvidenceTiming({ request: { at: record.request.at }, response: { at: 'invalid' } }).requestToResponseMs, null);
});

test('Prompt-area diagnostic displays measured request time, not model-only time', async () => {
    const rt = createRuntime(root), t = await rt.load('src/generationTiming.js');
    let html = '';
    const source = readFileSync(new URL('../src/ui/tokenMeter.js', import.meta.url), 'utf8')
        .replace(/^import\b[\s\S]*?;\r?$/gm, '').replace(/^export /gm, '');
    const sandbox = { ...t, $: () => ({ length: 1, html: value => { html = value; } }),
        escapeHtml: value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;'),
        getLastIndependentApiRequestDiagnostic: () => null };
    vm.createContext(sandbox); vm.runInContext(source, sandbox);
    sandbox.renderIndependentApiDiagnostic({ ok: true, requestElapsedMs: 40893, requestTimingEnd: 'response' });
    assert.match(html, /生成耗时.*40\.9 秒.*请求发出至回复结束/);
    sandbox.renderIndependentApiDiagnostic({ ok: false, requestElapsedMs: 900, requestTimingEnd: 'failure' });
    assert.match(html, /失败\/取消前耗时.*0\.9 秒/);
    sandbox.renderIndependentApiDiagnostic({ ok: true });
    assert.match(html, /耗时.*未记录/);
    assert.doesNotMatch(source, /setInterval\(/);
});
