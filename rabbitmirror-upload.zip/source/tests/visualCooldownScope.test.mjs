import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const fn = (source, name) => {
    const match = source.match(new RegExp('^(?:export )?function ' + name + '\\b[^]*?^}\\r?$', 'm'));
    assert.ok(match, name);
    return match[0].replace(/^export /, '');
};
const historySkeleton = 'surface_family: surface: paper_or_document_surface；contrast_family: contrast: light_weighted；unit_family: 矩形信息块/卡片化条目；space_family: space: layered_depth_or_spatial_scene';
const recipe = { themeIds: ['C.1.5', 'D.0'], formatIds: ['6.1.1'], samplingMode: 'classic',
    requestedPresentationMode: 'html', presentationMode: 'html' };
const historyWords = /配色短冷却|视觉短冷却|真实视觉纠偏|近因避让|连续视觉项|低明度主承载仍|交互形态冷却/;

async function fixture(avoidRepeat = false) {
    const rt = createRuntime(root);
    const config = await rt.load('src/settings.js');
    const storage = await rt.load('src/storage.js');
    for (let i = 0; i < 3; i++) {
        storage.setPendingCombo({ themeIds: ['history-' + i], formatIds: ['6.1.1'] });
        storage.commitPendingCombo('fixed prior artwork', historySkeleton,
            ['same_block_stack', 'weak_spatial_complexity'],
            i === 0 ? { confidence: 1, brightness: 'dark', darkAreaRatio: .8, averageLuminance: 50 } : null,
            { id: 'tabbed_radio_family', label: 'tabbed radio', confidence: 1 });
    }
    const settings = { ...structuredClone(config.defaultSettings), avoidRepeat, enhancedVisualDrawing: true,
        userDirectivePriority: false, visualPromptEditingEnabled: false, behaviorRuleMode: 'off' };
    const prompt = await rt.load('src/promptBuilder.js');
    return { rt, storage, settings, prompt };
}

for (const mode of ['normal', 'independent']) {
    for (const forms of [['html'], ['html', 'html'], ['html', 'longtext']]) {
        test(`legacy false still uses default strong history avoidance: ${mode} ${forms.join('+')}`, async () => {
            const f = await fixture(false);
            const faces = forms.map(form => ({ ...recipe, requestedPresentationMode: form,
                presentationMode: form === 'longtext' ? 'text' : 'html' }));
            const settings = { ...f.settings, rabbitMirrorFaceCount: faces.length,
                rabbitMirrorPresentationModes: forms };
            const plan = f.prompt.planRabbitMirrorPromptDetails(settings, mode, null, 'fixed',
                { missingFaceRetry: { indexes: faces.map((_, index) => index), faces } });
            const reads = [];
            const getItem = f.rt.store.getItem.bind(f.rt.store);
            f.rt.store.getItem = key => { reads.push(String(key)); return getItem(key); };
            const result = f.prompt.renderRabbitMirrorPromptPlan(plan);
            assert.match(result.prompt + result.executionLock, historyWords);
            assert.match(result.prompt, /增强视觉绘制/);
            assert.ok(reads.length > 0, 'default strong diversity reads completed history');
        });
    }
}

test('enabled avoidance keeps concrete material and content-layout repetition, not generic depth', async () => {
    const f = await fixture(true);
    const result = f.prompt.buildRabbitMirrorPromptDetails(f.settings, 'independent', null, 'fixed',
        { multifaceResay: { faceIndex: 0, faces: [recipe] } });
    assert.match(result.prompt, /视觉短冷却/);
    assert.match(result.prompt, /paper_or_document_surface/);
    assert.match(result.prompt, /真实视觉纠偏/);
    assert.doesNotMatch(result.prompt + result.executionLock, /空间结构「space: layered_depth_or_spatial_scene」/);
    assert.equal(f.storage.getRepeatedVisualFamilyDimensions(3, 2).some(item => item.key === 'space_family'), false);
});

function classifiers() {
    const source = readFileSync(root + '/src/visualScanner.js', 'utf8');
    const names = ['stripTags', 'count', 'expandHexColor', 'luminanceFromRgb', 'colorValueLuminance',
        'extractBackgroundValues', 'detectBaseColor', 'detectSurfaceFamily', 'detectSpaceFamily'];
    const ctx = vm.createContext({});
    vm.runInContext(names.map(name => fn(source, name)).join('\n'), ctx);
    return ctx;
}
const darkPanel = extra => `<div style="background:#123456;${extra}"><span>运行状态</span></div>`;
for (const [name, html] of [
    ['CSS letter spacing', darkPanel('letter-spacing:1px')],
    ['internal menu class', darkPanel('').replace('<span>', '<span class="tool-menu">')],
    ['internal ticket marker', '<rm-ticket>3</rm-ticket>' + darkPanel('')],
    ['internal planning marker', '<rm-think>纸张 paper</rm-think>' + darkPanel('')],
    ['CSS selector name', '<style>.letter{letter-spacing:1px}</style>' + darkPanel('')],
]) test('formatting metadata is not paper material: ' + name, () => {
    const c = classifiers();
    assert.equal(c.detectSurfaceFamily(html, c.stripTags(html)), 'surface: digital_dark_surface');
});

for (const [label, html, expected] of [
    ['paper', '<div style="background:#faf8ef">旧报纸</div>', 'surface: paper_or_document_surface'],
    ['glass', '<div style="backdrop-filter:blur(4px);background:rgba(250,250,255,.4)">观察窗</div>', 'surface: glass_or_translucent_surface'],
    ['metal', '<div>金属指针</div>', 'surface: metallic_or_hard_surface'],
    ['gradient', '<div style="background:linear-gradient(90deg,#123456,#ccddff)">运行状态</div>', 'surface: gradient_or_light_surface'],
]) test('genuine material evidence is retained: ' + label, () => {
    const c = classifiers();
    assert.equal(c.detectSurfaceFamily(html, c.stripTags(html)), expected);
});

test('flat SVG paths do not prove a layered scene', () => {
    const c = classifiers();
    assert.equal(c.detectSpaceFamily('<svg><path d="M0 0"/><path d="M1 1"/><path d="M2 2"/></svg>', 4),
        'space: flat_content_surface');
});
test('layered composition still records depth as a diagnostic signal', () => {
    const c = classifiers();
    const html = '<style>.back{position:absolute;z-index:1}.subject{position:absolute;z-index:2}.front{position:absolute;z-index:3}</style><div class="back"></div><div class="subject"></div><div class="front"></div>';
    assert.equal(c.detectSpaceFamily(html, 6), 'space: layered_depth_or_spatial_scene');
});

async function independentGuards() {
    const f = await fixture(false);
    const source = readFileSync(root + '/src/independentApi/request.js', 'utf8');
    let reads = 0;
    const ctx = vm.createContext({ ...f.storage, getSettings: () => ({ avoidRepeat: false }),
        readHistoryStore: () => { reads++; return { slots: {} }; },
        readStore: () => { reads++; return {}; },
        historyEntriesForSlot: () => { reads++; return [{ html: '<div>old</div>' }]; },
        normalizeHistoryEntry: x => x,
        wrappedIndependentMirrorHtml: x => x,
        scanRabbitMirrorHtml: () => ({ skeleton: historySkeleton }),
    });
    vm.runInContext(['recentIndependentPaletteRecords', 'independentVisualFamilyFromHtml',
        'repeatedIndependentVisualDimensions', 'independentVisualHistoryContext']
        .map(name => fn(source, name)).join('\n'), ctx);
    return { ...f, ctx, reads: () => reads };
}
test('legacy false does not suppress independent history and manual reroll guards', async () => {
    const f = await independentGuards();
    assert.equal(f.ctx.independentVisualHistoryContext({needsBackfill:true}).families.length, 0, 'empty history has no invented visual evidence');
    assert.ok(f.ctx.independentVisualHistoryContext({slot:'existing-slot',manualRetry:true}).previous);
    assert.ok(f.reads() > 0);
});
test('independent guards do not demand changing generic spatial depth', async () => {
    const f = await independentGuards();
    const family = f.ctx.independentVisualFamilyFromHtml('<div>scene</div>');
    const repeated = f.ctx.repeatedIndependentVisualDimensions([family, family, family]);
    assert.ok(repeated.some(item => item.key === 'surface_family'));
    assert.equal(repeated.some(item => item.key === 'space_family'), false);
    assert.equal(f.ctx.independentVisualHistoryContext({slot:'existing-slot',manualRetry:true}).previous.space_family, undefined);
});

test('complete stored history avoids fallback reads and retries share the request-local scan', async () => {
    const f = await independentGuards();
    const before = f.reads();
    f.ctx.independentVisualHistoryContext({needsBackfill:false});
    assert.equal(f.reads(),before);
    let scans=0;
    f.ctx.readHistoryStore=()=>({slots:{one:[{html:'<div>same</div>',ts:1}]}});
    f.ctx.historyEntriesForSlot=()=>[{html:'<div>same</div>'}];
    f.ctx.scanRabbitMirrorHtml=()=>{scans++;return {skeleton:historySkeleton};};
    const result=f.ctx.independentVisualHistoryContext({needsBackfill:true,slot:'one',manualRetry:true});
    assert.equal(result.families.length,1);
    assert.ok(result.previous);
    assert.equal(scans,1,'same fallback and retry HTML is scanned only once');
});

for (const avoidRepeat of [false, true]) for (const mixed of [false, true]) {
    test(`real request assembly preserves context order and respects avoidance: ${avoidRepeat}/${mixed}`, async () => {
        const f = await independentGuards();
        const source = readFileSync(root + '/src/independentApi/request.js', 'utf8');
        const start = source.indexOf(' const independentSystemRules=');
        const end = source.indexOf(' const totalRequestChars=', start);
        assert.ok(start > 0 && end > start);
        const settings={...f.settings,rabbitMirrorFaceCount:mixed?2:1,rabbitMirrorPresentationModes:mixed?['html','longtext']:['html']};
        const plan=f.prompt.planRabbitMirrorPromptDetails(settings,'independent',null,'request-merge');
        const rendered=f.prompt.renderRabbitMirrorPromptPlan(plan,null,null,undefined,({needsBackfill})=>
            f.ctx.independentVisualHistoryContext({needsBackfill,slot:'existing-slot',manualRetry:true}));
        const readsBefore=f.reads();
        Object.assign(f.ctx, {
            st: { avoidRepeat },
            details: { metadata: { faces: [{ presentationMode: 'html' }, ...(mixed ? [{ presentationMode: 'text' }] : [])] } },
            faceCount: mixed ? 2 : 1, requestOptions: { manualRetry: true, slot: 'existing-slot' },
            basePrompt: rendered.prompt, feedbackBlock: '', keepSelectionRewriteBlock: '', resayNoteBlock: '',
            executionLock: 'FINAL_RABBIT_LOCK', configuredIndependentMaxRequestChars: () => 100000,
            characterWorldBookContext: { text: 'CHARACTER_WORLD_REFERENCE' },
            globalWorldInfoSnapshotFor: () => null, globalWorldInfoContextView: () => null,
            contextBundle: () => ({ targetVisibleChars: 20,
                text: 'CURRENT_STORY\nCHARACTER_REFERENCE\nPERSONA_REFERENCE\nACTIVATED_WORLD_REFERENCE' }),
            ctx: {}, index: 0, msg: {}, readVisible: null,
        });
        vm.runInContext('function buildRequest(){\n' + source.slice(start, end) +
            '\nreturn { systemPrompt, userPrompt };\n}', f.ctx);
        const result = f.ctx.buildRequest();
        assert.ok(result.systemPrompt.startsWith(rendered.prompt));
        const markers = ['CURRENT_STORY', 'CHARACTER_REFERENCE', 'PERSONA_REFERENCE',
            'ACTIVATED_WORLD_REFERENCE', 'CHARACTER_WORLD_REFERENCE', 'FINAL_RABBIT_LOCK'];
        for (let i = 0; i < markers.length - 1; i++) {
            assert.ok(result.userPrompt.indexOf(markers[i]) < result.userPrompt.indexOf(markers[i + 1]));
        }
        assert.match(result.userPrompt, /直接输出|逐面抽取计划/);
        assert.equal(f.reads() > 0, true);
        assert.equal(f.reads(),readsBefore,'request tail must not read/send a second copy of history');
        assert.match(result.systemPrompt, /最高短期冷却/);
        assert.equal(result.systemPrompt.split('surface: paper_or_document_surface').length-1,1);
    });
}
