import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { createRuntime } from './helpers/vmLoader.mjs';
const root=process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..',import.meta.url));
const expected=readFileSync(new URL('./fixtures/visual-default-1.5.53.txt',import.meta.url),'utf8').trimEnd();
const hash=s=>createHash('sha256').update(s).digest('hex');
const newerColor=`色彩组织:
  - 从本轮场景、季节、物件与媒介推导主色、辅助色与强调色，建立主次和彼此呼应；主色不等于整面只用同一色相的深浅变化。
  - 色彩可以清亮、浓郁、鲜艳、冷暖对照或柔和克制，按内容选择；不要把低饱和、灰褐、米色或单色当成默认高级感。
  - 主体、背景、文字、装饰和交互状态用色相、明度、饱和度及材质形成清晰层次；需要时充分使用辅助色与强调色，保持文字可读。
  - 材质、环境光与阴影共同塑造画面；渐变、发光、投影和高饱和色均可在适合媒介时使用，效果与面积随内容决定。
  - 避重时可调整主辅色关系、冷暖、色相与彩度，不只替换一个背景色；用户明确指定的颜色，以及内容本就需要的单色或低彩度形式，继续尊重。`;
const newer=expected.slice(0,expected.indexOf('色彩组织:'))+newerColor;
test('factory default is byte-identical to the supplied 1.5.53 reference',async()=>{
    assert.equal(hash(expected),'e67f358890fc23b1a0a5039cf9cd784b44b921c3119b745af8652bfae4df4ab2');
    const c=await createRuntime(root).load('src/settings.js');assert.equal(c.DEFAULT_VISUAL_PROMPT,expected);
});
for(const [name,value,wanted] of [['new factory',newer,expected],['restored factory',expected,expected],
    ['custom old',expected+'\n用户偏好：靛蓝。',expected+'\n用户偏好：靛蓝。'],
    ['custom new',newer+'\n用户偏好：靛蓝。',newer+'\n用户偏好：靛蓝。'],['empty','', '']]) {
    test('settings migration preserves intent: '+name,async()=>{
        const c=await createRuntime(root).load('src/settings.js');c.getSettings().visualPrompt=value;
        assert.equal(c.getSettings().visualPrompt,wanted);assert.equal(c.getSettings().visualPrompt,wanted);
    });
}
for(const editing of [false,true]) for(const enhanced of [false,true]) {
    test(`retired palette mode uses factory color rules; editing=${editing}, enhanced=${enhanced}`,async()=>{
        const rt=createRuntime(root),c=await rt.load('src/settings.js'),p=await rt.load('src/promptBuilder.js');
        const settings={...structuredClone(c.defaultSettings), visualDesignMode:'current',postGenerationRecolor:false,forceVisualScenery:true,visualSceneryCombination:true,
            rabbitMirrorFaceCount:1,rabbitMirrorPresentationModes:['html'],visualPromptEditingEnabled:editing,
            enhancedVisualDrawing:enhanced,userDirectivePriority:false,avoidRepeat:false};
        const recipe={themeIds:['B.7.3'],formatIds:['10.2.2','6.5.3'],samplingMode:'classic',requestedPresentationMode:'html',
            presentationMode:'html',forcedVisualScenery:true,visualSceneryCombination:true};
        const plan=p.planRabbitMirrorPromptDetails(settings,'independent',null,'fixed',{multifaceResay:{faceIndex:0,faces:[recipe]}});
        const out=p.renderRabbitMirrorPromptPlan(plan);
        assert.equal(out.prompt.split('色彩组织:').length-1,1);
        assert.equal(out.prompt.split('生成配色参考【').length-1,0);
        assert.ok(!out.prompt.includes(newerColor));
        assert.equal(out.prompt.includes('增强视觉绘制'),enhanced);
    });
}
