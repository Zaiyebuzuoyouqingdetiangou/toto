import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { captureFinalPrompt } from './helpers/finalPromptCapture.mjs';

const root = process.env.RM_TEST_SOURCE_ROOT || fileURLToPath(new URL('..', import.meta.url));
test('scene-bound motion instruction reaches both dynamic modes and both beauty modes with enhancement off', async () => {
    for (const visualDesignMode of ['guided1553', 'reference1553']) for (const combination of [false, true]) {
        const result = await captureFinalPrompt(root, { overrides: { visualDesignMode,
            forceVisualScenery: !combination, visualSceneryCombination: combination, enhancedVisualDrawing: false } });
        const text = result.messages.map(m => m.content).join('\n');
        assert.match(text, /运动因果/);
        assert.match(text, /落叶|落花/);
        assert.match(text, /车辆|车轮/);
        assert.match(text, /红线/);
        assert.match(text, /文字卡片.*漂浮/);
        assert.match(text, /例子.*(?:启发|模板)/);
        assert.match(text, /@keyframes/);
        assert.match(text, /1 秒内/);
        assert.doesNotMatch(text, /增强视觉绘制：/);
        assert.equal(result.dispatches, 1);
    }
});

test('ordinary fixed HTML and longtext do not acquire the dedicated scene-motion instruction', async () => {
    const cases = [
        { overrides: {}, requestOptions: { resay: { mode: 'pure', directive: '写一封朴素书信' } } },
        { overrides: { rabbitMirrorPresentationModes: ['longtext'], forceVisualScenery: true, enhancedVisualDrawing: false } },
    ];
    for (const options of cases) {
        const result = await captureFinalPrompt(root, options);
        assert.doesNotMatch(result.messages.map(m => m.content).join('\n'), /运动因果/);
    }
});
