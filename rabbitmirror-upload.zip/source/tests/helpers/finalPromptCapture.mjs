import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { createRuntime } from './vmLoader.mjs';

// Execute the real callIndependentApi composer and real selection/build modules.
// Only absent host state and the transport boundary are substituted. No model
// is contacted and no fabricated response is interpreted as model evidence.
export async function captureFinalPrompt(root, { overrides = {}, history = [], requestOptions = {} } = {}) {
    const rt = createRuntime(root);
    const config = await rt.load('src/settings.js');
    const presentation = await rt.load('src/presentationMode.js');
    const prompt = await rt.load('src/promptBuilder.js');
    const storage = await rt.load('src/storage.js');
    const behavior = await rt.load('src/behaviorRules.js');
    rt.store.setItem('rabbit_mirror_theater:last_combo:v11', JSON.stringify(history));
    const settings = { ...JSON.parse(JSON.stringify(config.defaultSettings)), enabled: true, autoRabbitMirrorInjection: true,
        mode: 'all', rabbitMirrorFaceCount: 1, rabbitMirrorPresentationModes: ['html'],
        externalWorldBookRandomEnabled: false, userDirectivePriority: false,
        appearanceReferenceEnabled: false, memoryScanEnabled: false, independentReadCharacterWorldBook: false,
        behaviorRuleMode: 'off', visualPromptEditingEnabled: false, enhancedVisualDrawing: true,
        independentApiBaseUrl: 'https://example.invalid', independentApiModel: 'capture-only', ...overrides };
    const story = '雨停后，两人回到旧车站。她把修好的怀表放在木桌上，转动表冠，细小的齿轮重新走动。窗外的晚霞照亮玻璃和铜制零件。他翻开车票，指着旧站名，约好明天一起出发。';
    const ctx = { chat: [{ is_user: false, mes: story }] };
    const captured = { dispatches: 0 };
    const stopped = Object.assign(new Error('Captured at transport entry; no network request'), { code: 'TEST_CAPTURE_COMPLETE' });
    Object.assign(rt.context, presentation, prompt, {
        createVisualHistorySelection: storage.createVisualHistorySelection,
        getSettings: () => settings, swipeId: () => 0, messageSourceFingerprint: () => 'fixed-story',
        createIndependentVisibleTextReader: () => message => ({ text: message.mes }), isRabbitMirrorEligibleAssistantMessage: () => true,
        captureIndependentPromptOwner: () => ({}), assertIndependentPromptOwner() {}, bindIndependentPromptBatch() {},
        getExternalPoolHydrationStatus: () => ({ hydrated: true, enabledMetadataRebuildRequired: [] }),
        getSelectedExternalEntries: () => { throw new Error('Unexpected external raw read'); },
        independentExternalPromptPreflightError: error => error, independentVisualHistoryContext: () => ({}),
        configuredIndependentMaxRequestChars: () => 1000000, globalWorldInfoSnapshotFor: () => null, globalWorldInfoContextView: () => ({}),
        contextBundle: () => ({ text: story, targetVisibleChars: story.length, layers: 1, maxLayers: 1,
            transcriptChars: story.length, referenceContextChars: 0, worldInfoContextChars: 0 }),
        recordRabbitMirrorIndependentPrompt: record => { captured.meter = record; },
        promptSectionBreakdown: () => [], resolveBehaviorRuleText: behavior.resolveBehaviorRuleText,
        hashText: value => String(value), chatKey: () => 'chat:quota-parity', messageBaseSlotKey: () => 'slot', operationEpochForBase: () => 1,
        markPendingBatchAttempt: storage.markPendingBatchAttempt, releasePendingComboBatch: storage.releasePendingComboBatch,
        independentBatchPlanPreflightError: code => Object.assign(new Error(code), { code }),
        planRabbitMirrorPromptDetails(...args) {
            const plan = prompt.planRabbitMirrorPromptDetails(...args);
            captured.selections = JSON.parse(JSON.stringify(prompt.promptPlanSelections(plan)));
            return plan;
        },
        async requestIndependentCompletion(st, systemPrompt, userPrompt, options) {
            assert.equal(options.dispatchLease.consume(), true);
            captured.dispatches++;
            captured.messages = [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }];
            captured.diagnostic = options.diagnosticContext;
            throw stopped;
        },
    });
    const source = readFileSync(path.join(root, 'src/independentApi/request.js'), 'utf8');
    const call = source.slice(source.indexOf('export async function callIndependentApi('), source.indexOf('\nexport function externalOwnerMesid')).replace(/^export /, '');
    vm.runInContext(call, rt.context);
    await assert.rejects(rt.context.callIndependentApi(ctx, 0, ctx.chat[0], null,
        { dispatchLease: { consume: () => true }, ...requestOptions }), error => error === stopped);
    assert.equal(captured.dispatches, 1);
    const total = captured.messages.reduce((sum, message) => sum + message.content.length, 0);
    assert.equal(total, captured.meter.totalRequestChars);
    return captured;
}
