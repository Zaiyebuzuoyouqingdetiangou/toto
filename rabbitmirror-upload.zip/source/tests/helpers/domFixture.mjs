// Small detached DOM fixture for standard selectors used in these tests.
// This is a host double, not a browser/rendering or model-quality test.
const split = selector => selector.split(/,(?![^\[]*\])/).map(s => s.trim()).filter(Boolean);
function compounds(selector) {
    const parts = []; let text = '', bracket = 0, parens = 0, quote = '';
    for (const c of selector.trim()) {
        if (quote) { text += c; if (c === quote) quote = ''; continue; }
        if (c === '"' || c === "'") { quote = c; text += c; continue; }
        if (c === '[') bracket++; if (c === ']') bracket--;
        if (c === '(') parens++; if (c === ')') parens--;
        if (!bracket && !parens && /[\s>+~]/.test(c)) {
            if (text) { parts.push(text); text = ''; }
            if (/\s/.test(c)) { if (parts.length && !/^[ >+~]$/.test(parts.at(-1))) parts.push(' '); }
            else { if (/^[ >+~]$/.test(parts.at(-1))) parts.pop(); parts.push(c); }
        } else text += c;
    }
    if (text) parts.push(text);
    return parts;
}
function simple(node, selector, scope) {
    if (selector.includes(':scope')) { if (node !== scope) return false; selector = selector.replace(':scope', ''); }
    const nth = selector.match(/:nth-child\((\d+)\)/);
    if (nth) { if (node.parentElement?.children.indexOf(node) + 1 !== +nth[1]) return false; selector = selector.replace(nth[0], ''); }
    const attrs = [...selector.matchAll(/\[([\w-]+)(?:(\^?=)["']?([^\]"']*)["']?)?\]/g)];
    for (const [, key, op, value] of attrs) {
        const actual = node.getAttribute(key);
        if (actual === null || (op === '=' && actual !== value) || (op === '^=' && !actual.startsWith(value))) return false;
    }
    selector = selector.replace(/\[[^\]]*\]/g, '');
    for (const [, id] of selector.matchAll(/#([\w-]+)/g)) if (node.id !== id) return false;
    for (const [, cls] of selector.matchAll(/\.([\w-]+)/g)) if (!String(node.getAttribute('class') || '').split(/\s+/).includes(cls)) return false;
    const tag = selector.replace(/[#.][\w-]+/g, '').trim();
    if (tag && tag !== '*' && !/^[a-zA-Z][\w-]*$/.test(tag)) throw new Error('Unsupported fixture selector: ' + selector);
    return !tag || tag === '*' || node.tagName === tag.toUpperCase();
}
function matches(node, selector, scope) {
    return split(selector).some(item => {
        const parts = compounds(item);
        const visit = (current, at) => {
            if (!current || !simple(current, parts[at], scope)) return false;
            if (!at) return true;
            const op = parts[at - 1];
            if (op === '>') return visit(current.parentElement, at - 2);
            if (op === '+') return visit(current.previousElementSibling, at - 2);
            if (op === '~') { for (let n = current.previousElementSibling; n; n = n.previousElementSibling) if (visit(n, at - 2)) return true; return false; }
            for (let n = current.parentElement; n; n = n.parentElement) if (visit(n, at - 2)) return true;
            return false;
        };
        return visit(node, parts.length - 1);
    });
}
export class FixtureNode {
    constructor(tag, attrs = {}, children = []) {
        this.tagName = tag.toUpperCase(); this.attrs = { ...attrs }; this.nodes = []; this.nodeType = 1;
        for (const child of children.flat()) { this.nodes.push(child); if (child instanceof FixtureNode) child.parentElement = this; }
    }
    get children() { return this.nodes.filter(n => n instanceof FixtureNode); }
    get id() { return this.getAttribute('id') || ''; }
    get type() { return this.getAttribute('type') || ''; }
    get textContent() { return this.nodes.map(n => typeof n === 'string' ? n : n.textContent).join(''); }
    get previousElementSibling() { const peers = this.parentElement?.children || []; return peers[peers.indexOf(this) - 1] || null; }
    get outerHTML() { return `<${this.tagName.toLowerCase()}${Object.entries(this.attrs).map(([k,v]) => ` ${k}="${v}"`).join('')}>${this.nodes.map(n => typeof n === 'string' ? n : n.outerHTML).join('')}</${this.tagName.toLowerCase()}>`; }
    getAttribute(key) { return Object.hasOwn(this.attrs, key) ? String(this.attrs[key]) : null; }
    hasAttribute(key) { return Object.hasOwn(this.attrs, key); }
    matches(selector) { return matches(this, selector, this); }
    querySelectorAll(selector) {
        const all = this.children.flatMap(n => [n, ...n.querySelectorAll('*')]);
        return all.filter(n => matches(n, selector, this));
    }
    querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
    closest(selector) { for (let n = this; n; n = n.parentElement) if (n.matches(selector)) return n; return null; }
    contains(other) { for (let n = other; n; n = n.parentElement) if (n === this) return true; return false; }
    cloneNode() { return new FixtureNode(this.tagName, this.attrs, this.nodes.map(n => typeof n === 'string' ? n : n.cloneNode(true))); }
    remove() { if (this.parentElement) this.parentElement.nodes = this.parentElement.nodes.filter(n => n !== this); this.parentElement = null; }
}
export const el = (tag, attrs = {}, ...children) => new FixtureNode(tag, attrs, children);
export const mirror = (css, ...children) => el('toto', {'data-rabbit-mirror':'true'},
    el('details', {}, el('summary', {}, '测试镜面'), el('style', {}, css), ...children));
