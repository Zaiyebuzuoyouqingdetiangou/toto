import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { pathToFileURL } from 'node:url';

// Real DOM parser/CSSOM, no remote assets or script evaluation. This is not a
// browser/TT rendering acceptance test. Set RM_TEST_DOM_MODULE to happy-dom's
// entry point when reproducing outside this execution environment.
export async function createDomRuntime(root, { now = 1790805454761 } = {}) {
    const { Window } = await import(process.env.RM_TEST_DOM_MODULE);
    const window = new Window({ settings: { disableJavaScriptEvaluation: true,
        disableJavaScriptFileLoading: true, disableCSSFileLoading: true, disableIframePageLoading: true } });
    const values = new Map();
    let clock = now;
    class Clock extends Date {
        constructor(...args) { super(...(args.length ? args : [clock])); }
        static now() { return clock; }
    }
    const context = vm.createContext({ console, URL, Map, Set, WeakMap, WeakSet,
        Date: Clock, Math, TextEncoder, TextDecoder, Uint8Array, Uint32Array,
        Response, Headers, ReadableStream, TransformStream, AbortController,
        structuredClone, document: window.document, window, Node: window.Node,
        Element: window.Element, HTMLElement: window.HTMLElement, DOMParser: window.DOMParser,
        MutationObserver: window.MutationObserver, getComputedStyle: window.getComputedStyle.bind(window),
        location: { href: 'https://offline.invalid/', pathname: '/' },
        localStorage: { getItem: k => values.get(k) ?? null, setItem: (k, v) => values.set(k, v), removeItem: k => values.delete(k) },
        SillyTavern: { getContext: () => ({ chatId: 'offline', chat: [] }) },
        requestAnimationFrame: () => 0, cancelAnimationFrame() {}, setTimeout: () => 0, clearTimeout() {},
        setInterval: () => { throw Error('Unexpected interval'); }, clearInterval() {},
        fetch: () => { throw Error('Network is forbidden'); },
    });
    root = path.resolve(root);
    const walk = dir => readdirSync(dir).flatMap(name => {
        const file = path.join(dir, name);
        return statSync(file).isDirectory() ? walk(file) : file.endsWith('.js') ? [file] : [];
    });
    const files = [path.join(root, 'index.js'), ...walk(path.join(root, 'src')), ...walk(path.join(root, 'data'))];
    const resolve = (specifier, importer) => path.resolve(path.dirname(importer), specifier.split('?')[0]);
    const hostNames = new Map();
    for (const file of files) for (const match of readFileSync(file, 'utf8').matchAll(/import\s+\{([\s\S]*?)\}\s+from\s+['"]([^'"]+)['"]/g)) {
        const target = resolve(match[2], file);
        if (target.startsWith(root + path.sep)) continue;
        const names = hostNames.get(target) || new Set();
        for (const part of match[1].split(',')) {
            const name = part.trim().match(/^([\w$]+)/)?.[1];
            if (name) names.add(name);
        }
        hostNames.set(target, names);
    }
    const modules = new Map();
    const settings = {};
    const stub = name => name === 'extension_settings' ? settings
        : name === 'eventSource' ? { on() {}, removeListener() {} }
        : name === 'event_types' || name === 'extension_prompt_types' || name === 'extension_prompt_roles' ? {}
        : () => {};
    function get(file) {
        if (modules.has(file)) return modules.get(file);
        const module = hostNames.has(file) ? new vm.SyntheticModule([...hostNames.get(file)], function () {
            for (const name of hostNames.get(file)) this.setExport(name, stub(name));
        }, { context, identifier: file }) : new vm.SourceTextModule(readFileSync(file, 'utf8'), { context, identifier: file,
            initializeImportMeta: meta => { meta.url = pathToFileURL(file).href; } });
        modules.set(file, module);
        return module;
    }
    async function load(relative) {
        const module = get(path.resolve(root, relative));
        if (module.status === 'unlinked') await module.link((specifier, importer) => get(resolve(specifier, importer.identifier)));
        if (module.status === 'linked') await module.evaluate();
        return module.namespace;
    }
    return { load, context, window, settings, setNow: value => { clock = value; }, close: () => window.happyDOM.close() };
}
