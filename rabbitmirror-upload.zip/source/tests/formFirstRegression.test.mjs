import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';
// A saved trial setting now migrates to model-original guidance. Keep the
// selection, history, safety and scope invariants while checking that retirement.
const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const copy = x => JSON.parse(JSON.stringify(x));
async function fixture() {
 const rt = createRuntime(root), picker = await rt.load('src/picker.js'), builder = await rt.load('src/promptBuilder.js');
 const { defaultSettings } = await rt.load('src/settings.js');
 return {rt,picker,builder,settings:{...copy(defaultSettings), visualDesignMode:'current', postGenerationRecolor:false, userDirectivePriority:false, lotteryMethod:'classic', rabbitMirrorPresentationModes:['html']}};
}
async function scanner(rt) {
 Object.assign(rt.context, await rt.load('src/roleColorVariants.js'), await rt.load('src/presentationQuality.js'), await rt.load('src/compositionFingerprint.js'));
 const source = readFileSync(root + '/src/visualScanner.js','utf8');
 vm.runInContext(source.slice(0,source.indexOf('function normalizedText')).replace(/^import[\s\S]*?;\r?\n/gm,'').replace(/^export /gm,''),rt.context);
 return rt.context.scanRabbitMirrorHtml;
}
const colored = color => `<toto data-rabbit-mirror="true"><details open><summary>【兔子镜：材质】</summary><div style="background:${color};color:#292322;padding:20px">纸面上的记录</div></details></toto>`;

test('ordinary re-say redraws theme, form and interactions without a palette; continuation is exact',async()=>{
 const {picker,settings}=await fixture();
 let old=picker.pickCombination(settings,'begin').combo;
 for(let i=0;i<8;i++) {
  const next=picker.pickCombinationForMultifaceResay(settings,{faceIndex:0,faces:[old]}).combo;
  assert.ok(next.themeIds.every(id=>!old.themeIds.includes(id)),'theme must change');
  assert.ok(next.formatIds.every(id=>!old.formatIds.includes(id)),'form must change');
  assert.equal(next.paletteRecipeId,undefined);assert.equal(old.paletteRecipeId,undefined);
  assert.ok(next.interactionRecipeIds.every(id=>!old.interactionRecipeIds.includes(id)),'interaction IDs must change when available');
  const kept=picker.pickCombinationForMultifaceResay(settings,{faceIndex:0,faces:[next],preserveVariation:true}).combo;
  for(const key of ['themeIds','formatIds','interactionRecipeIds'])assert.deepEqual(copy(kept[key]),copy(next[key]));
  old=next;
 }
});
test('multiple form-compatible interactions are frozen, indexed, and only selected ticket enters history',async()=>{
 const {rt,builder,settings}=await fixture(),m=await rt.load('src/interactionRecipes.js'), storage=await rt.load('src/storage.js');
 const plan=builder.planRabbitMirrorPromptDetails({...settings,lotteryMethod:'atmosphere',atmosphereStoryPercent:100},'independent',null,'multi');
 const out=builder.renderRabbitMirrorPromptPlan(plan),menu=out.metadata.atmosphereMenu;
 assert.ok(menu.some(x=>x.interactionRecipeIds?.length>1));
 for(const ticket of menu) {
  const recipes=m.interactionRecipesFor(ticket);
  assert.equal(new Set(recipes.map(r=>r.id)).size,recipes.length);
  assert.equal(ticket.interactionRecipeId,recipes[0].id,'legacy alias remains');
  for(const r of recipes) assert.ok(out.prompt.includes(r.code));
 }
 assert.equal(builder.renderRabbitMirrorPromptPlan(plan).prompt,out.prompt);
 const chosen=storage.resolveVisualHistorySelection(storage.createVisualHistorySelection(out.metadata),2);
 storage.commitVisualHistorySelection(chosen,{});
 const last=storage.getRecentDiversityHistory(3).at(-1);
 assert.deepEqual(copy(last.interactionRecipeIds),copy(menu[2].interactionRecipeIds));
 assert.equal(last.interactionFamily,undefined);
 assert.equal(last.paletteFingerprint,undefined);
 assert.deepEqual(copy(builder.renderRabbitMirrorPromptPlan(plan).metadata.atmosphereMenu),copy(menu),'history refresh cannot redraw candidates');
});
test('old single interaction ID reads as one recipe; invalid IDs do not enter material',async()=>{
 const {rt}=await fixture(),m=await rt.load('src/interactionRecipes.js');
 assert.deepEqual(copy(m.interactionRecipesFor({interactionRecipeId:'hinged-open'}).map(x=>x.id)),['hinged-open']);
 assert.deepEqual(copy(m.interactionRecipeFields({interactionRecipeIds:['bad','hinged-open','hinged-open','<script>']})),{interactionRecipeId:'hinged-open',interactionRecipeIds:['hinged-open']});
 assert.deepEqual(copy(m.interactionRecipeFields({presentationMode:'text',interactionRecipeIds:['hinged-open']})),{});
});
test('actual cream HTML scan -> committed history -> next palette excludes the entire warm-neutral family',async()=>{
 for(const color of ['#F5F0E6','#F5EBDD','#FFF8E7','#F6EEE7','#FFF7C2','#FAF9F6']) {
  const {rt}=await fixture(),scan=await scanner(rt),m=await rt.load('src/paletteRecipes.js'),storage=await rt.load('src/storage.js');
  const found=scan(colored(color));
  assert.ok(found?.paletteFingerprint, 'real raw HTML is recognized');
  assert.equal(m.observedPaletteGroup(found),'warm_neutral',color);
  storage.commitVisualHistorySelection(storage.createVisualHistorySelection({themeIds:['A.1'],formatIds:['1.1']}),{
   visualSignature:found.signature,visualSkeleton:found.skeleton,paletteFingerprint:found.paletteFingerprint,interactionFamily:found.interactionFamily});
  const recent=storage.getRecentDiversityHistory(3);
  for(const n of [0,.2,.4,.6,.8,.999]) {
   const next=m.selectPaletteRecipe({formats:[{title:'纸本'}]},{recent,darkCooldown:true,randomUnit:()=>n});
   assert.notEqual(next.colorGroup,'warm_neutral');assert.notEqual(next.surfaceGroup,'warm_neutral');
  }
 }
});
test('scanner still recognizes dark, saturated yellow, cold blue, and unknown output without inventing a fingerprint',async()=>{
 const {rt}=await fixture(),scan=await scanner(rt),m=await rt.load('src/paletteRecipes.js');
 assert.equal(scan(colored('#171719')).paletteFingerprint.brightness,'dark');
 assert.equal(m.observedPaletteGroup(scan(colored('#FFFF00'))),'yellow');
 assert.equal(m.observedPaletteGroup(scan(colored('#E6F4FE'))),'blue');
 assert.equal(scan('<p>ordinary prose</p>').paletteFingerprint,null);
 const unknown=scan('<toto data-rabbit-mirror="true"><details><summary>【兔子镜：记录】</summary><p>无配色证据</p></details></toto>');
 assert.ok(unknown);assert.equal(unknown.paletteFingerprint,null);
});
test('large form surfaces carry colour, not only tiny accents, with independently checked readable ink',async()=>{
 const {rt}=await fixture(),m=await rt.load('src/generationPalettes.js');
 const {GENERATION_PALETTE_INDEX}=await rt.load('data/structured/generationPaletteIndex.js');
 const luminance=hex=>hex.slice(1).match(/../g).map(x=>parseInt(x,16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4).reduce((n,v,i)=>n+v*[.2126,.7152,.0722][i],0);
 const ratio=(a,b)=>{a=luminance(a);b=luminance(b);return(Math.max(a,b)+.05)/(Math.min(a,b)+.05);};
 for(const item of GENERATION_PALETTE_INDEX) {
  const p=m.composeGenerationPalette(item.family,item.companionFamily,item.brightness,item.surfaceFamily).roles;
  assert.ok(p.objectSurface && p.onObject,'named body surface, not a vague accent');
  for(const bg of ['background','surface','hover','selected']) for(const ink of ['text','muted'])assert.ok(ratio(p[bg],p[ink])>=4.5,item.id+':'+bg+ink);
  for(const [bg,ink] of [['objectSurface','onObject'],['objectHover','onObjectHover'],['accent','onAccent'],['accentHover','onAccentHover'],['companion','onCompanion']])assert.ok(ratio(p[bg],p[ink])>=4.5,item.id+':'+bg);
 }
 const blue=m.composeGenerationPalette('blue','amber','light','blue').roles;
 assert.notEqual(blue.background,'#FBFDFF');assert.notEqual(blue.surface,'#E6F4FE');
});
test('form-first contract is explicit and common core shrinks; HTML does not inherit long-story instructions',async()=>{
 const {builder,settings}=await fixture();
 const out=builder.buildRabbitMirrorPromptDetails(settings,'independent',null,'form');
 assert.match(out.prompt,/先构造展现形式本体/);
 assert.match(out.prompt,/多交互共同服务它，同种可复用/);
 assert.doesNotMatch(out.prompt,/长文本呈现规则：|兔子镜必须是复杂精美的微型交互媒介作品/);
 assert.doesNotMatch(out.prompt,/生成配色参考【|生成后换色【/);
 assert.match(out.prompt,/明暗与冷暖关系/);
});

test('three-pool redraw respects fixed scenery/combination settings and permits small-pool reuse without reviving blocked IDs',async()=>{
 const {rt,picker,settings}=await fixture();
 for(const combination of [false,true]) {
  const st={...settings,forceVisualScenery:!combination,visualSceneryCombination:combination};
  const first=picker.pickCombination(st,'fixed-'+combination).combo;
  const next=picker.pickCombinationForMultifaceResay(st,{faceIndex:0,faces:[first]}).combo;
  assert.ok(next.formatIds.includes('10.2.2'));
  if(combination)assert.ok(next.formatIds.filter(id=>id!=='10.2.2').every(id=>!first.formatIds.includes(id)));
 }
 const {PRESENTATION_FORMATS}=await rt.load('data/structured/presentationIndex.js');
 const st={...settings,samplingMode:'format_only',blacklistEnabled:true,
  blacklistedFormatIds:PRESENTATION_FORMATS.filter(item=>item.id!=='6.3.7').map(item=>item.id)};
 const one=picker.pickCombination(st,'tiny').combo;
 assert.deepEqual(copy(one.formatIds),['6.3.7']);
 const again=picker.pickCombinationForMultifaceResay(st,{faceIndex:0,faces:[one]}).combo;
 assert.deepEqual(copy(again.formatIds),['6.3.7']);
});

test('multiple recipes remain form-compatible; compact contains all drawn actions and only full includes mechanisms',async()=>{
 const {rt}=await fixture(),m=await rt.load('src/interactionRecipes.js');
 const combo={formats:[{title:'机械模型书册地图'}]};
 const allowed=new Set(m.eligibleInteractionRecipes(combo).map(r=>r.id));
 for(const roll of [0,.1,.4,.7,.99]) {
  const recipes=m.selectInteractionRecipes(combo,{randomUnit:()=>roll});
  assert.ok(recipes.every(r=>allowed.has(r.id)));
  assert.equal(new Set(recipes.map(r=>r.family)).size,recipes.length);
  const face=[{combo:{...combo,interactionRecipeIds:recipes.map(r=>r.id)}}];
  const compact=m.buildInteractionRecipeRule(face,'compact'),full=m.buildInteractionRecipeRule(face,'full');
  for(const r of recipes){assert.ok(compact.includes(r.code));assert.ok(compact.includes(r.summary));}
  assert.doesNotMatch(compact,/操作：|可见结果：|实现依据/);
  assert.equal(full.split('本轮实现依据').length-1,1);
 }
});

test('follow failed-slot continuation call site keeps the prepared theme/form/interaction choice',async()=>{
 const {rt,picker,builder,settings}=await fixture();
 const first=picker.pickCombination(settings,'follow-prepared').combo;
 const source=readFileSync(root+'/src/followFaceRetry.js','utf8');
 const line=source.match(/^\s*const plan=planRabbitMirrorPromptDetails[^\n]+/m)[0];
 Object.assign(rt.context,{settings,recipe:{faces:[first]},index:1,faceIndex:0,deps:{},planRabbitMirrorPromptDetails:builder.planRabbitMirrorPromptDetails});
 vm.runInContext(line+'\nglobalThis.continuationTestPlan=plan;',rt.context);
 const continued=builder.promptPlanSelections(rt.context.continuationTestPlan)[0].combo;
 for(const key of ['themeIds','formatIds','interactionRecipeIds'])assert.deepEqual(copy(continued[key]),copy(first[key]),key);
});
