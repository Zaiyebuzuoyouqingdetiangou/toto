import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root=process.env.RM_REPAIR_BASELINE||fileURLToPath(new URL('..',import.meta.url));
async function fixture(modes=['html']) {
    const rt=createRuntime(root), config=await rt.load('src/settings.js');
    const storage=await rt.load('src/storage.js'), builder=await rt.load('src/promptBuilder.js');
    const settings={...structuredClone(config.defaultSettings),userDirectivePriority:false,
        rabbitMirrorFaceCount:modes.length,rabbitMirrorPresentationModes:modes};
    const record=(skeleton)=>{storage.setPendingCombo({themeIds:['F.0'],formatIds:['7.6']});
        storage.commitPendingCombo('face',skeleton,[],null,{id:'multi_control_panel_family',label:'多控件状态面板',confidence:.9});};
    const render=source=>builder.renderRabbitMirrorPromptPlan(
        builder.planRabbitMirrorPromptDetails(settings,'independent',null,'history-merge'),null,null,undefined,source);
    return {render,record};
}
test('legacy independent history is merged once and identical family dimensions are not resent',async()=>{
    const f=await fixture();
    f.record('surface_family: surface: paper_or_document_surface；unit_family: 单元证据');
    f.record('surface_family: surface: paper_or_document_surface；unit_family: 单元证据');
    let reads=0;
    const result=f.render(({needsBackfill})=>{
        reads++;assert.equal(needsBackfill,true);
        return {families:[{surface_family:'surface: paper_or_document_surface',unit_family:'单元证据',
            operation_family:'text_disclosure_stack'}, {operation_family:'text_disclosure_stack'}]};
    });
    assert.equal(reads,1);
    assert.equal(result.prompt.split('surface: paper_or_document_surface').length-1,1);
    assert.equal(result.prompt.split('单元证据').length-1,1);
    assert.equal(result.prompt.split('同构文字条目逐项折叠展开').length-1,1);
    assert.equal(result.prompt.split('近期结构记录【').length-1,1);
    assert.doesNotMatch(result.prompt,/独立 API 近期五面结构补充/);
});
test('complete structural records avoid legacy backfill and merge the reroll source once',async()=>{
    const f=await fixture();
    f.record('operation_family: text_panel_switch；layout_family: scene_above_text');
    const result=f.render(({needsBackfill})=>{
        assert.equal(needsBackfill,false);
        return {families:[],previous:{operation_family:'text_panel_switch',layout_family:'scene_above_text'}};
    });
    assert.equal(result.prompt.split('同位置文字面板切换').length-1,1);
    assert.equal(result.prompt.split('上画下文：').length-1,1);
    assert.match(result.prompt,/最高短期冷却/);
});
test('text-only plans do not read independent visual history',async()=>{
    const f=await fixture(['longtext']);
    f.render(()=>{throw Error('text face must not read visual history');});
});
test('mixed faces merge shared history once with explicit HTML-only scope',async()=>{
    const f=await fixture(['html','longtext','html']);let reads=0;
    const result=f.render(()=>{reads++;return {families:[{operation_family:'text_disclosure_stack'}]};});
    assert.equal(reads,1);
    assert.match(result.prompt,/以下历史避重仅作用于 HTML 面（第 1、3 面）/);
    assert.equal(result.prompt.split('同构文字条目逐项折叠展开').length-1,1);
});
