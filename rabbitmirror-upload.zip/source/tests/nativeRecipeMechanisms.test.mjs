import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

// Exercise actual sanitizer + namespace functions. This is not browser paint.
function markupRuntime() {
    const strip = source => source.replace(/^import\s+[\s\S]*?from\s+['"][^'"]+['"];\s*/gm, '').replace(/^export /gm, '');
    const context = vm.createContext({ console, URL, Map, Set, WeakMap, WeakSet,
        getSettings: () => ({}), applyRabbitMirrorBannedWordsToDom() {} });
    vm.runInContext(['runtime', 'markup'].map(name => strip(readFileSync(new URL(`../src/outputSanitizer/${name}.js`, import.meta.url), 'utf8'))).join('\n'), context);
    return context;
}

const mechanisms = {
    toggle: '#lid:checked ~ .stage .part{transform:rotate(-55deg);transform-origin:left bottom;} .stage{position:relative;}',
    choice: '#left:checked ~ .stage .part{transform:translateX(0px);} #right:checked ~ .stage .part{transform:translateX(90px);}',
    combine: '#a:checked ~ #b:checked ~ .stage .part{opacity:1;transform:translateY(-20px);}',
    disclosure: 'details[open] .part{border-left:3px solid #557B96;} .part{white-space:normal;}',
    scroll: '.strip{max-width:100%;overflow-x:auto;scroll-snap-type:x proximity;} .part{scroll-snap-align:start;flex:0 0 85%;}',
    motion: '.part{animation:orbit 6s linear infinite;animation-play-state:paused;} #power:checked ~ .stage .part{animation-play-state:running;} @keyframes orbit{to{transform:rotate(360deg);}} @media(prefers-reduced-motion:reduce){.part{animation:none;}}',
};
for (const [name, css] of Object.entries(mechanisms)) {
    test(`${name}: safe state and geometry survive the real CSS sanitizer and face scoping`, () => {
        const runtime = markupRuntime();
        const clean = runtime.sanitizeGeneratedStyleSheet(css, { allowContainedAbsoluteStack: true });
        assert.ok(clean.length);
        const scoped = runtime.scopeRabbitMirrorCssText(clean, '[data-test-face="one"]', new Map(), new Set(), new Map());
        assert.match(scoped, /data-test-face="one"/);
        const feature = { toggle: 'rotate(-55deg)', choice: 'translateX(90px)', combine: '#a:checked ~ #b:checked',
            disclosure: 'details[open]', scroll: 'scroll-snap-type:x proximity', motion: 'animation-play-state:running' }[name];
        assert.ok(scoped.includes(feature), `${name}: ${scoped}`);
    });
}

test('adding safe recipes does not permit network CSS or executable imports', () => {
    const runtime = markupRuntime();
    const css = runtime.sanitizeGeneratedStyleSheet('@import "https://bad.invalid/a.css"; .part{background-image:url(https://bad.invalid/x);transform:rotate(40deg);}');
    assert.doesNotMatch(css, /bad.invalid|@import|url\(/);
    assert.match(css, /rotate\(40deg\)/);
});
