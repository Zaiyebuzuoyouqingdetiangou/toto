import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';
import { el, mirror } from './helpers/domFixture.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const interactionRisks = value => [...value.riskFlags].filter(flag => ['missing_interaction', 'fake_interaction'].includes(flag));
async function fixture() {
    const rt = createRuntime(root);
    const storage = await rt.load('src/storage.js');
    Object.assign(rt.context, await rt.load('src/roleColorVariants.js'), await rt.load('src/presentationQuality.js'), await rt.load('src/compositionFingerprint.js'));
    const source = readFileSync(root + '/src/visualScanner.js', 'utf8');
    vm.runInContext(source.slice(0, source.indexOf('function normalizedText'))
        .replace(/^import[\s\S]*?;\r?\n/gm, '').replace(/^export /gm, ''), rt.context);
    // Detached selector fixture only: no clicks, events, browser paint or model calls.
    const scan = node => {
        rt.context.DOMParser = class { parseFromString() { return { querySelector: () => node }; } };
        const before = node.outerHTML;
        const result = rt.context.scanRabbitMirrorHtml(before);
        assert.equal(node.outerHTML, before, 'scan must not mutate the source DOM');
        return result;
    };
    const commit = (id, skeleton, flags) => {
        storage.setPendingCombo({ themeIds: [id], formatIds: ['7.6'] });
        storage.commitPendingCombo('test', skeleton, flags, null, { key: 'multi_control_panel', label: '多控件状态面板' });
    };
    return { rt, storage, scan, commit };
}

const wheelCss = '.wheel{position:absolute;width:90px;height:90px;left:20px;top:20px;border:5px dashed #eca842;border-radius:50%;background:#182631;transition:transform .2s}';
const gear = (rule = '#lever:checked ~ .wheel{transform:translateX(100px) rotate(90deg)}', extraCss = '') => mirror(wheelCss + extraCss + rule,
    el('div', { style: 'position:relative;width:260px;height:180px;background:#384a65' },
        el('input', { type: 'checkbox', id: 'lever' }), el('label', { for: 'lever' }, '啮合齿轮'), el('div', { class: 'wheel' })));

test('persistent 2D object states are effective interactions and retain independent visual risks', async () => {
    const f = await fixture();
    for (const declaration of ['transform:translateX(100px) rotate(90deg)', 'transform:scale(1.8)', 'translate:100px 0', 'rotate:90deg', 'scale:1.8']) {
        const node = gear(`#lever:checked ~ .wheel{${declaration}}`);
        node.children[0].children.at(-1).attrs['data-rm-visual-scenery'] = 'true';
        const result = f.scan(node);
        assert.equal(f.storage.parseVisualFamilySkeleton(result.skeleton).operation_family, 'object_state_change', declaration);
        assert.deepEqual(interactionRisks(result), [], declaration);
        assert.ok(result.riskFlags.includes('weak_visual_scenery_motion'), 'state interaction must not waive required continuous motion');
    }
});

test('persistent SVG object rotation is effective without requiring text panels', async () => {
    const f = await fixture();
    for (const grouped of [false, true]) {
        const needle = el('path', { class: grouped ? 'blade' : 'needle', d: 'M80 80 L80 20' });
        const node = mirror('#lever:checked ~ svg .needle{transform:rotate(40deg)}',
            el('input', { id: 'lever', type: 'checkbox' }), el('label', { for: 'lever' }, '调整指针'),
            el('svg', { viewBox: '0 0 200 160' }, grouped ? el('g', { class: 'needle' }, needle) : needle));
        const result = f.scan(node);
        assert.equal(f.storage.parseVisualFamilySkeleton(result.skeleton).operation_family, 'object_state_change');
        assert.deepEqual(interactionRisks(result), []);
    }
});

test('control-only transforms, hover wiggles, unbound targets and unchanged geometry stay ineffective', async () => {
    const f = await fixture();
    const cases = [
        gear('#lever:checked ~ label{transform:translateX(2px) rotate(2deg);color:red}'),
        gear('#lever:checked ~ label{translate:2px;rotate:2deg;scale:1.05}'),
        gear('.wheel:hover{transform:translateX(3px) rotate(2deg)}'),
        gear('#lever:checked ~ .missing{transform:translateX(100px)}'),
        gear('#absent:checked ~ .wheel{transform:translateX(100px)}'),
        gear('#lever:checked ~ .wheel{transform:rotate(90deg)}', '.wheel{transform:rotate(90deg)}'),
        mirror('#lever:checked ~ .icon{transform:rotate(90deg)}', el('input', { id: 'lever', type: 'checkbox' }),
            el('label', { for: 'lever' }, '选择'), el('svg', { class: 'icon', viewBox: '0 0 20 20' }, el('path', { d: 'M0 0L20 20' }))),
    ];
    for (const node of cases) {
        const result = f.scan(node);
        assert.notEqual(f.storage.parseVisualFamilySkeleton(result.skeleton).operation_family, 'object_state_change');
        assert.deepEqual(interactionRisks(result), ['missing_interaction', 'fake_interaction']);
    }
});

test('checked styling on drawing descendants of a control is still control feedback', async () => {
    const f = await fixture();
    for (const tag of ['label', 'button']) {
        const node = mirror('.icon{position:absolute;width:90px;height:90px;background:red}#a:checked~.control .icon{transform:rotate(2deg)}',
            el('input', { id: 'a', type: 'checkbox' }),
            el(tag, { class: 'control', ...(tag === 'label' ? { for: 'a' } : {}) }, el('span', { class: 'icon' }), '选择'));
        const result = f.scan(node);
        assert.notEqual(f.storage.parseVisualFamilySkeleton(result.skeleton).operation_family, 'object_state_change');
        assert.deepEqual(interactionRisks(result), ['missing_interaction', 'fake_interaction']);
    }
});

test('default none, zero translation/rotation and unit scale do not prove a new object state', async () => {
    const f = await fixture();
    for (const [declaration, base] of [
        ['transform:none', ''], ['translate:0px', ''], ['rotate:0deg', ''], ['scale:1', ''],
        ['translate:0px 0px', ''], ['rotate:0turn', ''], ['scale:1 1', ''],
        ['translate:none', '.wheel{translate:0px}'], ['rotate:none', '.wheel{rotate:0deg}'],
        ['scale:none', '.wheel{scale:1}'],
    ]) {
        const result = f.scan(gear(`#lever:checked ~ .wheel{${declaration}}`, base));
        assert.notEqual(f.storage.parseVisualFamilySkeleton(result.skeleton).operation_family, 'object_state_change', declaration);
        assert.deepEqual(interactionRisks(result), ['missing_interaction', 'fake_interaction'], declaration);
    }
});

test('conditional CSS does not prove active object changes; unconditional layers still can', async () => {
    const f = await fixture();
    for (const condition of ['@media print', '@supports (display: not-a-real-value)', '@container (min-width: 99999px)']) {
        const result = f.scan(gear(`${condition}{#lever:checked ~ .wheel{transform:translateX(100px)}}`));
        assert.notEqual(f.storage.parseVisualFamilySkeleton(result.skeleton).operation_family, 'object_state_change', condition);
        assert.deepEqual(interactionRisks(result), ['missing_interaction', 'fake_interaction'], condition);
    }
    const layer = f.scan(gear('@layer scene{#lever:checked ~ .wheel{transform:translateX(100px)}}'));
    assert.equal(f.storage.parseVisualFamilySkeleton(layer.skeleton).operation_family, 'object_state_change');
    assert.deepEqual(interactionRisks(layer), []);
});

test('unsupported oversized scenes keep the existing conservative interaction fallback', async () => {
    const f = await fixture();
    const node = gear();
    for (let index = 0; index < 601; index++) node.children[0].nodes.push(el('i'));
    const result = f.scan(node);
    assert.notEqual(f.storage.parseVisualFamilySkeleton(result.skeleton).operation_family, 'object_state_change');
    assert.deepEqual(interactionRisks(result), ['missing_interaction', 'fake_interaction']);
});

test('native disclosure and actual text switching retain their existing effective behavior', async () => {
    const f = await fixture();
    const nodes = [
        mirror('', el('details', {}, el('summary', {}, '展开'), el('p', {}, '实际正文'))),
        mirror('#a:checked~article{display:block}', el('input', { type: 'checkbox', id: 'a' }),
            el('label', { for: 'a' }, '查看'), el('article', { style: 'display:none' }, '实际正文')),
    ];
    for (const node of nodes) assert.deepEqual(interactionRisks(f.scan(node)), []);
});

test('stored proven object states exclude only contradictory interaction risks at both history readers', async () => {
    const f = await fixture();
    // Legacy conflict is deliberately seeded, not claimed as fresh scanner output.
    f.commit('legacy-device', 'operation_family: object_state_change',
        ['missing_interaction', 'fake_interaction', 'weak_visual_scenery_motion', 'weak_media_body']);
    const before = JSON.stringify(f.storage.getComboHistory(5));
    assert.deepEqual([...f.storage.getRecentRiskFlags(5)], ['weak_visual_scenery_motion', 'weak_media_body']);
    assert.deepEqual({ ...f.storage.getRecentRiskFlagCounts(5) }, { weak_visual_scenery_motion: 1, weak_media_body: 1 });
    assert.deepEqual([...f.storage.getRecentInteractionFamilies(5)], []);
    assert.equal(JSON.stringify(f.storage.getComboHistory(5)), before, 'history correction must remain read-only');
});

test('history without exact object-state proof still contributes all interaction risks', async () => {
    const f = await fixture();
    for (const [index, skeleton] of ['', 'operation_family: text_panel_switch', 'operation_family: object_state_change_extra', 'mood: object_state_change'].entries()) {
        f.commit('unproven-' + index, skeleton, ['missing_interaction', 'fake_interaction']);
    }
    f.commit('proven', 'operation_family: object_state_change', ['missing_interaction', 'fake_interaction']);
    assert.deepEqual([...f.storage.getRecentRiskFlags(5)], ['missing_interaction', 'fake_interaction']);
    assert.deepEqual({ ...f.storage.getRecentRiskFlagCounts(5) }, { missing_interaction: 4, fake_interaction: 4 });
});
