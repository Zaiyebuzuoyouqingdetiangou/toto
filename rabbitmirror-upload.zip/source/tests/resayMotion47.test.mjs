import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';

const root = process.env.RM_TEST_SOURCE_ROOT || fileURLToPath(new URL('..', import.meta.url));
const run = fn => async () => { const rt = await createDomRuntime(root); try { await fn(rt); } finally { rt.close(); } };

test('manual resay never schedules extra paid attempts; first automatic generation retains configured retry', run(async rt => {
    const r = await rt.load('src/automaticReroll.js');
    assert.equal(r.shouldAutomaticReroll({ manualResay: true, failedPosts: 1, max: 2 }), false);
    assert.equal(r.shouldAutomaticReroll({ manualResay: true, failedPosts: 2, max: 8 }), false);
    assert.equal(r.shouldAutomaticReroll({ failedPosts: 1, max: 2 }), true);
}));

test('waiting for first response is not a stalled stream; progress stall and absolute bound remain', run(async rt => {
    const timers = new Map(); let id = 0; let error;
    rt.context.setTimeout = (fn, ms) => { timers.set(++id, { fn, ms }); return id; };
    rt.context.clearTimeout = id => timers.delete(id);
    const { createIndependentRequestDeadline } = await rt.load('src/independentApi/flights.js');
    const controller = new AbortController();
    const d = createIndependentRequestDeadline(controller, e => { error = e; }, { idleMs: 90, absoluteMs: 1200 });
    d.progress('request-sent');
    assert.deepEqual([...timers.values()].map(t => t.ms), [1200]);
    d.progress('response-headers');
    assert.deepEqual([...timers.values()].map(t => t.ms), [1200]);
    d.progress('response-chunk');
    assert.equal([...timers.values()].some(t => t.ms === 90), true);
    [...timers.values()].find(t => t.ms === 90).fn();
    assert.equal(controller.signal.aborted, true);
    assert.equal(error.code, 'RABBIT_MIRROR_INDEPENDENT_STALL_TIMEOUT');
    assert.equal(timers.size, 0);
}));

test('export releases runtime pause while preserving authored pause control and live state', run(async rt => {
    const doc = rt.window.document;
    doc.body.innerHTML = '<details open><summary>【兔子镜：风雪】</summary><style>.snow{animation:fall 2s infinite}#pause:checked~.snow{animation-play-state:paused}@keyframes fall{to{transform:translateY(40px)}}</style><input type="checkbox" id="pause"><label for="pause">暂停</label><div class="snow">雪</div><div class="author" style="animation-play-state:paused!important">作者暂停</div></details>';
    const face = doc.querySelector('details'), input = doc.querySelector('input'); input.checked = true;
    const rescue = await rt.load('src/outputSanitizer/checkedStateRescue.js');
    rescue.applyCheckedRuleTextFallback(face, input);
    assert.equal(doc.querySelector('.snow').style.animationPlayState, 'paused');
    let html;
    rt.context.navigator = { clipboard: { writeText: async s => { html = s; } } };
    const panel = doc.createElement('div'); panel.innerHTML = '<span data-rm-copy-html-status></span>'; doc.body.append(panel);
    const button = doc.createElement('button'); panel.append(button);
    await (await rt.load('src/outputSanitizer/diagnostics.js')).copyRabbitMirrorCurrentFaceHtml(face, button, panel);
    assert.ok(html, panel.textContent);
    const copy = doc.createElement('template'); copy.innerHTML = html;
    assert.equal(copy.content.querySelector('.snow').style.animationPlayState, '');
    assert.equal(copy.content.querySelector('.author').style.animationPlayState, 'paused');
    assert.equal(copy.content.querySelector('input').hasAttribute('checked'), true);
    assert.match(copy.content.querySelector('style').textContent, /:checked[^}]*animation-play-state:paused/);
    assert.equal(doc.querySelector('.snow').style.animationPlayState, 'paused');
}));

test('quick resay invokes captured owner directly and rejects unavailable owner without sending', run(async rt => {
    const tools = await rt.load('src/outputSanitizer/toolsChrome.js');
    const runtime = await rt.load('src/independentApi/runtime.js');
    let requests = 0;
    rt.context[runtime.ACTION_BRIDGE_KEY] = { runtime: runtime.RUNTIME_VERSION, prepareQuickResay: () => () => { requests++; return true; } };
    assert.equal(tools.quickResayRabbitMirror({}), true);
    assert.equal(requests, 1);
    rt.context[runtime.ACTION_BRIDGE_KEY].prepareQuickResay = () => null;
    assert.equal(tools.quickResayRabbitMirror({}), false);
    assert.equal(requests, 1);
}));

test('dynamic combination explicitly constructs a complete moving picture without losing its medium', () => {
    const source = readFileSync(root + '/src/promptBuilder.js', 'utf8');
    const fn = source.match(/^function visualCombinationRule\([^]*?^}/m)[0];
    const context = vm.createContext({ isTextPresentation: combo => combo.text });
    vm.runInContext(readFileSync(root + '/data/raw/visualSceneryRules.js', 'utf8').replace(/^export /gm, '') + '\n' + fn, context);
    const rule = context.visualCombinationRule({ visualSceneryCombination: true });
    assert.match(rule, /动态画面落实在该媒介自身的主体、空间、材质或叙事关系中/);
    assert.match(rule, /未操作时核心画面就完整可见/);
    assert.match(rule, /交互依抽中的形式自然产生/);
    assert.match(rule, /书信仍有完整书信、日志仍有实际记录/);
    assert.match(rule, /不能把正文降格为画面说明或删除其阅读路径/);
    assert.equal(context.visualCombinationRule({ visualSceneryCombination: true, text: true }), '');
    assert.equal(context.visualCombinationRule({}), '');
});

test('offscreen and hidden-page pause release without overriding user pauses, and detach/destroy release observers', run(async rt => {
    const doc = rt.window.document; const instances = [];
    class Observer {
        constructor(callback) { this.callback = callback; this.observed = new Set(); instances.push(this); }
        observe(root) { this.observed.add(root); }
        unobserve(root) { this.observed.delete(root); }
        disconnect() { this.observed.clear(); this.disconnected = true; }
        send(target, isIntersecting) { this.callback([{ target, isIntersecting }]); }
    }
    rt.window.IntersectionObserver = Observer;
    let hidden = false; Object.defineProperty(doc, 'hidden', { configurable: true, get: () => hidden });
    doc.body.innerHTML = '<details open><summary>画面</summary><div style="animation-play-state:paused">用户暂停</div></details><details open><summary>另一面</summary></details>';
    const [one, two] = doc.querySelectorAll('details');
    const m = await rt.load('src/animationVisibility.js');
    m.trackMirrorAnimations(one); m.trackMirrorAnimations(two); m.trackMirrorAnimations(one);
    assert.equal(instances.length, 1); assert.equal(instances[0].observed.size, 2);
    instances[0].send(one, false); assert.equal(one.hasAttribute('data-rm-animation-suspended'), true);
    instances[0].send(one, true); assert.equal(one.hasAttribute('data-rm-animation-suspended'), false);
    assert.equal(one.querySelector('div').style.animationPlayState, 'paused');
    hidden = true; doc.dispatchEvent(new rt.window.Event('visibilitychange'));
    assert.equal(two.hasAttribute('data-rm-animation-suspended'), true);
    hidden = false; doc.dispatchEvent(new rt.window.Event('visibilitychange'));
    assert.equal(two.hasAttribute('data-rm-animation-suspended'), false);
    one.remove(); m.pruneMirrorAnimationVisibility(); assert.equal(instances[0].observed.size, 1);
    instances[0].send(two, false); m.destroyMirrorAnimationVisibility();
    assert.equal(two.hasAttribute('data-rm-animation-suspended'), false); assert.equal(instances[0].disconnected, true);
    hidden = true; doc.dispatchEvent(new rt.window.Event('visibilitychange'));
    assert.equal(two.hasAttribute('data-rm-animation-suspended'), false);
}));

test('unknown model pause is preserved and only proven runtime pause is removed from favorites and stored faces', run(async rt => {
    const doc = rt.window.document;
    doc.body.innerHTML = '<div data-rabbit-mirror-external-source="true" class="rabbit-mirror-external-host"><details open data-rm-animation-suspended><summary>【兔子镜：原样保存】</summary><input type="checkbox" id="p"><style>#p:checked~.snow{animation-play-state:paused}</style><div class="snow">雪花</div><div class="author" style="animation-play-state:paused!important">原稿暂停</div></details></div>';
    const face = doc.querySelector('details'), control = doc.querySelector('input'); control.checked = true;
    const rescue = await rt.load('src/outputSanitizer/checkedStateRescue.js'); rescue.applyCheckedRuleTextFallback(face, control);
    const { captureTheaterFavoriteFromRoot } = await rt.load('src/theaterFavorites.js');
    const favorite = captureTheaterFavoriteFromRoot(face);
    assert.ok(favorite?.html);
    const { serializeExternalFaceDetails } = await rt.load('src/independentApi/mount.js');
    for (const html of [favorite.html, serializeExternalFaceDetails(face.parentElement)]) {
        const t = doc.createElement('template'); t.innerHTML = html;
        assert.equal(t.content.querySelector('.snow').style.animationPlayState, '');
        assert.equal(t.content.querySelector('.author').style.animationPlayState, 'paused');
        assert.doesNotMatch(html, /data-rm-animation-suspended/);
    }
    assert.equal(face.hasAttribute('data-rm-animation-suspended'), true);
}));

test('overlapping checked pause rules restore the original state on uncheck', run(async rt => {
    const doc = rt.window.document;
    doc.body.innerHTML = '<details open><summary>【兔子镜：恢复动画】</summary><style>#p:checked~.snow{animation-play-state:paused}#p:checked~div{animation-play-state:paused}</style><input type="checkbox" id="p"><div class="snow">雪花</div></details>';
    const face = doc.querySelector('details'), input = doc.querySelector('input'), snow = doc.querySelector('.snow');
    const r = await rt.load('src/outputSanitizer/checkedStateRescue.js');
    input.checked = true; r.applyCheckedRuleTextFallback(face, input); assert.equal(snow.style.animationPlayState, 'paused');
    input.checked = false; r.restoreInteractionInlineOverrides(input); assert.equal(snow.style.animationPlayState, '');
}));

test('first response waiting still has a finite absolute deadline and can be cleared', run(async rt => {
    const timers = new Map(); let id = 0; let error;
    rt.context.setTimeout = (fn, ms) => { timers.set(++id, { fn, ms }); return id; };
    rt.context.clearTimeout = id => timers.delete(id);
    const { createIndependentRequestDeadline } = await rt.load('src/independentApi/flights.js');
    const controller = new AbortController();
    const d = createIndependentRequestDeadline(controller, e => { error = e; }, { idleMs: 90, absoluteMs: 1200 });
    d.progress('request-sent'); [...timers.values()][0].fn();
    assert.equal(error.code, 'RABBIT_MIRROR_INDEPENDENT_ABSOLUTE_TIMEOUT'); assert.equal(controller.signal.aborted, true);
    const d2 = createIndependentRequestDeadline(new AbortController(), () => assert.fail(), { idleMs: 90, absoluteMs: 1200 });
    d2.progress('request-sent'); d2.clear(); assert.equal(timers.size, 0);
}));

test('offscreen inline-important animation holds speed, never calls play or undoes a user pause', run(async rt => {
    const doc = rt.window.document; let callback;
    rt.window.IntersectionObserver = class {
        constructor(fn) { callback = fn; }
        observe() {} unobserve() {} disconnect() {}
    };
    doc.body.innerHTML = '<details><div style="animation-play-state:running!important">动画</div></details>';
    const face = doc.querySelector('details'), target = face.querySelector('div');
    const moving = { animationName: 'wind', effect: { target }, playState: 'running', playbackRate: -2, currentTime: 220, play: () => assert.fail('must not force play') };
    const paused = { ...moving, playState: 'paused', playbackRate: 1 };
    const transition = { effect: { target }, playState: 'running', playbackRate: 1 };
    face.getAnimations = () => [moving, paused, transition];
    const m = await rt.load('src/animationVisibility.js'); m.trackMirrorAnimations(face);
    callback([{ target: face, isIntersecting: false }]);
    assert.equal(moving.playbackRate, 0); assert.equal(paused.playbackRate, 1); assert.equal(transition.playbackRate, 1);
    moving.playState = 'paused'; // a control or author rule pauses while offscreen
    callback([{ target: face, isIntersecting: true }]);
    assert.equal(moving.playbackRate, -2); assert.equal(moving.playState, 'paused'); assert.equal(moving.currentTime, 220);
    moving.playState = 'running'; callback([{ target: face, isIntersecting: false }]);
    m.destroyMirrorAnimationVisibility(); assert.equal(moving.playbackRate, -2);
    assert.equal(target.style.getPropertyPriority('animation-play-state'), 'important');
}));
