import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { el, mirror } from './helpers/domFixture.mjs';
import { detectInteractionFamily as legacyClassify } from './fixtures/legacyInteraction1553.js';
import { recentInteractionCooldowns } from '../src/interactionCooldown.js';
const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const source = readFileSync(root + '/src/visualScanner.js', 'utf8');
const names = ['stripTags', 'count', 'interactionFamilyRecord', 'labelsForControls', 'hasMeaningfulStateRule', 'detectEffectiveInteraction', 'detectInteractionFamily'];
const code = names.map(name => source.match(new RegExp('^function ' + name + '\\b[\\s\\S]*?^}', 'm'))[0]).join('\n');
const ctx = vm.createContext({});
vm.runInContext(code + '\nglobalThis.classify = detectInteractionFamily;', ctx);
const text = '掌柜放下茶壶，抬头看着窗外的雨。客人翻开记录旅途见闻的册子。';
const input = (i, type = 'radio') => el('input', { id: `c${i}`, type, name: 'camera' });
const label = i => el('label', { for: `c${i}`, class: 'same' }, `操作${i}`);
const panels = () => [1, 2, 3].map(i => el('article', { class: `panel p${i}` }, text));
const radios = (n = 3, css = '') => mirror(Array.from({length:n}, (_,i) => `#c${i+1}:checked ~ .p${i+1}{display:block}`).join('') + css,
    ...Array.from({length:n}, (_,i) => input(i+1)), ...Array.from({length:n}, (_,i) => label(i+1)), ...panels());
const cases = [
    ['three radio text pages', radios(), 'tabbed_radio_family'],
    ['camera plus scene controls', radios(3, '#c2:checked~.scene{transform:scale(1.6)}'), 'tabbed_radio_family'],
    ['two radio panels', radios(2), 'tabbed_radio_family'],
    ['three independent device controls', mirror('#c1:checked~.lamp{background:gold}#c2:checked~.steam{opacity:1}#c3:checked~.disc{transform:rotate(40deg)}',
        ...[1,2,3].map(i=>input(i,'checkbox')), ...[1,2,3].map(label), ...['lamp','steam','disc'].map(c=>el('div',{class:c}))), 'multi_control_panel_family'],
    ['three matching buttons alone', mirror('', ...[1,2,3].map(i=>el('button',{class:'same'},String(i)))), 'none'],
    ['one checkbox reveal', mirror('#c1:checked~article{display:block}', input(1,'checkbox'), label(1), ...panels()), 'checkbox_reveal_family'],
    ['two checkbox reveals', mirror('#c1:checked~article{display:block}#c2:checked~article{opacity:1}',input(1,'checkbox'),input(2,'checkbox'),label(1),label(2),...panels()), 'multi_checkbox_family'],
    ['vertical prose disclosures', mirror('', ...[1,2,3].map(i=>el('details',{},el('summary',{class:'same'},String(i)),el('p',{},text)))), 'inner_details_family'],
    ['vertical picture disclosures', mirror('', ...[1,2,3].map(i=>el('details',{},el('summary',{class:'same'},String(i)),el('svg',{},el('path'))))), 'inner_details_family'],
    ['exclusive native disclosures', mirror('', ...[1,2].map(i=>el('details',{name:'pages'},el('summary',{},String(i)),el('p',{},text)))), 'inner_details_family'],
    ['anchor target', mirror('.page:target{display:block}',el('a',{href:'#p'},'打开'),el('article',{id:'p',class:'page'},text)), 'target_navigation_family'],
    ['popover', mirror('',el('button',{popovertarget:'p'},'开'),el('article',{popover:'',id:'p'},text)), 'popover_family'],
    ['flip takes priority', radios(3,'.card{transform:rotateY(180deg);backface-visibility:hidden}'), 'flip_card_family'],
];
for (const [name,node,expected] of cases) test(`1.5.53 classification parity: ${name}`,()=>{
    const before = node.outerHTML;
    const result = ctx.classify(node,before);
    assert.equal(result.id,expected);
    assert.deepEqual(JSON.parse(JSON.stringify(result)),legacyClassify(node,before));
    assert.equal(node.outerHTML,before,'scanner must not change the artwork');
});

test('strong policy cools reliable latest use while retaining the six legacy families',()=>{
    const ids=['tabbed_radio_family','multi_control_panel_family','checkbox_reveal_family','multi_checkbox_family','inner_details_family','flip_card_family'];
    for(const id of ids){
        assert.deepEqual(recentInteractionCooldowns([{id,confidence:.9}]).map(item=>item.id),[id]);
        assert.deepEqual(recentInteractionCooldowns([{id,confidence:.4}]),[]);
        assert.deepEqual(recentInteractionCooldowns([{id,confidence:.9},null,null,null,null,null]),[]);
    }
    assert.deepEqual(recentInteractionCooldowns([{id:'unknown',confidence:1}]),[]);
    assert.equal(recentInteractionCooldowns(ids.slice(0,2).flatMap(id=>[{id},{id}])).length,2);
});
