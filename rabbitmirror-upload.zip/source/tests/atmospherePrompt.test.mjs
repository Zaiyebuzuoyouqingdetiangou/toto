import assert from 'node:assert/strict';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));

async function fixture(overrides = {}, ids = ['7.6', '8.3', '5.3.1', '10.2.2']) {
    const runtime = createRuntime(root);
    const { defaultSettings } = await runtime.load('src/settings.js');
    const prompt = await runtime.load('src/promptBuilder.js');
    const { PRESENTATION_FORMATS } = await runtime.load('data/structured/presentationIndex.js');
    const { THEMATIC_CATEGORIES } = await runtime.load('data/structured/thematicIndex.js');
    const themes = [THEMATIC_CATEGORIES.find(item => item.id !== 'I.1' && !item.tags.includes('if') && !item.tags.includes('adult'))];
    const formats = ids.map(id => PRESENTATION_FORMATS.find(item => item.id === id));
    const settings = { ...copy(defaultSettings), userDirectivePriority: false, ...overrides };
    const tickets = formats.map(format => ({
        themeIds: themes.map(item => item.id), formatIds: [format.id],
        themeLines: themes.map(item => `${item.id} ${item.title}：${item.summary}`),
        formatLines: [`${format.id} ${format.title}：${format.summary}`],
    }));
    const combo = { themes, formats: [formats[0]], themeIds: themes.map(item => item.id),
        formatIds: [formats[0].id], requestedPresentationMode: 'html', presentationMode: 'html',
        atmosphereBucket: 'story', atmosphereMenu: tickets };
    const render = (type = 'normal', selected = combo) => prompt.renderRabbitMirrorPromptPlan(
        prompt.planRabbitMirrorPromptDetails(settings, type, null, `pinned-${type}`,
            { pinnedSelections: [{ combo: selected, directive: null }] }));
    return { runtime, settings, prompt, combo, formats, render };
}

for (const type of ['normal', 'independent']) {
    test(`${type}: all four candidates reach the shared prompt, without a first-ticket execution lock`, async () => {
        const f = await fixture();
        const result = f.render(type);
        assert.match(result.prompt, /按正文挑签/);
        for (const item of f.formats) assert.ok(result.prompt.includes(`${item.id} ${item.title}`), item.title);
        assert.doesNotMatch(result.executionLock, /短检：主形式 7\.6/);
        assert.doesNotMatch(result.executionLock, /主题：[^\n]+展现形式：主 7\.6/);
        assert.equal((result.prompt.match(/按正文挑签：/g) || []).length, 1);
        assert.equal((result.executionLock.match(/签 1：/g) || []).length, 0, 'candidate material must not be sent twice');
    });
}

test('candidate-specific visual, tarot and worldview rules are conditional, not borrowed from ticket 1', async () => {
    const f = await fixture({ presentationWorldviewLock: true });
    const result = f.render();
    assert.match(result.prompt, /仅选中签 3 时[\s\S]*塔罗/);
    assert.match(result.prompt, /仅选中签 4 时[\s\S]*Visual Scenery/);
    assert.match(result.prompt, /选中签的形式/);
    assert.deepEqual([...result.metadata.atmosphereMenu[1].formatIds], ['8.3']);
});

test('longtext atmosphere keeps the menu but does not inherit HTML scenery or tarot instructions', async () => {
    const f = await fixture({ rabbitMirrorPresentationModes: ['longtext'] });
    const combo = { ...f.combo, requestedPresentationMode: 'longtext', presentationMode: 'text' };
    const result = f.render('independent', combo);
    assert.match(result.prompt, /按正文挑签/);
    assert.ok(result.prompt.includes('8.3 后日谈'));
    assert.doesNotMatch(result.prompt, /Visual Scenery 场景优先级|塔罗实体牌图硬锁/);
    assert.doesNotMatch(result.executionLock, /形式叙述特点：主 7\.6/);
});

for (const type of ['normal', 'independent']) {
    test(`${type}: five faces receive their own menus without duplicate material`, async () => {
        const f = await fixture({ rabbitMirrorFaceCount: 5, lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100 });
        const plan = f.prompt.planRabbitMirrorPromptDetails(f.settings, type, null, `batch-${type}`,
            { batchIdentity: { mesid: 8, swipeId: 0, sourceHash: 'body' } });
        const result = f.prompt.renderRabbitMirrorPromptPlan(plan);
        assert.equal(result.metadata.faces.length, 5);
        assert.equal((result.prompt.match(/按正文挑签：/g) || []).length, 5);
        assert.equal((result.prompt.match(/复杂交互视觉核心:/g) || []).length, 1, 'HTML faces share one core, not five copies');
        for (const face of result.metadata.faces) {
            assert.ok(face.atmosphereMenu?.length > 1);
            for (const ticket of face.atmosphereMenu) for (const line of ticket.formatLines) {
                assert.ok(result.prompt.includes(line.split('：')[0]), line);
            }
        }
        assert.doesNotMatch(result.executionLock, /选中的签仍须满足：第 \d 面：[\s\S]*展现形式：主/);
    });
}

test('external material is fetched for all frozen tickets, not just the first, and is not executed', async () => {
    const f = await fixture({}, ['7.6', '8.3']);
    const id = 'ext:atmosphere:format:second';
    f.combo.atmosphereMenu[1] = { themeIds: [], formatIds: [id], themeLines: [], formatLines: ['外部原始标题'] };
    const plan = f.prompt.planRabbitMirrorPromptDetails(f.settings, 'normal', null, 'external-menu',
        { pinnedSelections: [{ combo: f.combo }] });
    assert.deepEqual([...plan.selectedExternalIds], [id]);
    const material = { externalId: id, classification: 'format', enabled: true, userConfirmed: true,
        localTitle: '外部唱片机', summary: '曲目与唱针', sourceKeywords: [], rawContent: '<b>唱针</b>{{user}}' };
    const rendered = f.prompt.renderRabbitMirrorPromptPlan(plan, new Map([[id, material]]));
    assert.match(rendered.prompt, /外部唱片机/);
    assert.doesNotMatch(rendered.prompt, /<b>唱针<\/b>/);
    assert.equal(material.rawContent, '<b>唱针</b>{{user}}');
});

test('chosen ticket metadata survives independently of the provisional first ticket', async () => {
    const f = await fixture();
    const choices = await f.runtime.load('src/atmosphereChoice.js');
    const result = choices.applyAtmosphereNotes(f.render().metadata,
        '<toto><rm-ticket>2</rm-ticket><details><summary>十年以后</summary>生活片段</details></toto>');
    assert.deepEqual([...result.formatIds], ['8.3']);
    assert.equal(result.atmosphereChoice, 1);
    assert.deepEqual([...f.combo.formatIds], ['7.6'], 'the frozen draw is never rewritten while rendering');
});

test('mixed HTML and longtext menus both reach the prompt but retain their own presentation mode', async () => {
    const f = await fixture({ rabbitMirrorFaceCount: 2, rabbitMirrorPresentationModes: ['html', 'longtext'],
        lotteryMethod: 'atmosphere', atmosphereStoryPercent: 100 });
    const plan = f.prompt.planRabbitMirrorPromptDetails(f.settings, 'independent', null, 'mixed-menus',
        { batchIdentity: { mesid: 8, swipeId: 0, sourceHash: 'body' } });
    const result = f.prompt.renderRabbitMirrorPromptPlan(plan);
    assert.equal((result.prompt.match(/按正文挑签：/g) || []).length, 2);
    assert.equal(result.metadata.faces[0].presentationMode, 'html');
    assert.equal(result.metadata.faces[1].presentationMode, 'text');
    assert.match(result.executionLock, /第 2 面：长文本/);
    assert.doesNotMatch(result.executionLock, /形式叙述特点：主/);
});

test('IF worldview exemption belongs to the chosen candidate, not to the first ticket', async () => {
    const f = await fixture({ presentationWorldviewLock: true }, ['7.6', '8.3']);
    const { THEMATIC_CATEGORIES } = await f.runtime.load('data/structured/thematicIndex.js');
    const ifTheme = THEMATIC_CATEGORIES.find(item => item.tags.includes('if'));
    f.combo.atmosphereMenu[1].themeIds = [ifTheme.id];
    const result = f.render();
    const worldviewBlock = result.prompt.split(/(?=共用适用规则【)/).find(block => block.includes('世界观载体锁'));
    assert.ok(worldviewBlock);
    assert.match(worldviewBlock, /仅选中签 1 时适用/);
    assert.doesNotMatch(worldviewBlock, /仅选中签 2 时适用/);
});

test('a shared-memory candidate beyond ticket one participates in existing memory preparation', async () => {
    const f = await fixture({ memoryScanEnabled: true, memoryWorldBookEnabled: true, memoryWorldBookId: 'test-worldbook' }, ['7.6', '8.3']);
    f.combo.atmosphereMenu[1].themeIds = ['I.1'];
    const plan = f.prompt.planRabbitMirrorPromptDetails(f.settings, 'normal', null, 'memory-candidate',
        { pinnedSelections: [{ combo: f.combo }] });
    assert.equal(plan.memoryWorldBook.enabled, true);
});

test('optional tagged behavior is conditional on the chosen ticket, not the first candidate', async () => {
    const f = await fixture({ behaviorRuleMode: 'adult-only', behaviorRuleText: 'BEHAVIOR_ONLY_SELECTED' }, ['7.6', '8.3']);
    const { THEMATIC_CATEGORIES } = await f.runtime.load('data/structured/thematicIndex.js');
    f.combo.atmosphereMenu[1].themeIds = [THEMATIC_CATEGORIES.find(item => item.tags.includes('adult')).id];
    const result = f.render('independent');
    assert.match(result.prompt, /创作补充仅在第 1 面选中签 2\s*时适用/);
    assert.equal((result.prompt.match(/BEHAVIOR_ONLY_SELECTED/g) || []).length, 1);
});
