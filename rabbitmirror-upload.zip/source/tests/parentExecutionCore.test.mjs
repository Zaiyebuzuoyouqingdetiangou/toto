import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const originalCore = readFileSync(new URL('./fixtures/complex-core-1.62.31.txt', import.meta.url), 'utf8');
const clone = value => JSON.parse(JSON.stringify(value));
const count = (text, marker) => text.split(marker).length - 1;

async function fixture() {
    const rt = createRuntime(root);
    const builder = await rt.load('src/promptBuilder.js');
    const { defaultSettings } = await rt.load('src/settings.js');
    const { PRESENTATION_FORMATS: formats } = await rt.load('data/structured/presentationIndex.js');
    const { THEMATIC_CATEGORIES: themes } = await rt.load('data/structured/thematicIndex.js');
    const make = (ids, kind = 'ordinary', mode = 'html') => {
        const menu = ids.map(id => ({ themeIds: ['F.0'], formatIds: kind === 'combination'
            ? ['10.2.2', id] : kind === 'scenery' ? ['10.2.2'] : [id] }));
        return { themes: [themes.find(item => item.id === 'F.0')], themeIds: ['F.0'],
            formats: menu[0].formatIds.map(id => formats.find(item => item.id === id)), formatIds: menu[0].formatIds,
            ...(menu.length > 1 ? { atmosphereMenu: menu } : {}), visualSceneryCombination: kind === 'combination',
            forcedVisualScenery: kind !== 'ordinary', requestedPresentationMode: mode,
            presentationMode: mode === 'html' ? 'html' : 'text' };
    };
    const render = (combo, route = 'independent', overrides = {}) => builder.renderRabbitMirrorPromptPlan(
        builder.planRabbitMirrorPromptDetails({ ...clone(defaultSettings), userDirectivePriority: false,
            forceVisualScenery: false, visualSceneryCombination: false, rabbitMirrorFaceCount: 1,
            rabbitMirrorPresentationModes: [combo.requestedPresentationMode], ...overrides },
        route, null, 'parent-and-core-fixture', { pinnedSelections: [{ combo, directive: null }] }));
    return { formats, make, render };
}

for (const route of ['normal', 'independent']) for (const kind of ['ordinary', 'scenery', 'combination']) {
    test(`${route}/${kind}: four HTML tickets receive their scoped core with the form-first compact ordinary core`, async () => {
        const f = await fixture(), combo = f.make(['4.3', '3.9', '3.8', '4.2.1'], kind);
        const frozen = JSON.stringify(combo);
        const out = f.render(combo, route, { enhancedVisualDrawing: true });
        assert.equal(count(out.prompt, originalCore), 0, 'old redundant core is replaced, not appended');
        assert.equal(count(out.prompt, '复杂交互视觉核心:'), kind === 'ordinary' ? 1 : 0);
        assert.equal(count(out.prompt, '媒介内交互构造：'), 1);
        if (kind === 'ordinary') {
            assert.match(out.prompt, /可触摸对象、可保持状态和有意义的可见反馈/);
            assert.match(out.prompt, /先构造展现形式本体/);
            assert.match(out.prompt, /实际使用过程成立的翻阅、档位与折叠照常保留/);
        } else assert.match(out.prompt, kind === 'combination' ? /动态视觉组合【/ : /Visual Scenery 场景优先级/);
        assert.match(out.prompt, /控件数量不限/);
        if (kind === 'combination') assert.match(out.prompt, /交互依抽中的形式自然产生，须真实可触摸并改变内容/);
        assert.equal(out.metadata.atmosphereMenu.length, 4);
        assert.equal(JSON.stringify(combo), frozen);
    });
}

test('the reported TV parent receives real child descriptions, not a repeated heading', async () => {
    const f = await fixture(), combo = f.make(['4.3', '3.9', '3.8', '4.2.1'], 'combination');
    const out = f.render(combo);
    const row = out.executionLock.split('\n').find(line => line.startsWith('候选 1 核对：'));
    assert.match(row, /主形式 4\.3 电视节目/);
    assert.match(row, /演播室/);
    assert.match(row, /子形式.*按正文/);
    assert.match(row, /示例.*不限定/);
    assert.doesNotMatch(row, /电视节目：\* \*\*4\.3 电视节目\*\*/);
    assert.doesNotMatch(row, /田野调查笔记|事故调查报告|综合音讯/);
    assert.ok(row.length < 430, 'parent checks must remain bounded');
    assert.deepEqual(clone(out.metadata.atmosphereMenu), clone(combo.atmosphereMenu));
    assert.match(out.prompt, /4\.3\.6 民生节目/, 'existing mother material stays intact');
});

test('every heading-only builtin parent gets a meaningful, bounded check without changing the draw', async () => {
    const f = await fixture();
    const parents = f.formats.filter(item => !item.summary?.trim()
        && f.formats.some(child => child.id.startsWith(item.id + '.') && child.summary?.trim()));
    assert.equal(parents.length, 22, 'inventory of existing empty parent descriptions');
    for (const parent of parents) {
        const combo = f.make([parent.id]), frozen = JSON.stringify(combo);
        const out = f.render(combo, 'independent', { rawPolicy: 'compact' });
        const row = out.executionLock.split('\n').find(line => line.startsWith('本面短检：'));
        assert.ok(row?.includes(parent.id + ' ' + parent.title), parent.id);
        const children = f.formats.filter(child => child.id.startsWith(parent.id + '.') && child.summary?.trim());
        assert.ok(children.some(child => row.includes(child.summary.slice(0, 20))), parent.id + ': actual child description missing');
        assert.match(row, /子形式.*按正文/);
        assert.ok(row.length < 430, parent.id + ': parent reminder exceeded bound');
        assert.deepEqual(clone(out.metadata.formatIds), [parent.id]);
        assert.equal(JSON.stringify(combo), frozen);
    }
});

test('equal parent checks share one reminder while retaining all four tickets', async () => {
    const f = await fixture(), out = f.render(f.make(['4.3', '4.3', '4.3', '4.3'], 'combination'));
    assert.equal(count(out.executionLock, '候选 1、2、3、4 核对：'), 1);
    assert.equal(count(out.executionLock, '演播室'), 1);
    for (let n = 1; n <= 4; n++) assert.equal(count(out.prompt, `签 ${n}（以下材料仅在选中本签时适用）：`), 1);
});

test('text, longtext and pure order remain outside the common HTML core and parent checklist', async () => {
    const f = await fixture();
    for (const mode of ['text', 'longtext', 'pure']) {
        const combo = f.make(['4.3'], 'ordinary', mode === 'pure' ? 'html' : mode);
        if (mode === 'pure') combo.pureOrder = true;
        const out = f.render(combo);
        assert.doesNotMatch(out.prompt + out.executionLock, /复杂交互视觉核心:|媒介内交互构造：/);
        if (mode !== 'pure') assert.doesNotMatch(out.executionLock, /子形式.*按正文/);
    }
});
