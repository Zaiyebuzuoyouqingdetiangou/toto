import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_REPAIR_BASELINE || fileURLToPath(new URL('..', import.meta.url));
const clone = value => JSON.parse(JSON.stringify(value));

async function fixture() {
    const rt = createRuntime(root);
    const builder = await rt.load('src/promptBuilder.js');
    const { defaultSettings } = await rt.load('src/settings.js');
    const { PRESENTATION_FORMATS } = await rt.load('data/structured/presentationIndex.js');
    const { THEMATIC_CATEGORIES } = await rt.load('data/structured/thematicIndex.js');
    const make = (ids, combination = false, mode = 'html') => ({
        themes: [THEMATIC_CATEGORIES.find(x => x.id === 'F.0')], themeIds: ['F.0'],
        formats: ids.map(id => PRESENTATION_FORMATS.find(x => x.id === id)), formatIds: ids,
        visualSceneryCombination: combination, requestedPresentationMode: mode,
        presentationMode: mode === 'html' ? 'html' : 'text',
    });
    const render = combos => {
        // Multi-face planning intentionally draws a real batch instead of accepting
        // multiple pinnedSelections. Use the public user directive to fix materials.
        const multi = combos.length > 1;
        rt.context.SillyTavern.getContext = () => ({ chatId: 'fixed-roles', chat: [{ is_user: true,
            mes: '兔子镜主题：F.0\n兔子镜展现形式：3.3.1、3.9' }] });
        return builder.renderRabbitMirrorPromptPlan(builder.planRabbitMirrorPromptDetails({
            ...clone(defaultSettings), userDirectivePriority: multi, forceVisualScenery: false,
            visualSceneryCombination: multi && combos[0].visualSceneryCombination, rabbitMirrorFaceCount: combos.length,
            lotteryMethod: 'random', formatsMin: 2, formatsMax: 2,
            rabbitMirrorPresentationModes: combos.map(x => x.requestedPresentationMode),
        }, 'independent', null, 'fixed-roles', multi
            ? { batchIdentity: { mesid: 8, swipeId: 0, sourceHash: 'fixed-roles' } }
            : { pinnedSelections: combos.map(combo => ({ combo, directive: null })) }));
    };
    return { make, render };
}

for (const n of [1, 2]) test(`combined ${n}-face short lock agrees with system form roles without changing selection`, async () => {
    const f = await fixture();
    const combos = Array.from({ length: n }, () => f.make(['10.2.2', '3.3.1', '3.9'], true));
    const frozen = JSON.stringify(combos), out = f.render(combos);
    const rows = out.executionLock.split('\n').filter(x => /^(本轮锁定：|第 \d 面：)/.test(x) && x.includes('展现形式：'));
    assert.equal(rows.length, n);
    for (const row of rows) {
        assert.match(row, /动态视觉基底 10\.2\.2 Visual Scenery/);
        assert.match(row, /主 3\.3\.1 时间坐标 \+ 辅 3\.9 田野调查笔记/);
        assert.doesNotMatch(row, /主 10\.2\.2|辅 3\.3\.1/);
    }
    assert.match(out.prompt, /【3\.3\.1 时间坐标】[^\n]*本轮唯一主展现形式/);
    assert.equal(JSON.stringify(combos), frozen);
    for (const metadata of out.metadata.faces || [out.metadata]) assert.deepEqual(clone(metadata.formatIds), combos[0].formatIds);
});

test('ordinary and standalone scenery keep original primary/secondary form order', async () => {
    const f = await fixture();
    assert.match(f.render([f.make(['3.3.1', '3.9'])]).executionLock, /展现形式：主 3\.3\.1 时间坐标 \+ 辅 3\.9 田野调查笔记/);
    assert.match(f.render([f.make(['10.2.2'])]).executionLock, /展现形式：主 10\.2\.2 Visual Scenery/);
});

test('four combined candidates preserve independent form checks and all candidate material', async () => {
    const f = await fixture(), combo = f.make(['10.2.2', '3.3.1'], true);
    combo.atmosphereMenu = ['3.3.1', '3.9', '4.3', '4.2.1'].map(id => ({ themeIds: ['F.0'], formatIds: ['10.2.2', id] }));
    const before = JSON.stringify(combo), out = f.render([combo]);
    assert.equal(JSON.stringify(combo), before);
    assert.deepEqual(clone(out.metadata.atmosphereMenu), combo.atmosphereMenu);
    assert.doesNotMatch(out.executionLock, /本轮锁定：|主 10\.2\.2|辅 3\.3\.1/);
    for (let i = 0; i < 4; i++) {
        const row = out.executionLock.split('\n').find(x => x.startsWith(`候选 ${i + 1} 核对：`));
        assert.ok(row?.includes('主形式 ' + combo.atmosphereMenu[i].formatIds[1]));
        assert.ok(out.prompt.includes(`签 ${i + 1}（以下材料仅在选中本签时适用）`));
    }
});
