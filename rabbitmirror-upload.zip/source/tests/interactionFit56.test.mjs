import test from 'node:test';
import assert from 'node:assert/strict';
import { INTERACTION_RECIPES } from '../data/structured/interactionIndex.js';
import { PRESENTATION_FORMATS } from '../data/structured/presentationIndex.js';
import {
    eligibleInteractionRecipes, selectInteractionRecipe, selectInteractionRecipes,
    attachInteractionRecipes, buildInteractionRecipeRule, interactionRecipeFields,
} from '../src/interactionRecipes.js';

const scenery = PRESENTATION_FORMATS.find(item => item.id === '10.2.2');
const visualNew = ['key-unlock', 'popup-rise', 'phase-change', 'tear-mend', 'filter-lens',
    'mirror-compare', 'tide-level', 'hourglass-flip', 'jigsaw-place', 'chime-set',
    'flashlight-sweep', 'breath-fog', 'wind-up', 'gear-train'];
const ids = combo => eligibleInteractionRecipes(combo).map(item => item.id);
const fullMedium = { formats: [{ title: INTERACTION_RECIPES.flatMap(item => item.fit).join(' ') }] };
const temporal = { formats: [PRESENTATION_FORMATS.find(item => item.id === '10.2.3')] };
const families = [...new Set(INTERACTION_RECIPES.map(item => item.family))];

function unitFor(combo, id, options = {}) {
    for (let n = 0; n < 2000; n++) {
        const unit = (n + .5) / 2000;
        if (selectInteractionRecipe(combo, { ...options, randomUnit: () => unit })?.id === id) return unit;
    }
    throw new Error('Could not draw ' + id);
}

test('pure scenery admits the 14 new object/space operations as optional candidates', () => {
    const eligible = ids({ formats: [scenery] });
    for (const id of visualNew) assert.ok(eligible.includes(id), id);
    assert.ok(!eligible.includes('footnote-link'));
    assert.ok(!eligible.includes('redaction-lift'));
});

test('scenery identity survives title wording changes without making every visual format a scenery', () => {
    const eligible = ids({ formats: [{ id: '10.2.2', title: '场景', summary: '', tags: [] }] });
    assert.ok(eligible.includes('tide-level') && eligible.includes('wind-up'));
    const letter = { id: 'external:letter', title: '书信', tags: ['visual'] };
    assert.ok(!ids({ formats: [letter] }).includes('tide-level'));
});

test('every new interaction is reachable from at least one real built-in format', () => {
    const reachable = new Set(PRESENTATION_FORMATS.flatMap(format => ids({ formats: [format] })));
    for (const item of INTERACTION_RECIPES.slice(64)) assert.ok(reachable.has(item.id), item.id);
});

test('tide and winding can actually be drawn, not only listed as eligible', () => {
    for (const id of ['tide-level', 'wind-up']) {
        const combo = { formats: [scenery] };
        const unit = unitFor(combo, id);
        assert.equal(selectInteractionRecipes(combo, {
            randomUnit: (() => { let n = 0; return () => n++ ? .999 : unit; })(),
        })[0].id, id);
    }
});

test('dynamic combinations keep the concrete book medium instead of inheriting all scenery operations', () => {
    const book = { id: 'book', title: '书册', summary: '正文翻阅' };
    const expected = ids({ formats: [book] });
    assert.deepEqual(ids({ visualSceneryCombination: true, formats: [scenery, book] }), expected);
    assert.ok(!ids({ formats: [scenery, book] }).includes('wind-up'));
    assert.ok(!ids({ formats: [book] }).includes('tide-level'));
});

test('external water and clock media retain keyword matching', () => {
    assert.ok(ids({ formats: [{ id: 'ext:water', title: '海边潮汐水面' }] }).includes('tide-level'));
    assert.ok(ids({ formats: [{ id: 'ext:clock', title: '八音盒发条' }] }).includes('wind-up'));
});

test('text and pure orders remain outside the interaction lottery', () => {
    for (const flags of [{ presentationMode: 'text' }, { pureOrder: true }]) {
        const combo = { formats: [scenery], ...flags };
        assert.deepEqual(ids(combo), []);
        assert.deepEqual(selectInteractionRecipes(combo), []);
        assert.equal(attachInteractionRecipes(combo).interactionRecipeIds, undefined);
    }
});

test('same-face time comparison chooses a different operation when alternatives are available', () => {
    const firstUnit = unitFor(temporal, 'time-object');
    for (let n = 0; n < 301; n++) {
        const units = [firstUnit, 0, n / 301, .999]; let at = 0;
        const picked = selectInteractionRecipes(temporal, { randomUnit: () => units[at++] ?? .999 });
        assert.equal(picked.length, 2);
        assert.equal(picked[0].id, 'time-object');
        assert.notEqual(picked[1].id, 'before-after');
    }
});

for (const [first, similar] of [
    ['before-after', 'time-object'], ['assemble-parts', 'jigsaw-place'],
    ['light-direction', 'flashlight-sweep'], ['overlay-evidence', 'layer-discovery'],
    ['parallel-compare', 'cross-reading'], ['peel-layer', 'redaction-lift'],
]) test('same-face complementary preference: ' + first + ' / ' + similar, () => {
    for (let n = 0; n < 1001; n++) {
        const next = selectInteractionRecipe(fullMedium, {
            companionIds: [first], excludedFamilies: [INTERACTION_RECIPES.find(item => item.id === first).family],
            randomUnit: () => n / 1001,
        });
        assert.ok(next);
        assert.notEqual(next.id, similar);
    }
});

test('two distinct choice mechanisms remain allowed in the same face', () => {
    const first = unitFor(fullMedium, 'time-object');
    const second = unitFor(fullMedium, 'rotate-object', {
        usedIds: ['time-object'], excludedFamilies: ['sequence'], companionIds: ['time-object'],
    });
    const units = [first, 0, second, .999]; let at = 0;
    const picked = selectInteractionRecipes(fullMedium, { randomUnit: () => units[at++] ?? .999 });
    assert.deepEqual(picked.map(item => item.id), ['time-object', 'rotate-object']);
    assert.ok(picked.every(item => item.mechanism === 'choice'));
});

test('semantic preference softens when the remaining medium has only a similar operation', () => {
    const picked = selectInteractionRecipe({ formats: [{ title: '未识别的媒介' }] }, {
        companionIds: ['cross-reading'], excludedFamilies: families.filter(family => family !== 'comparison'),
        randomUnit: () => 0,
    });
    assert.equal(picked.id, 'parallel-compare');
});

test('companion preference stays local to the face rather than applying to earlier faces', () => {
    const options = { usedIds: ['time-object'] };
    const unit = unitFor(temporal, 'before-after', options);
    assert.equal(selectInteractionRecipe(temporal, { ...options, randomUnit: () => unit }).id, 'before-after');
});

test('frozen old combinations and old ID aliases are preserved', () => {
    const combo = { formats: [scenery], interactionRecipeId: 'time-object', interactionRecipeIds: ['time-object', 'before-after'] };
    const saved = structuredClone(combo);
    attachInteractionRecipes(combo, { randomUnit: () => { throw Error('Frozen selection must not redraw'); } });
    assert.deepEqual(combo, saved);
    assert.deepEqual(interactionRecipeFields({ interactionRecipeId: 'time-object' }), {
        interactionRecipeId: 'time-object', interactionRecipeIds: ['time-object'],
    });
});

test('newly drawn four-ticket menus use the selected ticket scope and preserve held tickets', () => {
    const combo = { atmosphereMenu: [
        { formatIds: ['10.2.2'], formatFullLines: ['动态场景'], interactionRecipeIds: ['time-object', 'before-after'] },
        { formatIds: ['10.2.2'], formatFullLines: ['动态场景'] },
        { formatIds: ['10.2.2', 'book'], formatFullLines: ['动态场景', '书册'] },
        { formatIds: ['book'], formatFullLines: ['书册'] },
    ], visualSceneryCombination: true };
    let i = 0;
    attachInteractionRecipes(combo, { randomUnit: () => [0.6, .999][i++ % 2] });
    assert.deepEqual(combo.atmosphereMenu[0].interactionRecipeIds, ['time-object', 'before-after']);
    assert.equal(combo.interactionRecipeId, undefined);
    for (const ticket of combo.atmosphereMenu) assert.ok(ticket.interactionRecipeIds.length);
    for (const ticket of combo.atmosphereMenu.slice(2)) assert.ok(!ticket.interactionRecipeIds.includes('wind-up'));
});

test('all eight families remain available; no new mechanism or control quota is imposed', () => {
    const picked = selectInteractionRecipes(fullMedium, { randomUnit: () => 0 });
    assert.equal(picked.length, 8);
    assert.equal(new Set(picked.map(item => item.family)).size, 8);
});

test('scenery and pairing metadata never enter compact, balanced or full prompts', () => {
    for (const policy of ['compact', 'balanced', 'full']) {
        const prompt = buildInteractionRecipeRule([{ combo: { interactionRecipeIds: ['tide-level', 'wind-up'] } }], policy);
        assert.match(prompt, /I\.71/);
        assert.match(prompt, /I\.79/);
        assert.doesNotMatch(prompt, /pairingGroup|sceneryCompatible|companionIds|time_comparison/);
    }
});
