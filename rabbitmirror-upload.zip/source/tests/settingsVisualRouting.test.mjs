import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { createRuntime } from './helpers/vmLoader.mjs';

// Execute production routing and jQuery handlers with a detached host double.
// This checks ancestry, node identity and saved settings, not browser layout.
const rootPath = fileURLToPath(new URL('..', import.meta.url));
const read = path => readFileSync(new URL('../' + path, import.meta.url), 'utf8');
const appearance = read('src/settingsAppearance.js');
const ui = read('src/ui.js');
const template = read('src/ui/settingsTemplate.js');
class Node {
    constructor(id = '') { this.id = id; this.children = []; this.handlers = new Map(); this.hidden = false; this.checked = false; this.disabled = false; }
    append(node) {
        if (node.parentElement) node.parentElement.children = node.parentElement.children.filter(n => n !== node);
        node.parentElement = this; this.children.push(node);
    }
    matches() { return false; }
    get visible() { return !this.hidden && (!this.parentElement || this.parentElement.visible); }
    async trigger(event) { return this.handlers.get(event)?.({ target: this, currentTarget: this }); }
}
function section(source, start, end) {
    const a = source.indexOf(start), b = source.indexOf(end, a);
    assert.ok(a >= 0 && b > a, 'production block must exist: ' + start);
    return source.slice(a, b);
}
function route(nodes, page, code, extras = {}) {
    const helpers = section(appearance, '    const move = ', '    const row = ');
    vm.runInNewContext(helpers + code, { get: id => nodes.get(id), body: () => page, ...extras });
}
function parents() {
    const root = new Node(), vault = new Node(), page = new Node();
    vault.hidden = true; root.append(vault); root.append(page);
    return { root, vault, page };
}
function versionNodes(vault) {
    const ids = ['rh_update_version_group', 'rh_current_version', 'rh_update_now', 'rh_version_check', 'rh_update_status', 'rh_update_reload'];
    const nodes = new Map(ids.map(id => [id, new Node(id)]));
    const group = nodes.get('rh_update_version_group');
    for (const id of ids.slice(1, 4)) group.append(nodes.get(id));
    vault.append(group); vault.append(nodes.get('rh_update_status')); vault.append(nodes.get('rh_update_reload'));
    return nodes;
}
test('update page exposes the loaded version and preserves the already-bound inspection button', async () => {
    const { vault, page } = parents(), nodes = versionNodes(vault);
    const check = nodes.get('rh_version_check'); let clicks = 0;
    const version = read('src/ui/runtime.js').match(/const RUNTIME_VERSION = '([^']+)'/)[1];
    for (const n of nodes.values()) n.isConnected = true;
    check.textContent = '版本核对';
    const context = vm.createContext({
        $: selector => ({ on: (event, fn) => nodes.get(selector.slice(1)).handlers.set(event, fn) }),
        document: { getElementById: id => nodes.get(id) }, RUNTIME_VERSION: version,
    });
    const imports = {
        './independentApi/runtime.js': { RUNTIME_VERSION: version },
        './extensionUpdater.js': {
            async inspectRabbitMirrorVersion(info) { clicks++; assert.equal(info.uiVersion, version); assert.equal(info.apiVersion, version); return 'loaded ' + version; },
            formatRabbitMirrorVersionStatus: result => result,
        },
    };
    vm.runInContext(section(ui, "    $('#rh_version_check').on", "    $('#rh_update_now').on"), context, {
        async importModuleDynamically(specifier) {
            const values = imports[specifier.split('?')[0]];
            assert.ok(values, specifier);
            const module = new vm.SyntheticModule(Object.keys(values), function () {
                for (const [key, value] of Object.entries(values)) this.setExport(key, value);
            }, { context });
            await module.link(() => {}); await module.evaluate(); return module;
        },
    });
    assert.equal(clicks, 0, 'binding the button never checks the network automatically');
    const bound = check.handlers.get('click');
    const code = section(appearance, "    move(get('rh_clear_last')", '    const steps=');
    const cleanup = new Node(), diagnostic = new Node();
    nodes.set('rh_clear_last', { parentElement: cleanup }); nodes.set('rh_external_diag_status', { parentElement: diagnostic });
    route(nodes, page, code);
    assert.equal(nodes.get('rh_current_version').visible, true, 'current version must leave the hidden source vault');
    assert.equal(check.visible, true, 'version inspection must leave the hidden source vault');
    assert.equal(check.handlers.get('click'), bound, 'move the bound node without cloning');
    await check.trigger('click'); assert.equal(clicks, 1);
    assert.equal(nodes.get('rh_update_status').textContent, 'loaded ' + version);
    assert.equal(check.disabled, false); assert.equal(check.textContent, '版本核对');
    nodes.get('rh_update_now').disabled = true;
    await check.trigger('click'); assert.equal(clicks, 1, 'do not race an active update');
    assert.match(template, /id="rh_update_version_group"/);
    assert.equal(nodes.get('rh_update_now').visible, true);
    assert.equal(vault.hidden, true);
    assert.equal(page.children.filter(n => n === nodes.get('rh_update_version_group')).length, 1);
    assert.match(template, /id="rh_current_version"[^>]*>[^<]*\$\{RUNTIME_VERSION\}/);
});

function modeNodes(vault) {
    const group = new Node('rh_visual_scenery_modes');
    const inputs = [...template.matchAll(/<input\b[^>]*name="rh_visual_scenery_mode"[^>]*>/g)].map(([tag]) => {
        const n = new Node(tag.match(/id="([^"]+)"/)[1]); n.value = tag.match(/value="([^"]+)"/)[1];
        assert.match(tag, /type="radio"/); group.append(n); return n;
    });
    assert.deepEqual(inputs.map(n => n.value), ['ordinary', 'scenery', 'combined'], 'three mutually exclusive modes must exist');
    const note = new Node('rh_visual_scenery_mode_help'); vault.append(group); vault.append(note);
    return { group, inputs, nodes: new Map([[group.id, group], [note.id, note]]) };
}
function jquery(inputs) {
    return selector => {
        assert.ok(selector.startsWith('input[name="rh_visual_scenery_mode"]'), selector);
        const value = selector.match(/\[value="([^"]+)"\]/)?.[1];
        const selected = inputs.filter(n => !value || n.value === value);
        return {
            prop(key, next) { for (const n of selected) n[key] = next; return this; },
            on(event, fn) { for (const n of selected) n.handlers.set(event, fn); return this; },
        };
    };
}
function initModes(inputs, config, writes) {
    const $ = jquery(inputs);
    vm.runInNewContext(section(ui, '    const visualSceneryMode = ', "    checked('#rh_image_enabled'"), { $, settings: config.getSettings() });
    vm.runInNewContext(section(ui, "    $('input[name=\"rh_visual_scenery_mode\"]').on('change'", "    $('#rh_image_enabled').on"), {
        $, updateSettings: patch => { writes.push(patch); config.updateSettings(patch); },
    });
}
const cases = [
    [false, false, 'ordinary'], [false, true, 'combined'], [true, false, 'scenery'], [true, true, 'combined'],
];
for (const [force, combined, expected] of cases) test(`legacy settings ${force}/${combined} open as ${expected} without rewriting them`, async () => {
    const { vault } = parents(), { inputs } = modeNodes(vault);
    const runtime = createRuntime(rootPath), config = await runtime.load('src/settings.js');
    config.updateSettings({ forceVisualScenery: force, visualSceneryCombination: combined, enhancedVisualDrawing: true });
    const before = JSON.stringify(config.getSettings()), writes = [];
    initModes(inputs, config, writes);
    assert.deepEqual(inputs.filter(n => n.checked).map(n => n.value), [expected]);
    assert.equal(JSON.stringify(config.getSettings()), before, 'opening settings is read-only');
    assert.equal(writes.length, 0);
});

test('moved modes save both old keys atomically, retain enhancement and roundtrip on reopening', async () => {
    const { vault, page } = parents(), { group, inputs, nodes } = modeNodes(vault);
    const runtime = createRuntime(rootPath), config = await runtime.load('src/settings.js');
    config.updateSettings({ enhancedVisualDrawing: true, samplingMode: 'classic' });
    const writes = [];
    initModes(inputs, config, writes);
    const code = section(appearance, "    move('rh_visual_scenery_modes'", "    for(const key of ['visualText'");
    nodes.set('rh_advanced_page_generation', new Node());
    route(nodes, page, code, { withNote: () => {} });
    assert.equal(group.parentElement, page); assert(inputs.every(n => n.visible && !n.disabled));
    const targets = [['combined', true, true], ['scenery', true, false], ['ordinary', false, false]];
    for (const [value, force, combination] of targets) {
        const target = inputs.find(n => n.value === value);
        for (const n of inputs) n.checked = n === target;
        const count = writes.length;
        await target.trigger('change');
        assert.equal(writes.length, count + 1, 'one user choice, one atomic settings update');
        assert.equal(config.getSettings().forceVisualScenery, force);
        assert.equal(config.getSettings().visualSceneryCombination, combination);
        assert.equal(config.getSettings().enhancedVisualDrawing, true);
        assert.equal(config.getSettings().samplingMode, 'classic');
        // SillyTavern persists extension_settings, not the browser's localStorage.
        const reloaded = createRuntime(rootPath);
        const host = await reloaded.load('../../../extensions.js');
        host.extension_settings[config.MODULE_NAME] = JSON.parse(JSON.stringify(config.getSettings()));
        const saved = await reloaded.load('src/settings.js');
        assert.equal(saved.getSettings().forceVisualScenery, force);
        assert.equal(saved.getSettings().visualSceneryCombination, combination);
        const again = modeNodes(new Node()).inputs;
        initModes(again, saved, writes);
        assert.deepEqual(again.filter(n => n.checked).map(n => n.value), [value]);
    }
    assert.doesNotMatch(template, /id="rh_force_visual_scenery"|id="rh_visual_scenery_combination"/);
});

test('the scenery guide targets a real mode choice and retains the separate enhancement control', async () => {
    const runtime = createRuntime(rootPath), help = await runtime.load('src/quickStart.js');
    const entry = help.QUICK_START_GROUPS.flatMap(group => group.items).find(item => item.id === 'scenery');
    assert.equal(entry.target, '#rh_visual_scenery_mode_scenery');
    assert.ok(template.includes('id="' + entry.target.slice(1) + '"'));
    assert.match(template, /id="rh_enhanced_visual_drawing" type="checkbox"/);
});
