import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createDomRuntime } from './helpers/browserDomRuntime.mjs';
import { createRuntime } from './helpers/vmLoader.mjs';

const root=process.env.RM_TEST_SOURCE_ROOT||fileURLToPath(new URL('..',import.meta.url));
const sample=(code='P.100',extra='')=>`<toto data-rabbit-mirror="true"><style>
.stage{--rmc-bg:#f3eee3;--rmc-surface:#fffaf4;--rmc-ink:#34312b;--rmc-object:#b8c2c3;--rmc-object-1:#7c8687;--rmc-object-rgb:184,194,195;background:var(--rmc-bg);color:var(--rmc-ink);position:relative;min-height:300px;}
.glass{background:linear-gradient(130deg,rgba(var(--rmc-object-rgb),.28) 0%,rgba(var(--rmc-object-rgb),.62) 100%);backdrop-filter:blur(7px);border-radius:13px;box-shadow:0 12px 20px #11223333;}
.motion{fill:var(--rmc-object-1);animation:move 2s linear infinite;}
@keyframes move{0%{transform:translateX(0)}100%{transform:translateX(12px)}}
input:checked~.glass .motion{animation-play-state:paused;transform:scale(.8)}
</style><details data-rm-palette="${code}" open><summary>【兔子镜：一巷秋光】</summary><div class="stage"><input type="checkbox" id="go"><label for="go">停下</label><div class="glass"><svg viewBox="0 0 100 100"><path class="motion" d="M0 0h50v50z"/><path fill="#952e28" d="M1 1h2v2z"/></svg><p style="color:var(--rmc-ink);background:var(--rmc-surface);padding:8px">正文内容与人物关系不变</p></div>${extra}</div></details></toto>`;
// Compatibility fixtures model already-saved trial output; production generation is tested separately.
async function runtime(){const rt=await createDomRuntime(root);(await rt.load('src/settings.js')).updateSettings({visualDesignMode:'current'});return {rt,colors:await rt.load('src/roleColorVariants.js'),markup:await rt.load('src/outputSanitizer/markup.js')};}

test('saved ordinary HTML and scenery colour variants keep geometry, alpha, fixed colours and interaction',async t=>{
 const {rt,colors,markup}=await runtime();t.after(()=>rt.close());
 for(const extra of ['', '<div data-rm-visual-scenery="true">动态本体</div>']){
  const out=markup.cleanRabbitMirrorOutput(colors.compileRoleColorVariants(sample('P.100',extra)));
  const host=rt.window.document.createElement('div');host.innerHTML=out;rt.window.document.body.append(host);
  assert.equal(colors.roleColorFaces(host).length,1);assert.equal(host.querySelectorAll('style').length,2);
  const mapped=host.querySelector('[data-rm-color-style="mapped"]'),original=host.querySelector('[data-rm-color-style="original"]');
  assert.equal(original.media,'not all');assert.equal(mapped.media,'all');
  assert.match(mapped.textContent, /\.28\) 0%,rgba\([^)]*,\.62\) 100%/);
  assert.match(mapped.textContent,/backdrop-filter:blur\(7px\)/);
  assert.match(mapped.textContent, /animation:[^;]*2s linear infinite/);
  assert.match(mapped.textContent,/:checked/);assert.match(mapped.textContent,/translateX\(12px\)/);
  assert.equal(host.querySelector('path[fill]').getAttribute('fill'),'#952e28');
  assert.equal(host.querySelector('p').textContent,'正文内容与人物关系不变');
  const p=host.querySelector('p'),checkbox=host.querySelector('input');checkbox.checked=true;
  assert(colors.setRoleColorVariant(host,'original'));assert.equal(checkbox.checked,true);assert.equal(original.media,'all');assert.equal(mapped.media,'not all');
  assert.equal(p.style.color.toLowerCase(),'#34312b');
  assert(colors.setRoleColorVariant(host,'mapped'));assert.equal(checkbox.checked,true);assert.notEqual(p.style.color.toLowerCase(),'#34312b');
  assert.equal(host.querySelector('p'),p,'no replacement of interaction DOM');
  host.remove();
 }
});
test('old, missing/unknown palette and ambiguous variables leave the authored source intact',async t=>{
 const {rt,colors}=await runtime();t.after(()=>rt.close());
 for(const html of ['<details><p>旧作品</p></details>',sample('unknown'),sample().replace('--rmc-ink:#34312b','--rmc-ink:#34312b;--rmc-ink:#454545')])assert.equal(colors.compileRoleColorVariants(html),html);
 assert.equal(colors.compileRoleColorVariants(sample(),{enabled:false}),sample());
});
test('compilation is idempotent and reloaded original/mapped controls remain reversible',async t=>{
 const {rt,colors,markup}=await runtime();t.after(()=>rt.close());
 const a=colors.compileRoleColorVariants(sample());assert.equal(colors.compileRoleColorVariants(a),a);
 const box=rt.window.document.createElement('div');box.innerHTML=markup.cleanRabbitMirrorOutput(a);
 colors.setRoleColorVariant(box,'original');const saved=box.innerHTML;
 const reloaded=rt.window.document.createElement('div');reloaded.innerHTML=markup.cleanRabbitMirrorOutput(saved);
 assert.equal(reloaded.querySelectorAll('style').length,2);assert.equal(reloaded.querySelector('[data-rm-color-style="original"]').media,'all');
 assert(colors.setRoleColorVariant(reloaded,'mapped'));assert.equal(reloaded.querySelector('[data-rm-color-style="original"]').media,'not all');
});
test('security still sanitizes both colour variants and rejects forged colour replay values',async t=>{
 const {rt,colors,markup}=await runtime();t.after(()=>rt.close());
 const template=rt.window.document.createElement('template');
 template.innerHTML=markup.cleanRabbitMirrorOutput(sample('P.100','<script>alert(1)</script><img src="https://evil.invalid/a" onerror="bad()">'));
 assert(markup.sanitizeRabbitMirrorUntrustedTemplate(template));
 assert.equal(template.content.querySelectorAll('script,[onerror],img[src]').length,0);
 const p=template.content.querySelector('p');p.setAttribute('data-rm-color-inline',JSON.stringify([['background','url(https://evil.invalid/a)','#fff',''],['position','fixed','static','']]));
 colors.setRoleColorVariant(template.content,'original');assert(!p.style.cssText.includes('evil'));assert(!p.style.cssText.includes('fixed'));
});
test('mixed faces keep independent codes and visual scanner receives only the active stylesheet',async t=>{
 const {rt,colors,markup}=await runtime();t.after(()=>rt.close());
 const box=rt.window.document.createElement('div');box.innerHTML=markup.cleanRabbitMirrorOutput(colors.compileRoleColorVariants(sample('P.100')+sample('P.200')));
 const faces=colors.roleColorFaces(box);assert.equal(faces.length,2);
 colors.setRoleColorVariant(faces[0],'original');assert.equal(faces[1].getAttribute('data-rm-color-variant'),'mapped');
 const active=colors.activeRoleColorHtml(box.innerHTML);assert.equal((active.match(/<style/g)||[]).length,2);assert(!active.includes('data-rm-color-inline='));
 const evidence=colors.roleColorEvidence(box.innerHTML);assert.equal(evidence.faces.length,2);assert.equal((evidence.originalHtml.match(/<style/g)||[]).length,2);
});
test('all built-in mapped base text pairs meet 4.5 without altering the reference palette data',async t=>{
 const {rt,colors}=await runtime();t.after(()=>rt.close());
 const {GENERATION_PALETTE_INDEX}=await rt.load('data/structured/generationPaletteIndex.js');
 for(const index of GENERATION_PALETTE_INDEX){const p=colors.mappedRoleColors(index.code);for(const [fg,bg] of [['ink','bg'],['ink','surface'],['muted','bg'],['muted','surface'],['on-accent','accent'],['on-object','object'],['on-companion','companion']])assert(colors.roleColorContrast(p[fg],p[bg])>=4.5,`${index.code} ${fg}/${bg}`);}
});
for(const route of ['normal','independent'])for(const mode of ['ordinary','scenery','combination'])test(`${route}/${mode}: retired post-colour flag cannot restore a contract; other rules stay intact`,async()=>{
 const rt=createRuntime(root),builder=await rt.load('src/promptBuilder.js'),settings=await rt.load('src/settings.js');
 const base={...JSON.parse(JSON.stringify(settings.defaultSettings)), visualDesignMode:'current',postGenerationRecolor:false,lotteryMethod:'atmosphere',rabbitMirrorFaceCount:1,rabbitMirrorPresentationModes:['html'],forceVisualScenery:mode==='scenery',visualSceneryCombination:mode==='combination'};
 const plan=builder.planRabbitMirrorPromptDetails(base,route,null,'colours');const before=builder.renderRabbitMirrorPromptPlan(plan);
 const on=builder.buildRabbitMirrorPromptDetails({...base,postGenerationRecolor:true},route,null,'colours');
 for(const out of [before,on]){assert.doesNotMatch(out.prompt,/生成配色参考【|生成后换色【|data-rm-palette/);assert.equal(out.metadata.atmosphereMenu.length,4);}
 assert.match(on.prompt,/展现形式落地/);assert.match(on.prompt,/交互构造库/);assert.match(on.executionLock,/本面短检/);
});

test('trusted face and chosen ticket override a wrong model palette; missing choice and text remain original',async t=>{
 const {rt,colors}=await runtime();t.after(()=>rt.close());
 const {GENERATION_PALETTE_INDEX:index}=await rt.load('data/structured/generationPaletteIndex.js');
 const [a,b]=index;const metadata={presentationMode:'html',paletteRecipeId:a.id};
 const bound=colors.bindRolePaletteCode(sample('P.516'),metadata);
 assert.match(bound,new RegExp(`data-rm-palette="${a.code}"`));
 const menu={presentationMode:'html',atmosphereMenu:[{paletteRecipeId:a.id},{paletteRecipeId:b.id}]};
 assert.match(colors.bindRolePaletteCode(sample(),menu,{choice:1}),new RegExp(`data-rm-palette="${b.code}"`));
 for(const meta of [menu,{...metadata,presentationMode:'text'},{...metadata,pureOrder:true}]){
  const raw=colors.bindRolePaletteCode(sample(),meta);assert(!raw.includes('data-rm-palette='));assert(!colors.compileRoleColorVariants(raw).includes('data-rm-color-variant='));
 }
});

test('independent ready, stored, swipe and remount paths retain both colour styles and state selectors',async t=>{
 const {rt,colors}=await runtime();t.after(()=>rt.close());
 const geometry=await rt.load('src/independentApi/geometry.js'),swipe=await rt.load('src/independentApi/faceSwipe.js');
 const ready=geometry.prepareIndependentReadyHtml(colors.compileRoleColorVariants(sample()));
 const stages=[ready,geometry.scrubIndependentInteractionState(ready,ready),swipe.scrubSwipeDetailsHtml(ready)];
 stages.push(geometry.prepareIndependentReadyHtml(stages[1]));
 for(const html of stages){
  const box=rt.window.document.createElement('div');box.innerHTML=html;
  assert.equal(colors.roleColorFaces(box).length,1);assert.equal(box.querySelectorAll('[data-rm-color-style]').length,2);
  assert.match(box.querySelector('[data-rm-color-style="mapped"]').textContent,/:checked/);
  colors.setRoleColorVariant(box,'original');assert.equal(box.querySelector('p').style.color.toLowerCase(),'#34312b');
 }
});

test('readability observation composites a translucent solid background, reports low contrast and leaves complex or hidden states unclaimed',async t=>{
 const {rt,colors,markup}=await runtime();t.after(()=>rt.close());
 const box=rt.window.document.createElement('div');box.innerHTML=markup.cleanRabbitMirrorOutput(colors.compileRoleColorVariants(sample()));rt.window.document.body.append(box);
 const stage=box.querySelector('.stage')||box.querySelector('input').parentElement;stage.innerHTML=`<p id="good" style="color:#111111;background:rgba(255,255,255,.5);background-image:none">可读</p><p style="color:#eeeeee;background:#ffffff;background-image:none">低对比</p><p style="color:#ffffff;background:linear-gradient(#000,#fff)">未知</p><p style="display:none;color:#000;background:#fff">隐藏</p>`;
 stage.style.backgroundColor='#ffffff';stage.style.backgroundImage='none';
 const before=box.innerHTML,result=colors.inspectRoleColorReadability(box);
 assert.equal(result.checked,2);assert.equal(result.lowContrast,1);assert.equal(result.unverified,1);assert.equal(result.hidden,1);assert.equal(box.innerHTML,before);
 box.querySelector('details').open=false;const closed=colors.inspectRoleColorReadability(box);assert.equal(closed.checked,0);assert.equal(closed.hidden,4);
});

test('inactive originals cannot affect actual palette or visual recognition; zero extra randomness',async t=>{
 const {rt,colors,markup}=await runtime();t.after(()=>rt.close());
 const scanner=await rt.load('src/visualScanner.js');const html=markup.cleanRabbitMirrorOutput(colors.compileRoleColorVariants(sample()));
 const full=scanner.scanRabbitMirrorHtml(html),active=scanner.scanRabbitMirrorHtml(colors.activeRoleColorHtml(html));
 assert.deepEqual(JSON.parse(JSON.stringify(full)),JSON.parse(JSON.stringify(active)));assert(full.paletteFingerprint);
 const oldMath=rt.context.Math;rt.context.Math=Object.create(oldMath);rt.context.Math.random=()=>{throw new Error('Unexpected sampling');};
 const a=colors.compileRoleColorVariants(sample()),b=colors.compileRoleColorVariants(sample());assert.equal(a,b);assert(a.includes('data-rm-color-variant'));rt.context.Math=oldMath;
});

test('optional style copies cannot push a valid source over the existing CSS budget',async t=>{
 const {rt,colors,markup}=await runtime();t.after(()=>rt.close());
 const html=sample().replace('</style>',Array.from({length:800},(_,i)=>`.layer${i}{color:var(--rmc-ink)}`).join('')+'</style>');
 const before=rt.window.document.createElement('template');before.innerHTML=html;
 assert(markup.validateRabbitMirrorTemplateStructuralBudget(before));
 const out=colors.compileRoleColorVariants(html,{acceptTemplate:markup.validateRabbitMirrorTemplateStructuralBudget});
 assert.equal(out,html);assert.doesNotMatch(out,/data-rm-color-variant/);
 const final=rt.window.document.createElement('template');final.innerHTML=markup.cleanRabbitMirrorOutput(out);
 assert(markup.sanitizeRabbitMirrorUntrustedTemplate(final));assert(final.content.querySelector('p'));
});

test('ordinary all-inline HTML and SVG presentation attributes switch without a stylesheet',async t=>{
 const {rt,colors,markup}=await runtime();t.after(()=>rt.close());
 const html=`<toto data-rabbit-mirror="true"><details open data-rm-palette="P.100" style="--rmc-bg:#fafafa;--rmc-ink:#123456;background:var(--rmc-bg);color:var(--rmc-ink)"><summary>【兔子镜：普通物件】</summary><svg><path fill="var(--rmc-ink)" d="M0 0h50v50z"/></svg><p style="border:1px solid var(--rmc-ink)">原生纸面</p></details></toto>`;
 const box=rt.window.document.createElement('div');box.innerHTML=markup.cleanRabbitMirrorOutput(colors.compileRoleColorVariants(html));
 assert.equal(colors.roleColorFaces(box).length,1);assert.equal(box.querySelectorAll('style').length,0);
 const path=box.querySelector('path');assert.notEqual(path.getAttribute('fill'),'#123456');
 colors.setRoleColorVariant(box,'original');assert.equal(path.getAttribute('fill'),'#123456');assert.equal(box.querySelector('details').style.background,'#fafafa');
 const unavailable=html.replace('--rmc-ink:#123456','--rmc-ink:hsl(200 50% 20%)');assert.equal(colors.compileRoleColorVariants(unavailable),unavailable);
});

test('CSS scope expansion also falls back to original instead of rejecting the optional doubled styles',async t=>{
 const {rt,colors,markup}=await runtime();t.after(()=>rt.close());
 const html=sample().replace('</style>',Array.from({length:600},(_,i)=>`.paint${i}_${'x'.repeat(65)}{color:var(--rmc-ink)}`).join('')+'</style>');
 const compiled=colors.compileRoleColorVariants(html,{acceptTemplate:markup.validateRabbitMirrorTemplateStructuralBudget});
 assert.match(compiled,/data-rm-color-variant="mapped"/,'unscoped variants initially fit');
 const out=markup.cleanRabbitMirrorOutput(html);assert.doesNotMatch(out,/data-rm-color-variant=/);
 const template=rt.window.document.createElement('template');template.innerHTML=out;
 assert(markup.sanitizeRabbitMirrorUntrustedTemplate(template));assert(template.content.querySelector('p'));
 assert.equal(template.content.querySelectorAll('style').length,1);
});
