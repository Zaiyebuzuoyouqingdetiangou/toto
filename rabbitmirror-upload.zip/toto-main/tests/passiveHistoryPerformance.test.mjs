import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import test from 'node:test';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=process.env.RM_PERF_FIX_ROOT||fileURLToPath(new URL('..',import.meta.url));
function fn(file,name){
 const src=fs.readFileSync(path.join(root,'src',file),'utf8').replace(/\r\n/g,'\n');
 const start=src.indexOf('function '+name+'(');assert.ok(start>=0,name);
 return src.slice(start,src.indexOf('\n}',start)+2);
}
function fixture(){
 const face={},textRoot={},host={isConnected:true,dataset:{rmSource:'independent',rmState:'ready'},__rabbitMirrorIndependentSource:'Saved HTML'};
 const element={querySelector:()=>textRoot},ctx={chatId:'same',chat:[{is_user:false,mes:'body',swipe_id:0,extra:{}}]};
 let currentElement=element,currentHost=host,currentFace=face;
 const listeners=new Map(),timers=[],batches=[];
 const chat={addEventListener:(n,f)=>listeners.set(n,f)};
 const sandbox={ctx,runtimeConfigSequence:1,STARTUP_SYNC_IMMEDIATE_MESSAGES:6,
  currentRuntime:()=>true,clearStartupHistoryLazySync(){},isRabbitMirrorManagedChatSurface:()=>false,
  document:{querySelector:()=>chat},getContext:()=>ctx,
  viewportMessageIndices:()=>[0],syncMessageBatch:ids=>batches.push([...ids]),
  messageElement:()=>currentElement,externalHosts:()=>currentHost?[currentHost]:[],
  isRabbitMirrorEligibleAssistantMessage:m=>!!m&&!m.is_user,
  externalFaceDetails:()=>[currentFace],chatKey:c=>c.chatId,swipeId:m=>m.swipe_id||0,
  setTimeout:f=>timers.push(f),startupHistoryFallbackRoot:null,startupHistoryFallbackHandler:null};
 const context=vm.createContext(sandbox);
 for(const name of ['restoredHistoryProbeState','sameRestoredHistoryProbe','installStartupHistoryLazySync'])vm.runInContext(fn('independentApi.js',name),context);
 const drain=()=>{while(timers.length)timers.shift()();};
 context.installStartupHistoryLazySync();drain();
 return {ctx,host,element,textRoot,batches,context,drain,
  probe(){listeners.get('scroll')();drain();},
  replaceElement(){currentElement={querySelector:()=>({})};},
  replaceHost(){currentHost={...host,dataset:{...host.dataset}};},
  replaceFace(){currentFace={};},removeHost(){currentHost=null;},
 };
}
test('passive history: repeated unchanged probes do not rerun ready restoration',()=>{
 const f=fixture();assert.equal(f.batches.length,1);
 for(let i=0;i<40;i++)f.probe();assert.equal(f.batches.length,1);
});
for(const kind of ['source','display','reasoning','swipe','message','chat','chatKey','element','host','face','textRoot','savedHtml','missingHost','loading']){
 test('passive history: changed '+kind+' remains eligible for restoration',()=>{
  const f=fixture();const m=f.ctx.chat[0];
  if(kind==='source')m.mes+=' appended';
  if(kind==='display')m.extra.display_text='new display';
  if(kind==='reasoning')m.extra.reasoning='new reasoning';
  if(kind==='swipe')m.swipe_id++;
  if(kind==='message')f.ctx.chat[0]={...m};
  if(kind==='chat')f.ctx.chat=f.ctx.chat.slice();
  if(kind==='chatKey')f.ctx.chatId='other';
  if(kind==='element')f.replaceElement();
  if(kind==='host')f.replaceHost();
  if(kind==='face')f.replaceFace();
  if(kind==='textRoot')f.element.querySelector=()=>({});
  if(kind==='savedHtml')f.host.__rabbitMirrorIndependentSource='Changed HTML';
  if(kind==='missingHost')f.removeHost();
  if(kind==='loading')f.host.dataset.rmState='loading';
  f.probe();assert.equal(f.batches.length,2,kind);
 });
}
test('passive history: obsolete runtime callback cannot restore a new session',()=>{
 const f=fixture();f.context.runtimeConfigSequence=2;f.probe();assert.equal(f.batches.length,1);
});
test('passive history: removed or replaced tool DOM invalidates ready probe cache',()=>{
 const f=fixture();const tool={};f.host.querySelectorAll=()=>[tool];f.probe();
 const previous=f.batches.length;f.probe();assert.equal(f.batches.length,previous);
 f.host.querySelectorAll=()=>[{}];f.probe();assert.equal(f.batches.length,previous+1);
 f.host.querySelectorAll=()=>[];f.probe();assert.equal(f.batches.length,previous+2);
});
test('passive history: user messages never cause a restoration batch',()=>{
 const f=fixture();f.ctx.chat[0].is_user=true;f.probe();assert.equal(f.batches.length,1);
});
test('tools: scoped feedback refresh leaves unrelated mirrors untouched; explicit global refresh still works',()=>{
 const make=()=>({writes:0,set title(v){this.writes++;},setAttribute(){this.writes++;},parentElement:null});
 const own=make(),other=make(),document={querySelectorAll:()=>[own,other]},scope={querySelectorAll:()=>[own]};
 const c=vm.createContext({document,FEEDBACK_CAT_ATTR:'data-feedback',TOOL_ENTRY_HOST_ATTR:'data-tools',
  feedbackCatButtonTitle:()=>'title',normalizeRabbitMirrorToolButton(){},normalizeRabbitMirrorToolHost(){}});
 vm.runInContext(fn('outputSanitizer.js','updateFeedbackCatButtonTitles'),c);
 c.updateFeedbackCatButtonTitles(scope);assert.equal(own.writes,2);assert.equal(other.writes,0);
 c.updateFeedbackCatButtonTitles();assert.equal(own.writes,4);assert.equal(other.writes,2);
});
test('tools: actual install scope passes only its own scope to feedback refresh',()=>{
 const scope={querySelectorAll(){}};let refreshed;
 const c=vm.createContext({isCurrentRuntime:()=>true,isMaintenanceRabbitEnabled:()=>false,isFeedbackCatEnabled:()=>true,
  getRenderedRabbitMirrorInteractionRoots:()=>[],updateFeedbackCatButtonTitles:value=>{refreshed=value;}});
 vm.runInContext(fn('outputSanitizer.js','installMaintenanceRabbitsInScopeCore'),c);
 c.installMaintenanceRabbitsInScopeCore(scope);assert.equal(refreshed,scope);
});
