import { readFileSync } from 'node:fs';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';

// Read-only production-source probe. No uploaded source or persistence file is written.
// The real syncMessages function and named helpers are compiled verbatim in a VM.
// Rendering and the absent host are explicit fixture adapters listed in the output.
const sourceFile = process.env.RABBIT_MIRROR_TEST_SOURCE || fileURLToPath(new URL('../src/independentApi.js',import.meta.url));
const source = readFileSync(sourceFile,'utf8');
const sha256 = value => createHash('sha256').update(value).digest('hex');
const productionFunctions = [
  'currentRuntime', 'byteLength', 'independentRecordWithinBudget', 'warnStorageTrimmed',
  'readStore', 'compactOutputStore', 'writeStore', 'emptyHistoryStore', 'readHistoryStore',
  'compactHistoryStore', 'writeHistoryStore', 'normalizeHistoryEntry', 'appendHistoryEntry',
  'historyEntriesForSlot', 'emptyChatOutputMetadata', 'chatMetadataObject', 'compactExternalSourceNote',
  'compactChatPersistedRecord', 'normalizeChatOutputMetadata', 'readChatOutputMetadata',
  'saveChatOutputMetadata', 'chatOwnerKey', 'parseChatOwnerKey', 'persistedOwnerForMessage',
  'writePersistedOwner', 'chatPersistenceSlot', 'mergeChatOutputsIntoLocalStore',
  'migrateLegacyLocalOutputsToChatMetadata', 'synchronizeIndependentChatPersistence',
  'readOwnerLockStore', 'writeOwnerLockStore', 'ownerLockStoreForAccess', 'ownerLockForBase',
  'setOwnerLockForBase', 'clearOwnerLockForBase', 'lockedIndependentRecordForBase',
  'hashText', 'getContext', 'legacyChatKey', 'chatKey', 'swipeId', 'messageBaseSlotKey',
  'messageSlotKey', 'legacyMessageSourceFingerprints', 'legacyMessageSlotKeys', 'recordKey',
  'baseSlotOf', 'slotSearchKeys', 'findSavedRecord', 'saveRecordForSlot',
  'isRabbitMirrorToolResultMessage', 'isRabbitMirrorEligibleAssistantMessage', 'assistantMessages',
  'messageBodyFingerprint', 'messageReasoningFingerprint', 'visibleDisplayTextOf',
  'messageDisplayFingerprint', 'messageSourceFingerprint', 'savedRecordMatchesObserved',
  'observeMessageSourceRevision', 'externalFaceDetails', 'copyIndependentReplacementReceipt',
  'completeReadyFaceDetails', 'readyDetailsFromHost', 'mountedIndependentReadyHostMatchesObserved',
  'mountedIndependentReadyHostSharesStableOwner', 'hasExplicitSourceReplacementEvidence',
  'readyRecordFromHost', 'usableReadyDetails', 'independentStoredHtmlLightRestorable',
  'independentStoredHtmlRestorable', 'historyRecoveryForObserved', 'recoverSavedRecord',
  'collapseDuplicateIdentityHosts', 'parseMessageIndexFromOwnerKey', 'runtimeMode',
  'passiveObservedIdentity', 'automaticCutoverVersionToken', 'suppressesAutomaticGeneration',
  'hasExistingFollowRabbitMirror', 'passiveIndependentFailureForIdentity',
  'activeIndependentFlightForBase', 'cancelFlightsForSlot', 'cancelSupersededFlightsForBase',
  'syncMessages',
];
const productionConstants = [
  'RUNTIME_VERSION', 'STORE_KEY', 'OWNER_LOCK_STORE_KEY', 'HISTORY_STORE_KEY',
  'CHAT_OUTPUT_METADATA_KEY', 'CHAT_OUTPUT_METADATA_SCHEMA', 'OUTPUT_STORE_BUDGET_BYTES',
  'HISTORY_STORE_BUDGET_BYTES', 'INDEPENDENT_HTML_BUDGET_BYTES', 'INDEPENDENT_RECORD_BUDGET_BYTES',
  'SOURCE_ATTR', 'DEFERRED_INTERACTION_RESCUE_ATTR',
];
for(const name of ['beginHostWorkTiming','syncMessagesCore','copyIndependentOwnerLineage','independentLineageOriginSlot','independentLineageMatchesObserved','bindIndependentRecordContinuity','updateIndependentRecordContinuity','revokeIndependentRecordContinuity']) {
 if(new RegExp(`^(?:async )?function ${name}\\(`,'m').test(source)) productionFunctions.push(name);
}
for(const name of ['INDEPENDENT_OWNER_OBSERVATION','independentRecordContinuity']) {
 if(new RegExp(`^const ${name}\\s*=`,'m').test(source)) productionConstants.push(name);
}

function extractFunction(name) {
  const pattern = new RegExp(`^(?:async )?function ${name}\\(`, 'm');
  const match = pattern.exec(source);
  assert.ok(match, `Production function missing: ${name}`);
  const tail = source.slice(match.index);
  const lines = tail.split(/(?<=\n)/);
  let candidate = '';
  for (let i = 0; i < lines.length; i++) {
    candidate += lines[i];
    if (i !== 0 && !/^}/.test(lines[i])) continue;
    try { new vm.Script(`(${candidate})`); }
    catch { continue; }
    return { name, code: candidate.trimEnd(), line: source.slice(0, match.index).split('\n').length };
  }
  throw new Error(`Cannot extract complete production function: ${name}`);
}
const extracted = productionFunctions.map(extractFunction);
const declarations = productionConstants.map(name => {
  const declaration = source.match(new RegExp(`^const ${name}\\s*=[^\\r\\n]+`, 'm'))?.[0];
  assert.ok(declaration, `Production constant missing: ${name}`);
  return declaration;
}).join('\n');
const fixtureHtml = '<details><summary>【兔子镜：审计样本】</summary><p>已完成且应可恢复的结果 A。</p></details>';
const originalBody = '正文 A：窗外下着雨。';
const driftedBody = '正文 A：窗外正下着雨。';

function makeDetails(html) {
  assert.match(html, /^<details><summary>[\s\S]*<\/summary><p>[\s\S]*<\/p><\/details>$/);
  const summary = { tagName: 'SUMMARY', nodeType: 1, textContent: html.match(/<summary>(.*?)<\/summary>/s)[1] };
  const body = { tagName: 'P', nodeType: 1, textContent: html.match(/<p>(.*?)<\/p>/s)[1], hidden: false, getAttribute: () => null, children: [] };
  return {
    tagName: 'DETAILS', nodeType: 1, outerHTML: html, innerHTML: html.slice(9, -10),
    childNodes: [summary, body], children: [summary, body], isConnected: true,
    classList: { contains: () => false }, hasAttribute: () => false,
    querySelector(selector) { return selector === ':scope > summary' ? summary : null; },
    querySelectorAll: () => [], closest: () => null,
    cloneNode() { return makeDetails(html); }, removeAttribute() {},
  };
}

function makeRuntime({ persisted = new Map(), ctx, mutation = false } = {}) {
  ctx ||= { chatMetadata: { chat_id: 'audit-chat-A' }, chat: [{ mes: originalBody, swipe_id: 0, is_user: false, extra: {} }] };
  const rows = [{ hosts: [], querySelectorAll: () => [] }];
  const calls = { rendering: 0, refresh: 0, placement: 0, network: 0 };
  const storage = {
    getItem(key) { return persisted.get(String(key)) ?? null; },
    setItem(key, value) { persisted.set(String(key), String(value)); },
    removeItem(key) { persisted.delete(String(key)); },
  };
  const reject = name => () => { throw new Error(`Unexpected fixture path: ${name}`); };
  const hostAdapter = (el, key, html, state, sourceKind, sourceHash) => {
    assert.equal(state, 'ready', 'Only saved READY hydration is in this fixture');
    assert.equal(html, fixtureHtml);
    calls.rendering++;
    let host = el.hosts.find(h => h.isConnected);
    if (!host) {
      host = {
        dataset: {}, hidden: false, isConnected: true, children: [makeDetails(html)],
        __rabbitMirrorIndependentSource: html,
        querySelector(selector) { return selector.startsWith(':scope > details') ? this.children[0] : null; },
        remove() { this.isConnected = false; el.hosts = el.hosts.filter(item => item !== this); },
      };
      el.hosts.push(host);
    }
    const parts = key.split(':');
    Object.assign(host.dataset, {
      rmState: state, rmSource: sourceKind, rmKey: key, rmSourceHash: sourceHash,
      rmOwnerChat: parts.slice(0, -3).join(':'), rmOwnerMesid: parts.at(-3), rmOwnerSwipe: parts.at(-2),
    });
    return host;
  };
  const flightMap = new Map();
  class FixedDate extends Date {
    constructor(...args) { super(...(args.length ? args : [1789800000000])); }
    static now() { return 1789800000000; }
  }
  const sandbox = {
    console, TextEncoder, Map, Set, Date: FixedDate, Node: { TEXT_NODE: 3, ELEMENT_NODE: 1 },
    localStorage: storage, SillyTavern: { getContext: () => ctx },
    getSettings: () => ({ enabled: true, autoRabbitMirrorInjection: true, generationSource: 'independent', independentApiModel: 'fixture' }),
    // Host chat-key resolution is outside this module; model its stable chat ID.
    getCurrentChatKey: () => ctx.chatMetadata.chat_id,
    messageElement: index => rows[index] || null,
    externalHosts: el => el.hosts.filter(host => host.isConnected),
    externalHostsByIdentityKey: (key, origin, chat) => rows.flatMap(row => row.hosts).filter(host => host.isConnected && host.dataset.rmKey === key && host.dataset.rmSource === origin && host.dataset.rmOwnerChat === chat),
    ensureExternalUi: hostAdapter,
    rebuildCollapsedReadyHost: (_el, host) => host,
    refreshExistingExternalDetails() { calls.refresh++; },
    placeExternalHost() { calls.placement++; },
    clearExternalHostFreshSourceState(host) { delete host.dataset.rmAwaitingFreshSource; delete host.dataset.rmFreshSourceStatus; },
    restoreFollowMirrorFromMessageSource() {}, restoreFollowInline() {}, removeIndependentInlineDuplicates() {},
    consumeIndependentDisplayModeChange: () => false, hostGenerationLooksActive: () => false,
    automaticFailureStopFor: () => null, globalFlights: () => flightMap,
    operationEpochForBase: () => 1,
    assertIndependentMarkupComplexity(html) { assert.equal(html, fixtureHtml); },
    hasMultifaceMarkup(html) { assert.equal(html, fixtureHtml); return false; },
    interactionStatePollutionScore(html) { assert.equal(html, fixtureHtml); return 0; },
    stripIndependentTransientLayoutArtifacts() {},
    normalizeSavedInteractionRecord: reject('interaction normalization'),
    abortFlight: reject('abortFlight'), automaticFlightStillOwnsBaseOperation: reject('active flight'),
    restorePassiveIndependentFailure: reject('passive error'), ensureReplyGenerationPlaceholder: reject('generation placeholder'),
    currentGenerationIdentity: reject('generation identity'), renderAutomaticFailureStop: reject('failure rendering'),
    parseMultifaceOutput: reject('multiple faces'), serializeExternalFaceDetails: reject('multiple faces'),
    fetch() { calls.network++; throw new Error('Network is forbidden'); },
    document: {
      createElement(name) {
        assert.equal(name, 'template');
        return { _html: '', set innerHTML(value) { this._html = value; }, get content() { return { querySelector: name => name === 'details' ? makeDetails(this._html) : null }; } };
      },
    },
  };
  const context = vm.createContext(sandbox);
  let functionCode = extracted.map(item => item.code).join('\n\n');
  if (mutation) {
    // Sensitivity-only mutant: removes cold ownership fingerprint comparison.
    // It changes an in-memory string, never sourceFile or the uploaded ZIP.
    const old = 'function savedRecordMatchesObserved(saved,observed){';
    assert.equal(functionCode.split(old).length, 2);
    functionCode = functionCode.replace(old, old + '\n if(saved?.html && observed) return true; // audit sensitivity mutant');
  }
  vm.runInContext(`${declarations}\nlet independentRecordContinuitySequence=0,syncRunning=false,storageWarningShown=false,activeOwnerLockBatch=null,activeOwnerLockBatchDirty=false,activeRestorableHtmlCache=null;\nconst messageSourceRevisions=new Map(),automaticGenerationCutovers=new Map(),automaticFailureStops=new Map(),pending=new Map();\nglobalThis.__rabbitMirrorRuntimeVersion=RUNTIME_VERSION;\n${functionCode}`, context, { filename: sourceFile + (mutation ? '#in-memory-mutant' : '#extracted') });
  const run = code => vm.runInContext(code, context);
  return {
    run, ctx, persisted, calls, rows,
    sync() { run('syncMessages()'); },
    visibleReady() { return rows.flatMap(row => row.hosts).filter(host => host.isConnected && !host.hidden && host.dataset.rmState === 'ready' && host.dataset.rmAwaitingFreshSource !== 'true').length; },
    cold(nextCtx = structuredClone(ctx), coldMutation = mutation) { return makeRuntime({ persisted: new Map(persisted), ctx: nextCtx, mutation: coldMutation }); },
    persistenceSnapshot() { return { local: Object.fromEntries(persisted), metadata: structuredClone(ctx.chatMetadata) }; },
    seed() {
      context.fixtureHtml = fixtureHtml;
      run(`const fixtureMsg=getContext().chat[0]; const fixtureObserved=observeMessageSourceRevision(getContext(),0,fixtureMsg); const fixtureRecord={html:fixtureHtml,sourceHash:fixtureObserved.sourceHash,bodyHash:fixtureObserved.bodyHash,displayHash:fixtureObserved.displayHash,reasoningHash:'',ts:Date.now(),runtime:RUNTIME_VERSION}; const fixtureStore=readStore(); saveRecordForSlot(fixtureStore,fixtureObserved.slot,fixtureRecord); writeStore(fixtureStore); writePersistedOwner(getContext(),0,fixtureMsg,fixtureRecord); setOwnerLockForBase(messageBaseSlotKey(getContext(),0,fixtureMsg),fixtureObserved.slot,fixtureObserved.sourceHash);`);
    },
  };
}


const check=(name,fn)=>test('independent persistence: '+name,fn);
function fresh() { const runtime=makeRuntime(); runtime.seed(); runtime.sync(); assert.equal(runtime.visibleReady(),1,'Seeded persisted READY must hydrate'); return runtime; }
check('paid-ready-source-postprocessing-then-cold-return', () => {
 const warm=fresh(); warm.ctx.chat[0].mes=driftedBody; warm.sync();
 assert.equal(warm.visibleReady(),1,'Existing completed mirror must stay visible');
 const cold=warm.cold(); cold.sync();
 assert.equal(cold.visibleReady(),1,'Already-paid same-owner output must survive witnessed passive正文 postprocessing and cold return');
 assert.equal(warm.calls.network+cold.calls.network,0,'Restoring a paid result must send zero requests');
 assert.equal(cold.rows[0].hosts[0].__rabbitMirrorIndependentSource,fixtureHtml,'Restore exact completed payload');
 return {warmReady:1,coldReady:1,networkCalls:0};
});
check('twice-postprocessed-ready-local-only-cold-return', () => {
 const warm=fresh(); warm.ctx.chat[0].mes=driftedBody; warm.sync();
 warm.ctx.chat[0].mes+='再一次已见证的正文后处理。'; warm.sync();
 const next=structuredClone(warm.ctx); next.chatMetadata={chat_id:'audit-chat-A'};
 const cold=warm.cold(next); cold.sync();
 assert.equal(cold.visibleReady(),1,'Local persistence must carry the latest witnessed body lineage');
 assert.equal(cold.calls.network,0); return {coldReady:1,networkCalls:0};
});
check('postprocessed-ready-metadata-only-cold-return', () => {
 const warm=fresh(); warm.ctx.chat[0].mes=driftedBody; warm.sync();
 const cold=makeRuntime({persisted:new Map(),ctx:structuredClone(warm.ctx)}); cold.sync();
 assert.equal(cold.visibleReady(),1,'Host metadata compaction must preserve witnessed body lineage');
 assert.equal(cold.calls.network,0); return {coldReady:1,networkCalls:0};
});
check('unchanged-ready-cold-return', () => {
 const warm=fresh(), cold=warm.cold(); cold.sync(); assert.equal(cold.visibleReady(),1); assert.equal(cold.calls.network,0); return {coldReady:1};
});
check('display-only-postprocessing-cold-return', () => {
 const warm=fresh(); warm.ctx.chat[0].extra.display_text='仅显示文本发生改变。'; warm.sync();
 const cold=warm.cold(); cold.sync(); assert.equal(cold.visibleReady(),1); return {coldReady:1};
});
check('different-swipe-cannot-reuse-ready', () => {
 const warm=fresh(); warm.ctx.chat[0].mes=driftedBody; warm.sync();
 warm.ctx.chat[0].swipe_id=1;
 const cold=warm.cold(); cold.sync(); assert.equal(cold.visibleReady(),0,'A different swipe must not inherit the paid owner'); return {coldReady:0};
});
check('different-chat-cannot-reuse-ready', () => {
 const warm=fresh(); warm.ctx.chat[0].mes=driftedBody; warm.sync();
 const other={chatMetadata:{chat_id:'audit-chat-B'},chat:structuredClone(warm.ctx.chat)};
 const cold=warm.cold(other); cold.sync(); assert.equal(cold.visibleReady(),0,'Another chat cannot recover the old local owner'); return {coldReady:0};
});
check('unwitnessed-body-replacement-cannot-reuse-ready', () => {
 const warm=fresh(); const other=structuredClone(warm.ctx); other.chat[0].mes='A wholly different body installed while old runtime absent';
 const cold=warm.cold(other); cold.sync(); assert.equal(cold.visibleReady(),0,'No mounted continuity proof: source hash guard must remain effective'); return {coldReady:0};
});
check('replaced-message-object-cannot-create-passive-proof', () => {
 const warm=fresh(); warm.ctx.chat[0]={...structuredClone(warm.ctx.chat[0]),mes:driftedBody}; warm.sync();
 const cold=warm.cold(); cold.sync(); assert.equal(cold.visibleReady(),0,'New object with copied marker cannot inherit the hot runtime witness'); return {coldReady:0};
});
check('replaced-chat-array-cannot-create-passive-proof', () => {
 const warm=fresh(); warm.ctx.chat=[...warm.ctx.chat]; warm.ctx.chat[0].mes=driftedBody; warm.sync();
 const cold=warm.cold(); cold.sync(); assert.equal(cold.visibleReady(),0,'New chat array cannot inherit the hot runtime witness'); return {coldReady:0};
});
check('accepted-lineage-cannot-authorize-unknown-next-body', () => {
 const warm=fresh(); warm.ctx.chat[0].mes=driftedBody; warm.sync();
 const other=structuredClone(warm.ctx); other.chat[0].mes+='unobserved later replacement';
 const cold=warm.cold(other); cold.sync(); assert.equal(cold.visibleReady(),0,'Saved lineage must only match its actually accepted body hash'); return {coldReady:0};
});
check('unsaved-message-marker-with-exact-accepted-body-recovers', () => {
 const warm=fresh(); warm.ctx.chat[0].mes=driftedBody; warm.sync();
 const other=structuredClone(warm.ctx); other.chat[0].extra={};
 const cold=warm.cold(other); cold.sync(); assert.equal(cold.visibleReady(),1,'A durable positively witnessed body hash can restore even when host has not saved message.extra'); return {coldReady:1};
});
check('mismatched-message-marker-cannot-recover-drifted-ready', () => {
 const warm=fresh(); warm.ctx.chat[0].mes=driftedBody; warm.sync();
 const other=structuredClone(warm.ctx); other.chat[0].extra.rabbitMirrorOwnerLineage={id:'unrelated-owner',swipe:0};
 const cold=warm.cold(other); cold.sync(); assert.equal(cold.visibleReady(),0,'An existing conflicting owner marker must prevent recovery'); return {coldReady:0};
});
check('revoked-message-marker-cannot-recover-drifted-ready', () => {
 const warm=fresh(); warm.ctx.chat[0].mes=driftedBody; warm.sync();
 const other=structuredClone(warm.ctx); other.chat[0].extra.rabbitMirrorOwnerLineage={...other.chat[0].extra.rabbitMirrorOwnerLineage,revoked:true};
 const cold=warm.cold(other); cold.sync(); assert.equal(cold.visibleReady(),0,'Explicit owner revocation must prevent recovery'); return {coldReady:0};
});
check('deletion-tombstone-wins-over-saved-ready', () => {
 const warm=fresh(); warm.ctx.chat[0].mes=driftedBody; warm.sync();
 warm.run("writePersistedOwner(getContext(),0,getContext().chat[0],{deleted:true,ts:Date.now()},{overwrite:true})");
 const cold=warm.cold(); cold.sync(); assert.equal(cold.visibleReady(),0,'Deletion marker must suppress both local and metadata recovery'); return {coldReady:0};
});
check('unchanged-body-deletion-tombstone-wins', () => {
 const warm=fresh();
 warm.run("writePersistedOwner(getContext(),0,getContext().chat[0],{deleted:true,ts:Date.now()},{overwrite:true})");
 const cold=warm.cold(); cold.sync(); assert.equal(cold.visibleReady(),0,'Even an exact original source hash cannot resurrect a deleted result'); return {coldReady:0};
});
check('explicit-regeneration-cannot-record-passive-alias', () => {
 const warm=fresh();
 warm.run("automaticGenerationCutovers.set(chatKey(getContext()),{activeHostGeneration:{chat:chatKey(getContext()),startTailRole:'assistant',type:'regenerate',startTailIndex:0},authorized:new Map()});");
 warm.ctx.chat[0].mes=driftedBody;
 warm.sync();
 const cold=warm.cold(); cold.sync(); assert.equal(cold.visibleReady(),0,'A known regenerate replacement must not create a passive-drift recovery alias'); return {coldReady:0};
});
