import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import test from 'node:test';
import {fileURLToPath} from 'node:url';

// These behavior tests execute unchanged production functions. Only their host,
// DOM and transport boundaries are fixtures. Browser acceptance is a separate run.
const sourceFile=process.env.RABBIT_MIRROR_TIMING_RUNTIME_SOURCE||fileURLToPath(new URL('../src/independentApi.js',import.meta.url));
let source=fs.readFileSync(sourceFile,'utf8').replace(/\r\n/g,'\n');
const mutations={
 'accept-replaced-source':['source.startsWith(owner.sourceText)','true'],
 'drop-chat-reference':['|| owner.intent?.cancelled || owner.chat!==ctx.chat || owner.chatKey!==chatKey(ctx)','|| owner.intent?.cancelled || false || owner.chatKey!==chatKey(ctx)'],
 'drop-message-reference':['|| owner.message!==ctx.chat?.[owner.index] || owner.swipe!==swipeId(owner.message)\n  || owner.epoch','|| false || owner.swipe!==swipeId(owner.message)\n  || owner.epoch'],
 'drop-swipe':['|| owner.message!==ctx.chat?.[owner.index] || owner.swipe!==swipeId(owner.message)\n  || owner.epoch','|| owner.message!==ctx.chat?.[owner.index] || false\n  || owner.epoch'],
 'drop-epoch':['owner.epoch!==operationEpochForBase(owner.baseSlot)','false'],
 'drop-cancelled-intent':['owner.intent?.cancelled || owner.chat!==ctx.chat','false || owner.chat!==ctx.chat'],
 'drop-click-consumption':['intent.consumed=true;','/* mutation: click not consumed */'],
 'allow-nonmanual-shell':["host.dataset.rmState!=='manual' || !manualIndependentTiming()","false || !manualIndependentTiming()"],
 'enable-automatic-in-manual':["function automaticIndependentTiming(){ return independentGenerationTiming(getSettings())==='auto'; }","function automaticIndependentTiming(){ return true; }"],
 'cancel-paid-on-timing-change':["if(!flight.dispatchLease?.consumed?.()) abortFlight(flight,'generation-timing-changed');","if(true) abortFlight(flight,'generation-timing-changed');"],
 'repeat-bound-binder':['if(bound) return bound;','if(false) return bound;'],
 'remount-existing-placeholder':['if(currentManualPlaceholder(existing,ctx,index,msg,intent)) return existing;','if(false) return existing;'],
 'requeue-existing-placeholder':['if(externalHosts(el).some(host=>currentManualPlaceholder(host,ctx,index,ctx.chat[index],intent))) return;','if(false) return;'],
 'skip-without-retry':['intent.consumed=false;','/* mutation: retry remains consumed */'],
 'skip-paid-retry':['!owner?.firstGeneration || !intent || flight.dispatchLease?.consumed?.()','!owner?.firstGeneration || !intent || false'],
 'omit-manual-terminal-sync':['if(ids.size) queueMessageSync([...ids]);','/* mutation: terminal sync omitted */'],
 'retain-terminal-event-hint':["hostGenerationInProgress=false;hostGenerationHintStartedAt=0;","/* mutation: keep the stale terminal hint */"],
 'clear-new-auto-operation-hint':["!automaticGenerationCutovers.get(chatKey(ctx))?.activeHostGeneration && !externalHostGenerationActivity().active","true && !externalHostGenerationActivity().active"],
 'permit-pending-early-packet-in-manual':['if(!automaticIndependentTiming() || !packet || !earlyBodyEnabled(ctx)','if(!packet || !earlyBodyEnabled(ctx)'],
 'manual-init-auto-hint':['hostGenerationInProgress=automaticIndependentTiming() && hostGenerationLooksActive();','hostGenerationInProgress=hostGenerationLooksActive();'],
 'keep-old-click-owner-on-resay':['manualTerminalOwners.set(owner.baseSlot,owner);','if(!manualTerminalOwners.has(owner.baseSlot)) manualTerminalOwners.set(owner.baseSlot,owner);'],
 'drop-no-intent-resay-owner':['manualTerminalOwners.set(owner.baseSlot,owner);','if(owner.intent) manualTerminalOwners.set(owner.baseSlot,owner);'],
};
const mutation=process.env.RABBIT_MIRROR_TIMING_RUNTIME_MUTATION;
if(mutation){
 const pair=mutations[mutation];assert.ok(pair,'known mutation');
 assert.equal(source.split(pair[0]).length,2,'unique mutation anchor');source=source.replace(...pair);
}
function productionFunction(name){
 const start=source.indexOf(`function ${name}(`);
 assert.notEqual(start,-1,'production function exists: '+name);
 const end=source.indexOf('\n}',start);
 assert.notEqual(end,-1,'production function boundary exists: '+name);
 return source.slice(start,end+2);
}
function fixture(){
 const settings={enabled:true,autoRabbitMirrorInjection:true,generationSource:'independent',independentGenerationTiming:'manual'};
 const msg={is_user:false,mes:'<content>captured body</content>',swipe_id:0,extra:{}};
 const chat=[{is_user:true,mes:'user'},msg];
 const ctx={chatId:'same-chat',chat};
 const intent={id:'intent',chat,chatKey:'same-chat',message:msg,index:1,swipe:0,cancelled:false,consumed:false,type:'normal'};
 const button={disabled:false};
 const body={querySelector:()=>button},details={querySelector:()=>body};
 const host={isConnected:true,dataset:{rmState:'manual',rmSource:'independent'},matches:()=>true,querySelectorAll:()=>[button],querySelector:selector=>selector===':scope > details'?details:button};
 const effects={requests:[],sync:[],aborted:[],cancelledEarly:[],clearSchedules:0,restores:0,mounts:[],binds:0};
 let epoch=2,explicitReplacement=false,activeFlight=null,visible='visible text at click';
 const flights=new Map(),cutovers=new Map();
 const scope=vm.createContext({
  getSettings:()=>settings,getContext:()=>ctx,
  independentGenerationTiming:value=>value.independentGenerationTiming||'auto',
  runtimeMode:()=>settings.enabled&&settings.generationSource==='independent'?'independent':'off',
  chatKey:value=>value.chatId,swipeId:value=>value?.swipe_id||0,
  messageBaseSlotKey:(value,index,message)=>`${value.chatId}:${index}:${message.swipe_id||0}`,
  operationEpochForBase:()=>epoch,isRabbitMirrorEligibleAssistantMessage:value=>value?.is_user===false,
  hasExplicitSourceReplacementEvidence:()=>explicitReplacement,
  createIndependentVisibleTextReader:()=>()=>({text:visible,source:'live-dom'}),
  activeIndependentFlightForBase:()=>activeFlight,
  generateFor:(...args)=>{effects.requests.push(args);return Promise.resolve();},
  currentRuntime:()=>true,globalFlights:()=>flights,
  abortFlight:(flight,reason)=>{effects.aborted.push({flight,reason});flight.cancelled=true;},
  queueMessageSync:ids=>effects.sync.push([...ids]),allExternalHosts:()=>[],
  clearScheduledGeneration:()=>{effects.clearSchedules++;},
  clearAutomaticHostGenerationSettlement:owner=>{if(owner)owner.timerCleared=true;},
  cancelEarlyBodyOwner:(owner,reason)=>{owner.cancelled=true;effects.cancelledEarly.push(reason);},
  automaticGenerationCutovers:cutovers,
  INDEPENDENT_GENERATION_INTENTS_KEY:'__autoIntents',
  currentGenerationIdentity:()=>({slot:'slot',sourceHash:'hash'}),
  exactIndependentReadyForIdentity:()=>({html:'ready'}),
  clearAutomaticFailureStop(){},restoreExactIndependentReadyForIdentity(){effects.restores++;},
  hasExistingFollowRabbitMirror:()=>false,
  messageElement:()=>({}),externalHosts:()=>[host],readyDetailsFromHost:()=>null,
  recordKey:()=> 'record',messageSourceFingerprint:value=>value.mes,
  externalHostGenerationActivity:()=>({active:false}),hostGenerationInProgress:true,hostGenerationHintStartedAt:123,
  ensureExternalUi:(el,key,text,state)=>{effects.mounts.push({key,text,state});host.dataset.rmState=state;return host;},
  __host:host,__ctx:ctx,__intent:intent,
 });
 const start=source.indexOf("const MANUAL_INTENTS_KEY=");
 const end=source.indexOf('function runtimeMode(){',start);
 assert.ok(start>=0&&end>start,'manual runtime block exists');
 vm.runInContext(`let lastAppliedIndependentTiming=null;\n${source.slice(start,end)}`,scope,{filename:sourceFile+'#manual'});
 scope.__rabbitMirrorIndependentManualIntentsV1=[intent];
 scope.__rabbitMirrorBindIndependentManualIntent=()=>{effects.binds++;};
 vm.runInContext('manualPlaceholderOwners.set(__host,{intent:__intent,chat:__ctx.chat,chatKey:__ctx.chatId,index:1,message:__ctx.chat[1],swipe:0})',scope);
 return {scope,settings,msg,chat,ctx,intent,host,button,effects,flights,cutovers,
  run:code=>vm.runInContext(code,scope),
  capture:()=>scope.captureManualBodyOwner(ctx,1,msg,intent),
  current:owner=>scope.manualBodyOwnerCurrent(owner),click:()=>scope.generateManualIndependentMirror(host),
  setEpoch:value=>{epoch=value;},setReplacement:value=>{explicitReplacement=value;},
  setActive:value=>{activeFlight=value;},setVisible:value=>{visible=value;}};
}
const check=(name,fn)=>test('independent timing runtime: '+name,fn);
check('click snapshot accepts only append and keeps the clicked visible text',()=>{
 const f=fixture(),owner=f.capture();f.msg.mes+='<status>later status';f.setVisible('later visible state');
 assert.equal(f.current(owner),true);assert.equal(owner.visible.text,'visible text at click');assert.ok(Object.isFrozen(owner.visible));
});
check('editing one captured character invalidates the snapshot',()=>{
 const f=fixture(),owner=f.capture();f.msg.mes=f.msg.mes.replace('captured','different');assert.equal(f.current(owner),false);
});
check('an empty raw source is not a wildcard for future content',()=>{
 const f=fixture();f.msg.mes='';const owner=f.capture();f.msg.mes='unrelated replacement';assert.equal(f.current(owner),false);
});
for(const [name,mutate] of [
 ['chat array replacement',f=>{f.ctx.chat=[...f.chat];}],
 ['chat identifier replacement',f=>{f.ctx.chatId='other-chat';}],
 ['message object replacement',f=>{f.ctx.chat[1]={...f.msg};}],
 ['swipe replacement',f=>{f.msg.swipe_id=1;}],
 ['operation epoch replacement',f=>f.setEpoch(3)],
 ['explicit source replacement',f=>f.setReplacement(true)],
 ['cancelled host intent',f=>{f.intent.cancelled=true;}],
 ['disabled source',f=>{f.settings.enabled=false;}],
 ['off timing',f=>{f.settings.independentGenerationTiming='off';}],
]) check(name+' cannot reuse a clicked snapshot',()=>{const f=fixture(),owner=f.capture();mutate(f);assert.equal(f.current(owner),false);});
check('auto/manual switching does not revoke an unchanged paid snapshot',()=>{
 const f=fixture(),owner=f.capture();f.settings.independentGenerationTiming='auto';assert.equal(f.current(owner),true);
});
check('two synchronous clicks dispatch only once before UI mutation',()=>{
 const f=fixture();assert.equal(f.click(),true);assert.equal(f.click(),false);
 assert.equal(f.effects.requests.length,1);assert.equal(f.button.disabled,true);assert.equal(f.effects.requests[0][6].visible.text,'visible text at click');
});
check('existing same-owner request is not cancelled or charged by a click',()=>{
 const f=fixture();f.setActive({task:Promise.resolve()});assert.equal(f.click(),true);assert.equal(f.effects.requests.length,0);assert.equal(f.intent.consumed,false);
});
check('forged DOM attributes cannot create a manual request owner',()=>{
 const f=fixture();const forged={...f.host};assert.equal(f.scope.generateManualIndependentMirror(forged),false);assert.equal(f.effects.requests.length,0);
});
check('a retained button on a completed shell cannot start a new operation',()=>{
 const f=fixture();f.host.dataset.rmState='ready';assert.equal(f.click(),false);assert.equal(f.effects.requests.length,0);
});
check('a cancelled or detached placeholder cannot dispatch',()=>{
 const f=fixture();f.intent.cancelled=true;assert.equal(f.click(),false);f.intent.cancelled=false;f.host.isConnected=false;assert.equal(f.click(),false);assert.equal(f.effects.requests.length,0);
});
check('switching away from manual disables old placeholder actions',()=>{
 const f=fixture();f.settings.independentGenerationTiming='auto';assert.equal(f.click(),false);assert.equal(f.effects.requests.length,0);
});
check('new auto scheduling is denied in manual without creating a timer',()=>{
 const f=fixture();f.scope.suppressesAutomaticGeneration=()=>false;
 vm.runInContext(productionFunction('scheduleMessageGeneration'),f.scope);
 assert.equal(f.scope.scheduleMessageGeneration(1),null);assert.equal(f.effects.restores,0);
 f.settings.independentGenerationTiming='auto';assert.equal(f.scope.scheduleMessageGeneration(1),null);assert.equal(f.effects.restores,1);
});
check('mode changes revoke unspent plans and preserve spent requests',()=>{
 const f=fixture();f.run("lastAppliedIndependentTiming='auto'");
 const paid={dispatchLease:{consumed:()=>true}},unpaid={dispatchLease:{consumed:()=>false}};
 f.flights.set('paid',paid);f.flights.set('unpaid',unpaid);
 f.scope.reconcileManualTimingChange();assert.equal(f.effects.clearSchedules,1);
 assert.deepEqual(f.effects.aborted.map(item=>item.flight),[unpaid]);assert.equal(paid.cancelled,undefined);
});
check('mode changes preserve an already dispatched early body owner',()=>{
 const f=fixture();f.run("lastAppliedIndependentTiming='auto'");
 const paid={flight:{dispatchLease:{consumed:()=>true}}},unpaid={flight:{dispatchLease:{consumed:()=>false}}};
 const active={};const cutover={authorized:new Map([[1,{}]]),earlyBodies:new Map([[1,paid],[2,unpaid]]),activeHostGeneration:active};
 f.cutovers.set('same-chat',cutover);f.scope.reconcileManualTimingChange();
 assert.equal(cutover.authorized.size,0);assert.equal(cutover.activeHostGeneration,active);assert.equal(paid.cancelled,undefined);assert.equal(unpaid.cancelled,true);
});
check('reading an already bound intention never re-enters the binding event producer',()=>{
 const f=fixture();for(let i=0;i<4;i++)assert.equal(f.scope.manualIntentForMessage(f.ctx,1),f.intent);
 assert.equal(f.effects.binds,0);assert.equal(f.effects.sync.length,0);
});
check('reconciling an unchanged waiting shell preserves its button and details',()=>{
 const f=fixture();for(let i=0;i<4;i++)assert.equal(f.scope.ensureManualGenerationPlaceholder(f.ctx,1,f.msg,f.intent),f.host);
 assert.equal(f.effects.mounts.length,0);
});
check('stream notifications leave an already mounted waiting shell idle',()=>{
 const f=fixture();for(let i=0;i<4;i++){f.msg.mes+=' tail';f.scope.handleIndependentManualBridge({kind:'changed',intent:f.intent});}
 assert.equal(f.effects.binds,0);assert.equal(f.effects.sync.length,0);assert.equal(f.effects.mounts.length,0);
});
check('skipped prompt without a paid lease explains why and permits one explicit retry',()=>{
 const f=fixture();f.click();f.host.dataset.rmState='loading';
 const flight={manualBodyOwner:f.effects.requests[0][6],dispatchLease:{consumed:()=>false}};f.setActive(flight);
 assert.equal(f.scope.settleSkippedManualIndependentFlightUi(flight,{reason:'directive-disabled'}),true);
 assert.equal(f.host.dataset.rmState,'manual');assert.match(f.effects.mounts.at(-1).text,/关闭兔子镜指令.*未发送请求/);
 assert.equal(f.intent.consumed,false);assert.equal(f.effects.requests.length,1);
 f.setActive(null);assert.equal(f.click(),true);assert.equal(f.click(),false);assert.equal(f.effects.requests.length,2);
});
check('empty prompt skip also explains the zero-request result',()=>{
 const f=fixture();f.click();f.host.dataset.rmState='loading';
 assert.equal(f.scope.settleSkippedManualIndependentFlightUi({manualBodyOwner:f.effects.requests[0][6],dispatchLease:{consumed:()=>false}},{reason:'empty-prompt'}),true);
 assert.match(f.effects.mounts.at(-1).text,/没有可用的生成提示词.*未发送请求/);
});
check('skipped response cannot reopen a consumed paid lease',()=>{
 const f=fixture();f.click();f.host.dataset.rmState='loading';
 assert.equal(f.scope.settleSkippedManualIndependentFlightUi({manualBodyOwner:f.effects.requests[0][6],dispatchLease:{consumed:()=>true}},{reason:'empty-prompt'}),false);
 assert.equal(f.intent.consumed,true);assert.equal(f.effects.mounts.length,0);
});
check('terminal event passively saves the exact clicked owner after an appended tail',()=>{
 const f=fixture();f.click();f.msg.mes+=' status footer';f.scope.queueManualGenerationTerminalSync();
 assert.deepEqual(f.effects.sync,[[1]]);assert.equal(f.effects.requests.length,1);
 assert.equal(f.scope.hostGenerationInProgress,false);assert.equal(f.scope.hostGenerationHintStartedAt,0);
});
check('terminal event never accepts an edited or replaced clicked owner',()=>{
 for(const change of [f=>{f.msg.mes='replacement';},f=>{f.intent.cancelled=true;},f=>{f.ctx.chat[1]={...f.msg};}]){
  const f=fixture();f.click();change(f);f.scope.queueManualGenerationTerminalSync();assert.equal(f.effects.sync.length,0);assert.equal(f.effects.requests.length,1);
 }
});
check('manual terminal never clears a still active host or auto timing event hint',()=>{
 for(const change of [f=>{f.scope.externalHostGenerationActivity=()=>({active:true});},f=>{f.settings.independentGenerationTiming='auto';}]){
  const f=fixture();f.click();change(f);f.scope.queueManualGenerationTerminalSync();
  assert.equal(f.scope.hostGenerationInProgress,true);assert.equal(f.scope.hostGenerationHintStartedAt,123);
 }
});
check('a paid manual owner changed to auto can finalize its exact original processor',()=>{
 const f=fixture();f.ctx.streamingProcessor={messageId:1,isFinished:false};f.click();f.settings.independentGenerationTiming='auto';
 f.ctx.streamingProcessor.isFinished=true;f.msg.mes+=' status tail';f.scope.queueManualGenerationTerminalSync();
 assert.equal(f.scope.hostGenerationInProgress,false);assert.deepEqual(f.effects.sync,[[1]]);assert.equal(f.effects.requests.length,1);
});
check('an old manual owner cannot clear the hint of a newer auto host generation',()=>{
 const f=fixture();f.ctx.streamingProcessor={messageId:1,isFinished:false};f.click();f.settings.independentGenerationTiming='auto';
 f.ctx.streamingProcessor.isFinished=true;f.cutovers.set('same-chat',{activeHostGeneration:{type:'normal'}});f.scope.queueManualGenerationTerminalSync();
 assert.equal(f.scope.hostGenerationInProgress,true);assert.equal(f.scope.hostGenerationHintStartedAt,123);
});
check('an old manual owner cannot claim a replaced streaming processor',()=>{
 const f=fixture();f.ctx.streamingProcessor={messageId:1,isFinished:false};f.click();f.settings.independentGenerationTiming='auto';
 f.ctx.streamingProcessor={messageId:1,isFinished:true};f.scope.queueManualGenerationTerminalSync();
 assert.equal(f.scope.hostGenerationInProgress,true);assert.equal(f.scope.hostGenerationHintStartedAt,123);
});
check('switching to manual cannot dispatch an already captured automatic early-body packet',()=>{
 const f=fixture();const processor={messageId:1,type:'normal',result:'<content>body</content>',toolCalls:[]};
 f.ctx.streamingProcessor=processor;f.ctx.canPerformToolCalls=()=>false;
 f.scope.earlyBodyEnabled=()=>true;f.scope.deferredIndependentGenerationIntents=()=>[{id:'early'}];f.scope.deferredIndependentIntentCandidateIndex=()=>1;
 vm.runInContext(productionFunction('earlyBodyPacketCurrent'),f.scope);
 const packet={chat:f.chat,chatKey:f.ctx.chatId,index:1,message:f.msg,swipe:0,processor,type:'normal',selectionKey:JSON.stringify(['',[],[]]),text:processor.result,intentId:'early'};
 f.settings.independentGenerationTiming='auto';assert.equal(f.scope.earlyBodyPacketCurrent(packet,f.ctx),true);
 f.settings.independentGenerationTiming='manual';assert.equal(f.scope.earlyBodyPacketCurrent(packet,f.ctx),false);
 f.settings.independentGenerationTiming='off';assert.equal(f.scope.earlyBodyPacketCurrent(packet,f.ctx),false);
});
check('manual cold initialization never invents an automatic generation hint',()=>{
 const f=fixture();f.scope.hostGenerationLooksActive=()=>true;
 const start=source.indexOf(' installFollowMultifaceCommitListener();',source.indexOf('export async function initIndependentRabbitMirror'))+' installFollowMultifaceCommitListener();'.length;
 const end=source.indexOf(' for(const key of LEGACY_GLOBAL_FLIGHT_KEYS)',start);
 assert.ok(start>0&&end>start,'existing runtime initialization statements');
 const initialize=()=>vm.runInContext(source.slice(start,end),f.scope);
 initialize();assert.equal(f.scope.hostGenerationInProgress,false);assert.equal(f.scope.hostGenerationHintStartedAt,0);
 f.settings.independentGenerationTiming='auto';initialize();assert.equal(f.scope.hostGenerationInProgress,true);assert.ok(f.scope.hostGenerationHintStartedAt>0);
 f.scope.hostGenerationLooksActive=()=>false;initialize();assert.equal(f.scope.hostGenerationInProgress,false);assert.equal(f.scope.hostGenerationHintStartedAt,0);
});
check('explicit resay replaces the terminal snapshot with its new epoch',()=>{
 const f=fixture();f.click();f.setEpoch(3);
 const resay=f.scope.captureManualBodyOwner(f.ctx,1,f.msg,f.intent);
 f.scope.rememberManualClickOwner(resay);f.msg.mes+=' tail after resay';f.scope.queueManualGenerationTerminalSync();
 assert.deepEqual(f.effects.sync,[[1]]);assert.equal(f.intent.consumed,true);
 assert.equal(f.effects.requests.length,1,'terminal bookkeeping itself never dispatches');
});
check('cold READY resay can reconcile its click snapshot without inventing a generation intent',()=>{
 const f=fixture();f.scope.__rabbitMirrorIndependentManualIntentsV1=[];
 const resay=f.scope.captureManualBodyOwner(f.ctx,1,f.msg);
 f.scope.rememberManualClickOwner(resay);f.msg.mes+=' footer after existing READY resay';f.scope.queueManualGenerationTerminalSync();
 assert.deepEqual(f.effects.sync,[[1]]);assert.equal(f.scope.__rabbitMirrorIndependentManualIntentsV1.length,0);assert.equal(f.effects.requests.length,0);
});
check('chat clearing removes all manual terminal bookkeeping',()=>{
 const f=fixture();f.scope.rememberManualClickOwner(f.capture());f.scope.handleIndependentManualBridge({kind:'clear'});
 f.scope.queueManualGenerationTerminalSync();assert.equal(f.effects.sync.length,0);
});
