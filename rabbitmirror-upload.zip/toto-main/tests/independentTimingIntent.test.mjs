import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import test from 'node:test';

const sourceFile = process.env.RABBIT_MIRROR_INJECTOR_SOURCE || fileURLToPath(new URL('../src/injector.js', import.meta.url));
const source = readFileSync(sourceFile, 'utf8').replace(/^import[\s\S]*?;\s*/gm, '').replace(/^export\s+/gm, '');
const helperFile = process.env.RABBIT_MIRROR_TIMING_SOURCE || fileURLToPath(new URL('../src/independentTiming.js', import.meta.url));
const helperSource = readFileSync(helperFile, 'utf8').replace(/^export\s+/gm, '');

function fixture(timing = 'manual') {
    const settings = { enabled: true, autoRabbitMirrorInjection: true, mode: 'integrated', generationSource: 'independent',
        independentGenerationTiming: timing, independentEarlyBodyEnabled: false };
    const ctx = { chatId: 'manual-intent-contract', chat: [{ is_user: true, mes: 'Current user', swipe_id: 0, extra: {} }],
        mainApi: 'openai', canPerformToolCalls: () => false, isGenerating: false };
    const handlers = new Map();
    const timers = new Map();
    const notifications = [];
    const promptWrites = [];
    let timerId = 0;
    const sandbox = { console, ctx, settings, notifications, promptWrites,
        getSettings: () => settings, getCurrentChatKey: () => ctx.chatId, SillyTavern: { getContext: () => ctx },
        hostRuntime: new Proxy({}, { get: (_target, key) => key === 'isGenerating' ? () => ctx.isGenerating : ctx[key] }),
        event_types: new Proxy({}, { get: (_target, key) => key }),
        eventSource: { on(event, fn) { if (!handlers.has(event)) handlers.set(event, new Set()); handlers.get(event).add(fn); },
            off(event, fn) { handlers.get(event)?.delete(fn); } },
        MODULE_NAME: 'rabbit_mirror_theater', extension_prompt_types: { IN_CHAT: 1 }, extension_prompt_roles: { SYSTEM: 1 },
        setExtensionPrompt: (...args) => promptWrites.push(args), clearFeedbackCatExtensionPrompt() {}, recordRabbitMirrorNoInjection() {},
        setTimeout(fn) { const id = ++timerId; timers.set(id, fn); return id; }, clearTimeout(id) { timers.delete(id); },
        document: { querySelector: () => null }, __rabbitMirrorIndependentManualBridge: event => notifications.push(event),
    };
    const context = vm.createContext(sandbox);
    vm.runInContext(helperSource + '\n' + source, context, { filename: sourceFile });
    const run = code => vm.runInContext(code, context);
    run('initIndependentGenerationIntentBridge()');
    const start = async (type = 'normal', input = ctx.chat) => { sandbox.input = input; sandbox.startType = type;
        await run('rabbitMirrorGenerateInterceptor(input, 0, null, startType)'); };
    const append = (body = '') => ctx.chat.push({ is_user: false, mes: body, swipe_id: 0, extra: {} }) - 1;
    const emit = (event, ...values) => { for (const fn of handlers.get(event) || []) fn(...values); };
    const intents = () => sandbox.__rabbitMirrorIndependentManualIntentsV1 || [];
    const automatic = () => sandbox.__rabbitMirrorIndependentGenerationIntents || [];
    return { settings, ctx, sandbox, run, start, append, emit, intents, automatic, notifications, timers, handlers, promptWrites };
}

test('timing intent: automatic uses the original authorization and writes no manual frame', async () => {
    const f = fixture('auto'); await f.start();
    assert.equal(f.automatic().length, 1); assert.equal(f.intents().length, 0);
    f.append('Complete body'); f.emit('CHARACTER_MESSAGE_RENDERED', 1);
    assert.equal(f.automatic()[0].finalIndex, 1); assert.ok(f.automatic()[0].completedAt);
    assert.equal(f.promptWrites.at(-1)[1], '');
});

test('manual host: START before new user and render binds without interceptor', () => {
    const f = fixture(); f.append('Old assistant');
    f.emit('GENERATION_STARTED', 'normal', {}, false);
    f.ctx.chat.push({ is_user: true, mes: 'New user', swipe_id: 0 });
    f.emit('MESSAGE_SENT', 2);
    f.append('New assistant'); f.emit('CHARACTER_MESSAGE_RENDERED', 3);
    const bound = f.intents().filter(i => !i.cancelled && i.message);
    assert.equal(bound.length, 1); assert.equal(bound[0].message, f.ctx.chat[3]);
    assert.equal(f.automatic().length, 0);
});

test('manual host: start from empty chat then user sent still binds exactly new reply', () => {
    const f = fixture(); f.ctx.chat.length = 0;
    f.emit('GENERATION_STARTED', undefined, {}, false);
    f.ctx.chat.push({ is_user: true, mes: 'First user' }); f.emit('MESSAGE_SENT', { messageId: 0 });
    f.append('First response'); f.emit('MESSAGE_RECEIVED', 1);
    assert.equal(f.intents().filter(i => !i.cancelled && i.message === f.ctx.chat[1]).length, 1);
});

test('manual host: interceptor reuses exact host intent without cancellation or duplicates', async () => {
    const f = fixture(); f.emit('GENERATION_STARTED', 'normal', {}, false);
    const old = f.intents()[0]; assert.ok(old);
    await f.start(); assert.equal(f.intents().length, 1); assert.equal(f.intents()[0], old);
    f.append('Response'); f.emit('MESSAGE_RECEIVED', 1); assert.equal(old.cancelled, false);
});

test('manual host: dry runs, quiet and impersonation never create a pending shell intent', () => {
    for (const [type, dry] of [['normal', true], ['quiet', false], ['impersonate', false]]) {
        const f = fixture(); f.emit('GENERATION_STARTED', type, {}, dry);
        f.ctx.chat.push({ is_user: true, mes: 'Unrelated' }); f.emit('MESSAGE_SENT', 1);
        f.append('Unrelated'); f.emit('CHARACTER_MESSAGE_RENDERED', 2);
        assert.equal(f.intents().length, 0);
    }
});

test('manual host: history render and unpaired user send cannot mint pending owners', () => {
    const f = fixture(); f.emit('MESSAGE_SENT', 0); f.append('History'); f.emit('CHARACTER_MESSAGE_RENDERED', 1);
    assert.equal(f.intents().length, 0);
});

test('manual host: user boundary cannot cross replaced chat, tail or chat key', () => {
    for (const mutation of ['chat', 'tail', 'key']) {
        const f = fixture(); f.emit('GENERATION_STARTED', 'normal', {}, false);
        if (mutation === 'chat') f.ctx.chat = f.ctx.chat.slice();
        if (mutation === 'tail') f.ctx.chat[0] = { ...f.ctx.chat[0] };
        if (mutation === 'key') f.ctx.chatId = 'Other chat';
        f.ctx.chat.push({ is_user: true, mes: 'User in replaced context' }); f.emit('MESSAGE_SENT', 1);
        f.append('Response'); f.emit('CHARACTER_MESSAGE_RENDERED', 2);
        assert.equal(f.intents().filter(i => i.message).length, 0, mutation);
    }
});

test('manual host: terminal clears the pending user boundary', () => {
    for (const terminal of ['GENERATION_ENDED', 'GENERATION_STOPPED', 'CHAT_CHANGED']) {
        const f = fixture(); f.emit('GENERATION_STARTED', 'normal', {}, false); f.emit(terminal);
        f.ctx.chat.push({ is_user: true, mes: 'Later unpaired message' }); f.emit('MESSAGE_SENT', 1);
        f.append('Response'); f.emit('CHARACTER_MESSAGE_RENDERED', 2);
        assert.equal(f.intents().filter(i => !i.cancelled && i.message).length, 0, terminal);
    }
});

test('manual host: start and user events cannot authorize automatic or disabled generation', () => {
    for (const mode of ['auto', 'off']) {
        const f = fixture(mode); f.emit('GENERATION_STARTED', 'normal', {}, false);
        f.ctx.chat.push({ is_user: true, mes: 'New user' }); f.emit('MESSAGE_SENT', 1);
        assert.equal(f.intents().length, 0); assert.equal(f.automatic().length, 0);
    }
    const f = fixture(); f.settings.enabled = false;
    f.emit('GENERATION_STARTED', 'normal', {}, false); assert.equal(f.intents().length, 0);
});
test('manual host: in-place operations retain their existing interceptor owner path', async () => {
    for (const type of ['continue', 'swipe', 'regenerate']) {
        const f=fixture();f.ctx.chat[0]={is_user:false,mes:'Before',swipe_id:0};
        f.emit('GENERATION_STARTED',type,{},false);assert.equal(f.intents().length,0);
        await f.start(type);const intent=f.intents()[0];assert.ok(intent);
        f.ctx.chat[0].mes='After';f.emit('CHARACTER_MESSAGE_RENDERED',0);
        assert.equal(intent.message,f.ctx.chat[0]);assert.equal(intent.cancelled,false);
    }
});

test('timing intent: legacy automatic selection keeps the same authorization', async () => {
    const f = fixture(); delete f.settings.independentGenerationTiming; await f.start();
    assert.equal(f.automatic().length, 1); assert.equal(f.intents().length, 0);
});

test('timing intent: manual creates only one pending intention and a finite runtime wake', async () => {
    const f = fixture(); await f.start();
    assert.equal(f.intents().length, 1); assert.equal(f.automatic().length, 0); assert.equal(f.timers.size, 1);
    assert.equal(f.intents()[0].index, -1); assert.equal(f.intents()[0].message, null);
    assert.equal(f.promptWrites.at(-1)[1], '');
});

test('timing intent: off captures neither automatic nor manual intentions', async () => {
    const f = fixture('off'); await f.start();
    assert.equal(f.intents().length, 0); assert.equal(f.automatic().length, 0); assert.equal(f.timers.size, 0);
});

test('timing intent: manual raw owner ignores interceptor message clones', async () => {
    const f = fixture(); const clone = f.ctx.chat.map(message => ({ ...message, mes: 'Prompt transformed' }));
    await f.start('normal', clone); const intent = f.intents()[0];
    assert.equal(intent.chat, f.ctx.chat); assert.equal(intent.tail, f.ctx.chat[0]); assert.equal(intent.tailSource, 'Current user');
});

test('timing intent: no historical receive or render can create a manual intention', () => {
    const f = fixture(); f.append('Historical body'); f.emit('MESSAGE_RECEIVED', 1); f.emit('CHARACTER_MESSAGE_RENDERED', 1);
    assert.equal(f.intents().length, 0); assert.equal(f.notifications.length, 0);
});

test('timing intent: first stream binds an empty current assistant frame without sending automatically', async () => {
    const f = fixture(); await f.start(); f.append();
    f.ctx.streamingProcessor = { messageId: 1, type: 'normal', isFinished: false, result: '' };
    f.emit('STREAM_TOKEN_RECEIVED', '');
    assert.equal(f.intents()[0].index, 1); assert.equal(f.intents()[0].message, f.ctx.chat[1]);
    assert.equal(f.automatic().length, 0); assert.ok(f.notifications.some(event => event.intent?.index === 1));
});

test('timing intent: RECEIVE and existing mount binder target only the recorded next message', async () => {
    const f = fixture(); await f.start(); f.append('First response'); f.append('Unrelated response');
    f.emit('MESSAGE_RECEIVED', 2); assert.equal(f.intents()[0].message, null);
    f.sandbox.__rabbitMirrorBindIndependentManualIntent(1); assert.equal(f.intents()[0].message, f.ctx.chat[1]);
    assert.equal(f.intents()[0].index, 1);
});

test('timing intent: changed user source, replaced tail or replaced chat cannot bind a stale target', async () => {
    for (const mutation of ['source', 'tail', 'chat']) {
        const f = fixture(); await f.start(); f.append('New response');
        if (mutation === 'source') f.ctx.chat[0].mes += ' changed';
        if (mutation === 'tail') f.ctx.chat[0] = { ...f.ctx.chat[0] };
        if (mutation === 'chat') f.ctx.chat = [...f.ctx.chat];
        f.emit('CHARACTER_MESSAGE_RENDERED', 1); assert.equal(f.intents()[0].message, null, mutation);
    }
});

test('timing intent: continuation waits for new body or exact matching stream evidence', async () => {
    const f = fixture(); f.ctx.chat[0] = { is_user: false, mes: 'Existing response', swipe_id: 0, extra: {} };
    await f.start('continue'); f.emit('CHARACTER_MESSAGE_RENDERED', 0); assert.equal(f.intents()[0].message, null);
    f.ctx.streamingProcessor = { messageId: 0, type: 'normal', isFinished: false };
    f.emit('STREAM_TOKEN_RECEIVED', ''); assert.equal(f.intents()[0].message, null);
    f.ctx.streamingProcessor.type = 'continue'; f.emit('STREAM_TOKEN_RECEIVED', '');
    assert.equal(f.intents()[0].message, f.ctx.chat[0]);
});

test('timing intent: changed continuation or swipe owner can bind without a stream processor', async () => {
    for (const type of ['continue', 'swipe', 'regenerate']) {
        const f = fixture(); f.ctx.chat[0] = { is_user: false, mes: 'Existing response', swipe_id: 0, extra: {} };
        await f.start(type); f.ctx.chat[0].mes = 'New version';
        if (type === 'swipe') f.ctx.chat[0].swipe_id = 1;
        f.emit('MESSAGE_RECEIVED', 0);
        assert.equal(f.intents()[0].message, f.ctx.chat[0], type); assert.equal(f.intents()[0].swipe, type === 'swipe' ? 1 : 0);
    }
});

test('timing intent: later normal turns preserve a prior waiting frame', async () => {
    const f = fixture(); await f.start(); f.append('Prior response'); f.emit('MESSAGE_RECEIVED', 1);
    const prior = f.intents()[0]; f.ctx.chat.push({ is_user: true, mes: 'Next user', swipe_id: 0 }); await f.start();
    assert.equal(prior.cancelled, false); assert.equal(prior.message, f.ctx.chat[1]); assert.equal(f.intents().length, 2);
    f.append('Next response'); f.emit('CHARACTER_MESSAGE_RENDERED', 3); assert.equal(f.intents()[1].index, 3);
});

test('timing intent: missed render still retains only the exact prior response on next start', async () => {
    const f = fixture(); await f.start(); f.append('Prior response'); const prior = f.intents()[0];
    f.ctx.chat.push({ is_user: true, mes: 'Next user', swipe_id: 0 }); await f.start();
    assert.equal(prior.cancelled, false); assert.equal(prior.index, 1);
});

test('timing intent: replacement cancels a consumed manual owner even after mode is turned off', async () => {
    const f = fixture(); await f.start(); f.append('Prior response'); f.emit('MESSAGE_RECEIVED', 1);
    const prior = f.intents()[0]; prior.consumed = true; f.settings.independentGenerationTiming = 'off';
    await f.start('regenerate'); assert.equal(prior.cancelled, true); assert.equal(f.intents().length, 1);
});

test('timing intent: later normal body append does not cancel a consumed paid owner', async () => {
    const f = fixture(); await f.start(); f.append('Body'); f.emit('MESSAGE_RECEIVED', 1);
    const prior = f.intents()[0]; prior.consumed = true; f.ctx.chat[1].mes += '\n<status>tail</status>';
    f.emit('CHARACTER_MESSAGE_RENDERED', 1); assert.equal(prior.cancelled, false);
    f.ctx.chat.push({ is_user: true, mes: 'Next user', swipe_id: 0 }); await f.start(); assert.equal(prior.cancelled, false);
});

test('timing intent: manual never creates early automatic permission', async () => {
    const f = fixture(); Object.assign(f.settings, { independentEarlyBodyEnabled: true,
        independentEarlyBodyChatKey: f.ctx.chatId, independentEarlyBodyTags: ['story'] });
    await f.start(); f.append('<story>done</story>'); f.ctx.streamingProcessor = { messageId: 1, type: 'normal',
        isFinished: false, result: '<story>done</story>', toolCalls: [] };
    f.emit('STREAM_TOKEN_RECEIVED', '<story>done</story>');
    assert.equal(f.automatic().length, 0); assert.equal(f.sandbox.__rabbitMirrorEarlyBodyPacket, undefined);
    assert.equal(f.intents()[0].message, f.ctx.chat[1]);
});

test('timing intent: switching to manual prevents a prior automatic early intention from sending', async () => {
    const f = fixture('auto'); Object.assign(f.settings, { independentEarlyBodyEnabled: true,
        independentEarlyBodyChatKey: f.ctx.chatId, independentEarlyBodyTags: ['story'] });
    await f.start(); assert.equal(f.automatic().length, 1);
    f.settings.independentGenerationTiming = 'manual'; f.append('<story>done</story>');
    f.ctx.streamingProcessor = { messageId: 1, type: 'normal', isFinished: false, result: '<story>done</story>', toolCalls: [] };
    f.emit('STREAM_TOKEN_RECEIVED', '<story>done</story>');
    assert.equal(f.sandbox.__rabbitMirrorEarlyBodyPacket, undefined);
});

test('timing intent: automatic retains opt-in early generation for any selected body tag', async () => {
    const f = fixture('auto'); Object.assign(f.settings, { independentEarlyBodyEnabled: true,
        independentEarlyBodyChatKey: f.ctx.chatId, independentEarlyBodyTags: ['narrative'] });
    await f.start(); f.append('<narrative>done</narrative>');
    f.ctx.streamingProcessor = { messageId: 1, type: 'normal', isFinished: false, result: '<narrative>done</narrative>', toolCalls: [] };
    f.emit('STREAM_TOKEN_RECEIVED', '<narrative>done</narrative>');
    assert.equal(f.sandbox.__rabbitMirrorEarlyBodyPacket.message, f.ctx.chat[1]);
    assert.equal(f.sandbox.__rabbitMirrorEarlyBodyPacket.text, '<narrative>done</narrative>');
});

test('timing intent: automatic completion adds no new tag or refusal text rejection', async () => {
    const f = fixture('auto'); await f.start(); f.append('<narrative>抱歉');
    f.emit('CHARACTER_MESSAGE_RENDERED', 1); assert.ok(f.automatic()[0].completedAt);
});

test('timing intent: unsupported auxiliary generation does not add a frame or wake', async () => {
    const f = fixture(); await f.start('quiet'); await f.start('impersonate');
    assert.equal(f.intents().length, 0); assert.equal(f.timers.size, 0);
});

test('timing intent: switching chats cancels captured owners and clears the plain bridge', async () => {
    const f = fixture(); await f.start(); const prior = f.intents()[0]; f.emit('CHAT_CHANGED');
    assert.equal(prior.cancelled, true); assert.equal(f.intents().length, 0);
    assert.ok(f.notifications.some(event => event.kind === 'clear'));
    f.run('destroyIndependentGenerationIntentBridge()'); assert.equal(f.sandbox.__rabbitMirrorBindIndependentManualIntent, undefined);
    assert.ok([...f.handlers.values()].every(set => set.size === 0));
});
