import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RM_PERFDIAG_ROOT || fileURLToPath(new URL('..', import.meta.url));
async function fixture(native = false) {
    const runtime = createRuntime(root);
    let time = 100, next = 0;
    const timers = new Map(), observers = new Map(), listeners = new Set();
    const target = {
        addEventListener(name, fn) { listeners.add(fn); },
        removeEventListener(name, fn) { listeners.delete(fn); },
    };
    Object.assign(runtime.context, target, {
        document: { ...target, readyState: 'complete', querySelector: () => null },
        performance: { now: () => time, getEntriesByType: () => [] },
        setInterval: (fn, ms) => { timers.set(++next, { fn, ms }); return next; },
        clearInterval: id => timers.delete(id),
        setTimeout: (fn, ms) => { timers.set(++next, { fn, ms }); return next; },
        clearTimeout: id => timers.delete(id),
        PerformanceObserver: class {
            static supportedEntryTypes = native ? ['longtask', 'event'] : ['event'];
            constructor(callback) { this.callback = callback; }
            observe({ type }) { this.type = type; observers.set(type, this); }
            disconnect() { observers.delete(this.type); }
        },
    });
    runtime.context.window = runtime.context;
    const mod = await runtime.load('src/externalDiagnostics.js');
    return { runtime, mod, timers, listeners, observers,
        advance: ms => { time += ms; },
        emit: (type, rows) => observers.get(type).callback({ getEntries: () => rows }),
        start: () => mod.initRabbitMirrorExternalDiagnostics(),
    };
}

test('diagnostic import is idle; explicit start and stop own all listeners/timers', async () => {
    const f = await fixture();
    assert.equal(f.runtime.context.__rabbitMirrorExternalDiag, undefined);
    assert.equal(f.timers.size, 0);
    const api = f.start();
    assert.equal(f.start(), api);
    assert.ok(f.timers.size > 0);
    f.mod.destroyRabbitMirrorExternalDiagnostics();
    assert.equal(f.timers.size, 0);
    assert.equal(f.listeners.size, 0);
    assert.equal(f.observers.size, 0);
    assert.equal(f.runtime.context.__rabbitMirrorExternalDiag, undefined);
});

test('5738ms idle-chat stall is in automatic conclusion without send, repair or LoAF', async () => {
    const f = await fixture(); const api = f.start();
    f.advance(6738);
    [...f.timers.values()].find(x => x.ms === 1000).fn();
    const headline = api.report().split('【外部启动资源】')[0];
    assert.match(headline, /5738ms/);
    assert.match(headline, /未归因/);
    assert.doesNotMatch(headline, /暂未捕获/);
});

test('native long task is reported without guessing script ownership', async () => {
    const f = await fixture(true); const api = f.start();
    f.emit('longtask', [{ startTime: 100, duration: 2345, attribution: [] }]);
    const headline = api.report().split('【外部启动资源】')[0];
    assert.match(headline, /2345ms/);
    assert.match(headline, /未归因/);
});

test('slow input conclusion distinguishes total duration from input queue delay', async () => {
    const f = await fixture(); const api = f.start();
    f.emit('event', [{ name: 'pointerup', startTime: 100, duration: 5384, processingStart: 2088, processingEnd: 2089 }]);
    const headline = api.report().split('【外部启动资源】')[0];
    assert.match(headline, /5384ms/);
    assert.match(headline, /1988ms/);
    assert.match(headline, /1ms/);
});

test('no evidence does not promise a smooth host', async () => {
    const api = (await fixture()).start();
    assert.match(api.report(), /不能据此认定页面流畅/);
});

test('host timings aggregate count, total, maximum and peak window with no body metadata', async () => {
    const f = await fixture(); const api = f.start();
    const stop = api.beginHostWork('independent.syncMessages', { body: 'PRIVATE_PROMPT' });
    f.advance(18); stop(); stop();
    const end = api.beginHostWork('independent.syncMessages'); f.advance(42); end();
    const row = api.hostWork()[0];
    assert.equal(row.count, 2); assert.equal(row.totalMs, 60); assert.equal(row.maxMs, 42);
    assert.equal(row.peakStartMs, 18); assert.equal(row.peakEndMs, 60);
    assert.equal(api.beginHostWork('PRIVATE_PROMPT'), null);
    assert.doesNotMatch(JSON.stringify(api.hostWork()) + api.report(), /PRIVATE_PROMPT/);
    assert.match(api.report(), /independent.syncMessages/);
    assert.match(api.report(), /包含嵌套调用.*不能相加/);
    assert.match(api.report(), /不含异步任务及后续绘制/);
});

test('aggregate memory is bounded by fixed operation names even after 2000 calls', async () => {
    const f = await fixture(); const api = f.start();
    const events = api.dump().length;
    for (let i = 0; i < 2000; i++) { const end = api.beginHostWork('independent.ensureExternalUi'); f.advance(1); end(); }
    assert.equal(api.hostWork().length, 1);
    assert.equal(api.hostWork()[0].count, 2000);
    assert.equal(api.dump().length, events);
    api.hostWork()[0].count = -1;
    assert.equal(api.hostWork()[0].count, 2000);
});

test('reset discards previous session and ignores unfinished old timing', async () => {
    const f = await fixture(); const api = f.start();
    const complete = api.beginHostWork('independent.syncMessages'); f.advance(4); complete();
    const old = api.beginHostWork('independent.syncMessages');
    api.reset('user-start'); f.advance(10); old();
    assert.equal(api.hostWork().length, 0);
    const end = api.beginHostWork('independent.syncMessages'); f.advance(8); end();
    assert.equal(api.hostWork()[0].totalMs, 8);
});

test('stop and restart reject old API and unfinished old session writes', async () => {
    const f = await fixture(); const oldApi = f.start();
    const old = oldApi.beginHostWork('independent.syncMessages');
    f.mod.destroyRabbitMirrorExternalDiagnostics();
    assert.equal(oldApi.beginHostWork('independent.syncMessages'), null);
    const api = f.start();
    assert.equal(oldApi.beginHostWork('independent.syncMessages'), null);
    f.advance(20); old(); assert.equal(api.hostWork().length, 0);
});

// Execute the real measurement wrappers and real diagnostic API together.
// Core operations are substituted only here to assert argument, return and throw
// transparency. Full-module DOM integration is additionally run in Edge.
const wrappers = [
    ['independentApi.js', 'syncMessages', [new Set([2])]],
    ['independentApi.js', 'ensureExternalUi', [{}, 'key', '<details>private</details>', 'ready', 'independent', 'hash', {}]],
    ['independentApi.js', 'refreshExistingExternalDetails', [{}, 'key', 'independent']],
    ['independentApi.js', 'reconcileVisibleMirrorDuplicates', [new Set([2])]],
    ['independentApi.js', 'viewportMessageIndices', [{}, 6]],
    ['outputSanitizer.js', 'installMaintenanceRabbitsInScope', [{}, { historyRestoreLight: true }]],
];
function functionText(source, name) {
    const start = source.indexOf(`function ${name}(`);
    assert.ok(start >= 0, `wrapper exists: ${name}`);
    return source.slice(start, source.indexOf('\n}', start) + 2);
}
for (const [file, name, args] of wrappers) {
    test(`host timing wrapper preserves results and errors: ${name}`, async () => {
        const f = await fixture(); const api = f.start();
        const source = fs.readFileSync(path.join(root, 'src', file), 'utf8').replace(/\r\n/g, '\n');
        const result = {}, failure = new Error('business failure'); let throws = false, calls = 0;
        f.runtime.context[name + 'Core'] = (...actual) => {
            calls++; assert.equal(actual.length, args.length);
            actual.forEach((value, i) => assert.equal(value, args[i]));
            f.advance(17); if (throws) throw failure; return result;
        };
        vm.runInContext(functionText(source, 'beginHostWorkTiming') + '\n' + functionText(source, name), f.runtime.context);
        const call = () => f.runtime.context[name](...args);
        assert.equal(call(), result); assert.equal(api.hostWork()[0].totalMs, 17);
        throws = true; assert.throws(call, err => err === failure);
        assert.equal(api.hostWork()[0].count, 2); assert.equal(calls, 2);
        throws = false;
        f.runtime.context.__rabbitMirrorExternalDiag = { beginHostWork() { throw new Error('recorder start failure'); } };
        assert.equal(call(), result);
        f.runtime.context.__rabbitMirrorExternalDiag = { beginHostWork: () => () => { throw new Error('recorder stop failure'); } };
        assert.equal(call(), result);
        f.mod.destroyRabbitMirrorExternalDiagnostics();
        delete f.runtime.context.__rabbitMirrorExternalDiag;
        assert.equal(call(), result);
        assert.equal(api.hostWork().length, 0);
    });
}
