import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../src/outputSanitizer.js',import.meta.url),'utf8');
function body(name,next){const start=source.indexOf('function '+name+'('),end=source.indexOf('\n'+next,start);assert.ok(start>=0&&end>start);return source.slice(start,end);}
test('blacklist entry is available for missing and external-only per-face records only when enabled',()=>{
 const context={};vm.createContext(context);vm.runInContext(body('recipeButtonShouldBeVisible','function clearMirrorTitleDisplayArtifacts'),context);
 for(const recipe of [null,{hasExternalReferences:true,themes:[],formats:[]},{themes:[{id:'1'}],formats:[]}]){
  assert.equal(context.recipeButtonShouldBeVisible(recipe,{enabled:true}),true);
  assert.equal(context.recipeButtonShouldBeVisible(recipe,{enabled:false}),false);
 }
});
test('fallback clipboard selects complete content inside active modal and restores focus',async()=>{
 const text='HEAD'+('文本与样式'.repeat(12000))+'TAIL';let focus,removed=false,selected=false,host;
 const previous={isConnected:true,focus(){focus=this;}};focus=previous;
 const field={style:{},focus(){focus=this;},select(){selected=true;},setSelectionRange(a,b){this.start=a;this.end=b;},remove(){removed=true;}};
 const modal={appendChild(node){host=this;assert.equal(node,field);},matches(){return true;}};
 const document={get activeElement(){return focus;},createElement(){return field;},querySelectorAll(){return [modal];},body:{appendChild(){throw Error('inert body must not receive field');}},execCommand(cmd){assert.equal(cmd,'copy');assert.equal(host,modal);assert.equal(field.value,text);assert.equal(field.start,0);assert.equal(field.end,text.length);assert.equal(selected,true);return true;}};
 const context={document,navigator:{clipboard:{async writeText(){throw Error('unavailable');}}}};vm.createContext(context);vm.runInContext('async '+body('writeRabbitMirrorHtmlClipboard','async function copyRabbitMirrorCurrentFaceHtml'),context);
 assert.equal(await context.writeRabbitMirrorHtmlClipboard(text,{closest(){return null;}}),true);assert.equal(removed,true);assert.equal(focus,previous);
});
