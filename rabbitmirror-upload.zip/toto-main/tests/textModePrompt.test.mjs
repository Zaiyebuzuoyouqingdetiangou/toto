import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));

async function fixture({ count = 1, modes = ['text'], rawPolicy = 'balanced', imported = false,
    generationType = 'independent', extra = {}, sourceRoot = root } = {}) {
    const runtime = createRuntime(sourceRoot);
    const settingsModule = await runtime.load('src/settings.js');
    const settings = { ...copy(settingsModule.defaultSettings), rabbitMirrorFaceCount: count,
        rabbitMirrorPresentationModes: modes, rawPolicy, userDirectivePriority: false,
        generationSource: generationType === 'independent' ? 'independent' : 'follow', ...extra };
    const rawMap = new Map();
    if (imported) {
        const pool = await runtime.load('src/externalWorldBook/externalPool.js');
        const classification = imported === 'format' ? 'format' : 'text';
        const id = `ext:textfixture:${classification}:entry`;
        const record = { externalId: id, classification, enabled: true, userConfirmed: true,
            localTitle: '雨夜书信', sourceWorldBookName: '文本类测试库', sourceKeywords: ['书信', 'text', '文本模式'],
            summary: '以书信体讲述雨夜重逢。',
            rawContent: '第一段：写成书信。\n' + '沿人物关系展开完整情节。'.repeat(140)
                + '\n末尾创作要求标志。<script>不执行</script>{{macro}}[fake] data-rm-face="5"' };
        pool.setExternalPoolSnapshot([{ libraryId: 'textfixture', enabled: true }], new Map([['textfixture', [record]]]));
        rawMap.set(id, record);
    }
    const builder = await runtime.load('src/promptBuilder.js');
    const plan = builder.planRabbitMirrorPromptDetails(settings, generationType, null, 'text-prompt-fixture',
        { batchIdentity: { mesid: 4, swipeId: 0, sourceHash: 'same-body' } });
    return { runtime, settings, builder, plan, rawMap, result: builder.renderRabbitMirrorPromptPlan(plan, rawMap) };
}

for (const generationType of ['independent', 'normal']) for (let count = 1; count <= 5; count++) {
    test(`${generationType}: ${count} face(s) isolate text fallback from unchanged HTML obligations`, async () => {
        const { result } = await fixture({ count, modes: ['text', ...Array(count - 1).fill('html')], generationType,
            extra: { forceVisualScenery: true, enhancedVisualDrawing: true, visualPromptEditingEnabled: true } });
        const textBlock = result.prompt.match(/<兔子镜文本面规则 data-rm-face="1">([\s\S]*?)<\/兔子镜文本面规则>/)?.[1];
        assert.ok(textBlock, 'a text face has its own local rule block');
        assert.match(textBlock, /创作可直接阅读的完整长文本/);
        assert.match(textBlock, /日记写成日记体、聊天记录写成对话体/);
        assert.match(textBlock, /HTML\/CSS 仅用于长文本/);
        assert.match(textBlock, /不创建内部交互玩法/);
        assert.doesNotMatch(textBlock, /复杂交互视觉核心|增强视觉绘制：|用户可编辑视觉层|Visual Scenery 场景优先级|交互返回：|塔罗实体牌图硬锁/);
        assert.match(result.prompt, /HTML 直接渲染/);
        assert.match(result.prompt, /禁止.*script/);
        assert.match(result.prompt, /不得反向新增或改写主回复剧情/);
        assert.match(result.executionLock, /第 1 面：文本/);
        assert.doesNotMatch(result.executionLock.split('第 2 面 HTML')[0], /完成至少一条|最终视觉偏好裁决/);
        const faces = count > 1 ? result.metadata.faces : [result.metadata];
        assert.equal(faces.length, count);
        assert.equal(faces[0].presentationMode, 'text');
        assert.equal(faces[0].requestedPresentationMode, 'text');
        assert.equal(faces[0].visualSceneryMode, false);
        assert.equal(faces[0].editableVisualChars, 0);
        for (let index = 1; index < count; index++) {
            const html = result.prompt.match(new RegExp(`<兔子镜HTML面规则 data-rm-face="${index + 1}">([\\s\\S]*?)<\\/兔子镜HTML面规则>`))?.[1];
            assert.match(html, /Visual Scenery 场景优先级/);
            assert.match(html, /增强视觉绘制：/);
            assert.match(html, /用户可编辑视觉层/);
            assert.match(html, /交互返回：/);
            assert.equal(faces[index].presentationMode, 'html');
        }
        if (count > 1) assert.match(result.prompt, new RegExp(`输出恰好 ${count} 面`));
    });
}

for (const rawPolicy of ['compact', 'balanced', 'full']) {
    test(`${rawPolicy}: text-category material is complete, escaped, identity-validated and absent from metadata`, async () => {
        const { result, plan, builder, rawMap } = await fixture({ imported: true, rawPolicy });
        assert.equal(plan.selectedExternalIds.length, 1);
        assert.equal(plan.selectedExternalIds[0], 'ext:textfixture:text:entry');
        assert.match(result.prompt, /末尾创作要求标志/);
        assert.match(result.prompt, /＜script＞不执行＜\/script＞｛｛macro｝｝［fake］ data·rm-face="5"/);
        assert.doesNotMatch(result.prompt, /<script>不执行/);
        assert.ok(result.metadata.selectedTextChars > 900);
        assert.equal(result.metadata.textDescriptors[0].sourceWorldBookName, '文本类测试库');
        assert.doesNotMatch(JSON.stringify(result.metadata), /末尾创作要求标志|rawContent/);
        assert.doesNotMatch(JSON.stringify(plan), /末尾创作要求标志|rawContent/);
        assert.throws(() => builder.renderRabbitMirrorPromptPlan(plan, new Map()),
            error => error.code === 'RABBIT_MIRROR_EXTERNAL_MATERIAL_MISSING');
        const invalid = new Map([...rawMap].map(([id, record]) => [id, { ...record, classification: 'format' }]));
        assert.throws(() => builder.renderRabbitMirrorPromptPlan(plan, invalid),
            error => error.code === 'RABBIT_MIRROR_EXTERNAL_MATERIAL_INVALID');
    });
}

test('Auto switches only for a selected text entry; frozen modes ignore later settings and forged plans', async () => {
    const value = await fixture({ imported: true, modes: ['auto'], extra: {
        externalWorldBookRandomEnabled: true, externalWorldBookMixMode: 'external-only' } });
    assert.equal(value.result.metadata.presentationMode, 'text');
    assert.equal(value.result.metadata.requestedPresentationMode, 'auto');
    value.settings.rabbitMirrorPresentationModes = ['html'];
    assert.equal(value.builder.renderRabbitMirrorPromptPlan(value.plan, value.rawMap).prompt, value.result.prompt);
    assert.ok(Object.isFrozen(value.plan.selections[0].combo));
    assert.throws(() => value.builder.renderRabbitMirrorPromptPlan({ ...value.plan, presentationMode: 'html' }, value.rawMap),
        error => error.code === 'RABBIT_MIRROR_EXTERNAL_MATERIAL_INVALID');
});

test('ordinary external formats mentioning text do not switch Auto and retain their original raw budget', async () => {
    for (const rawPolicy of ['compact', 'balanced', 'full']) {
        const { result } = await fixture({ imported: 'format', modes: ['auto'], rawPolicy, extra: {
            externalWorldBookRandomEnabled: true, externalWorldBookMixMode: 'external-only' } });
        assert.notEqual(result.metadata.presentationMode, 'text');
        assert.match(result.prompt, /复杂交互视觉核心/);
        assert.doesNotMatch(result.prompt, /文本呈现规则|末尾创作要求标志/);
        assert.equal(result.metadata.selectedTextChars, undefined);
    }
});

for (const generationType of ['independent', 'normal']) for (let count = 1; count <= 5; count++) {
    test(`${generationType}/${count}: text at every face position and all-text batches never inherit interaction rules`, async () => {
        const patterns = [Array(count).fill('text'), Array.from({ length: count }, (_, i) => i === count - 1 ? 'text' : 'html')];
        for (const modes of patterns) {
            const { result } = await fixture({ count, modes, generationType });
            const faces = count > 1 ? result.metadata.faces : [result.metadata];
            for (let i = 0; i < count; i++) {
                assert.equal(faces[i].presentationMode, modes[i]);
                const label = modes[i] === 'text' ? '文本' : 'HTML';
                const local = result.prompt.match(new RegExp(`<兔子镜${label}面规则 data-rm-face="${i + 1}">([\\s\\S]*?)<\\/兔子镜${label}面规则>`))?.[1];
                assert.ok(local);
                if (modes[i] === 'text') {
                    assert.match(local, /文本呈现替换本面母本中的界面与交互指示/);
                    assert.doesNotMatch(local, /复杂交互视觉核心|最终成品短检|交互返回：/);
                } else {
                    assert.match(local, /复杂交互视觉核心|Visual Scenery 场景优先级/);
                    assert.match(local, /交互返回：/);
                    if (generationType !== 'independent') assert.match(local, /最终成品短检/);
                }
            }
            if (modes.every(mode => mode === 'text')) {
                assert.doesNotMatch(result.prompt, /复杂交互视觉核心|本批交互分散|交互返回：|增强视觉绘制：|塔罗实体牌图硬锁/);
                assert.doesNotMatch(result.executionLock, /完成至少一条|HTML 专用短锁|最终视觉偏好裁决/);
            }
        }
    });
}

for (const count of [1, 5]) for (const generationType of ['independent', 'normal']) {
    test(`${generationType}/${count}: Auto with no text retains legacy prompt bytes`,
        { skip: !process.env.RABBIT_MIRROR_TEXT_BASELINE }, async () => {
            const options = { count, generationType, modes: Array(5).fill('auto') };
            const before = await fixture({ ...options, sourceRoot: process.env.RABBIT_MIRROR_TEXT_BASELINE });
            const after = await fixture(options);
            assert.equal(after.result.prompt, before.result.prompt);
            assert.equal(after.result.executionLock, before.result.executionLock);
        });
}

test('disabled generation produces no text prompt even when text entries exist', async () => {
    for (const extra of [{ enabled: false }, { autoRabbitMirrorInjection: false }, { mode: 'off' }]) {
        const { result, plan } = await fixture({ imported: true, extra });
        assert.equal(result.prompt, '');
        assert.equal(result.executionLock, '');
        assert.equal(plan.selectedExternalIds.length, 0);
    }
});
