import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../src/ui.js',import.meta.url),'utf8');
function runtime(withAnimationFrame=true){
 const frames=[],tasks=[],calls=[];let active=true;
 const sandbox={setTimeout:callback=>tasks.push(callback),isCurrentRuntime:()=>active,refreshMaintenanceRabbits:()=>calls.push('refresh')};
 if(withAnimationFrame)sandbox.requestAnimationFrame=callback=>frames.push(callback);
 vm.createContext(sandbox);
 const start=source.indexOf('let settingsToolsRefreshPending = false;');
 const end=source.indexOf('function scheduleUiMountRetry()',start);
 assert.ok(start>=0&&end>start,'Load the actual settings refresh scheduler');
 vm.runInContext(source.slice(start,end),sandbox);
 return {schedule:()=>sandbox.scheduleSettingsToolsRefresh(),frames,tasks,calls,deactivate:()=>{active=false;}};
}
test('settings tools coalesce rapid changes and refresh only after the checkbox paint opportunity',()=>{
 const r=runtime();r.schedule();r.schedule();r.schedule();
 assert.equal(r.calls.length,0);assert.equal(r.frames.length,1);assert.equal(r.tasks.length,0);
 r.frames.shift()();assert.equal(r.calls.length,0);assert.equal(r.tasks.length,1);
 r.tasks.shift()();assert.equal(r.calls.length,1);
 r.schedule();assert.equal(r.frames.length,1,'Future changes still schedule their own refresh');
});
test('settings tools work without animation frames and never run a stale runtime refresh',()=>{
 const r=runtime(false);r.schedule();r.schedule();assert.equal(r.tasks.length,1);r.tasks.shift()();assert.equal(r.calls.length,1);
 r.schedule();r.deactivate();r.tasks.shift()();assert.equal(r.calls.length,1);
});
