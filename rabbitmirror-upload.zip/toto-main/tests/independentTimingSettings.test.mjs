import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const json = value => JSON.parse(JSON.stringify(value));
async function fixture(seed) {
    const runtime = createRuntime(root);
    const hostPath = path.relative(root, path.resolve(root, 'src/../../../../extensions.js'));
    const host = await runtime.load(hostPath);
    const api = await runtime.load('src/settings.js');
    if (seed !== undefined) host.extension_settings[api.MODULE_NAME] = json(seed);
    return { api, host, runtime };
}

for (const timing of ['auto', 'manual', 'off']) {
    test(`timing explicit ${timing} survives contradictory legacy flags`, async () => {
        const runtime = createRuntime(root);
        const { independentGenerationTiming } = await runtime.load('src/independentTiming.js');
        const settings = { independentGenerationTiming: timing, enabled: false, autoRabbitMirrorInjection: false, mode: 'off' };
        const before = json(settings);
        assert.equal(independentGenerationTiming(settings), timing);
        assert.deepEqual(settings, before);
    });
}

for (const [name, seed, expected] of [
    ['fresh enabled', {}, 'auto'],
    ['enabled false', { enabled: false }, 'off'],
    ['auto switch false', { autoRabbitMirrorInjection: false }, 'off'],
    ['mode off', { mode: 'off' }, 'off'],
    ['all legacy flags disabled', { enabled: false, autoRabbitMirrorInjection: false, mode: 'off' }, 'off'],
    ['old automatic', { enabled: true, autoRabbitMirrorInjection: true, mode: 'integrated' }, 'auto'],
    ['corrupt new value while disabled', { independentGenerationTiming: 'bad', enabled: false }, 'off'],
    ['corrupt new value while enabled', { independentGenerationTiming: 7, enabled: true }, 'auto'],
]) {
    test(`timing migration before defaults: ${name}`, async () => {
        const { api } = await fixture(seed);
        const result = api.getSettings();
        assert.equal(result.independentGenerationTiming, expected);
        assert.equal(api.getSettings().independentGenerationTiming, expected);
    });
}

test('timing default and reset stay automatic without adding quality settings', async () => {
    const { api } = await fixture();
    assert.equal(api.defaultSettings.independentGenerationTiming, 'auto');
    assert.equal(api.getSettings().generationSource, 'follow');
    assert.equal(api.getSettings().independentGenerationTiming, 'auto');
    api.updateSettings({ generationSource: 'independent', independentGenerationTiming: 'manual' });
    api.resetSettings();
    assert.equal(api.getSettings().independentGenerationTiming, 'auto');
    assert.equal(api.getSettings().generationSource, 'follow');
    assert.deepEqual(Object.keys(api.defaultSettings).filter(key => /refusal|apology|qualityGate|openingMessage/i.test(key)), []);
});

test('timing selection writes legacy request flags but retains non-off sampling mode', async () => {
    const { api } = await fixture({ generationSource: 'independent', mode: 'format', enabled: true, autoRabbitMirrorInjection: true });
    const before = json(api.getSettings());
    for (const timing of ['manual', 'auto']) {
        api.updateSettings({ independentGenerationTiming: timing });
        const actual = json(api.getSettings());
        assert.equal(actual.independentGenerationTiming, timing);
        assert.equal(actual.enabled, true);
        assert.equal(actual.autoRabbitMirrorInjection, true);
        assert.equal(actual.mode, 'format');
        const { independentGenerationTiming: ignored, ...rest } = actual;
        const { independentGenerationTiming: beforeIgnored, ...beforeRest } = before;
        assert.deepEqual(rest, beforeRest);
    }
});

test('timing off retains legacy shutdown flags and explicit manual reopens from off', async () => {
    const { api } = await fixture({ generationSource: 'independent', independentGenerationTiming: 'auto' });
    api.updateSettings({ independentGenerationTiming: 'off' });
    let settings = api.getSettings();
    assert.deepEqual([settings.enabled, settings.autoRabbitMirrorInjection, settings.mode], [false, false, 'off']);
    api.updateSettings({ independentGenerationTiming: 'manual' });
    settings = api.getSettings();
    assert.deepEqual([settings.enabled, settings.autoRabbitMirrorInjection, settings.mode], [true, true, 'integrated']);
    assert.equal(settings.independentGenerationTiming, 'manual');
});

test('timing preference and follow API legacy switch do not overwrite each other', async () => {
    const { api } = await fixture({ generationSource: 'follow', enabled: true, autoRabbitMirrorInjection: true, mode: 'format' });
    api.updateSettings({ independentGenerationTiming: 'manual' });
    let settings = api.getSettings();
    assert.deepEqual([settings.enabled, settings.autoRabbitMirrorInjection, settings.mode], [true, true, 'format']);
    api.updateSettings({ enabled: false, autoRabbitMirrorInjection: false, mode: 'off' });
    settings = api.getSettings();
    assert.equal(settings.independentGenerationTiming, 'manual');
    assert.deepEqual([settings.enabled, settings.autoRabbitMirrorInjection, settings.mode], [false, false, 'off']);
    api.updateSettings({ generationSource: 'independent' });
    settings = api.getSettings();
    assert.equal(settings.independentGenerationTiming, 'manual');
    assert.deepEqual([settings.enabled, settings.autoRabbitMirrorInjection, settings.mode], [true, true, 'integrated']);
    api.updateSettings({ generationSource: 'follow' });
    api.updateSettings({ enabled: false, autoRabbitMirrorInjection: false, mode: 'off' });
    assert.equal(api.getSettings().independentGenerationTiming, 'manual');
});

test('timing choices survive actual serialized settings reload', async () => {
    for (const timing of ['auto', 'manual', 'off']) {
        const { api } = await fixture({ generationSource: 'independent' });
        api.updateSettings({ independentGenerationTiming: timing });
        const restored = await fixture(json(api.getSettings()));
        assert.equal(restored.api.getSettings().independentGenerationTiming, timing);
        assert.deepEqual(
            [restored.api.getSettings().enabled, restored.api.getSettings().autoRabbitMirrorInjection, restored.api.getSettings().mode],
            timing === 'off' ? [false, false, 'off'] : [true, true, 'integrated'],
        );
    }
});
