import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createRuntime } from './helpers/vmLoader.mjs';
const root=fileURLToPath(new URL('..',import.meta.url));

test('manual image generation is off for existing/default settings and requires explicit boolean enable',async()=>{
 const runtime=createRuntime(root);const s=await runtime.load('src/settings.js');
 assert.equal(s.defaultSettings.imageEnabled,false);
 assert.equal(s.getSettings().imageEnabled,false);
 s.updateSettings({imageEnabled:'true'});assert.equal(s.getSettings().imageEnabled,false);
 s.updateSettings({imageEnabled:true});assert.equal(s.getSettings().imageEnabled,true);
 s.updateSettings({imageEnabled:false});assert.equal(s.getSettings().imageEnabled,false);
});

for(const type of ['normal','independent'])test(`${type}: enabling image tools without clicking preserves five-face draw and Prompt`,async()=>{
 const run=async imageEnabled=>{
  const runtime=createRuntime(root);const s=await runtime.load('src/settings.js');
  const builder=await runtime.load('src/promptBuilder.js');
  const plan=builder.planRabbitMirrorPromptDetails({...s.defaultSettings,imageEnabled,rabbitMirrorFaceCount:5},type,null,'image-no-click');
  return JSON.parse(JSON.stringify({selection:plan.selections,rendered:builder.renderRabbitMirrorPromptPlan(plan)}));
 };
 assert.deepEqual(await run(false),await run(true));
});
