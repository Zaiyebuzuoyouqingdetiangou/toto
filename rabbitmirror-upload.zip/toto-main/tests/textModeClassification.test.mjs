import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = process.env.RABBITMIRROR_TEXT_TEST_ROOT || fileURLToPath(new URL('..', import.meta.url));
const plain = value => JSON.parse(JSON.stringify(value));
async function modules() {
    const runtime = createRuntime(root);
    return { runtime, classifier: await runtime.load('src/externalWorldBook/classifier.js'),
        store: await runtime.load('src/externalWorldBook/store.js'),
        pool: await runtime.load('src/externalWorldBook/externalPool.js'),
        backup: await runtime.load('src/externalWorldBook/backup.js'),
        selection: await runtime.load('src/externalWorldBook/selectionState.js') };
}
function book() {
    return { sourceType: 'local', sourceTransport: 'file', sourceId: 'text-fixture', sourceName: '我的文本类', sourceHash: 'sample',
        entries: [
            { sourceEntryId: '1', sourceEntryUid: '1', title: '展现形式 1 日记', content: '保留这个独有故事要求。', contentHash: 'h1', primaryKeywords: [], secondaryKeywords: [], originalOrder: 0 },
            { sourceEntryId: '2', sourceEntryUid: '2', title: '主题元素 2 梦境', content: '另一条长文本要求。', contentHash: 'h2', primaryKeywords: [], secondaryKeywords: [], originalOrder: 1 },
            { sourceEntryId: '3', sourceEntryUid: '3', title: '尚未选中的条目', content: '不要保存。', contentHash: 'h3', primaryKeywords: [], secondaryKeywords: [], originalOrder: 2 },
        ] };
}
function imported(m, kind = 'text') {
    const source = book();
    const ids = new Set(source.entries.slice(0, 2).map(m.selection.entryIdentity));
    const draft = m.classifier.createExternalWorldBookClassificationDraft(source, ids, { importKind: kind });
    return { source, draft, snapshot: m.store.prepareExternalLibrarySnapshot(source, draft, { now: 1234, enabled: true }) };
}

test('text import explicitly classifies every selected entry without changing source or guessing format', async () => {
    const m = await modules(), { source, draft, snapshot } = imported(m);
    assert.equal(m.classifier.EXTERNAL_WORLD_BOOK_CLASSIFICATION.TEXT, 'text');
    assert.deepEqual(plain(draft.map(row => row.classification)), ['text', 'text']);
    assert.ok(draft.every(row => row.userConfirmed && !row.requiresReview));
    assert.equal(snapshot.library.textCount, 2);
    assert.equal(snapshot.library.formatCount, 0);
    assert.equal(snapshot.library.themeCount, 0);
    assert.ok(snapshot.entries.every(row => row.enabled && row.externalId.startsWith(`ext:${snapshot.library.libraryId}:text:`)));
    assert.deepEqual(plain(snapshot.entries.map(row => row.rawContent)), source.entries.slice(0, 2).map(row => row.content));
    assert.equal(source.entries[0].classification, undefined);
    assert.deepEqual(plain(m.classifier.externalWorldBookClassificationCounts(draft)).text, 2);
});

test('ordinary import never guesses text from prose, title, or HTML and remains default disabled', async () => {
    const m = await modules();
    for (const title of ['文本模式', '长文本', '展现形式 1 日记']) {
        assert.notEqual(m.classifier.classifyExternalWorldBookEntry({ title, content: 'text 文本模式 ' + '<div>长文本</div>'.repeat(500) }).suggestion, 'text');
    }
    const { source, draft } = imported(m, '');
    assert.deepEqual(plain(draft.map(row => row.classification)), ['format', 'theme']);
    const snapshot = m.store.prepareExternalLibrarySnapshot(source, draft, { now: 1234 });
    assert.equal(snapshot.library.enabled, false);
    assert.equal(snapshot.library.textCount, undefined);
});

test('text pool stays separate from formats and ignores disabled/unconfirmed entries and libraries', async () => {
    const m = await modules(), { snapshot } = imported(m);
    const lib = snapshot.library, [one, two] = snapshot.entries;
    const format = { ...one, externalId: `ext:${lib.libraryId}:format:f`, classification: 'format' };
    m.pool.setExternalPoolSnapshot([lib, { libraryId: 'disabled', enabled: false }], new Map([
        [lib.libraryId, [one, { ...two, enabled: false }, { ...two, externalId: `ext:${lib.libraryId}:text:unconfirmed`, userConfirmed: false }, format]],
        ['disabled', [{ ...one, externalId: 'ext:disabled:text:a' }]],
    ]));
    const s = m.pool.getExternalPoolSnapshot();
    assert.equal(s.textCount, 1); assert.equal(s.formatCount, 1);
    assert.deepEqual(plain(s.textsByLibrary[0].ids), [one.externalId]);
    assert.deepEqual(plain(s.formatsByLibrary[0].ids), [format.externalId]);
    assert.equal(m.pool.externalPoolEligibleCount('presentation'), 2);
    const settings = { externalWorldBookRandomEnabled: true, externalWorldBookMixMode: 'external-only' };
    assert.equal(m.pool.pickExternalItems(settings, 'text', 1, { randomUnit: () => 0 })[0].externalKind, 'text');
    assert.equal(m.pool.pickExternalItems(settings, 'presentation', 1, { randomUnit: () => .99 })[0].externalKind, 'text');
    assert.equal(m.pool.pickExternalItems(settings, 'format', 1, { randomUnit: () => .99 })[0].externalKind, 'format');
    assert.equal(m.pool.pickExternalItems(settings, 'text', 1, { hardExcludedIds: [one.externalId], randomUnit: () => 0 }).length, 0);
});

test('text ID metadata survives hydration, upsert, removal and old metadata remains valid', async () => {
    const m = await modules(), { snapshot } = imported(m);
    const metadata = m.pool.externalPoolMetadataForLibrary(snapshot.library, snapshot.entries);
    assert.deepEqual(plain(metadata.textIds), plain(snapshot.entries.map(row => row.externalId)));
    assert.equal(m.pool.validExternalPoolMetadata(metadata, snapshot.library.libraryId), true);
    assert.equal(m.pool.validExternalPoolMetadata({ ...metadata, textIds: ['ext:wrong:text:x'] }, snapshot.library.libraryId), false);
    const old = { ...metadata }; delete old.textIds;
    assert.equal(m.pool.validExternalPoolMetadata(old, snapshot.library.libraryId), true);
    m.pool.setExternalPoolMetadataSnapshot([snapshot.library], [metadata]);
    const key = m.pool.getExternalPoolSelectionKey();
    assert.equal(m.pool.getExternalPoolSnapshot().textCount, 2);
    m.pool.upsertExternalPoolLibrary({ libraryId: 'another', enabled: true }, [{ externalId: 'ext:another:theme:a', classification: 'theme', enabled: true, userConfirmed: true }]);
    assert.equal(m.pool.getExternalPoolSnapshot().textCount, 2);
    m.pool.removeExternalPoolLibrary('another');
    assert.equal(m.pool.getExternalPoolSelectionKey(), key);
    m.pool.setExternalPoolMetadataSnapshot([snapshot.library], [old]);
    assert.equal(m.pool.getExternalPoolSnapshot().textCount, 0);
});

test('text backup round-trips classification, exact raw text and stable identity; old backups remain accepted', async () => {
    const m = await modules(), { snapshot } = imported(m);
    const raw = { format: m.backup.EXTERNAL_BACKUP_FORMAT, version: 1, exportedAt: 1234, libraries: [plain(snapshot)] };
    const parsed = m.backup.parseExternalLibraryBackup(JSON.stringify(raw));
    assert.deepEqual(plain(parsed), raw);
    const corrupted = structuredClone(raw); corrupted.libraries[0].entries[0].externalId = corrupted.libraries[0].entries[0].externalId.replace(':text:', ':format:');
    assert.throws(() => m.backup.validateExternalLibraryBackup(corrupted));
    const wrongCount = structuredClone(raw); wrongCount.libraries[0].library.textCount = 1;
    assert.throws(() => m.backup.validateExternalLibraryBackup(wrongCount));
    const ordinary = imported(m, '').snapshot;
    assert.equal(ordinary.library.textCount, undefined);
    assert.equal(m.backup.validateExternalLibraryBackup({ ...raw, libraries: [ordinary] }).libraries.length, 1);
});

test('no-text source selection consumes old number of draws and retains legacy selection key', async () => {
    const m = await modules();
    m.pool.setExternalPoolSnapshot([{ libraryId: 'old', enabled: true }], new Map([['old', [{ externalId: 'ext:old:format:f', classification: 'format', enabled: true, userConfirmed: true }]]]));
    let draws = 0;
    const random = () => { draws++; return .1; };
    assert.equal(m.pool.chooseExternalSource({ externalWorldBookRandomEnabled: false }, 'format', random), false);
    assert.equal(draws, 0);
    assert.equal(m.pool.chooseExternalSource({ externalWorldBookRandomEnabled: true, externalWorldBookMixMode: 'balanced' }, 'format', random), true);
    assert.equal(draws, 1);
    const key = m.pool.getExternalPoolSelectionKey();
    m.pool.setExternalPoolSnapshotObject({ libraries: [{ libraryId: 'old', formatIds: ['ext:old:format:f'] }] });
    assert.equal(m.pool.getExternalPoolSelectionKey(), key);
    assert.equal(m.pool.getExternalPoolSnapshot().textCount, 0);
});
