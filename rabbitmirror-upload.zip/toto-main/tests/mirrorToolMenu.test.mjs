import test from 'node:test';
import assert from 'node:assert/strict';
import { fitMirrorToolPanel } from '../src/mirrorToolMenu.js';

test('tool panel follows a shrinking and offset visual viewport and releases listeners on close', () => {
    const original = Object.fromEntries(['document','visualViewport','innerWidth','innerHeight','MutationObserver','addEventListener','removeEventListener'].map(key => [key, Object.getOwnPropertyDescriptor(globalThis,key)]));
    const events = new Map(); let observer;
    const view = { width:320,height:568,offsetLeft:0,offsetTop:0,
        addEventListener:(type,fn)=>events.set(type,fn),removeEventListener:type=>events.delete(type) };
    Object.assign(globalThis, { document:{body:{}},visualViewport:view,innerWidth:320,innerHeight:568,
        addEventListener(){},removeEventListener(){},MutationObserver:class { constructor(fn){observer=this;this.fn=fn;} observe(){} disconnect(){this.disconnected=true;} } });
    try {
        const styles=new Map();const panel={isConnected:true,offsetHeight:720,style:{setProperty:(name,value)=>styles.set(name,value)}};
        const opener={closest:()=>null,getBoundingClientRect:()=>({left:290,bottom:550})};
        fitMirrorToolPanel(panel,opener,420);
        assert.equal(styles.get('width'),'296px');assert.equal(styles.get('max-height'),'544px');
        assert.equal(styles.get('left'),'12px');assert.equal(styles.get('top'),'12px');assert.equal(styles.get('overflow'),'auto');
        // Mobile keyboard and page zoom can shrink and offset the visible viewport.
        Object.assign(view,{width:240,height:120,offsetLeft:31,offsetTop:81});events.get('resize')();
        assert.equal(styles.get('width'),'216px');assert.equal(styles.get('max-height'),'96px');
        assert.equal(styles.get('left'),'43px');assert.equal(styles.get('top'),'93px');
        Object.assign(view,{width:80,height:24});events.get('scroll')();
        assert.equal(styles.get('width'),'74px');assert.equal(styles.get('max-height'),'18px');
        panel.isConnected=false;observer.fn();assert.equal(observer.disconnected,true);assert.equal(events.size,0);
    } finally { for(const [key,descriptor] of Object.entries(original)){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];} }
});
