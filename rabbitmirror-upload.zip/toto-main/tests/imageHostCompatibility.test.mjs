import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';

const source = readFileSync(process.env.RM_IMAGE_TEST_SOURCE || new URL('../src/imageUi.js', import.meta.url), 'utf8');
const start = source.indexOf('function safeImageUrl(');
const end = source.indexOf('\nfunction makeImage(', start);
assert.ok(start >= 0 && end > start, 'load the actual image URL display function');
function resolve(value, href, baseURI = href) {
    return vm.runInNewContext(`${source.slice(start, end)}\nsafeImageUrl(value)`, {
        URL, value, document: { baseURI, location: { href } },
    });
}

test('TT restores existing relative and absolute local image paths without generating again', () => {
    const base = 'tauri://localhost/';
    for (const path of ['/user/images/RabbitMirror/fixture.png', 'user/images/RabbitMirror/fixture.png', 'tauri://localhost/user/images/RabbitMirror/fixture.png']) {
        assert.equal(resolve(path, base), 'tauri://localhost/user/images/RabbitMirror/fixture.png');
    }
    assert.equal(resolve('/user/images/兔子镜/插图.png?revision=2#preview', base), 'tauri://localhost/user/images/%E5%85%94%E5%AD%90%E9%95%9C/%E6%8F%92%E5%9B%BE.png?revision=2#preview');
});

test('PC and mobile browser HTTP/HTTPS and existing bitmap data URL handling stay unchanged', () => {
    for (const base of ['http://localhost:8000/', 'https://cloud.example/']) {
        assert.equal(resolve('/user/images/fixture.png', base), `${base}user/images/fixture.png`);
        assert.equal(resolve('https://images.example/existing.png', base), 'https://images.example/existing.png');
        assert.equal(resolve('data:image/png;base64,YQ==', base), 'data:image/png;base64,YQ==');
    }
});

test('TT scheme display is confined to the current local TT host, without relaxing executable URL rejection', () => {
    for (const bad of ['tauri://other/user/images/a.png', 'tauri://localhost:123/user/images/a.png', 'tauri://user@localhost/user/images/a.png', 'javascript:alert(1)', 'file:///private/image.png', 'data:text/html;base64,YQ==']) {
        assert.equal(resolve(bad, 'tauri://localhost/'), '', bad);
    }
    assert.equal(resolve('tauri://localhost/user/images/a.png', 'https://cloud.example/'), '');
    assert.equal(resolve('/user/images/a.png', 'https://cloud.example/', 'tauri://localhost/'), '');
});
