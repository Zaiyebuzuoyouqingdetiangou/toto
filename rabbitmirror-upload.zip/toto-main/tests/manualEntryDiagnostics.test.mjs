import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import test from 'node:test';

const sourceFile = process.env.RABBIT_MIRROR_INJECTOR_SOURCE || fileURLToPath(new URL('../src/injector.js', import.meta.url));
const source = readFileSync(sourceFile, 'utf8').replace(/^import[\s\S]*?;\s*/gm, '').replace(/^export\s+/gm, '');
const helperFile = process.env.RABBIT_MIRROR_TIMING_SOURCE || fileURLToPath(new URL('../src/independentTiming.js', import.meta.url));
const helperSource = readFileSync(helperFile, 'utf8').replace(/^export\s+/gm, '');

function fixture(timing = 'manual') {
    const settings = { enabled: true, autoRabbitMirrorInjection: true, mode: 'integrated', generationSource: 'independent',
        independentGenerationTiming: timing, independentEarlyBodyEnabled: false };
    const ctx = { chatId: 'manual-intent-contract', chat: [{ is_user: true, mes: 'Current user', swipe_id: 0, extra: {} }],
        mainApi: 'openai', canPerformToolCalls: () => false, isGenerating: false };
    const handlers = new Map();
    const timers = new Map();
    const notifications = [];
    const promptWrites = [];
    let timerId = 0;
    const sandbox = { console, ctx, settings, notifications, promptWrites,
        getSettings: () => settings, getCurrentChatKey: () => ctx.chatId, SillyTavern: { getContext: () => ctx },
        hostRuntime: new Proxy({}, { get: (_target, key) => key === 'isGenerating' ? () => ctx.isGenerating : ctx[key] }),
        event_types: new Proxy({}, { get: (_target, key) => key }),
        eventSource: { on(event, fn) { if (!handlers.has(event)) handlers.set(event, new Set()); handlers.get(event).add(fn); },
            off(event, fn) { handlers.get(event)?.delete(fn); } },
        MODULE_NAME: 'rabbit_mirror_theater', extension_prompt_types: { IN_CHAT: 1 }, extension_prompt_roles: { SYSTEM: 1 },
        setExtensionPrompt: (...args) => promptWrites.push(args), clearFeedbackCatExtensionPrompt() {}, recordRabbitMirrorNoInjection() {},
        setTimeout(fn) { const id = ++timerId; timers.set(id, fn); return id; }, clearTimeout(id) { timers.delete(id); },
        document: { querySelector: () => null }, __rabbitMirrorIndependentManualBridge: event => notifications.push(event),
    };
    const context = vm.createContext(sandbox);
    vm.runInContext(helperSource + '\n' + source, context, { filename: sourceFile });
    const run = code => vm.runInContext(code, context);
    run('initIndependentGenerationIntentBridge()');
    const start = async (type = 'normal', input = ctx.chat) => { sandbox.input = input; sandbox.startType = type;
        await run('rabbitMirrorGenerateInterceptor(input, 0, null, startType)'); };
    const append = (body = '') => ctx.chat.push({ is_user: false, mes: body, swipe_id: 0, extra: {} }) - 1;
    const emit = (event, ...values) => { for (const fn of handlers.get(event) || []) fn(...values); };
    const intents = () => sandbox.__rabbitMirrorIndependentManualIntentsV1 || [];
    const automatic = () => sandbox.__rabbitMirrorIndependentGenerationIntents || [];
    return { settings, ctx, sandbox, run, start, append, emit, intents, automatic, notifications, timers, handlers, promptWrites };
}

test('manual diagnostics: default off and stop prevent recording, requests and timers', () => {
    const f=fixture(); const timers=f.timers.size;
    assert.equal(f.run('getManualEntryDiagnosticState().active'),false);
    f.run("recordManualEntryDiagnostic('start',{messageCount:1})");
    assert.equal(f.run('stopManualEntryDiagnostic()'),'');
    f.run('startManualEntryDiagnostic()');
    assert.equal(f.timers.size,timers); assert.equal(f.intents().length,0); assert.equal(f.promptWrites.length,0);
    const report=f.run('stopManualEntryDiagnostic()');
    assert.ok(report.includes('manualdiag1')); assert.equal(f.sandbox.__rabbitMirrorManualEntryDiagnosticRecord,undefined);
    f.emit('MESSAGE_RECEIVED',0);
    assert.equal(f.run('getManualEntryDiagnosticState().report'),report);
    assert.equal(f.run('getManualEntryDiagnosticState().active'),false);
});
test('manual diagnostics: allowlist rejects secrets and raw event values', () => {
    const f=fixture();f.run('startManualEntryDiagnostic()');
    f.run("recordManualEntryDiagnostic('placeholder',{index:2,result:'created',mes:'SECRET_BODY',prompt:'SECRET_PROMPT',apiKey:'SECRET_KEY',type:'SECRET_TYPE',runtimeVersion:'SECRET_VERSION',messageCount:'SECRET_COUNT',hidden:'SECRET_BOOLEAN'})");
    f.run("recordManualEntryDiagnostic('SECRET_EVENT',{index:3})");
    f.emit('STREAM_TOKEN_RECEIVED','SECRET_TOKEN');
    const report=f.run('stopManualEntryDiagnostic()');
    assert.ok(!report.includes('SECRET_'));assert.ok(report.includes('"index":2'));assert.ok(report.includes('"result":"created"'));
    assert.ok(report.includes('host-event:STREAM_TOKEN_RECEIVED'));
});
test('manual diagnostics: bounded timeline retains first record and exact event counts', () => {
    const f=fixture();f.run('startManualEntryDiagnostic()');
    for(let i=0;i<260;i++)f.run(`recordManualEntryDiagnostic('placeholder',{index:${i}})`);
    const report=f.run('stopManualEntryDiagnostic()');
    const rows=report.split('【时序】\n')[1].split('\n').map(JSON.parse);
    assert.equal(rows.length,200); assert.equal(rows[0].event,'start');assert.equal(rows.at(-1).event,'stop');
    assert.ok(report.includes('省略中间记录 62 条'));assert.ok(report.includes('"placeholder":260'));
});
test('manual diagnostics: real bridge events and manual intent binding are observable', () => {
    const f=fixture(); f.run('startManualEntryDiagnostic()');
    f.emit('GENERATION_STARTED','normal',{},false);f.append('SECRET_RESPONSE');f.emit('MESSAGE_RECEIVED',1);
    const report=f.run('stopManualEntryDiagnostic()');
    assert.ok(report.includes('host-event:GENERATION_STARTED'));assert.ok(report.includes('host-event:MESSAGE_RECEIVED'));
    assert.ok(report.includes('"result":"created"'));assert.ok(report.includes('"result":"bound"'));
    assert.ok(report.includes('"boundCount":1'));assert.ok(!report.includes('SECRET_RESPONSE'));
});
test('manual diagnostics: no-intent render has explicit missing boundary', () => {
    const f=fixture(); f.run('startManualEntryDiagnostic()'); f.emit('MESSAGE_RECEIVED',0);
    assert.ok(f.run('stopManualEntryDiagnostic()').includes('"result":"missing-intent"'));
});
test('manual diagnostics: blocked settings expose scalar flags without changing them', () => {
    const f=fixture(); f.settings.enabled=false; f.settings.independentApiKey='SECRET_KEY';
    const before=JSON.stringify(f.settings);f.run('startManualEntryDiagnostic()');f.emit('GENERATION_STARTED','normal',{},false);
    const report=f.run('stopManualEntryDiagnostic()');assert.ok(report.includes('"enabled":false'));
    assert.equal(JSON.stringify(f.settings),before);assert.equal(f.intents().length,0);assert.ok(!report.includes('SECRET_KEY'));
});
test('manual diagnostics: destroying bridge stops capture and subscriptions', () => {
    const f=fixture();f.run('startManualEntryDiagnostic()');f.run('destroyIndependentGenerationIntentBridge()');
    assert.equal(f.run('getManualEntryDiagnosticState().active'),false);
    assert.equal(f.sandbox.__rabbitMirrorManualEntryDiagnosticRecord,undefined);
    assert.ok([...f.handlers.values()].every(set=>set.size===0));
});
test('manual diagnostics: unavailable core snapshot does not pretend to be loaded', () => {
    const f=fixture();f.run('startManualEntryDiagnostic()');const report=f.run('stopManualEntryDiagnostic()');
    assert.ok(report.includes('"result":"unavailable"'));assert.ok(!report.includes('"runtimeVersion":"1.5.53-manualdiag1"'));
});
test('manual diagnostics: starting another session clears only diagnostic records', () => {
    const f=fixture();f.run('startManualEntryDiagnostic()');f.run("recordManualEntryDiagnostic('placeholder',{index:42})");
    f.run('stopManualEntryDiagnostic()');f.run('startManualEntryDiagnostic()');const report=f.run('stopManualEntryDiagnostic()');
    assert.ok(!report.includes('"index":42'));assert.equal(f.ctx.chat[0].mes,'Current user');
});
