import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { createRuntime } from './helpers/vmLoader.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const copy = value => JSON.parse(JSON.stringify(value));
async function fixture({ modes = ['auto'], textCount = 0, mix = 'builtin-only', forceVisualScenery = false, rootPath = root } = {}) {
    const runtime = createRuntime(rootPath);
    const { defaultSettings } = await runtime.load('src/settings.js');
    const settings = { ...copy(defaultSettings), rabbitMirrorPresentationModes: modes,
        themesMin: 1, themesMax: 1, formatsMin: 1, formatsMax: 1, userDirectivePriority: false,
        externalWorldBookRandomEnabled: mix !== 'builtin-only', externalWorldBookMixMode: mix, forceVisualScenery };
    const pool = await runtime.load('src/externalWorldBook/externalPool.js');
    const entries = Array.from({ length: textCount }, (_, index) => ({ externalId: `ext:test:text:${index}`,
        classification: 'text', enabled: true, userConfirmed: true }));
    pool.setExternalPoolSnapshot([{ libraryId: 'test', enabled: true }], new Map([['test', entries]]));
    const picker = await runtime.load('src/picker.js');
    return { runtime, settings, picker, pool, entries };
}
const operation = key => ({ batchPlanningOnly: true, batchOperation: { operationId: key, generationType: 'independent' } });

test('explicit Text prioritizes standalone imported text regardless of ordinary mix and forced visual; HTML excludes it', async () => {
    for (const mix of ['builtin-only', 'builtin-preferred', 'balanced', 'external-preferred', 'external-only']) {
        const { settings, picker } = await fixture({ modes: ['text'], textCount: 2, mix, forceVisualScenery: true });
        const combo = picker.pickCombination(settings, `text-${mix}`).combo;
        assert.equal(combo.presentationMode, 'text');
        assert.equal(combo.requestedPresentationMode, 'text');
        assert.equal(combo.textIds.length, 1);
        assert.equal(combo.themes.length, 0);
        assert.equal(combo.formats.length, 0);
        assert.equal(combo.forcedVisualScenery, false);
    }
    const { settings, picker } = await fixture({ modes: ['html'], textCount: 3, mix: 'balanced' });
    const combo = picker.pickCombination(settings, 'html').combo;
    assert.equal(combo.presentationMode, 'html');
    assert.equal(combo.textIds, undefined);
    assert.equal(combo.formats.length, 1);
});

test('explicit Text with no eligible text falls back to ordinary sampling without a new refusal', async () => {
    const { settings, picker } = await fixture({ modes: ['text'], forceVisualScenery: true });
    const combo = picker.pickCombination(settings, 'fallback').combo;
    assert.equal(combo.presentationMode, 'text');
    assert.equal(combo.textIds, undefined);
    assert.equal(combo.themeIds.length, 1);
    assert.equal(combo.formatIds.length, 1);
    assert.equal(combo.forcedVisualScenery, false);
});

test('Auto uses configured external share and only selected text switches mode', async () => {
    const builtin = await fixture({ textCount: 2 });
    assert.equal(builtin.picker.pickCombination(builtin.settings, 'auto-builtin').combo.presentationMode, undefined);
    const external = await fixture({ textCount: 2, mix: 'external-only' });
    const selected = external.picker.pickCombination(external.settings, 'auto-external').combo;
    assert.equal(selected.presentationMode, 'text');
    assert.equal(selected.requestedPresentationMode, 'auto');
    assert.equal(selected.textIds.length, 1);
    assert.equal(selected.formats.length, 0);
});

for (const count of [1, 2, 3, 4, 5]) test(`${count} faces: Text preference, no text duplicate, frozen plan and original-face resay`, async () => {
    const { settings, picker } = await fixture({ modes: Array(count).fill('text'), textCount: count });
    const scope = `text-${count}`;
    const first = picker.pickCombinationBatch(settings, scope, operation(scope), count);
    assert.equal(first.length, count);
    const ids = first.flatMap(face => face.combo.textIds);
    assert.equal(new Set(ids).size, count);
    assert.ok(first.every(face => face.combo.presentationMode === 'text'));
    const again = picker.pickCombinationBatch(settings, scope, operation(scope), count);
    assert.deepEqual(copy(again), copy(first));
    const last = first[count - 1].combo;
    const resay = picker.pickCombinationForMultifaceResay({ ...settings, rabbitMirrorPresentationModes: ['html'] },
        { faceIndex: count - 1, faces: first.map(face => face.combo) });
    assert.deepEqual(copy(resay.combo.textIds), copy(last.textIds));
    assert.equal(resay.combo.presentationMode, 'text');
});

test('five mixed faces retain real indices; only HTML faces get interaction diversity', async () => {
    const { settings, picker, runtime } = await fixture({ modes: ['text', 'html', 'text', 'html', 'html'], textCount: 2 });
    settings.avoidRepeat = true;
    const faces = picker.pickCombinationBatch(settings, 'mixed', operation('mixed'), 5);
    assert.deepEqual(copy(faces.map(face => face.combo.presentationMode)), ['text', 'html', 'text', 'html', 'html']);
    assert.equal(faces[0].combo.interactionDiversity, undefined);
    assert.equal(faces[2].combo.interactionDiversity, undefined);
    assert.deepEqual(copy(faces[3].combo.interactionDiversity.compareWithFaceIndices), [1]);
    assert.deepEqual(copy(faces[4].combo.interactionDiversity.compareWithFaceIndices), [1, 3]);
    const diversity = await runtime.load('src/batchInteractionDiversity.js');
    assert.match(diversity.buildBatchInteractionDiversityRule(faces.map(face => face.combo), settings), /第 2、4、5 面 HTML/);
});

test('exhausted text pool falls back per face without repeating a text entry', async () => {
    const { settings, picker } = await fixture({ modes: ['text', 'text', 'text', 'text', 'text'], textCount: 1 });
    const faces = picker.pickCombinationBatch(settings, 'fallback-batch', operation('fallback-batch'), 5);
    assert.equal(faces.length, 5);
    assert.equal(faces.flatMap(face => face.combo.textIds || []).length, 1);
    assert.ok(faces.every(face => face.combo.presentationMode === 'text'));
    assert.ok(faces.slice(1).every(face => face.combo.formatIds.length === 1));
});

test('Auto with no text leaves legacy selection and random stream identical', { skip: !process.env.RABBIT_MIRROR_TEXT_BASELINE }, async () => {
    const baseline = process.env.RABBIT_MIRROR_TEXT_BASELINE;
    for (const mix of ['builtin-only', 'balanced']) {
        const before = await fixture({ rootPath: baseline, mix });
        const after = await fixture({ mix });
        for (let turn = 0; turn < 3; turn++) {
            assert.deepEqual(copy(after.picker.pickCombination(after.settings, `parity-${turn}`)),
                copy(before.picker.pickCombination(before.settings, `parity-${turn}`)));
        }
    }
});


test('Text directive cache follows library import changes even when ordinary source mix is builtin-only',async()=>{
    const f=await fixture({modes:['text']});
    f.settings.userDirectivePriority=true;
    const context={chat:[{is_user:true,mes:'兔子镜：雨夜散步',mesid:1}]};
    const before=f.picker.pickCombination(f.settings,'directive-before',context).combo;
    assert.equal(before.presentationMode,'text');
    assert.equal(before.textIds,undefined);
    f.pool.setExternalPoolSnapshot([{libraryId:'new',enabled:true}],new Map([['new',[{externalId:'ext:new:text:1',classification:'text',enabled:true,userConfirmed:true}]]]));
    const after=f.picker.pickCombination(f.settings,'directive-after',context).combo;
    assert.ok(Array.isArray(after.textIds), 'newly imported text must be selected with text IDs');
    assert.deepEqual(copy(after.textIds),['ext:new:text:1']);
    const frozen=f.picker.pickCombination({...f.settings,rabbitMirrorPresentationModes:['html']},'directive-after',context).combo;
    assert.deepEqual(copy(frozen),copy(after),'same generation remains frozen after UI settings change');
    const next=f.picker.pickCombination({...f.settings,rabbitMirrorPresentationModes:['html']},'directive-next',context).combo;
    assert.equal(next.presentationMode,'html');
    assert.equal(next.textIds,undefined);
});
