import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
import test from 'node:test';

// Full production injector module, with only absent import boundaries supplied.
// Timers are recorded, not executed: these tests prove intent authorization;
// the separate browser contract covers actual dispatch and paid-request count.
const sourceFile=process.env.RABBIT_MIRROR_INJECTOR_SOURCE||fileURLToPath(new URL('../src/injector.js',import.meta.url));
const source=readFileSync(sourceFile,'utf8').replace(/^import[\s\S]*?;\s*/gm,'').replace(/^export\s+/gm,'');
function fixture({tools=false}={}){
 const ctx={chatId:'intent-contract',chat:[{is_user:true,mes:'User source',swipe_id:0,extra:{}}],mainApi:'openai',canPerformToolCalls:()=>tools,isGenerating:false};
 const handlers=new Map();const timers=new Map();let timerId=0;
 const eventSource={on(event,handler){if(!handlers.has(event))handlers.set(event,new Set());handlers.get(event).add(handler);},off(event,handler){handlers.get(event)?.delete(handler);}};
 const hostRuntime=new Proxy({}, {get:(_target,key)=>key==='isGenerating'?()=>ctx.isGenerating:ctx[key]});
 const sandbox={console,ctx,hostRuntime,eventSource,event_types:new Proxy({}, {get:(_target,key)=>String(key)}),MODULE_NAME:'rabbit_mirror_theater',
  getSettings:()=>({enabled:true,autoRabbitMirrorInjection:true,generationSource:'independent',mode:'integrated',independentEarlyBodyEnabled:false}),
  getCurrentChatKey:()=>ctx.chatId,SillyTavern:{getContext:()=>ctx},
  setTimeout(fn){const id=++timerId;timers.set(id,fn);return id;},clearTimeout(id){timers.delete(id);},
  document:{querySelector:()=>null},
 };
 const context=vm.createContext(sandbox);vm.runInContext(source,context,{filename:sourceFile});
 const run=code=>vm.runInContext(code,context);
 run('initIndependentGenerationIntentBridge()');
 const emit=(event,value)=>{for(const handler of [...(handlers.get(event)||[])])handler(value);};
 const start=(type='normal')=>run(`recordIndependentGenerationIntent(ctx.chat,${JSON.stringify(type)})`);
 const append=()=>ctx.chat.push({is_user:false,mes:'Completed assistant body',swipe_id:0,extra:{}})-1;
 const intents=()=>sandbox.__rabbitMirrorIndependentGenerationIntents||[];
 const current=()=>intents().at(-1);
 const ready=()=>Number(current()?.completedAt)>0;
 return {ctx,run,start,append,emit,intents,current,ready,timers};
}
const check=(name,fn)=>test('independent intent: '+name,fn);
check('RECEIVE alone does not authorize a paid request',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);assert.equal(f.ready(),false);});
check('exact received non-tool owner plus END proves completion without render',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.emit('GENERATION_ENDED');assert.equal(f.ready(),true);assert.equal(f.current().finalIndex,1);assert.equal(f.current().finalBodyHash,f.run('hashIndependentIntentText(ctx.chat[1].mes)'));});
check('render followed by postprocessing and END captures the final body',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.emit('CHARACTER_MESSAGE_RENDERED',1);const previous=f.current().finalBodyHash;f.ctx.chat[1].mes+=' postprocessed';f.emit('GENERATION_ENDED');assert.equal(f.ready(),true);assert.notEqual(f.current().finalBodyHash,previous);assert.equal(f.current().finalBodyHash,f.run('hashIndependentIntentText(ctx.chat[1].mes)'));});
check('replaced message object cannot reuse the received owner',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.ctx.chat[1]={...f.ctx.chat[1]};f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('replaced chat array cannot reuse the received owner',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.ctx.chat=[...f.ctx.chat];f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('swipe change cannot reuse the received owner',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.ctx.chat[1].swipe_id=1;f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('missing exact received or rendered owner leaves END unbound',()=>{const f=fixture();f.start();f.append();f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('invalid completion payload must not coerce to message zero',()=>{const f=fixture();f.ctx.chat[0]={is_user:false,mes:'Original',swipe_id:0,extra:{}};f.start('continue');f.ctx.chat[0].mes+=' continued';for(const value of [null,'',false,{},undefined]){f.emit('MESSAGE_RECEIVED',value);f.emit('CHARACTER_MESSAGE_RENDERED',value);}f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('tool stream intermediate END and render cannot authorize',()=>{const f=fixture({tools:true});f.start();f.append();f.ctx.streamingProcessor={messageId:1,isFinished:true,toolCalls:[{id:'mid-tool'}]};f.emit('MESSAGE_RECEIVED',1);f.emit('CHARACTER_MESSAGE_RENDERED',1);f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('tool-capable owner without final stream proof is not completed by END',()=>{const f=fixture({tools:true});f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('STOP without final render cannot certify complete body',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.emit('GENERATION_STOPPED');assert.equal(f.ready(),false);});
check('later END cannot relabel an already stopped unfinished intent',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.emit('GENERATION_STOPPED');f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('auxiliary quiet END cannot finish outer generation',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.start('quiet');f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('active host cannot be completed by an unscoped END',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.ctx.isGenerating=true;f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('final non-tool render remains sufficient when END is absent',()=>{const f=fixture();f.start();f.append();f.emit('CHARACTER_MESSAGE_RENDERED',1);assert.equal(f.ready(),true);});
check('new regenerate start revokes the previous completion intent',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.emit('CHARACTER_MESSAGE_RENDERED',1);f.start('regenerate');f.ctx.chat[1].mes='Partial new body';f.emit('GENERATION_ENDED');assert.equal(f.ready(),false);});
check('duplicate END cannot retarget a terminal intent to another body',()=>{const f=fixture();f.start();f.append();f.emit('MESSAGE_RECEIVED',1);f.emit('GENERATION_ENDED');assert.equal(f.ready(),true);const hash=f.current().finalBodyHash;f.ctx.chat[1].mes+='later unobserved body';f.emit('GENERATION_ENDED');assert.equal(f.current().finalBodyHash,hash);});
check('historical received and END without an intent stay unbound',()=>{const f=fixture();f.append();f.emit('MESSAGE_RECEIVED',1);f.emit('GENERATION_ENDED');assert.equal(f.intents().length,0);});
