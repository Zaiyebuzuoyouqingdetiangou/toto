import assert from 'node:assert/strict';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { createRuntime, createStore } from './helpers/vmLoader.mjs';
const root = fileURLToPath(new URL('..', import.meta.url));
const plain = value => JSON.parse(JSON.stringify(value));
async function storageFixture(store = createStore(), modes = ['text','html','text','html','text']) {
    const runtime = createRuntime(root, { store });
    const settingsModule = await runtime.load('src/settings.js');
    const settings = { ...plain(settingsModule.defaultSettings), rabbitMirrorPresentationModes: modes,
        themesMin: 1, themesMax: 1, formatsMin: 1, formatsMax: 1, userDirectivePriority: false };
    const pool = await runtime.load('src/externalWorldBook/externalPool.js');
    pool.setExternalPoolSnapshot([{libraryId:'persist',enabled:true}], new Map([['persist', Array.from({length:5},(_,i)=>({
        externalId:`ext:persist:text:${i}`,classification:'text',enabled:true,userConfirmed:true,
    }))]]));
    const storage = await runtime.load('src/storage.js');
    const picker = await runtime.load('src/picker.js');
    return { runtime, storage, picker, settings, store };
}
const operation = (id, preview = false) => ({batchPlanningOnly:true,batchOperation:{operationId:id,generationType:'independent',preview}});

test('recipe: text-only source survives fresh VM and does not leak into auto HTML sibling',async()=>{
    const f=await storageFixture();
    const recipes=await f.runtime.load('src/blacklist.js');
    const picked=f.picker.pickCombinationBatch({...f.settings,rabbitMirrorPresentationModes:['text','auto']},'recipe',operation('recipe'),2);
    const faces=picked.map(({combo})=>({...combo,hasExternalReferences:!!combo.textIds?.length}));
    const message={mes:'本地保存的原始正文',swipe_id:0};
    assert.equal(recipes.recordRabbitMirrorRecipe({chatKey:'recipe',messageIndex:2,message,metadata:{...faces[0],faces}}),true);
    const fresh=createRuntime(root,{store:f.store});
    const restored=await fresh.load('src/blacklist.js');
    const text=restored.getRabbitMirrorRecipe({chatKey:'recipe',messageIndex:2,message,swipeId:0,faceIndex:0,includeExternalOnly:true});
    assert.equal(text.presentationMode,'text');
    assert.deepEqual(plain(text.textIds),plain(faces[0].textIds));
    const html=restored.getRabbitMirrorRecipe({chatKey:'recipe',messageIndex:2,message,swipeId:0,faceIndex:1,includeExternalOnly:true});
    assert.ok(html);
    assert.equal(html.presentationMode,undefined);
    assert.equal(html.textIds,undefined);
    assert.equal(restored.getRabbitMirrorRecipe({chatKey:'recipe',messageIndex:2,message:{...message,mes:'重说后的其他正文'},swipeId:0,faceIndex:0,includeExternalOnly:true}),null);
});

test('proof: model attributes never establish text mode; trusted local proof does',async()=>{
    const f=await storageFixture();
    const proof=await f.runtime.load('src/multifaceProof.js');
    const root={dataset:{presentationMode:'text'},getAttribute:()=> 'text'};
    assert.equal(proof.getSanitizedRabbitMirrorFaceProof(root),null);
    assert.equal(proof.markSanitizedRabbitMirrorFace(root,{faceIndex:0,faceCount:1,origin:'follow',presentationMode:'text',textIds:['ext:persist:text:0']}),true);
    assert.equal(proof.getSanitizedRabbitMirrorFaceProof(root).presentationMode,'text');
    assert.equal(proof.clearSanitizedRabbitMirrorFaceProof(root),true);
    assert.equal(proof.getSanitizedRabbitMirrorFaceProof(root),null);
});

test('storage/nonlive: five mixed faces retain exact signatures and cached selection instead of falling back to one',async()=>{
    const f=await storageFixture();
    const context={batchIdentity:{mesid:3,swipeId:0,sourceHash:'body'}};
    const faces=f.picker.pickCombinationBatch(f.settings,'nonlive',context,5);
    assert.equal(faces.length,5);
    const pending=f.storage.readPendingComboBatch();
    assert.equal(pending.faces.length,5);
    assert.equal(pending.faces[0].presentationMode,'text');
    assert.deepEqual(plain(pending.faces[0].textIds),plain(faces[0].combo.textIds));
    assert.deepEqual(plain(f.picker.pickCombinationBatch(f.settings,'nonlive',context,5)),plain(faces));
});

test('storage/live: fresh VM recovers frozen mixed plan, commits text history once and preserves original resay',async()=>{
    const writer=await storageFixture();
    const faces=writer.picker.pickCombinationBatch(writer.settings,'live',operation('live'),5);
    const original=plain(faces.batchPlan);
    assert.equal(writer.storage.markPendingBatchAttempt(original),true);
    const reader=await storageFixture(writer.store);
    const recovered=reader.storage.findPendingComboBatchPlan(original.identity);
    assert.deepEqual(plain(recovered),original);
    const picked=reader.picker.pickCombinationBatch(reader.settings,'live',operation('live'),5);
    assert.deepEqual(plain(picked.batchPlan),original);
    const scans=original.faces.map(face=>({faceIndex:face.faceIndex,visualSignature:`face-${face.faceIndex}`}));
    assert.equal(reader.storage.commitPendingComboBatch(scans,original),true);
    const history=reader.storage.getComboHistory(10);
    assert.equal(history.length,5);
    assert.ok(Array.isArray(history[0].textIds), 'committed text history must retain text IDs');
    assert.deepEqual(plain(history[0].textIds),original.faces[0].combo.textIds);
    assert.equal(history[0].presentationMode,'text');
    const recent=reader.storage.getRecentIds(10);
    assert.deepEqual(new Set(recent.textIds),new Set(original.faces.flatMap(face=>face.combo.textIds || [])));
    assert.equal(recent.textIdHits[history[0].textIds[0]],1);
    assert.equal(history[0].texts,undefined);
    assert.equal(reader.storage.commitPendingComboBatch(scans,original),false);
    assert.equal(reader.storage.getComboHistory(10).length,5);
    const resay=reader.picker.pickCombinationForMultifaceResay({...reader.settings,rabbitMirrorPresentationModes:['html']},{faceIndex:0,faces:history});
    assert.deepEqual(plain(resay.combo.textIds),original.faces[0].combo.textIds);
    assert.equal(resay.combo.presentationMode,'text');
});

test('storage/preview: preview cannot dispatch, mode changes create a different plan, unchanged plan remains frozen',async()=>{
    const f=await storageFixture();
    const before=f.picker.pickCombinationBatch(f.settings,'preview',operation('preview',true),5);
    assert.equal(f.storage.markPendingBatchAttempt(before.batchPlan),false);
    const after=f.picker.pickCombinationBatch({...f.settings,rabbitMirrorPresentationModes:['html','text','html','text','html']},'preview',operation('preview',true),5);
    assert.notEqual(after.batchPlan.batchId,before.batchPlan.batchId);
    assert.notEqual(after.batchPlan.identity.settingsKey,before.batchPlan.identity.settingsKey);
    assert.equal(before[0].combo.presentationMode,'text');
    assert.equal(after[0].combo.presentationMode,'html');
    const again=f.picker.pickCombinationBatch(f.settings,'preview',operation('preview',true),5);
    assert.deepEqual(plain(again),plain(before));
});

test('storage/text cooldown: recorded attempts and committed history retain separate text IDs/hit counts',async()=>{
    const f=await storageFixture(createStore(),['text']);
    f.runtime.context.Math.random = () => 0;
    const first=f.picker.pickCombination(f.settings,'text-attempt-1').combo;
    const second=f.picker.pickCombination(f.settings,'text-attempt-2').combo;
    assert.notEqual(first.textIds[0],second.textIds[0]);
    const chatKey=f.storage.getCurrentChatKey();
    const attempts=f.storage.getRecentGenerationAttemptIds(chatKey);
    assert.deepEqual(new Set(attempts.textIds),new Set([...first.textIds,...second.textIds]));
    assert.equal(attempts.textIdHits[first.textIds[0]],1);
    assert.equal(attempts.formatIds.length,0);
});


test('storage/text validation: malformed text identity cannot silently lose IDs at accounting boundary', async()=>{
    const f=await storageFixture();
    const plan=f.picker.pickCombinationBatch(f.settings,'validation',operation('validation'),5).batchPlan;
    for (const patch of [{presentationMode:'html'},{presentationMode:undefined},{textIds:['builtin-id']},{textIds:['ext:persist:text:0','ext:persist:text:0']}]) {
        const combos=plain(plan.faces.map(face=>face.combo));
        Object.assign(combos[0],patch);
        assert.equal(f.storage.createPendingComboBatchPlan(combos,plan.identity),null);
    }
    assert.equal(f.store.length,0);
});

test('storage/nonlive: forced visuals stay on HTML faces without reducing configured mixed face count',async()=>{
    const f=await storageFixture();
    f.settings.forceVisualScenery=true;
    const faces=f.picker.pickCombinationBatch(f.settings,'nonlive-forced',{batchIdentity:{mesid:4,swipeId:0,sourceHash:'body'}},5);
    assert.equal(faces.length,5);
    assert.deepEqual(plain(faces.map(face=>face.combo.forcedVisualScenery)),[false,true,false,true,false]);
});

test('storage/text cooldown: Auto presentation union respects text attempts and exhausted pool reuse',async()=>{
    const f=await storageFixture(createStore(),['auto']);
    f.settings.externalWorldBookRandomEnabled=true;
    f.settings.externalWorldBookMixMode='external-only';
    f.runtime.context.Math.random=()=>0;
    const picks=Array.from({length:6},(_,i)=>f.picker.pickCombination(f.settings,`cooldown-${i}`).combo.textIds[0]);
    assert.equal(new Set(picks.slice(0,5)).size,5);
    assert.equal(picks[5],picks[0]);
    assert.equal(f.storage.getRecentGenerationAttemptIds(f.storage.getCurrentChatKey()).textIdHits[picks[0]],2);
});
