import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const read = name => readFile(new URL('../src/'+name+'.js',import.meta.url),'utf8');
const plan = await import('data:text/javascript;base64,'+Buffer.from(await read('imagePlan')).toString('base64'));
const uiSource=await read('imageUi');
const imageFailureText=new Function(uiSource.slice(uiSource.indexOf('function imageFailureText('),uiSource.indexOf('function safeImageUrl('))+';return imageFailureText;')();
const apiSource=await read('independentApi');
const planningFailure=new Function(apiSource.slice(apiSource.indexOf('function mirrorImagePlanningFailure('),apiSource.indexOf('async function requestMirrorImagePlan('))+';return mirrorImagePlanningFailure;')();

test('image diagnostics distinguish every rejected plan shape without relaxing acceptance',()=>{
 const cases=[['not JSON','PLAN_INVALID_JSON','JSON'],['[]','PLAN_INVALID_OBJECT','JSON 对象'],['{}','PLAN_MISSING_PROMPT','prompt'],['{"prompt":"x","characters":{}}','PLAN_INVALID_CHARACTERS','characters'],['{"prompt":"x","characters":[{"name":"甲"}]}','PLAN_INCOMPLETE_CHARACTER','name 或 tag']];
 for(const [value,code,reason]of cases){
  assert.throws(()=>plan.parseImagePlan(value),e=>{
   assert.equal(e.rabbitMirrorImageCode,code);const text=imageFailureText(e,'planning');
   assert.ok(text.includes(reason));assert.ok(text.includes('尚未进入柏宝绘出图'));return true;
  });
 }
 assert.throws(()=>plan.buildImagePlanningPrompt({faceText:''}),{rabbitMirrorImageCode:'PLAN_EMPTY_SOURCE'});
});
test('short image sources still build and valid existing plans retain exact content',()=>{
 for(const faceText of ['琴','07:00 投喂早饭。','Track 01：绝对焦点。'])assert.ok(plan.buildImagePlanningPrompt({faceText}).userPrompt);
 const p={prompt:'tea, window',nl:'甲在窗前喝茶',flatPrompt:'tea, window',characters:[],promptFormat:'nai5-natural'};
 assert.deepEqual(plan.parseImagePlan(JSON.stringify(p)),p);
 assert.deepEqual(plan.parseImagePlan('```json\n'+JSON.stringify(p)+'\n```'),p);
});
test('planning transport labels use existing diagnostics and keep HTTP failure details scalar',()=>{
 const cases=[[{status:401},'PLAN_AUTH'],[{status:429},'PLAN_RATE_LIMIT'],[{status:503},'PLAN_HTTP'],[{semanticFailure:'empty-content'},'PLAN_EMPTY_RESPONSE'],[{semanticFailure:'empty-stream'},'PLAN_EMPTY_RESPONSE'],[{semanticFailure:'unparsed-stream'},'PLAN_UNPARSED_STREAM'],[{semanticFailure:'error-payload'},'PLAN_UPSTREAM_ERROR'],[{transport:{failureCategory:'network'}},'PLAN_NETWORK'],[{transport:{failureCategory:'concurrency'}},'PLAN_CONCURRENCY'],[{transport:{failureCategory:'local-preflight'}},'PLAN_PREFLIGHT'],[{},'PLAN_REQUEST_FAILED']];
 for(const [d,code]of cases){const e=planningFailure(new Error('PRIVATE RESPONSE'),d);assert.equal(e.rabbitMirrorImageCode,code);const text=imageFailureText(e,'planning');assert.ok(text.includes(code));assert.ok(!text.includes('PRIVATE RESPONSE'));}
 assert.ok(imageFailureText(planningFailure(null,{status:503}),'planning').includes('HTTP 503'));
 const e=planningFailure({code:'RABBIT_MIRROR_DISPATCH_LEASE_REJECTED'},{});assert.equal(e.rabbitMirrorImageCode,'PLAN_DISPATCH_LEASE');
 assert.equal(planningFailure({rabbitMirrorImageCode:'PLAN_TARGET_CHANGED'},{}).rabbitMirrorImageCode,'PLAN_TARGET_CHANGED');
});
test('image error display never echoes arbitrary provider body code or credentials',()=>{
 const secret='SENSITIVE_KEY_AND_CHAT';
 for(const stage of ['backend','characters','planning','drawing']){
  const text=imageFailureText({message:secret,code:secret,rabbitMirrorImageCode:secret,rabbitMirrorImageHttpStatus:secret},stage);
  assert.ok(!text.includes(secret));assert.ok(text.includes('UNKNOWN'));assert.ok(text.includes('没有自动补发'));
 }
 assert.ok(!imageFailureText({rabbitMirrorImageCode:'toString'},'planning').includes('function'));
 assert.ok(!imageFailureText({code:'rate_limited'},'drawing').includes('尚未进入柏宝绘出图'));
 assert.ok(imageFailureText({code:'rate_limited'},'drawing').includes('柏宝绘报告限流'));
});
